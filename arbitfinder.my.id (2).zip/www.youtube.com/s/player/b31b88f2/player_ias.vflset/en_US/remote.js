(function(g) {
    var window = this;
    'use strict';
    var a8 = function(a) {
            g.Fp(a, "zx", Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ g.nb()).toString(36));
            return a
        },
        b8 = function(a, b, c) {
            Array.isArray(c) || (c = [String(c)]);
            g.Cga(a.B, b, c)
        },
        ayb = function(a) {
            if (a instanceof g.vt) return a;
            if ("function" == typeof a.Ak) return a.Ak(!1);
            if (g.bb(a)) {
                var b = 0,
                    c = new g.vt;
                c.next = function() {
                    for (;;) {
                        if (b >= a.length) return g.L2;
                        if (b in a) return g.wt(a[b++]);
                        b++
                    }
                };
                return c
            }
            throw Error("Not implemented");
        },
        byb = function(a, b, c) {
            if (g.bb(a)) g.cc(a, b, c);
            else
                for (a = ayb(a);;) {
                    var d = a.next();
                    if (d.done) break;
                    b.call(c, d.value, void 0, a)
                }
        },
        cyb = function(a, b) {
            var c = [];
            byb(b, function(d) {
                try {
                    var e = g.Pv.prototype.B.call(this, d, !0)
                } catch (f) {
                    if ("Storage: Invalid value was encountered" == f) return;
                    throw f;
                }
                void 0 === e ? c.push(d) : g.rla(e) && c.push(d)
            }, a);
            return c
        },
        dyb = function(a, b) {
            cyb(a, b).forEach(function(c) {
                g.Pv.prototype.remove.call(this, c)
            }, a)
        },
        eyb = function(a) {
            if (a.ma) {
                if (a.ma.locationOverrideToken) return {
                    locationOverrideToken: a.ma.locationOverrideToken
                };
                if (null != a.ma.latitudeE7 && null != a.ma.longitudeE7) return {
                    latitudeE7: a.ma.latitudeE7,
                    longitudeE7: a.ma.longitudeE7
                }
            }
            return null
        },
        fyb = function(a, b) {
            g.Gb(a, b) || a.push(b)
        },
        gyb = function(a) {
            var b = 0,
                c;
            for (c in a) b++;
            return b
        },
        hyb = function(a, b) {
            return g.kd(a, b)
        },
        iyb = function(a) {
            try {
                return g.Sa.JSON.parse(a)
            } catch (b) {}
            a = String(a);
            if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
                return eval("(" + a + ")")
            } catch (b) {}
            throw Error("Invalid JSON string: " + a);
        },
        c8 = function(a) {
            if (g.Sa.JSON) try {
                return g.Sa.JSON.parse(a)
            } catch (b) {}
            return iyb(a)
        },
        jyb = function(a) {
            if (a.Xl && "function" == typeof a.Xl) return a.Xl();
            if ("undefined" !== typeof Map && a instanceof Map || "undefined" !== typeof Set && a instanceof Set) return Array.from(a.values());
            if ("string" === typeof a) return a.split("");
            if (g.bb(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            return g.hd(a)
        },
        kyb = function(a) {
            if (a.pp && "function" == typeof a.pp) return a.pp();
            if (!a.Xl || "function" != typeof a.Xl) {
                if ("undefined" !== typeof Map && a instanceof Map) return Array.from(a.keys());
                if (!("undefined" !== typeof Set && a instanceof Set)) {
                    if (g.bb(a) || "string" === typeof a) {
                        var b = [];
                        a = a.length;
                        for (var c = 0; c < a; c++) b.push(c);
                        return b
                    }
                    return g.id(a)
                }
            }
        },
        lyb = function(a, b) {
            if (a.forEach && "function" == typeof a.forEach) a.forEach(b, void 0);
            else if (g.bb(a) || "string" === typeof a) Array.prototype.forEach.call(a, b, void 0);
            else
                for (var c = kyb(a), d = jyb(a), e = d.length, f = 0; f < e; f++) b.call(void 0, d[f], c && c[f], a)
        },
        myb = function(a, b, c, d) {
            var e = new g.xp(null);
            a && g.yp(e, a);
            b && g.zp(e, b);
            c && g.Ap(e, c);
            d && (e.C = d);
            return e
        },
        nyb = function() {
            this.j = d8();
            this.j.Bk("/client_streamz/youtube/living_room/mdx/channel/opened", {
                Xe: 3,
                We: "channel_type"
            })
        },
        oyb = function(a, b) {
            a.j.Mm("/client_streamz/youtube/living_room/mdx/channel/opened", b)
        },
        pyb = function() {
            this.j = d8();
            this.j.Bk("/client_streamz/youtube/living_room/mdx/channel/closed", {
                Xe: 3,
                We: "channel_type"
            })
        },
        qyb = function(a, b) {
            a.j.Mm("/client_streamz/youtube/living_room/mdx/channel/closed", b)
        },
        ryb = function() {
            this.j = d8();
            this.j.Bk("/client_streamz/youtube/living_room/mdx/channel/message_received", {
                Xe: 3,
                We: "channel_type"
            })
        },
        syb = function(a, b) {
            a.j.Mm("/client_streamz/youtube/living_room/mdx/channel/message_received", b)
        },
        tyb = function() {
            this.j = d8();
            this.j.Bk("/client_streamz/youtube/living_room/mdx/channel/error", {
                Xe: 3,
                We: "channel_type"
            })
        },
        uyb = function(a, b) {
            a.j.Mm("/client_streamz/youtube/living_room/mdx/channel/error", b)
        },
        vyb = function() {
            this.j = d8();
            this.j.Bk("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps")
        },
        wyb = function() {
            this.j = d8();
            this.j.Bk("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps")
        },
        Ayb = function(a) {
            this.name = this.id = "";
            this.clientName = "UNKNOWN_INTERFACE";
            this.app = "";
            this.type = "REMOTE_CONTROL";
            this.obfuscatedGaiaId = this.avatar = this.username = "";
            this.capabilities = new Set;
            this.compatibleSenderThemes = new Set;
            this.experiments = new Set;
            this.theme = "u";
            new g.xv;
            this.model = this.brand = "";
            this.year = 0;
            this.chipset = this.osVersion = this.os = "";
            this.mdxDialServerType = "MDX_DIAL_SERVER_TYPE_UNKNOWN";
            a && (this.id = a.id || a.name, this.name = a.name, this.clientName = a.clientName ? a.clientName.toUpperCase() : "UNKNOWN_INTERFACE", this.app = a.app, this.type =
                a.type || "REMOTE_CONTROL", this.username = a.user || "", this.avatar = a.userAvatarUri || "", this.obfuscatedGaiaId = a.obfuscatedGaiaId || "", this.theme = a.theme || "u", xyb(this, a.capabilities || ""), yyb(this, a.compatibleSenderThemes || ""), zyb(this, a.experiments || ""), this.brand = a.brand || "", this.model = a.model || "", this.year = a.year || 0, this.os = a.os || "", this.osVersion = a.osVersion || "", this.chipset = a.chipset || "", this.mdxDialServerType = a.mdxDialServerType || "MDX_DIAL_SERVER_TYPE_UNKNOWN", a = a.deviceInfo) && (a = JSON.parse(a), this.brand =
                a.brand || "", this.model = a.model || "", this.year = a.year || 0, this.os = a.os || "", this.osVersion = a.osVersion || "", this.chipset = a.chipset || "", this.clientName = a.clientName ? a.clientName.toUpperCase() : "UNKNOWN_INTERFACE", this.mdxDialServerType = a.mdxDialServerType || "MDX_DIAL_SERVER_TYPE_UNKNOWN")
        },
        xyb = function(a, b) {
            a.capabilities.clear();
            g.Bt(b.split(","), g.kb(hyb, Byb)).forEach(function(c) {
                a.capabilities.add(c)
            })
        },
        yyb = function(a, b) {
            a.compatibleSenderThemes.clear();
            g.Bt(b.split(","), g.kb(hyb, Cyb)).forEach(function(c) {
                a.compatibleSenderThemes.add(c)
            })
        },
        zyb = function(a, b) {
            a.experiments.clear();
            b.split(",").forEach(function(c) {
                a.experiments.add(c)
            })
        },
        e8 = function(a) {
            a = a || {};
            this.name = a.name || "";
            this.id = a.id || a.screenId || "";
            this.token = a.token || a.loungeToken || "";
            this.uuid = a.uuid || a.dialId || "";
            this.idType = a.screenIdType || "normal"
        },
        f8 = function(a, b) {
            return !!b && (a.id == b || a.uuid == b)
        },
        Dyb = function(a) {
            return {
                name: a.name,
                screenId: a.id,
                loungeToken: a.token,
                dialId: a.uuid,
                screenIdType: a.idType
            }
        },
        Eyb = function(a) {
            return new e8(a)
        },
        Fyb = function(a) {
            return Array.isArray(a) ? g.Nr(a, Eyb) : []
        },
        g8 = function(a) {
            return a ? '{name:"' + a.name + '",id:' + a.id.substr(0, 6) + "..,token:" + ((a.token ? ".." + a.token.slice(-6) : "-") + ",uuid:" + (a.uuid ? ".." + a.uuid.slice(-6) : "-") + ",idType:" + a.idType + "}") : "null"
        },
        Gyb = function(a) {
            return Array.isArray(a) ? "[" + g.Nr(a, g8).join(",") + "]" : "null"
        },
        Hyb = function() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,
                function(a) {
                    var b = 16 * Math.random() | 0;
                    return ("x" == a ? b : b & 3 | 8).toString(16)
                })
        },
        Iyb = function(a) {
            return g.Nr(a, function(b) {
                return {
                    key: b.id,
                    name: b.name
                }
            })
        },
        Jyb = function(a, b) {
            return g.Db(a, function(c) {
                return c || b ? !c != !b ? !1 : c.id == b.id : !0
            })
        },
        h8 = function(a, b) {
            return g.Db(a, function(c) {
                return f8(c, b)
            })
        },
        Kyb = function() {
            var a = (0, g.nD)();
            a && dyb(a, a.j.Ak(!0))
        },
        i8 = function() {
            var a = g.pD("yt-remote-connected-devices") || [];
            g.Yb(a);
            return a
        },
        Lyb = function(a) {
            if (0 == a.length) return [];
            var b = a[0].indexOf("#"),
                c = -1 == b ? a[0] : a[0].substring(0, b);
            return g.Nr(a, function(d, e) {
                return 0 == e ? d : d.substring(c.length)
            })
        },
        Myb = function(a) {
            g.oD("yt-remote-connected-devices", a, 86400)
        },
        j8 = function() {
            if (Nyb) return Nyb;
            var a = g.pD("yt-remote-device-id");
            a || (a = Hyb(), g.oD("yt-remote-device-id", a, 31536E3));
            for (var b = i8(), c = 1, d = a; g.Gb(b, d);) c++, d = a + "#" + c;
            return Nyb = d
        },
        Oyb = function() {
            var a = i8(),
                b = j8();
            g.rD() && g.$b(a, b);
            a = Lyb(a);
            if (0 == a.length) try {
                g.Moa("remote_sid")
            } catch (c) {} else try {
                g.GC("remote_sid", a.join(","), -1)
            } catch (c) {}
        },
        Pyb = function() {
            return g.pD("yt-remote-session-browser-channel")
        },
        Qyb = function() {
            return g.pD("yt-remote-local-screens") || []
        },
        Ryb = function() {
            g.oD("yt-remote-lounge-token-expiration", !0, 86400)
        },
        Syb = function(a) {
            5 < a.length && (a = a.slice(a.length - 5));
            var b = g.Nr(Qyb(), function(d) {
                    return d.loungeToken
                }),
                c = g.Nr(a, function(d) {
                    return d.loungeToken
                });
            g.Or(c, function(d) {
                return !g.Gb(b, d)
            }) && Ryb();
            g.oD("yt-remote-local-screens", a, 31536E3)
        },
        k8 = function(a) {
            a || (g.qD("yt-remote-session-screen-id"), g.qD("yt-remote-session-video-id"));
            Oyb();
            a = i8();
            g.Ib(a, j8());
            Myb(a)
        },
        Tyb = function() {
            if (!l8) {
                var a = g.Zv();
                a && (l8 = new g.Mv(a))
            }
        },
        Uyb = function() {
            Tyb();
            return l8 ? !!l8.get("yt-remote-use-staging-server") : !1
        },
        m8 = function(a, b) {
            g.bF[a] = !0;
            var c = g.$E();
            c && c.publish.apply(c, arguments);
            g.bF[a] = !1
        },
        Vyb = function() {},
        d8 = function() {
            if (!n8) {
                n8 = new g.ng(new Vyb);
                var a = g.cC("client_streamz_web_flush_count", -1); - 1 !== a && (n8.D = a)
            }
            return n8
        },
        Wyb = function() {
            var a = window.navigator.userAgent.match(/Chrome\/([0-9]+)/);
            return a ? parseInt(a[1], 10) : 0
        },
        Xyb = function(a) {
            return !!document.currentScript && (-1 != document.currentScript.src.indexOf("?" + a) || -1 != document.currentScript.src.indexOf("&" + a))
        },
        Yyb = function() {
            return "function" == typeof window.__onGCastApiAvailable ? window.__onGCastApiAvailable : null
        },
        o8 = function(a) {
            a.length ? Zyb(a.shift(), function() {
                o8(a)
            }) : $yb()
        },
        azb = function(a) {
            return "chrome-extension://" + a + "/cast_sender.js"
        },
        Zyb = function(a, b, c) {
            var d = document.createElement("script");
            d.onerror = b;
            c && (d.onload = c);
            g.ro(d, g.Nw(a));
            (document.head || document.documentElement).appendChild(d)
        },
        bzb = function() {
            var a = Wyb(),
                b = [];
            if (1 < a) {
                var c = a - 1;
                b.push("//www.gstatic.com/eureka/clank/" + a + "/cast_sender.js");
                b.push("//www.gstatic.com/eureka/clank/" + c + "/cast_sender.js")
            }
            return b
        },
        $yb = function() {
            var a = Yyb();
            a && a(!1, "No cast extension found")
        },
        dzb = function() {
            if (czb) {
                var a = 2,
                    b = Yyb(),
                    c = function() {
                        a--;
                        0 == a && b && b(!0)
                    };
                window.__onGCastApiAvailable = c;
                Zyb("//www.gstatic.com/cast/sdk/libs/sender/1.0/cast_framework.js", $yb, c)
            }
        },
        ezb = function() {
            dzb();
            var a = bzb();
            a.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            o8(a)
        },
        gzb = function() {
            dzb();
            var a = bzb();
            a.push.apply(a, g.pa(fzb.map(azb)));
            a.push("//www.gstatic.com/eureka/clank/cast_sender.js");
            o8(a)
        },
        p8 = function(a, b, c) {
            g.I.call(this);
            this.K = null != c ? (0, g.jb)(a, c) : a;
            this.Yi = b;
            this.G = (0, g.jb)(this.B2, this);
            this.j = !1;
            this.B = 0;
            this.C = this.jd = null;
            this.D = []
        },
        q8 = function(a, b, c) {
            g.I.call(this);
            this.D = null != c ? a.bind(c) : a;
            this.Yi = b;
            this.C = null;
            this.j = !1;
            this.B = 0;
            this.jd = null
        },
        hzb = function(a) {
            a.jd = g.gg(function() {
                a.jd = null;
                a.j && !a.B && (a.j = !1, hzb(a))
            }, a.Yi);
            var b = a.C;
            a.C = null;
            a.D.apply(null, b)
        },
        r8 = function() {},
        izb = function() {
            g.Ab.call(this, "p")
        },
        jzb = function() {
            g.Ab.call(this, "o")
        },
        lzb = function() {
            return kzb = kzb || new g.Kd
        },
        mzb = function(a) {
            g.Ab.call(this, "serverreachability", a)
        },
        s8 = function(a) {
            var b = lzb();
            b.dispatchEvent(new mzb(b, a))
        },
        nzb = function(a) {
            g.Ab.call(this, "statevent", a)
        },
        t8 = function(a) {
            var b = lzb();
            b.dispatchEvent(new nzb(b, a))
        },
        ozb = function(a, b, c, d) {
            g.Ab.call(this, "timingevent", a);
            this.size = b;
            this.retries = d
        },
        u8 = function(a, b) {
            if ("function" !== typeof a) throw Error("Fn must not be null and must be a function");
            return g.Sa.setTimeout(function() {
                a()
            }, b)
        },
        v8 = function() {},
        w8 = function(a, b, c, d) {
            this.G = a;
            this.D = b;
            this.Jc = c;
            this.ac = d || 1;
            this.bb = new g.Kp(this);
            this.ub = 45E3;
            a = g.LS ? 125 : void 0;
            this.ib = new g.fg(a);
            this.Na = null;
            this.C = !1;
            this.X = this.Za = this.Z = this.Ta = this.Ba = this.Jb = this.ma = null;
            this.ra = [];
            this.j = null;
            this.K = 0;
            this.N = this.Ea = null;
            this.zb = -1;
            this.La = !1;
            this.qb = 0;
            this.Xa = null;
            this.Zb = this.Ua = this.Rb = this.Ga = !1;
            this.B = new pzb
        },
        pzb = function() {
            this.C = null;
            this.j = "";
            this.B = !1
        },
        rzb = function(a, b, c) {
            a.Ta = 1;
            a.Z = a8(b.clone());
            a.X = c;
            a.Ga = !0;
            qzb(a, null)
        },
        qzb = function(a, b) {
            a.Ba = Date.now();
            x8(a);
            a.Za = a.Z.clone();
            b8(a.Za, "t", a.ac);
            a.K = 0;
            var c = a.G.Ta;
            a.B = new pzb;
            a.j = szb(a.G, c ? b : null, !a.X);
            0 < a.qb && (a.Xa = new q8((0, g.jb)(a.RS, a, a.j), a.qb));
            a.bb.Qa(a.j, "readystatechange", a.E2);
            b = a.Na ? g.qd(a.Na) : {};
            a.X ? (a.Ea || (a.Ea = "POST"), b["Content-Type"] = "application/x-www-form-urlencoded", a.j.send(a.Za, a.Ea, a.X, b)) : (a.Ea = "GET", a.j.send(a.Za, a.Ea, null, b));
            s8(1)
        },
        tzb = function(a) {
            return a.j ? "GET" == a.Ea && 2 != a.Ta && a.G.Af : !1
        },
        yzb = function(a, b, c) {
            for (var d = !0, e; !a.La && a.K < c.length;)
                if (e = uzb(a, c), e == vzb) {
                    4 == b &&
                        (a.N = 4, t8(14), d = !1);
                    break
                } else if (e == wzb) {
                a.N = 4;
                t8(15);
                d = !1;
                break
            } else xzb(a, e);
            tzb(a) && 0 != a.K && (a.B.j = a.B.j.slice(a.K), a.K = 0);
            4 != b || 0 != c.length || a.B.B || (a.N = 1, t8(16), d = !1);
            a.C = a.C && d;
            d ? 0 < c.length && !a.Zb && (a.Zb = !0, a.G.SP(a)) : (y8(a), z8(a))
        },
        uzb = function(a, b) {
            var c = a.K,
                d = b.indexOf("\n", c);
            if (-1 == d) return vzb;
            c = Number(b.substring(c, d));
            if (isNaN(c)) return wzb;
            d += 1;
            if (d + c > b.length) return vzb;
            b = b.slice(d, d + c);
            a.K = d + c;
            return b
        },
        x8 = function(a) {
            a.Jb = Date.now() + a.ub;
            zzb(a, a.ub)
        },
        zzb = function(a, b) {
            if (null != a.ma) throw Error("WatchDog timer not null");
            a.ma = u8((0, g.jb)(a.C2, a), b)
        },
        A8 = function(a) {
            a.ma && (g.Sa.clearTimeout(a.ma), a.ma = null)
        },
        z8 = function(a) {
            a.G.Ng() || a.La || Azb(a.G, a)
        },
        y8 = function(a) {
            A8(a);
            g.vb(a.Xa);
            a.Xa = null;
            a.ib.stop();
            a.bb.Jf();
            if (a.j) {
                var b = a.j;
                a.j = null;
                b.abort();
                b.dispose()
            }
        },
        xzb = function(a, b) {
            try {
                var c = a.G;
                if (0 != c.Fh && (c.j == a || Bzb(c.B, a)))
                    if (!a.Ua && Bzb(c.B, a) && 3 == c.Fh) {
                        try {
                            var d = c.Bf.j.parse(b)
                        } catch (x) {
                            d = null
                        }
                        if (Array.isArray(d) && 3 == d.length) {
                            var e = d;
                            if (0 == e[0]) a: {
                                if (!c.Z) {
                                    if (c.j)
                                        if (c.j.Ba + 3E3 < a.Ba) B8(c), C8(c);
                                        else break a;
                                    Czb(c);
                                    t8(18)
                                }
                            }
                            else c.Xd = e[1], 0 < c.Xd - c.Xa && 37500 > e[2] && c.Ua && 0 == c.ra && !c.ma && (c.ma = u8((0, g.jb)(c.F2, c), 6E3));
                            if (1 >= Dzb(c.B) && c.kd) {
                                try {
                                    c.kd()
                                } catch (x) {}
                                c.kd = void 0
                            }
                        } else D8(c, 11)
                    } else if ((a.Ua || c.j == a) && B8(c), !g.hc(b))
                    for (e = c.Bf.j.parse(b), b = 0; b < e.length; b++) {
                        var f = e[b];
                        c.Xa = f[0];
                        f = f[1];
                        if (2 == c.Fh)
                            if ("c" == f[0]) {
                                c.D = f[1];
                                c.Zb = f[2];
                                var h = f[3];
                                null != h && (c.SS = h);
                                var l = f[5];
                                null != l && "number" === typeof l && 0 < l && (c.bb = 1.5 * l);
                                d = c;
                                var m = a.iO();
                                if (m) {
                                    var n = g.On(m, "X-Client-Wire-Protocol");
                                    if (n) {
                                        var p = d.B;
                                        !p.j && (g.jc(n, "spdy") || g.jc(n, "quic") || g.jc(n, "h2")) && (p.D = p.G, p.j = new Set, p.B && (Ezb(p, p.B), p.B = null))
                                    }
                                    if (d.Ga) {
                                        var q = g.On(m, "X-HTTP-Session-Id");
                                        q && (d.Le = q, g.Fp(d.Na, d.Ga, q))
                                    }
                                }
                                c.Fh = 3;
                                c.G && c.G.ZS();
                                c.Mc && (c.Pd = Date.now() - a.Ba);
                                d = c;
                                var r = a;
                                d.xd = Fzb(d, d.Ta ? d.Zb : null, d.ac);
                                if (r.Ua) {
                                    Gzb(d.B,
                                        r);
                                    var t = r,
                                        v = d.bb;
                                    v && t.setTimeout(v);
                                    t.ma && (A8(t), x8(t));
                                    d.j = r
                                } else Hzb(d);
                                0 < c.C.length && E8(c)
                            } else "stop" != f[0] && "close" != f[0] || D8(c, 7);
                        else 3 == c.Fh && ("stop" == f[0] || "close" == f[0] ? "stop" == f[0] ? D8(c, 7) : c.disconnect() : "noop" != f[0] && c.G && c.G.YS(f), c.ra = 0)
                    }
                s8(4)
            } catch (x) {}
        },
        Izb = function(a, b) {
            this.j = a;
            this.map = b;
            this.context = null
        },
        Jzb = function(a) {
            this.G = a || 10;
            g.Sa.PerformanceNavigationTiming ? (a = g.Sa.performance.getEntriesByType("navigation"), a = 0 < a.length && ("hq" == a[0].nextHopProtocol || "h2" == a[0].nextHopProtocol)) : a = !!(g.Sa.chrome && g.Sa.chrome.loadTimes && g.Sa.chrome.loadTimes() && g.Sa.chrome.loadTimes().wasFetchedViaSpdy);
            this.D = a ? this.G : 1;
            this.j = null;
            1 < this.D && (this.j = new Set);
            this.B = null;
            this.C = []
        },
        Kzb = function(a) {
            return a.B ? !0 : a.j ? a.j.size >= a.D : !1
        },
        Dzb = function(a) {
            return a.B ? 1 : a.j ? a.j.size : 0
        },
        Bzb = function(a, b) {
            return a.B ? a.B == b : a.j ? a.j.has(b) : !1
        },
        Ezb =
        function(a, b) {
            a.j ? a.j.add(b) : a.B = b
        },
        Gzb = function(a, b) {
            a.B && a.B == b ? a.B = null : a.j && a.j.has(b) && a.j.delete(b)
        },
        Lzb = function(a) {
            if (null != a.B) return a.C.concat(a.B.ra);
            if (null != a.j && 0 !== a.j.size) {
                var b = a.C;
                a = g.u(a.j.values());
                for (var c = a.next(); !c.done; c = a.next()) b = b.concat(c.value.ra);
                return b
            }
            return g.Lb(a.C)
        },
        Mzb = function(a, b) {
            var c = new v8;
            if (g.Sa.Image) {
                var d = new Image;
                d.onload = g.kb(F8, c, d, "TestLoadImage: loaded", !0, b);
                d.onerror = g.kb(F8, c, d, "TestLoadImage: error", !1, b);
                d.onabort = g.kb(F8, c, d, "TestLoadImage: abort", !1, b);
                d.ontimeout = g.kb(F8, c, d, "TestLoadImage: timeout", !1, b);
                g.Sa.setTimeout(function() {
                    if (d.ontimeout) d.ontimeout()
                }, 1E4);
                d.src = a
            } else b(!1)
        },
        F8 = function(a, b, c, d, e) {
            try {
                b.onload = null, b.onerror = null, b.onabort = null, b.ontimeout = null, e(d)
            } catch (f) {}
        },
        Nzb = function() {
            this.j = new r8
        },
        Ozb = function(a, b, c) {
            var d = c || "";
            try {
                lyb(a, function(e, f) {
                    var h = e;
                    g.cb(e) && (h = g.an(e));
                    b.push(d + f + "=" + encodeURIComponent(h))
                })
            } catch (e) {
                throw b.push(d + "type=" + encodeURIComponent("_badmap")), e;
            }
        },
        G8 = function(a, b, c) {
            return c && c.R7 ? c.R7[a] || b : b
        },
        Pzb = function(a) {
            this.C = [];
            this.Zb = this.xd = this.Na = this.ac = this.j = this.Le = this.Ga = this.La = this.N = this.Jb = this.X = null;
            this.Of = this.Za = 0;
            this.Mf = G8("failFast", !1, a);
            this.Ua = this.ma = this.Z = this.K = this.G = null;
            this.Jc = !0;
            this.Xd = this.Xa = -1;
            this.Rb = this.ra = this.Ba = 0;
            this.lh = G8("baseRetryDelayMs", 5E3, a);
            this.Pf = G8("retryDelaySeedMs", 1E4, a);
            this.Nf = G8("forwardChannelMaxRetries", 2, a);
            this.Ke = G8("forwardChannelRequestTimeoutMs", 2E4, a);
            this.Ae = a && a.Anb || void 0;
            this.Af = a && a.wnb || !1;
            this.bb = void 0;
            this.Ta = a && a.sca || !1;
            this.D = "";
            this.B =
                new Jzb(a && a.Ckb);
            this.Bf = new Nzb;
            this.ub = a && a.Tkb || !1;
            this.qb = a && a.Ikb || !1;
            this.ub && this.qb && (this.qb = !1);
            this.Qf = a && a.ukb || !1;
            a && a.Vkb && (this.Jc = !1);
            this.Mc = !this.ub && this.Jc && a && a.Gkb || !1;
            this.md = void 0;
            a && a.gY && 0 < a.gY && (this.md = a.gY);
            this.kd = void 0;
            this.Pd = 0;
            this.ib = !1;
            this.zb = this.Ea = null
        },
        C8 = function(a) {
            a.j && (Qzb(a), a.j.cancel(), a.j = null)
        },
        Rzb = function(a) {
            C8(a);
            a.Z && (g.Sa.clearTimeout(a.Z), a.Z = null);
            B8(a);
            a.B.cancel();
            a.K && ("number" === typeof a.K && g.Sa.clearTimeout(a.K), a.K = null)
        },
        E8 = function(a) {
            Kzb(a.B) || a.K || (a.K = !0, g.Xf(a.VS, a), a.Ba = 0)
        },
        Tzb = function(a, b) {
            if (Dzb(a.B) >= a.B.D - (a.K ? 1 : 0)) return !1;
            if (a.K) return a.C = b.ra.concat(a.C), !0;
            if (1 == a.Fh || 2 == a.Fh || a.Ba >= (a.Mf ? 0 : a.Nf)) return !1;
            a.K = u8((0, g.jb)(a.VS, a, b), Szb(a, a.Ba));
            a.Ba++;
            return !0
        },
        Vzb = function(a, b) {
            var c;
            b ? c = b.Jc : c = a.Za++;
            var d = a.Na.clone();
            g.Fp(d, "SID", a.D);
            g.Fp(d, "RID", c);
            g.Fp(d, "AID", a.Xa);
            H8(a, d);
            a.N && a.X && g.Jp(d, a.N, a.X);
            c = new w8(a, a.D, c, a.Ba + 1);
            null === a.N && (c.Na = a.X);
            b && (a.C = b.ra.concat(a.C));
            b = Uzb(a, c, 1E3);
            c.setTimeout(Math.round(.5 * a.Ke) + Math.round(.5 * a.Ke * Math.random()));
            Ezb(a.B, c);
            rzb(c, d, b)
        },
        H8 = function(a, b) {
            a.La && g.bd(a.La, function(c, d) {
                g.Fp(b, d, c)
            });
            a.G && lyb({}, function(c, d) {
                g.Fp(b, d, c)
            })
        },
        Uzb = function(a, b, c) {
            c = Math.min(a.C.length, c);
            var d = a.G ? (0, g.jb)(a.G.G2, a.G, a) : null;
            a: for (var e = a.C, f = -1;;) {
                var h = ["count=" + c]; - 1 == f ? 0 < c ? (f = e[0].j, h.push("ofs=" + f)) : f = 0 : h.push("ofs=" + f);
                for (var l = !0, m = 0; m < c; m++) {
                    var n = e[m].j,
                        p = e[m].map;
                    n -= f;
                    if (0 > n) f = Math.max(0, e[m].j - 100), l = !1;
                    else try {
                        Ozb(p, h, "req" + n + "_")
                    } catch (q) {
                        d && d(p)
                    }
                }
                if (l) {
                    d = h.join("&");
                    break a
                }
            }
            a = a.C.splice(0, c);
            b.ra = a;
            return d
        },
        Hzb = function(a) {
            a.j || a.Z || (a.Rb = 1, g.Xf(a.US, a), a.ra = 0)
        },
        Czb = function(a) {
            if (a.j || a.Z || 3 <= a.ra) return !1;
            a.Rb++;
            a.Z = u8((0, g.jb)(a.US, a), Szb(a, a.ra));
            a.ra++;
            return !0
        },
        Qzb = function(a) {
            null != a.Ea && (g.Sa.clearTimeout(a.Ea), a.Ea = null)
        },
        Wzb = function(a) {
            a.j = new w8(a, a.D, "rpc", a.Rb);
            null === a.N && (a.j.Na = a.X);
            a.j.qb = 0;
            var b = a.xd.clone();
            g.Fp(b, "RID", "rpc");
            g.Fp(b, "SID", a.D);
            g.Fp(b, "AID", a.Xa);
            g.Fp(b, "CI", a.Ua ? "0" : "1");
            !a.Ua && a.md && g.Fp(b, "TO", a.md);
            g.Fp(b, "TYPE", "xmlhttp");
            H8(a, b);
            a.N && a.X && g.Jp(b, a.N, a.X);
            a.bb && a.j.setTimeout(a.bb);
            var c = a.j;
            a = a.Zb;
            c.Ta = 1;
            c.Z = a8(b.clone());
            c.X = null;
            c.Ga = !0;
            qzb(c, a)
        },
        B8 = function(a) {
            null != a.ma && (g.Sa.clearTimeout(a.ma), a.ma = null)
        },
        Azb = function(a, b) {
            var c = null;
            if (a.j == b) {
                B8(a);
                Qzb(a);
                a.j = null;
                var d = 2
            } else if (Bzb(a.B, b)) c = b.ra, Gzb(a.B, b), d = 1;
            else return;
            if (0 != a.Fh)
                if (b.C)
                    if (1 == d) {
                        c = b.X ? b.X.length : 0;
                        b = Date.now() - b.Ba;
                        var e = a.Ba;
                        d = lzb();
                        d.dispatchEvent(new ozb(d, c, b, e));
                        E8(a)
                    } else Hzb(a);
            else {
                var f = b.zb;
                e = b.getLastError();
                if (3 == e || 0 == e && 0 < f || !(1 == d && Tzb(a, b) || 2 == d && Czb(a))) switch (c && 0 < c.length && (b = a.B, b.C = b.C.concat(c)), e) {
                    case 1:
                        D8(a, 5);
                        break;
                    case 4:
                        D8(a, 10);
                        break;
                    case 3:
                        D8(a, 6);
                        break;
                    default:
                        D8(a, 2)
                }
            }
        },
        Szb = function(a, b) {
            var c = a.lh + Math.floor(Math.random() *
                a.Pf);
            a.isActive() || (c *= 2);
            return c * b
        },
        D8 = function(a, b) {
            if (2 == b) {
                var c = null;
                a.G && (c = null);
                var d = (0, g.jb)(a.yca, a);
                c || (c = new g.xp("//www.google.com/images/cleardot.gif"), g.Sa.location && "http" == g.Sa.location.protocol || g.yp(c, "https"), a8(c));
                Mzb(c.toString(), d)
            } else t8(2);
            a.Fh = 0;
            a.G && a.G.XS(b);
            Xzb(a);
            Rzb(a)
        },
        Xzb = function(a) {
            a.Fh = 0;
            a.zb = [];
            if (a.G) {
                var b = Lzb(a.B);
                if (0 != b.length || 0 != a.C.length) g.Nb(a.zb, b), g.Nb(a.zb, a.C), a.B.C.length = 0, g.Lb(a.C), a.C.length = 0;
                a.G.WS()
            }
        },
        Yzb = function(a) {
            if (0 == a.Fh) return a.zb;
            var b = [];
            g.Nb(b, Lzb(a.B));
            g.Nb(b, a.C);
            return b
        },
        Fzb = function(a, b, c) {
            var d = g.Gp(c);
            "" != d.j ? (b && g.zp(d, b + "." + d.j), g.Ap(d, d.D)) : (d = g.Sa.location, d = myb(d.protocol, b ? b + "." + d.hostname : d.hostname, +d.port, c));
            b = a.Ga;
            c = a.Le;
            b && c && g.Fp(d, b, c);
            g.Fp(d, "VER", a.SS);
            H8(a, d);
            return d
        },
        szb = function(a, b, c) {
            if (b && !a.Ta) throw Error("Can't create secondary domain capable XhrIo object.");
            b = a.Af && !a.Ae ? new g.en(new g.tp({
                M_: c
            })) : new g.en(a.Ae);
            b.K = a.Ta;
            return b
        },
        Zzb = function() {},
        $zb = function() {
            if (g.gf && !g.Wc(10)) throw Error("Environmental error: no available transport.");
        },
        J8 = function(a, b) {
            g.Kd.call(this);
            this.j = new Pzb(b);
            this.G = a;
            this.B = b && b.H8 || null;
            a = b && b.G8 || null;
            b && b.Akb && (a ? a["X-Client-Protocol"] = "webchannel" : a = {
                "X-Client-Protocol": "webchannel"
            });
            this.j.X = a;
            a = b && b.Vlb || null;
            b && b.oY && (a ? a["X-WebChannel-Content-Type"] = b.oY : a = {
                "X-WebChannel-Content-Type": b.oY
            });
            b && b.uV && (a ? a["X-WebChannel-Client-Profile"] = b.uV : a = {
                "X-WebChannel-Client-Profile": b.uV
            });
            this.j.Jb = a;
            (a = b && b.Ulb) && !g.hc(a) && (this.j.N = a);
            this.K = b && b.sca || !1;
            this.D = b && b.Vmb || !1;
            (b = b && b.M7) && !g.hc(b) && (this.j.Ga = b, g.jd(this.B, b) && (a = this.B,
                b in a && delete a[b]));
            this.C = new I8(this)
        },
        aAb = function(a) {
            izb.call(this);
            a.__headers__ && (this.headers = a.__headers__, this.statusCode = a.__status__, delete a.__headers__, delete a.__status__);
            var b = a.__sm__;
            b ? this.data = (this.j = g.fd(b)) ? g.od(b, this.j) : b : this.data = a
        },
        bAb = function(a) {
            jzb.call(this);
            this.status = 1;
            this.errorCode = a
        },
        I8 = function(a) {
            this.j = a
        },
        cAb = function(a, b) {
            this.B = a;
            this.j = b
        },
        dAb = function(a) {
            return Yzb(a.j).map(function(b) {
                var c = a.B;
                b = b.map;
                "__data__" in b ? (b = b.__data__, c = c.D ? iyb(b) : b) : c = b;
                return c
            })
        },
        K8 = function(a, b) {
            if ("function" !== typeof a) throw Error("Fn must not be null and must be a function");
            return g.Sa.setTimeout(function() {
                a()
            }, b)
        },
        M8 = function(a) {
            L8.dispatchEvent(new eAb(L8, a))
        },
        eAb = function(a) {
            g.Ab.call(this, "statevent", a)
        },
        N8 = function(a, b, c, d) {
            this.j = a;
            this.D = b;
            this.N = c;
            this.K = d || 1;
            this.B = 45E3;
            this.C = new g.Kp(this);
            this.G = new g.fg;
            this.G.setInterval(250)
        },
        gAb = function(a, b, c) {
            a.Cx = 1;
            a.Nr = a8(b.clone());
            a.Cu = c;
            a.Ga = !0;
            fAb(a, null)
        },
        hAb = function(a, b, c, d, e) {
            a.Cx = 1;
            a.Nr = a8(b.clone());
            a.Cu = null;
            a.Ga = c;
            e && (a.q_ = !1);
            fAb(a, d)
        },
        fAb = function(a, b) {
            a.Bx = Date.now();
            O8(a);
            a.Pr = a.Nr.clone();
            b8(a.Pr, "t", a.K);
            a.kG = 0;
            a.ij = a.j.uL(a.j.LB() ? b : null);
            0 < a.sL && (a.iG = new q8((0, g.jb)(a.aT, a, a.ij), a.sL));
            a.C.Qa(a.ij, "readystatechange", a.I2);
            b = a.Bu ? g.qd(a.Bu) : {};
            a.Cu ? (a.jG = "POST", b["Content-Type"] = "application/x-www-form-urlencoded", a.ij.send(a.Pr, a.jG, a.Cu, b)) : (a.jG = "GET", a.q_ && !g.Xc && (b.Connection = "close"), a.ij.send(a.Pr, a.jG, null, b));
            a.j.Ln(1)
        },
        kAb = function(a, b) {
            var c = a.kG,
                d = b.indexOf("\n", c);
            if (-1 == d) return iAb;
            c = Number(b.substring(c, d));
            if (isNaN(c)) return jAb;
            d += 1;
            if (d + c > b.length) return iAb;
            b = b.slice(d, d + c);
            a.kG = d + c;
            return b
        },
        mAb = function(a, b) {
            a.Bx = Date.now();
            O8(a);
            var c = b ? window.location.hostname : "";
            a.Pr = a.Nr.clone();
            g.Fp(a.Pr, "DOMAIN", c);
            g.Fp(a.Pr, "t", a.K);
            try {
                a.po = new ActiveXObject("htmlfile")
            } catch (m) {
                P8(a);
                a.Or = 7;
                M8(22);
                Q8(a);
                return
            }
            var d = "<html><body>";
            if (b) {
                var e = "";
                for (b = 0; b < c.length; b++) {
                    var f = c.charAt(b);
                    if ("<" == f) f = e + "\\x3c";
                    else if (">" == f) f = e + "\\x3e";
                    else {
                        if (f in R8) f = R8[f];
                        else if (f in lAb) f = R8[f] = lAb[f];
                        else {
                            var h = f.charCodeAt(0);
                            if (31 < h && 127 > h) var l = f;
                            else {
                                if (256 > h) {
                                    if (l = "\\x", 16 > h || 256 < h) l += "0"
                                } else l = "\\u", 4096 > h && (l += "0");
                                l += h.toString(16).toUpperCase()
                            }
                            f =
                                R8[f] = l
                        }
                        f = e + f
                    }
                    e = f
                }
                d += '<script>document.domain="' + e + '"\x3c/script>'
            }
            c = g.ue(d + "</body></html>");
            a.po.open();
            a.po.write(g.te(c));
            a.po.close();
            a.po.parentWindow.m = (0, g.jb)(a.Aaa, a);
            a.po.parentWindow.d = (0, g.jb)(a.lZ, a, !0);
            a.po.parentWindow.rpcClose = (0, g.jb)(a.lZ, a, !1);
            c = a.po.createElement("DIV");
            a.po.parentWindow.document.body.appendChild(c);
            d = g.ke(a.Pr.toString()) || g.re;
            d = g.Me(g.ie(d));
            d = g.ue('<iframe src="' + d + '"></iframe>');
            g.Kba(c, d);
            a.j.Ln(1)
        },
        O8 = function(a) {
            a.tL = Date.now() + a.B;
            nAb(a, a.B)
        },
        nAb = function(a, b) {
            if (null != a.Dx) throw Error("WatchDog timer not null");
            a.Dx = K8((0, g.jb)(a.H2, a), b)
        },
        oAb = function(a) {
            a.Dx && (g.Sa.clearTimeout(a.Dx), a.Dx = null)
        },
        Q8 = function(a) {
            a.j.Ng() || a.Au || a.j.lG(a)
        },
        P8 = function(a) {
            oAb(a);
            g.vb(a.iG);
            a.iG = null;
            a.G.stop();
            a.C.Jf();
            if (a.ij) {
                var b = a.ij;
                a.ij = null;
                b.abort();
                b.dispose()
            }
            a.po && (a.po = null)
        },
        pAb = function(a, b) {
            try {
                a.j.bT(a, b), a.j.Ln(4)
            } catch (c) {}
        },
        rAb = function(a, b, c, d, e) {
            if (0 == d) c(!1);
            else {
                var f = e || 0;
                d--;
                qAb(a, b, function(h) {
                    h ? c(!0) : g.Sa.setTimeout(function() {
                        rAb(a, b, c, d, f)
                    }, f)
                })
            }
        },
        qAb = function(a, b, c) {
            var d = new Image;
            d.onload = function() {
                try {
                    S8(d), c(!0)
                } catch (e) {}
            };
            d.onerror = function() {
                try {
                    S8(d), c(!1)
                } catch (e) {}
            };
            d.onabort = function() {
                try {
                    S8(d), c(!1)
                } catch (e) {}
            };
            d.ontimeout = function() {
                try {
                    S8(d), c(!1)
                } catch (e) {}
            };
            g.Sa.setTimeout(function() {
                if (d.ontimeout) d.ontimeout()
            }, b);
            d.src = a
        },
        S8 = function(a) {
            a.onload = null;
            a.onerror = null;
            a.onabort = null;
            a.ontimeout = null
        },
        sAb = function(a) {
            this.j = a;
            this.B = new r8
        },
        tAb = function(a) {
            var b = T8(a.j, a.uC, "/mail/images/cleardot.gif");
            a8(b);
            rAb(b.toString(), 5E3, (0, g.jb)(a.r5, a), 3, 2E3);
            a.Ln(1)
        },
        uAb = function(a) {
            var b = a.j.K;
            if (null != b) M8(5), b ? (M8(11), U8(a.j, a, !1)) : (M8(12), U8(a.j, a, !0));
            else if (a.Jj = new N8(a), a.Jj.Bu = a.vL, b = a.j, b = T8(b, b.LB() ? a.KB : null, a.wL), M8(5), !g.gf || g.Wc(10)) b8(b, "TYPE", "xmlhttp"), hAb(a.Jj, b, !1, a.KB, !1);
            else {
                b8(b, "TYPE", "html");
                var c = a.Jj;
                a = !!a.KB;
                c.Cx = 3;
                c.Nr = a8(b.clone());
                mAb(c, a)
            }
        },
        vAb = function(a, b, c) {
            this.j = 1;
            this.B = [];
            this.C = [];
            this.G = new r8;
            this.X = a || null;
            this.K = null != b ? b : null;
            this.Z = c || !1
        },
        wAb = function(a, b) {
            this.j = a;
            this.map = b;
            this.context = null
        },
        xAb = function(a, b, c, d) {
            g.Ab.call(this, "timingevent", a);
            this.size = b;
            this.retries = d
        },
        yAb = function(a) {
            g.Ab.call(this, "serverreachability", a)
        },
        AAb = function(a) {
            a.J2(1, 0);
            a.mG = T8(a, null, a.xL);
            zAb(a)
        },
        BAb = function(a) {
            a.qs && (a.qs.abort(), a.qs = null);
            a.Jg && (a.Jg.cancel(), a.Jg = null);
            a.fq && (g.Sa.clearTimeout(a.fq), a.fq = null);
            V8(a);
            a.Tj && (a.Tj.cancel(), a.Tj = null);
            a.Qr && (g.Sa.clearTimeout(a.Qr), a.Qr = null)
        },
        CAb = function(a, b) {
            if (0 == a.j) throw Error("Invalid operation: sending map when state is closed");
            a.B.push(new wAb(a.K2++, b));
            2 != a.j && 3 != a.j || zAb(a)
        },
        DAb = function(a) {
            var b = 0;
            a.Jg && b++;
            a.Tj && b++;
            return b
        },
        zAb = function(a) {
            a.Tj || a.Qr || (a.Qr = K8((0, g.jb)(a.fT, a), 0), a.Fx = 0)
        },
        GAb = function(a, b) {
            if (1 == a.j) {
                if (!b) {
                    a.NB = Math.floor(1E5 * Math.random());
                    b = a.NB++;
                    var c = new N8(a, "", b);
                    c.Bu = a.Do;
                    var d = EAb(a),
                        e = a.mG.clone();
                    g.Fp(e, "RID", b);
                    g.Fp(e, "CVER", "1");
                    W8(a, e);
                    gAb(c, e, d);
                    a.Tj = c;
                    a.j = 2
                }
            } else 3 == a.j && (b ? FAb(a, b) : 0 == a.B.length || a.Tj || FAb(a))
        },
        FAb = function(a, b) {
            if (b)
                if (6 < a.Du) {
                    a.B = a.C.concat(a.B);
                    a.C.length = 0;
                    var c = a.NB - 1;
                    b = EAb(a)
                } else c = b.N, b = b.Cu;
            else c = a.NB++, b = EAb(a);
            var d = a.mG.clone();
            g.Fp(d, "SID", a.D);
            g.Fp(d, "RID", c);
            g.Fp(d, "AID", a.Gx);
            W8(a, d);
            c = new N8(a, a.D, c, a.Fx + 1);
            c.Bu = a.Do;
            c.setTimeout(1E4 + Math.round(1E4 * Math.random()));
            a.Tj = c;
            gAb(c, d, b)
        },
        W8 = function(a, b) {
            a.Ni && (a = a.Ni.jT()) && g.bd(a, function(c, d) {
                g.Fp(b, d, c)
            })
        },
        EAb = function(a) {
            var b = Math.min(a.B.length, 1E3),
                c = ["count=" + b];
            if (6 < a.Du && 0 < b) {
                var d = a.B[0].j;
                c.push("ofs=" + d)
            } else d = 0;
            for (var e = {}, f = 0; f < b; e = {
                    dE: void 0
                }, f++) {
                e.dE = a.B[f].j;
                var h = a.B[f].map;
                e.dE = 6 >= a.Du ? f : e.dE - d;
                try {
                    g.bd(h, function(l) {
                        return function(m, n) {
                            c.push("req" + l.dE + "_" + n + "=" + encodeURIComponent(m))
                        }
                    }(e))
                } catch (l) {
                    c.push("req" + e.dE + "_type=" + encodeURIComponent("_badmap"))
                }
            }
            a.C = a.C.concat(a.B.splice(0, b));
            return c.join("&")
        },
        HAb = function(a) {
            a.Jg || a.fq || (a.N = 1, a.fq = K8((0, g.jb)(a.eT, a), 0), a.Ex = 0)
        },
        JAb = function(a) {
            if (a.Jg || a.fq || 3 <= a.Ex) return !1;
            a.N++;
            a.fq = K8((0, g.jb)(a.eT, a), IAb(a, a.Ex));
            a.Ex++;
            return !0
        },
        U8 = function(a, b, c) {
            a.RK = null == a.K ? c : !a.K;
            a.Eo = b.eq;
            a.Z || AAb(a)
        },
        V8 = function(a) {
            null != a.Eu && (g.Sa.clearTimeout(a.Eu), a.Eu = null)
        },
        IAb = function(a, b) {
            var c = 5E3 + Math.floor(1E4 * Math.random());
            a.isActive() || (c *= 2);
            return c * b
        },
        X8 = function(a, b) {
            if (2 == b || 9 == b) {
                var c = null;
                a.Ni && (c = null);
                var d = (0, g.jb)(a.xca, a);
                c || (c = new g.xp("//www.google.com/images/cleardot.gif"), a8(c));
                qAb(c.toString(), 1E4, d)
            } else M8(2);
            KAb(a, b)
        },
        KAb = function(a, b) {
            a.j = 0;
            a.Ni && a.Ni.gT(b);
            LAb(a);
            BAb(a)
        },
        LAb = function(a) {
            a.j = 0;
            a.Eo = -1;
            if (a.Ni)
                if (0 == a.C.length && 0 == a.B.length) a.Ni.yL();
                else {
                    var b = g.Lb(a.C),
                        c = g.Lb(a.B);
                    a.C.length = 0;
                    a.B.length = 0;
                    a.Ni.yL(b, c)
                }
        },
        T8 = function(a, b, c) {
            var d = g.Gp(c);
            if ("" != d.j) b && g.zp(d, b + "." + d.j), g.Ap(d, d.D);
            else {
                var e = window.location;
                d = myb(e.protocol, b ? b + "." + e.hostname : e.hostname, +e.port, c)
            }
            a.MB && g.bd(a.MB, function(f, h) {
                g.Fp(d, h, f)
            });
            g.Fp(d, "VER", a.Du);
            W8(a, d);
            return d
        },
        MAb = function() {},
        NAb = function() {
            this.j = [];
            this.B = []
        },
        OAb = function(a) {
            g.Ab.call(this, "channelMessage");
            this.message = a
        },
        PAb = function(a) {
            g.Ab.call(this, "channelError");
            this.error = a
        },
        QAb = function(a, b) {
            this.action = a;
            this.params = b || {}
        },
        Y8 = function(a, b) {
            g.I.call(this);
            this.j = new g.fv(this.saa, 0, this);
            g.M(this, this.j);
            this.Yi = 5E3;
            this.B = 0;
            if ("function" === typeof a) b && (a = (0, g.jb)(a, b));
            else if (a && "function" === typeof a.handleEvent) a = (0, g.jb)(a.handleEvent, a);
            else throw Error("Invalid listener argument");
            this.C = a
        },
        RAb = function(a, b, c, d, e) {
            c = void 0 === c ? !1 : c;
            d = void 0 === d ? function() {
                return ""
            } : d;
            e = void 0 === e ? !1 : e;
            this.Ba = a;
            this.N = b;
            this.C = new g.Lv;
            this.B = new Y8(this.Lba, this);
            this.j = null;
            this.ma = !1;
            this.K = null;
            this.X = "";
            this.Z = this.G = 0;
            this.D = [];
            this.Ta = c;
            this.ra = d;
            this.Ua = e;
            this.Na = new nyb;
            this.Ea = new pyb;
            this.La = new ryb;
            this.Ga = new tyb;
            this.Xa = new vyb;
            this.Za = new wyb
        },
        SAb = function(a) {
            if (a.j) {
                var b = a.ra(),
                    c = a.j.Do || {};
                b ? c["x-youtube-lounge-xsrf-token"] = b : delete c["x-youtube-lounge-xsrf-token"];
                a.j.Do = c
            }
        },
        Z8 = function(a) {
            this.scheme = "https";
            this.port = this.domain = "";
            this.j = "/api/lounge";
            this.B = !0;
            a = a || document.location.href;
            var b = Number(g.Ul(4, a)) || "";
            b && (this.port = ":" + b);
            this.domain = g.Vl(a) || "";
            a = g.pc();
            0 <= a.search("MSIE") && (a = a.match(/MSIE ([\d.]+)/)[1], 0 > g.oc(a, "10.0") && (this.B = !1))
        },
        $8 = function(a, b) {
            var c = a.j;
            a.B && (c = a.scheme + "://" + a.domain + a.port + a.j);
            return g.Fm(c + b, {})
        },
        TAb = function(a, b, c, d, e) {
            a = {
                format: "JSON",
                method: "POST",
                context: a,
                timeout: 5E3,
                withCredentials: !1,
                onSuccess: g.kb(a.D, d, !0),
                onError: g.kb(a.C, e),
                onTimeout: g.kb(a.G, e)
            };
            c && (a.postParams = c, a.headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            });
            return g.xC(b, a)
        },
        UAb = function(a, b) {
            g.Kd.call(this);
            var c = this;
            this.Ed = a();
            this.Ed.subscribe("handlerOpened", this.O2, this);
            this.Ed.subscribe("handlerClosed", this.M2, this);
            this.Ed.subscribe("handlerError", function(d, e) {
                c.onError(e)
            });
            this.Ed.subscribe("handlerMessage", this.N2, this);
            this.j = b
        },
        VAb = function(a, b, c) {
            var d = this;
            c = void 0 === c ? function() {
                return ""
            } : c;
            var e = void 0 === e ? new $zb : e;
            var f = void 0 === f ? new g.Lv : f;
            this.pathPrefix = a;
            this.j = b;
            this.Ba = c;
            this.G = f;
            this.Z = null;
            this.X = this.N = 0;
            this.channel = null;
            this.K = 0;
            this.C = new Y8(function() {
                d.C.isActive();
                var h;
                0 === (null == (h = d.channel) ? void 0 : Dzb((new cAb(h, h.j)).j.B)) && d.connect(d.Z, d.N)
            });
            this.D = {};
            this.B = {};
            this.ma = !1;
            this.logger = null;
            this.ra = [];
            this.Cg = void 0;
            this.Na = new nyb;
            this.Ea = new pyb;
            this.La = new ryb;
            this.Ga = new tyb
        },
        WAb = function(a) {
            g.Bd(a.channel, "m", function() {
                a.K = 3;
                a.C.reset();
                a.Z = null;
                a.N = 0;
                for (var b = g.u(a.ra), c = b.next(); !c.done; c = b.next()) c = c.value, a.channel && a.channel.send(c);
                a.ra = [];
                a.oa("webChannelOpened");
                oyb(a.Na, "WEB_CHANNEL")
            });
            g.Bd(a.channel, "n", function() {
                a.K = 0;
                a.C.isActive() || a.oa("webChannelClosed");
                var b, c = null == (b = a.channel) ? void 0 : dAb(new cAb(b, b.j));
                c && (a.ra = [].concat(g.pa(c)));
                qyb(a.Ea, "WEB_CHANNEL")
            });
            g.Bd(a.channel, "p", function(b) {
                var c = b.data;
                "gracefulReconnect" === c[0] ? (a.C.start(), a.channel && a.channel.close()) : a.oa("webChannelMessage", new QAb(c[0], c[1]));
                a.Cg = b.statusCode;
                syb(a.La, "WEB_CHANNEL")
            });
            g.Bd(a.channel, "o", function() {
                401 === a.Cg || a.C.start();
                a.oa("webChannelError");
                uyb(a.Ga, "WEB_CHANNEL")
            })
        },
        XAb = function(a) {
            var b = a.Ba();
            b ? a.D["x-youtube-lounge-xsrf-token"] = b : delete a.D["x-youtube-lounge-xsrf-token"]
        },
        YAb = function(a) {
            g.Kd.call(this);
            this.j = a();
            this.j.subscribe("webChannelOpened", this.R2, this);
            this.j.subscribe("webChannelClosed", this.P2, this);
            this.j.subscribe("webChannelError", this.onError, this);
            this.j.subscribe("webChannelMessage", this.Q2, this)
        },
        ZAb = function(a, b, c, d, e) {
            function f() {
                return new RAb($8(a, "/bc"), b, !1, c, d)
            }
            c = void 0 === c ? function() {
                return ""
            } : c;
            return g.bC("enable_mdx_web_channel_desktop") ? new YAb(function() {
                return new VAb($8(a, "/wc"), b, c)
            }) : new UAb(f, e)
        },
        cBb = function() {
            var a = $Ab;
            aBb();
            a9.push(a);
            bBb()
        },
        b9 = function(a, b) {
            aBb();
            var c = dBb(a, String(b));
            0 == a9.length ? eBb(c) : (bBb(), g.cc(a9, function(d) {
                d(c)
            }))
        },
        c9 = function(a) {
            b9("CP", a)
        },
        aBb = function() {
            a9 || (a9 = g.Va("yt.mdx.remote.debug.handlers_") || [], g.Ua("yt.mdx.remote.debug.handlers_", a9))
        },
        eBb = function(a) {
            var b = (d9 + 1) % 50;
            d9 = b;
            e9[b] = a;
            f9 || (f9 = 49 == b)
        },
        bBb = function() {
            var a = a9;
            if (e9[0]) {
                var b = f9 ? d9 : -1;
                do {
                    b = (b + 1) % 50;
                    var c = e9[b];
                    g.cc(a, function(d) {
                        d(c)
                    })
                } while (b != d9);
                e9 = Array(50);
                d9 = -1;
                f9 = !1
            }
        },
        dBb = function(a, b) {
            var c = (Date.now() - fBb) / 1E3;
            c.toFixed && (c = c.toFixed(3));
            var d = [];
            d.push("[", c + "s", "] ");
            d.push("[", "yt.mdx.remote", "] ");
            d.push(a + ": " + b, "\n");
            return d.join("")
        },
        g9 = function(a) {
            g.zG.call(this);
            this.K = a;
            this.screens = []
        },
        gBb = function(a, b) {
            var c = a.get(b.uuid) || a.get(b.id);
            if (c) return a = c.name, c.id = b.id || c.id, c.name = b.name, c.token = b.token, c.uuid = b.uuid || c.uuid, c.name != a;
            a.screens.push(b);
            return !0
        },
        hBb = function(a, b) {
            var c = a.screens.length != b.length;
            a.screens = g.Bt(a.screens, function(f) {
                return !!Jyb(b, f)
            });
            for (var d = 0, e = b.length; d < e; d++) c = gBb(a, b[d]) || c;
            return c
        },
        iBb = function(a, b) {
            var c = a.screens.length;
            a.screens = g.Bt(a.screens, function(d) {
                return !(d || b ? !d != !b ? 0 : d.id == b.id : 1)
            });
            return a.screens.length < c
        },
        jBb = function(a, b, c, d, e) {
            g.zG.call(this);
            this.C = a;
            this.N = b;
            this.D = c;
            this.K = d;
            this.G = e;
            this.B = 0;
            this.j = null;
            this.jd = NaN
        },
        i9 = function(a) {
            g9.call(this, "LocalScreenService");
            this.B = a;
            this.j = NaN;
            h9(this);
            this.info("Initializing with " + Gyb(this.screens))
        },
        kBb = function(a) {
            if (a.screens.length) {
                var b = g.Nr(a.screens, function(d) {
                        return d.id
                    }),
                    c = $8(a.B, "/pairing/get_lounge_token_batch");
                TAb(a.B, c, {
                    screen_ids: b.join(",")
                }, (0, g.jb)(a.k7, a), (0, g.jb)(a.j7, a))
            }
        },
        h9 = function(a) {
            if (g.bC("deprecate_pair_servlet_enabled")) return hBb(a, []);
            var b = Fyb(Qyb());
            b = g.Bt(b, function(c) {
                return !c.uuid
            });
            return hBb(a, b)
        },
        j9 = function(a, b) {
            Syb(g.Nr(a.screens, Dyb));
            b && Ryb()
        },
        mBb = function(a, b) {
            g.zG.call(this);
            this.K = b;
            b = (b = g.pD("yt-remote-online-screen-ids") || "") ? b.split(",") : [];
            for (var c = {}, d = this.K(), e = d.length, f = 0; f < e; ++f) {
                var h = d[f].id;
                c[h] = g.Gb(b, h)
            }
            this.j = c;
            this.G = a;
            this.C = this.D = NaN;
            this.B = null;
            lBb("Initialized with " + g.an(this.j))
        },
        nBb = function(a, b, c) {
            var d = $8(a.G, "/pairing/get_screen_availability");
            TAb(a.G, d, {
                lounge_token: b.token
            }, (0, g.jb)(function(e) {
                e = e.screens || [];
                for (var f = e.length, h = 0; h < f; ++h)
                    if (e[h].loungeToken == b.token) {
                        c("online" == e[h].status);
                        return
                    }
                c(!1)
            }, a), (0, g.jb)(function() {
                c(!1)
            }, a))
        },
        pBb = function(a, b) {
            a: if (gyb(b) != gyb(a.j)) var c = !1;
                else {
                    c = g.id(b);
                    for (var d = c.length, e = 0; e < d; ++e)
                        if (!a.j[c[e]]) {
                            c = !1;
                            break a
                        }
                    c = !0
                }c || (lBb("Updated online screens: " + g.an(a.j)), a.j = b, a.oa("screenChange"));oBb(a)
        },
        k9 = function(a) {
            isNaN(a.C) || g.uC(a.C);
            a.C = g.sC((0, g.jb)(a.XQ, a), 0 < a.D && a.D < g.nb() ? 2E4 : 1E4)
        },
        lBb = function(a) {
            b9("OnlineScreenService", a)
        },
        qBb = function(a) {
            var b = {};
            g.cc(a.K(), function(c) {
                c.token ? b[c.token] = c.id : this.cg("Requesting availability of screen w/o lounge token.")
            });
            return b
        },
        oBb = function(a) {
            a = g.id(g.cd(a.j, function(b) {
                return b
            }));
            g.Yb(a);
            a.length ? g.oD("yt-remote-online-screen-ids", a.join(","), 60) : g.qD("yt-remote-online-screen-ids")
        },
        l9 = function(a, b) {
            b = void 0 === b ? !1 : b;
            g9.call(this, "ScreenService");
            this.D = a;
            this.N = b;
            this.j = this.B = null;
            this.C = [];
            this.G = {};
            rBb(this)
        },
        tBb = function(a, b, c, d, e, f) {
            a.info("getAutomaticScreenByIds " + c + " / " + b);
            c || (c = a.G[b]);
            var h = a.Nk(),
                l = c ? h8(h, c) : null;
            c && (a.N || l) || (l = h8(h, b));
            if (l) {
                l.uuid = b;
                var m = m9(a, l);
                nBb(a.j, m, function(n) {
                    e(n ? m : null)
                })
            } else c ? sBb(a, c, (0, g.jb)(function(n) {
                var p = m9(this, new e8({
                    name: d,
                    screenId: c,
                    loungeToken: n,
                    dialId: b || ""
                }));
                nBb(this.j, p, function(q) {
                    e(q ? p : null)
                })
            }, a), f) : e(null)
        },
        uBb = function(a, b) {
            for (var c = a.screens.length, d = 0; d < c; ++d)
                if (a.screens[d].name == b) return a.screens[d];
            return null
        },
        vBb = function(a, b, c) {
            nBb(a.j, b, c)
        },
        sBb = function(a, b, c, d) {
            a.info("requestLoungeToken_ for " + b);
            var e = {
                postParams: {
                    screen_ids: b
                },
                method: "POST",
                context: a,
                onSuccess: function(f, h) {
                    f = h && h.screens || [];
                    f[0] && f[0].screenId == b ? c(f[0].loungeToken) : d(Error("Missing lounge token in token response"))
                },
                onError: function() {
                    d(Error("Request screen lounge token failed"))
                }
            };
            g.xC($8(a.D, "/pairing/get_lounge_token_batch"), e)
        },
        wBb = function(a) {
            a.screens = a.B.Nk();
            var b = a.G,
                c = {},
                d;
            for (d in b) c[b[d]] = d;
            b = a.screens.length;
            for (d = 0; d < b; ++d) {
                var e = a.screens[d];
                e.uuid = c[e.id] || ""
            }
            a.info("Updated manual screens: " + Gyb(a.screens))
        },
        rBb = function(a) {
            xBb(a);
            a.B = new i9(a.D);
            a.B.subscribe("screenChange", (0, g.jb)(a.u7, a));
            wBb(a);
            a.N || (a.C = Fyb(g.pD("yt-remote-automatic-screen-cache") || []));
            xBb(a);
            a.info("Initializing automatic screens: " + Gyb(a.C));
            a.j = new mBb(a.D, (0, g.jb)(a.Nk, a, !0));
            a.j.subscribe("screenChange", (0, g.jb)(function() {
                this.oa("onlineScreenChange")
            }, a))
        },
        m9 = function(a, b) {
            var c = a.get(b.id);
            c ? (c.uuid = b.uuid, b = c) : ((c = h8(a.C, b.uuid)) ? (c.id = b.id, c.token = b.token, b = c) : a.C.push(b), a.N || yBb(a));
            xBb(a);
            a.G[b.uuid] = b.id;
            g.oD("yt-remote-device-id-map", a.G, 31536E3);
            return b
        },
        yBb = function(a) {
            a = g.Bt(a.C, function(b) {
                return "shortLived" != b.idType
            });
            g.oD("yt-remote-automatic-screen-cache", g.Nr(a, Dyb))
        },
        xBb = function(a) {
            a.G = g.pD("yt-remote-device-id-map") || {}
        },
        n9 = function(a, b, c) {
            g.zG.call(this);
            this.Ga = c;
            this.D = a;
            this.B = b;
            this.j = null
        },
        o9 = function(a, b) {
            a.j = b;
            a.oa("sessionScreen", a.j)
        },
        zBb = function(a, b) {
            a.j && (a.j.token = b, m9(a.D, a.j));
            a.oa("sessionScreen", a.j)
        },
        p9 = function(a, b) {
            b9(a.Ga, b)
        },
        q9 = function(a, b, c) {
            n9.call(this, a, b, "CastSession");
            var d = this;
            this.config_ = c;
            this.C = null;
            this.ra = (0, g.jb)(this.W2, this);
            this.Ea = (0, g.jb)(this.Iaa, this);
            this.ma = g.sC(function() {
                ABb(d, null)
            }, 12E4);
            this.N = this.G = this.K = this.Z = 0;
            this.Ba = !1;
            this.X = "unknown"
        },
        CBb = function(a, b) {
            g.uC(a.N);
            a.N = 0;
            0 == b ? BBb(a) : a.N = g.sC(function() {
                BBb(a)
            }, b)
        },
        BBb = function(a) {
            DBb(a, "getLoungeToken");
            g.uC(a.G);
            a.G = g.sC(function() {
                EBb(a, null)
            }, 3E4)
        },
        DBb = function(a, b) {
            a.info("sendYoutubeMessage_: " + b + " " + g.an());
            var c = {};
            c.type = b;
            a.C ? a.C.sendMessage("urn:x-cast:com.google.youtube.mdx", c, function() {}, (0, g.jb)(function() {
                p9(this, "Failed to send message: " + b + ".")
            }, a)) : p9(a, "Sending yt message without session: " + g.an(c))
        },
        FBb = function(a, b) {
            b ? (a.info("onConnectedScreenId_: Received screenId: " + b), a.j && a.j.id == b || a.FW(b, function(c) {
                o9(a, c)
            }, function() {
                return a.Aj()
            }, 5)) : a.Aj(Error("Waiting for session status timed out."))
        },
        HBb = function(a, b, c) {
            a.info("onConnectedScreenData_: Received screenData: " + JSON.stringify(b));
            var d = new e8(b);
            GBb(a, d, function(e) {
                e ? (a.Ba = !0, m9(a.D, d), o9(a, d), a.X = "unknown", CBb(a, c)) : (g.eC(Error("CastSession, RemoteScreen from screenData: " + JSON.stringify(b) + " is not online.")), a.Aj())
            }, 5)
        },
        ABb = function(a, b) {
            g.uC(a.ma);
            a.ma = 0;
            b ? a.config_.enableCastLoungeToken && b.loungeToken ? b.deviceId ? a.j && a.j.uuid == b.deviceId || (b.loungeTokenRefreshIntervalMs ? HBb(a, {
                    name: a.B.friendlyName,
                    screenId: b.screenId,
                    loungeToken: b.loungeToken,
                    dialId: b.deviceId,
                    screenIdType: "shortLived"
                }, b.loungeTokenRefreshIntervalMs) : (g.eC(Error("No loungeTokenRefreshIntervalMs presents in mdxSessionStatusData: " + JSON.stringify(b) + ".")), FBb(a, b.screenId))) : (g.eC(Error("No device id presents in mdxSessionStatusData: " + JSON.stringify(b) + ".")), FBb(a, b.screenId)) :
                FBb(a, b.screenId) : a.Aj(Error("Waiting for session status timed out."))
        },
        EBb = function(a, b) {
            g.uC(a.G);
            a.G = 0;
            var c = null;
            if (b)
                if (b.loungeToken) {
                    var d;
                    (null == (d = a.j) ? void 0 : d.token) == b.loungeToken && (c = "staleLoungeToken")
                } else c = "missingLoungeToken";
            else c = "noLoungeTokenResponse";
            c ? (a.info("Did not receive a new lounge token in onLoungeToken_ with data: " + (JSON.stringify(b) + ", error: " + c)), a.X = c, CBb(a, 3E4)) : (zBb(a, b.loungeToken), a.Ba = !1, a.X = "unknown", CBb(a, b.loungeTokenRefreshIntervalMs))
        },
        GBb = function(a, b, c, d) {
            g.uC(a.K);
            a.K = 0;
            vBb(a.D, b, function(e) {
                e || 0 > d ? c(e) : a.K = g.sC(function() {
                    GBb(a, b, c, d - 1)
                }, 300)
            })
        },
        IBb = function(a) {
            g.uC(a.Z);
            a.Z = 0;
            g.uC(a.K);
            a.K = 0;
            g.uC(a.ma);
            a.ma = 0;
            g.uC(a.G);
            a.G = 0;
            g.uC(a.N);
            a.N = 0
        },
        r9 = function(a, b, c, d) {
            n9.call(this, a, b, "DialSession");
            this.config_ = d;
            this.C = this.Z = null;
            this.Ea = "";
            this.Ta = c;
            this.Na = null;
            this.ma = function() {};
            this.X = NaN;
            this.La = (0, g.jb)(this.X2, this);
            this.G = function() {};
            this.N = this.K = 0;
            this.ra = !1;
            this.Ba = "unknown"
        },
        s9 = function(a) {
            var b;
            return !!(a.config_.enableDialLoungeToken && (null == (b = a.C) ? 0 : b.getDialAppInfo))
        },
        JBb = function(a) {
            a.G = a.D.lT(a.Ea, a.B.label, a.B.friendlyName, s9(a), function(b, c) {
                a.G = function() {};
                a.ra = !0;
                o9(a, b);
                "shortLived" == b.idType && 0 < c && t9(a, c)
            }, function(b) {
                a.G = function() {};
                a.Aj(b)
            })
        },
        KBb = function(a) {
            var b = {};
            b.pairingCode = a.Ea;
            b.theme = a.Ta;
            Uyb() && (b.env_useStageMdx = 1);
            return g.Em(b)
        },
        LBb = function(a) {
            return new Promise(function(b) {
                a.Ea = Hyb();
                if (a.Na) {
                    var c = new chrome.cast.DialLaunchResponse(!0, KBb(a));
                    b(c);
                    JBb(a)
                } else a.ma = function() {
                    g.uC(a.X);
                    a.ma = function() {};
                    a.X = NaN;
                    var d = new chrome.cast.DialLaunchResponse(!0, KBb(a));
                    b(d);
                    JBb(a)
                }, a.X = g.sC(function() {
                    a.ma()
                }, 100)
            })
        },
        NBb = function(a, b, c) {
            a.info("initOnConnectedScreenDataPromise_: Received screenData: " + JSON.stringify(b));
            var d = new e8(b);
            return (new Promise(function(e) {
                MBb(a, d, function(f) {
                    f ? (a.ra = !0, m9(a.D, d), o9(a, d), t9(a, c)) : g.eC(Error("DialSession, RemoteScreen from screenData: " + JSON.stringify(b) + " is not online."));
                    e(f)
                }, 5)
            })).then(function(e) {
                return e ? new chrome.cast.DialLaunchResponse(!1) : LBb(a)
            })
        },
        OBb = function(a, b) {
            var c = a.Z.receiver.label,
                d = a.B.friendlyName;
            return (new Promise(function(e) {
                tBb(a.D, c, b, d, function(f) {
                    f && f.token && o9(a, f);
                    e(f)
                }, function(f) {
                    p9(a, "Failed to get DIAL screen: " + f);
                    e(null)
                })
            })).then(function(e) {
                return e && e.token ? new chrome.cast.DialLaunchResponse(!1) : LBb(a)
            })
        },
        MBb = function(a, b, c, d) {
            g.uC(a.K);
            a.K = 0;
            vBb(a.D, b, function(e) {
                e || 0 > d ? c(e) : a.K = g.sC(function() {
                    MBb(a, b, c, d - 1)
                }, 300)
            })
        },
        t9 = function(a, b) {
            a.info("getDialAppInfoWithTimeout_ " + b);
            s9(a) && (g.uC(a.N), a.N = 0, 0 == b ? PBb(a) : a.N = g.sC(function() {
                PBb(a)
            }, b))
        },
        PBb = function(a) {
            s9(a) && a.C.getDialAppInfo(function(b) {
                a.info("getDialAppInfo dialLaunchData: " + JSON.stringify(b));
                b = b.extraData || {};
                var c = null;
                if (b.loungeToken) {
                    var d;
                    (null == (d = a.j) ? void 0 : d.token) == b.loungeToken && (c = "staleLoungeToken")
                } else c = "missingLoungeToken";
                c ? (a.Ba = c, t9(a, 3E4)) : (a.ra = !1, a.Ba = "unknown", zBb(a, b.loungeToken), t9(a, b.loungeTokenRefreshIntervalMs))
            }, function(b) {
                a.info("getDialAppInfo error: " + b);
                a.Ba = "noLoungeTokenResponse";
                t9(a, 3E4)
            })
        },
        QBb = function(a) {
            g.uC(a.K);
            a.K = 0;
            g.uC(a.N);
            a.N = 0;
            a.G();
            a.G = function() {};
            g.uC(a.X)
        },
        u9 = function(a, b) {
            n9.call(this, a, b, "ManualSession");
            this.C = g.sC((0, g.jb)(this.Lz, this, null), 150)
        },
        v9 = function(a, b) {
            g.zG.call(this);
            this.config_ = b;
            this.B = a;
            this.Z = b.appId || "233637DE";
            this.D = b.theme || "cl";
            this.X = b.disableCastApi || !1;
            this.K = b.forceMirroring || !1;
            this.j = null;
            this.N = !1;
            this.C = [];
            this.G = (0, g.jb)(this.B$, this)
        },
        RBb = function(a, b) {
            return b ? g.Db(a.C, function(c) {
                return f8(b, c.label)
            }, a) : null
        },
        w9 = function(a) {
            b9("Controller", a)
        },
        $Ab = function(a) {
            window.chrome && chrome.cast && chrome.cast.logMessage && chrome.cast.logMessage(a)
        },
        x9 = function(a) {
            return a.N || !!a.C.length || !!a.j
        },
        y9 = function(a, b, c) {
            b != a.j && (g.vb(a.j), (a.j = b) ? (c ? a.oa("yt-remote-cast2-receiver-resumed",
                b.B) : a.oa("yt-remote-cast2-receiver-selected", b.B), b.subscribe("sessionScreen", (0, g.jb)(a.jZ, a, b)), b.subscribe("sessionFailed", function() {
                return SBb(a, b)
            }), b.j ? a.oa("yt-remote-cast2-session-change", b.j) : c && a.j.Lz(null)) : a.oa("yt-remote-cast2-session-change", null))
        },
        SBb = function(a, b) {
            a.j == b && a.oa("yt-remote-cast2-session-failed")
        },
        TBb = function(a) {
            var b = a.B.kT(),
                c = a.j && a.j.B;
            a = g.Nr(b, function(d) {
                c && f8(d, c.label) && (c = null);
                var e = d.uuid ? d.uuid : d.id,
                    f = RBb(this, d);
                f ? (f.label = e, f.friendlyName = d.name) : (f = new chrome.cast.Receiver(e, d.name), f.receiverType = chrome.cast.ReceiverType.CUSTOM);
                return f
            }, a);
            c && (c.receiverType != chrome.cast.ReceiverType.CUSTOM && (c = new chrome.cast.Receiver(c.label, c.friendlyName), c.receiverType = chrome.cast.ReceiverType.CUSTOM), a.push(c));
            return a
        },
        $Bb = function(a, b, c, d) {
            d.disableCastApi ? z9("Cannot initialize because disabled by Mdx config.") : UBb() ? VBb(b, d) && (WBb(!0), window.chrome && chrome.cast && chrome.cast.isAvailable ? XBb(a, c) : (window.__onGCastApiAvailable = function(e, f) {
                e ? XBb(a, c) : (A9("Failed to load cast API: " + f), YBb(!1), WBb(!1), g.qD("yt-remote-cast-available"), g.qD("yt-remote-cast-receiver"),
                    ZBb(), c(!1))
            }, d.loadCastApiSetupScript ? g.Ksa("https://www.gstatic.com/cv/js/sender/v1/cast_sender.js") : 0 <= window.navigator.userAgent.indexOf("Android") && 0 <= window.navigator.userAgent.indexOf("Chrome/") && window.navigator.presentation ? 60 <= Wyb() && ezb() : !window.chrome || !window.navigator.presentation || 0 <= window.navigator.userAgent.indexOf("Edge") ? $yb() : 89 <= Wyb() ? gzb() : (dzb(), o8(fzb.map(azb))))) : z9("Cannot initialize because not running Chrome")
        },
        ZBb = function() {
            z9("dispose");
            var a = B9();
            a && a.dispose();
            g.Ua("yt.mdx.remote.cloudview.instance_", null);
            aCb(!1);
            g.eF(bCb);
            bCb.length = 0
        },
        C9 = function() {
            return !!g.pD("yt-remote-cast-installed")
        },
        cCb = function() {
            var a = g.pD("yt-remote-cast-receiver");
            return a ? a.friendlyName : null
        },
        dCb = function() {
            z9("clearCurrentReceiver");
            g.qD("yt-remote-cast-receiver")
        },
        eCb = function() {
            return C9() ? B9() ? B9().getCastSession() : (A9("getCastSelector: Cast is not initialized."), null) : (A9("getCastSelector: Cast API is not installed!"), null)
        },
        fCb = function() {
            C9() ? B9() ? D9() ? (z9("Requesting cast selector."), B9().requestSession()) : (z9("Wait for cast API to be ready to request the session."), bCb.push(g.dF("yt-remote-cast2-api-ready", fCb))) : A9("requestCastSelector: Cast is not initialized.") : A9("requestCastSelector: Cast API is not installed!")
        },
        E9 = function(a, b) {
            D9() ? B9().setConnectedScreenStatus(a, b) : A9("setConnectedScreenStatus called before ready.")
        },
        UBb = function() {
            var a = 0 <= g.pc().search(/ (CrMo|Chrome|CriOS)\//);
            return g.jL || a
        },
        gCb = function(a, b) {
            B9().init(a, b)
        },
        VBb = function(a, b) {
            var c = !1;
            B9() || (a = new v9(a, b), a.subscribe("yt-remote-cast2-availability-change", function(d) {
                g.oD("yt-remote-cast-available", d);
                m8("yt-remote-cast2-availability-change", d)
            }), a.subscribe("yt-remote-cast2-receiver-selected", function(d) {
                z9("onReceiverSelected: " + d.friendlyName);
                g.oD("yt-remote-cast-receiver", d);
                m8("yt-remote-cast2-receiver-selected", d)
            }), a.subscribe("yt-remote-cast2-receiver-resumed", function(d) {
                z9("onReceiverResumed: " + d.friendlyName);
                g.oD("yt-remote-cast-receiver", d);
                m8("yt-remote-cast2-receiver-resumed", d)
            }), a.subscribe("yt-remote-cast2-session-change", function(d) {
                z9("onSessionChange: " + g8(d));
                d || g.qD("yt-remote-cast-receiver");
                m8("yt-remote-cast2-session-change", d)
            }), g.Ua("yt.mdx.remote.cloudview.instance_", a), c = !0);
            z9("cloudview.createSingleton_: " + c);
            return c
        },
        B9 = function() {
            return g.Va("yt.mdx.remote.cloudview.instance_")
        },
        XBb = function(a, b) {
            YBb(!0);
            WBb(!1);
            gCb(a, function(c) {
                c ? (aCb(!0), g.fF("yt-remote-cast2-api-ready")) : (A9("Failed to initialize cast API."), YBb(!1), g.qD("yt-remote-cast-available"), g.qD("yt-remote-cast-receiver"), ZBb());
                b(c)
            })
        },
        z9 = function(a) {
            b9("cloudview", a)
        },
        A9 = function(a) {
            b9("cloudview", a)
        },
        YBb = function(a) {
            z9("setCastInstalled_ " + a);
            g.oD("yt-remote-cast-installed", a)
        },
        D9 = function() {
            return !!g.Va("yt.mdx.remote.cloudview.apiReady_")
        },
        aCb = function(a) {
            z9("setApiReady_ " + a);
            g.Ua("yt.mdx.remote.cloudview.apiReady_", a)
        },
        WBb = function(a) {
            g.Ua("yt.mdx.remote.cloudview.initializing_", a)
        },
        F9 = function(a) {
            this.index = -1;
            this.videoId = this.listId = "";
            this.volume = this.playerState = -1;
            this.muted = !1;
            this.audioTrackId = null;
            this.K = this.N = 0;
            this.trackData = null;
            this.Qk = this.xp = !1;
            this.Z = this.G = this.j = this.D = 0;
            this.C = NaN;
            this.B = !1;
            this.reset(a)
        },
        hCb = function(a) {
            a.audioTrackId = null;
            a.trackData = null;
            a.playerState = -1;
            a.xp = !1;
            a.Qk = !1;
            a.N = 0;
            a.K = g.nb();
            a.D = 0;
            a.j = 0;
            a.G = 0;
            a.Z = 0;
            a.C = NaN;
            a.B = !1
        },
        G9 = function(a) {
            return a.isPlaying() ? (g.nb() - a.K) / 1E3 : 0
        },
        H9 = function(a, b) {
            a.N = b;
            a.K = g.nb()
        },
        I9 = function(a) {
            switch (a.playerState) {
                case 1:
                case 1081:
                    return (g.nb() - a.K) / 1E3 + a.N;
                case -1E3:
                    return 0
            }
            return a.N
        },
        J9 = function(a, b, c) {
            var d = a.videoId;
            a.videoId = b;
            a.index = c;
            b != d && hCb(a)
        },
        iCb = function(a) {
            var b = {};
            b.index = a.index;
            b.listId = a.listId;
            b.videoId = a.videoId;
            b.playerState = a.playerState;
            b.volume = a.volume;
            b.muted = a.muted;
            b.audioTrackId = a.audioTrackId;
            b.trackData = g.rd(a.trackData);
            b.hasPrevious = a.xp;
            b.hasNext = a.Qk;
            b.playerTime = a.N;
            b.playerTimeAt = a.K;
            b.seekableStart = a.D;
            b.seekableEnd = a.j;
            b.duration = a.G;
            b.loadedTime = a.Z;
            b.liveIngestionTime = a.C;
            return b
        },
        L9 = function(a, b) {
            g.zG.call(this);
            var c = this;
            this.C = 0;
            this.D = a;
            this.K = [];
            this.G = new NAb;
            this.B = this.j = null;
            this.X = (0, g.jb)(this.r9, this);
            this.N = (0, g.jb)(this.mE, this);
            this.Z = (0, g.jb)(this.q9, this);
            this.ma = (0, g.jb)(this.u9, this);
            var d = 0;
            a ? (d = a.getProxyState(), 3 != d && (a.subscribe("proxyStateChange", this.uR, this), jCb(this))) : d = 3;
            0 != d && (b ? this.uR(d) : g.sC(function() {
                c.uR(d)
            }, 0));
            (a = eCb()) && K9(this, a);
            this.subscribe("yt-remote-cast2-session-change", this.ma)
        },
        M9 = function(a) {
            return new F9(a.D.getPlayerContextData())
        },
        jCb = function(a) {
            g.cc("nowAutoplaying autoplayDismissed remotePlayerChange remoteQueueChange autoplayModeChange autoplayUpNext previousNextChange multiStateLoopEnabled loopModeChange".split(" "), function(b) {
                this.K.push(this.D.subscribe(b, g.kb(this.z$, b), this))
            }, a)
        },
        kCb = function(a) {
            g.cc(a.K, function(b) {
                this.D.unsubscribeByKey(b)
            }, a);
            a.K.length = 0
        },
        N9 = function(a) {
            return 1 == a.getState()
        },
        O9 = function(a, b) {
            var c = a.G;
            50 > c.j.length + c.B.length && a.G.B.push(b)
        },
        lCb = function(a, b, c) {
            var d = M9(a);
            H9(d, c); - 1E3 != d.playerState && (d.playerState = b);
            P9(a, d)
        },
        Q9 = function(a, b, c) {
            a.D.sendMessage(b, c)
        },
        P9 = function(a, b) {
            kCb(a);
            a.D.setPlayerContextData(iCb(b));
            jCb(a)
        },
        K9 = function(a, b) {
            a.B && (a.B.removeUpdateListener(a.X), a.B.removeMediaListener(a.N), a.mE(null));
            a.B = b;
            a.B && (c9("Setting cast session: " + a.B.sessionId), a.B.addUpdateListener(a.X), a.B.addMediaListener(a.N), a.B.media.length && a.mE(a.B.media[0]))
        },
        mCb = function(a) {
            var b = a.j.media,
                c = a.j.customData;
            if (b && c) {
                var d = M9(a);
                b.contentId != d.videoId && c9("Cast changing video to: " + b.contentId);
                d.videoId = b.contentId;
                d.playerState = c.playerState;
                H9(d, a.j.getEstimatedTime());
                P9(a, d)
            } else c9("No cast media video. Ignoring state update.")
        },
        R9 = function(a, b, c) {
            return (0, g.jb)(function(d) {
                this.cg("Failed to " + b + " with cast v2 channel. Error code: " + d.code);
                d.code != chrome.cast.ErrorCode.TIMEOUT && (this.cg("Retrying " + b + " using MDx browser channel."), Q9(this, b, c))
            }, a)
        },
        U9 = function(a, b, c, d) {
            d = void 0 === d ? !1 : d;
            g.zG.call(this);
            var e = this;
            this.K = NaN;
            this.Ea = !1;
            this.X = this.Z = this.ra = this.Ba = NaN;
            this.ma = [];
            this.G = this.N = this.D = this.j = this.B = null;
            this.Na = a;
            this.La = d;
            this.ma.push(g.fD(window, "beforeunload", function() {
                e.Ty(2)
            }));
            this.C = [];
            this.j = new F9;
            this.Ta = b.id;
            this.Ga = b.idType;
            this.B = ZAb(this.Na, c, this.pT, "shortLived" == this.Ga, this.Ta);
            this.B.Qa("channelOpened", function() {
                nCb(e)
            });
            this.B.Qa("channelClosed", function() {
                S9("Channel closed");
                isNaN(e.K) ? k8(!0) : k8();
                e.dispose()
            });
            this.B.Qa("channelError", function(f) {
                k8();
                isNaN(e.oD()) ? (1 == f && "shortLived" == e.Ga && e.oa("browserChannelAuthError", f), S9("Channel error: " + f + " without reconnection"), e.dispose()) : (e.Ea = !0, S9("Channel error: " + f + " with reconnection in " + e.oD() + " ms"), T9(e, 2))
            });
            this.B.Qa("channelMessage", function(f) {
                oCb(e, f)
            });
            this.B.yr(b.token);
            this.subscribe("remoteQueueChange", function() {
                var f = e.j.videoId;
                g.rD() && g.oD("yt-remote-session-video-id", f)
            })
        },
        pCb = function(a) {
            return g.Db(a.C, function(b) {
                return "LOUNGE_SCREEN" == b.type
            })
        },
        S9 = function(a) {
            b9("conn", a)
        },
        T9 = function(a, b) {
            a.oa("proxyStateChange", b)
        },
        qCb = function(a) {
            a.K = g.sC(function() {
                S9("Connecting timeout");
                a.Ty(1)
            }, 2E4)
        },
        rCb = function(a) {
            g.uC(a.K);
            a.K = NaN
        },
        sCb = function(a) {
            g.uC(a.Ba);
            a.Ba = NaN
        },
        uCb = function(a) {
            tCb(a);
            a.ra = g.sC(function() {
                V9(a, "getNowPlaying")
            }, 2E4)
        },
        tCb = function(a) {
            g.uC(a.ra);
            a.ra = NaN
        },
        nCb = function(a) {
            S9("Channel opened");
            a.Ea && (a.Ea = !1, sCb(a), a.Ba = g.sC(function() {
                S9("Timing out waiting for a screen.");
                a.Ty(1)
            }, 15E3))
        },
        wCb = function(a, b) {
            var c = null;
            if (b) {
                var d = pCb(a);
                d && (c = {
                    clientName: d.clientName,
                    deviceMake: d.brand,
                    deviceModel: d.model,
                    osVersion: d.osVersion
                })
            }
            g.Ua("yt.mdx.remote.remoteClient_", c);
            b && (rCb(a), sCb(a));
            c = a.B.Az() && isNaN(a.K);
            b == c ? b && (T9(a, 1), V9(a, "getSubtitlesTrack")) : b ? (a.yW() && a.j.reset(), T9(a, 1), V9(a, "getNowPlaying"), vCb(a)) : a.Ty(1)
        },
        xCb = function(a, b) {
            var c = b.params.videoId;
            delete b.params.videoId;
            c == a.j.videoId && (g.nd(b.params) ? a.j.trackData = null : a.j.trackData = b.params, a.oa("remotePlayerChange"))
        },
        yCb = function(a, b, c) {
            var d = b.params.videoId || b.params.video_id,
                e = parseInt(b.params.currentIndex, 10);
            a.j.listId = b.params.listId || a.j.listId;
            J9(a.j, d, e);
            a.oa("remoteQueueChange", c)
        },
        ACb = function(a, b) {
            b.params = b.params || {};
            yCb(a, b, "NOW_PLAYING_MAY_CHANGE");
            zCb(a, b);
            a.oa("autoplayDismissed")
        },
        zCb = function(a, b) {
            var c = parseInt(b.params.currentTime || b.params.current_time, 10);
            H9(a.j, isNaN(c) ? 0 : c);
            c = parseInt(b.params.state, 10);
            c = isNaN(c) ? -1 : c; - 1 == c && -1E3 == a.j.playerState && (c = -1E3);
            a.j.playerState = c;
            c = Number(b.params.loadedTime);
            a.j.Z = isNaN(c) ? 0 : c;
            a.j.ql(Number(b.params.duration));
            c = a.j;
            var d = Number(b.params.liveIngestionTime);
            c.C = d;
            c.B = isNaN(d) ? !1 : !0;
            c = a.j;
            d = Number(b.params.seekableStartTime);
            b = Number(b.params.seekableEndTime);
            c.D = isNaN(d) ? 0 : d;
            c.j = isNaN(b) ? 0 : b;
            1 == a.j.playerState ? uCb(a) : tCb(a);
            a.oa("remotePlayerChange")
        },
        BCb = function(a, b) {
            if (-1E3 != a.j.playerState) {
                var c =
                    1085;
                switch (parseInt(b.params.adState, 10)) {
                    case 1:
                        c = 1081;
                        break;
                    case 2:
                        c = 1084;
                        break;
                    case 0:
                        c = 1083
                }
                a.j.playerState = c;
                b = parseInt(b.params.currentTime, 10);
                H9(a.j, isNaN(b) ? 0 : b);
                a.oa("remotePlayerChange")
            }
        },
        CCb = function(a, b) {
            var c = "true" == b.params.muted;
            a.j.volume = parseInt(b.params.volume, 10);
            a.j.muted = c;
            a.oa("remotePlayerChange")
        },
        DCb = function(a, b) {
            a.N = b.params.videoId;
            a.oa("nowAutoplaying", parseInt(b.params.timeout, 10))
        },
        ECb = function(a, b) {
            a.N = b.params.videoId || null;
            a.oa("autoplayUpNext", a.N)
        },
        FCb = function(a, b) {
            a.G = b.params.autoplayMode;
            a.oa("autoplayModeChange", a.G);
            "DISABLED" == a.G && a.oa("autoplayDismissed")
        },
        GCb = function(a, b) {
            var c = "true" == b.params.hasNext;
            a.j.xp = "true" == b.params.hasPrevious;
            a.j.Qk = c;
            a.oa("previousNextChange")
        },
        oCb = function(a, b) {
            b = b.message;
            b.params ? S9("Received: action=" + b.action + ", params=" + g.an(b.params)) : S9("Received: action=" + b.action + " {}");
            switch (b.action) {
                case "loungeStatus":
                    b = c8(b.params.devices);
                    a.C = g.Nr(b, function(d) {
                        return new Ayb(d)
                    });
                    b = !!g.Db(a.C, function(d) {
                        return "LOUNGE_SCREEN" == d.type
                    });
                    wCb(a, b);
                    b = a.DX("mlm");
                    a.oa("multiStateLoopEnabled", b);
                    break;
                case "loungeScreenDisconnected":
                    g.Jb(a.C, function(d) {
                        return "LOUNGE_SCREEN" == d.type
                    });
                    wCb(a, !1);
                    break;
                case "remoteConnected":
                    var c = new Ayb(c8(b.params.device));
                    g.Db(a.C, function(d) {
                        return c ? d.id == c.id : !1
                    }) || fyb(a.C, c);
                    break;
                case "remoteDisconnected":
                    c = new Ayb(c8(b.params.device));
                    g.Jb(a.C, function(d) {
                        return c ? d.id == c.id : !1
                    });
                    break;
                case "gracefulDisconnect":
                    break;
                case "playlistModified":
                    yCb(a, b, "QUEUE_MODIFIED");
                    break;
                case "nowPlaying":
                    ACb(a, b);
                    break;
                case "onStateChange":
                    zCb(a, b);
                    break;
                case "onAdStateChange":
                    BCb(a, b);
                    break;
                case "onVolumeChanged":
                    CCb(a, b);
                    break;
                case "onSubtitlesTrackChanged":
                    xCb(a, b);
                    break;
                case "nowAutoplaying":
                    DCb(a, b);
                    break;
                case "autoplayDismissed":
                    a.oa("autoplayDismissed");
                    break;
                case "autoplayUpNext":
                    ECb(a, b);
                    break;
                case "onAutoplayModeChanged":
                    FCb(a, b);
                    break;
                case "onHasPreviousNextChanged":
                    GCb(a, b);
                    break;
                case "requestAssistedSignIn":
                    a.oa("assistedSignInRequested", b.params.authCode);
                    break;
                case "onLoopModeChanged":
                    a.oa("loopModeChange", b.params.loopMode);
                    break;
                default:
                    S9("Unrecognized action: " + b.action)
            }
        },
        vCb = function(a) {
            g.uC(a.X);
            a.X = g.sC(function() {
                a.Ty(1)
            }, 864E5)
        },
        V9 = function(a, b, c) {
            c ? S9("Sending: action=" + b + ", params=" + g.an(c)) : S9("Sending: action=" + b);
            a.B.sendMessage(b, c)
        },
        HCb = function(a) {
            g9.call(this, "ScreenServiceProxy");
            this.dh = a;
            this.j = [];
            this.j.push(this.dh.$_s("screenChange", (0, g.jb)(this.d3, this)));
            this.j.push(this.dh.$_s("onlineScreenChange", (0, g.jb)(this.h$, this)))
        },
        MCb = function(a, b) {
            Tyb();
            if (!l8 || !l8.get("yt-remote-disable-remote-module-for-dev")) {
                b = g.$B("MDX_CONFIG") || b;
                Kyb();
                Oyb();
                W9 || (W9 = new Z8(b ? b.loungeApiHost : void 0), Uyb() && (W9.j = "/api/loungedev"));
                X9 || (X9 = g.Va("yt.mdx.remote.deferredProxies_") || [], g.Ua("yt.mdx.remote.deferredProxies_", X9));
                ICb();
                var c = Y9();
                if (!c) {
                    var d = new l9(W9, b ? b.disableAutomaticScreenCache || !1 : !1);
                    g.Ua("yt.mdx.remote.screenService_", d);
                    c = Y9();
                    var e = {};
                    b && (e = {
                        appId: b.appId,
                        disableDial: b.disableDial,
                        theme: b.theme,
                        loadCastApiSetupScript: b.loadCastApiSetupScript,
                        disableCastApi: b.disableCastApi,
                        enableDialLoungeToken: b.enableDialLoungeToken,
                        enableCastLoungeToken: b.enableCastLoungeToken,
                        forceMirroring: b.forceMirroring
                    });
                    g.Ua("yt.mdx.remote.enableConnectWithInitialState_", b ? b.enableConnectWithInitialState || !1 : !1);
                    $Bb(a, d, function(f) {
                        f ? Z9() && E9(Z9(), "YouTube TV") : d.subscribe("onlineScreenChange", function() {
                            m8("yt-remote-receiver-availability-change")
                        })
                    }, e)
                }
                b && !g.Va("yt.mdx.remote.initialized_") && (g.Ua("yt.mdx.remote.initialized_", !0), $9("Initializing: " + g.an(b)),
                    a$.push(g.dF("yt-remote-cast2-api-ready", function() {
                        m8("yt-remote-api-ready")
                    })), a$.push(g.dF("yt-remote-cast2-availability-change", function() {
                        m8("yt-remote-receiver-availability-change")
                    })), a$.push(g.dF("yt-remote-cast2-receiver-selected", function() {
                        b$(null);
                        m8("yt-remote-auto-connect", "cast-selector-receiver")
                    })), a$.push(g.dF("yt-remote-cast2-receiver-resumed", function() {
                        m8("yt-remote-receiver-resumed", "cast-selector-receiver")
                    })), a$.push(g.dF("yt-remote-cast2-session-change", JCb)), a$.push(g.dF("yt-remote-connection-change", function(f) {
                        f ? E9(Z9(), "YouTube TV") : c$() || (E9(null, null), dCb())
                    })), a$.push(g.dF("yt-remote-cast2-session-failed", function() {
                        m8("yt-remote-connection-failed")
                    })), a = KCb(), b.isAuto && (a.id += "#dial"), e = b.capabilities || [], g.bC("desktop_enable_autoplay") &&
                    e.push("atp"), 0 < e.length && (a.capabilities = e), a.name = b.device, a.app = b.app, (b = b.theme) && (a.theme = b), $9(" -- with channel params: " + g.an(a)), a ? (g.oD("yt-remote-session-app", a.app), g.oD("yt-remote-session-name", a.name)) : (g.qD("yt-remote-session-app"), g.qD("yt-remote-session-name")), g.Ua("yt.mdx.remote.channelParams_", a), c.start(), Z9() || LCb())
            }
        },
        NCb = function() {
            var a = Y9().dh.$_gos();
            var b = d$();
            b && e$() && (Jyb(a, b) || a.push(b));
            return Iyb(a)
        },
        PCb = function() {
            var a = OCb();
            !a && C9() && cCb() && (a = {
                key: "cast-selector-receiver",
                name: cCb()
            });
            return a
        },
        OCb = function() {
            var a = NCb(),
                b = d$();
            b || (b = c$());
            return g.Db(a, function(c) {
                return b && f8(b, c.key) ? !0 : !1
            })
        },
        d$ = function() {
            var a = Z9();
            if (!a) return null;
            var b = Y9().Nk();
            return h8(b, a)
        },
        JCb = function(a) {
            $9("remote.onCastSessionChange_: " + g8(a));
            if (a) {
                var b = d$();
                if (b && b.id == a.id) {
                    if (E9(b.id, "YouTube TV"), "shortLived" == a.idType && (a = a.token)) f$ && (f$.token = a), (b = e$()) && b.yr(a)
                } else b && g$(), h$(a, 1)
            } else e$() && g$()
        },
        g$ = function() {
            D9() ? B9().stopSession() : A9("stopSession called before API ready.");
            var a = e$();
            a && (a.disconnect(1), QCb(null))
        },
        RCb = function() {
            var a = e$();
            return !!a && 3 != a.getProxyState()
        },
        $9 = function(a) {
            b9("remote", a)
        },
        Y9 = function() {
            if (!SCb) {
                var a = g.Va("yt.mdx.remote.screenService_");
                SCb = a ? new HCb(a) : null
            }
            return SCb
        },
        Z9 = function() {
            return g.Va("yt.mdx.remote.currentScreenId_")
        },
        TCb = function(a) {
            g.Ua("yt.mdx.remote.currentScreenId_", a)
        },
        UCb = function() {
            return g.Va("yt.mdx.remote.connectData_")
        },
        b$ = function(a) {
            g.Ua("yt.mdx.remote.connectData_", a)
        },
        e$ = function() {
            return g.Va("yt.mdx.remote.connection_")
        },
        QCb = function(a) {
            var b = e$();
            b$(null);
            a || TCb("");
            g.Ua("yt.mdx.remote.connection_", a);
            X9 && (g.cc(X9, function(c) {
                c(a)
            }), X9.length = 0);
            b && !a ? m8("yt-remote-connection-change", !1) : !b && a && m8("yt-remote-connection-change", !0)
        },
        c$ = function() {
            var a = g.rD();
            if (!a) return null;
            var b = Y9();
            if (!b) return null;
            b = b.Nk();
            return h8(b, a)
        },
        h$ = function(a, b) {
            Z9();
            d$() && d$();
            if (i$) f$ = a;
            else {
                TCb(a.id);
                var c = g.Va("yt.mdx.remote.enableConnectWithInitialState_") || !1;
                a = new U9(W9, a, KCb(), c);
                a.connect(b, UCb());
                a.subscribe("beforeDisconnect", function(d) {
                    m8("yt-remote-before-disconnect", d)
                });
                a.subscribe("beforeDispose", function() {
                    e$() && (e$(), QCb(null))
                });
                a.subscribe("browserChannelAuthError", function() {
                    var d = d$();
                    d && "shortLived" == d.idType && (D9() ? B9().handleBrowserChannelAuthError() : A9("refreshLoungeToken called before API ready."))
                });
                QCb(a)
            }
        },
        LCb = function() {
            var a = c$();
            a ? ($9("Resume connection to: " + g8(a)), h$(a, 0)) : (k8(), dCb(), $9("Skipping connecting because no session screen found."))
        },
        ICb = function() {
            var a = KCb();
            if (g.nd(a)) {
                a = j8();
                var b = g.pD("yt-remote-session-name") || "",
                    c = g.pD("yt-remote-session-app") || "";
                a = {
                    device: "REMOTE_CONTROL",
                    id: a,
                    name: b,
                    app: c,
                    mdxVersion: 3
                };
                a.authuser = String(g.$B("SESSION_INDEX", "0"));
                (b = g.$B("DELEGATED_SESSION_ID")) && (a.pageId = String(b));
                g.Ua("yt.mdx.remote.channelParams_", a)
            }
        },
        KCb = function() {
            return g.Va("yt.mdx.remote.channelParams_") || {}
        },
        XCb = function(a, b, c) {
            g.I.call(this);
            var d = this;
            this.module = a;
            this.J = b;
            this.Fc = c;
            this.events = new g.lL(this);
            this.X = this.events.T(this.J, "onVolumeChange", function(e) {
                VCb(d, e)
            });
            this.D = !1;
            this.G = new g.YL(64);
            this.j = new g.fv(this.I_, 500, this);
            this.B = new g.fv(this.J_, 1E3, this);
            this.N = new p8(this.Wca, 0, this);
            this.C = {};
            this.Z = new g.fv(this.B0, 1E3, this);
            this.K = new q8(this.seekTo, 1E3, this);
            g.M(this, this.events);
            this.events.T(b, "onCaptionsTrackListChanged", this.S9);
            this.events.T(b, "captionschanged", this.o9);
            this.events.T(b, "captionssettingschanged", this.R_);
            this.events.T(b, "videoplayerreset", this.xJ);
            this.events.T(b, "mdxautoplaycancel", function() {
                d.Fc.LV()
            });
            b.L("enable_mdx_video_play_directly") && this.events.T(b, "videodatachange", function() {
                WCb(d.module) || j$(d) || k$(d, 0)
            });
            a = this.Fc;
            a.isDisposed();
            a.subscribe("proxyStateChange", this.gZ, this);
            a.subscribe("remotePlayerChange", this.sE, this);
            a.subscribe("remoteQueueChange", this.xJ, this);
            a.subscribe("previousNextChange", this.dZ, this);
            a.subscribe("nowAutoplaying", this.YY, this);
            a.subscribe("autoplayDismissed", this.DY, this);
            g.M(this, this.j);
            g.M(this, this.B);
            g.M(this, this.N);
            g.M(this, this.Z);
            g.M(this, this.K);
            this.R_();
            this.xJ();
            this.sE()
        },
        VCb = function(a, b) {
            if (j$(a)) {
                a.Fc.unsubscribe("remotePlayerChange", a.sE, a);
                var c = Math.round(b.volume);
                b = !!b.muted;
                var d = M9(a.Fc);
                if (c !== d.volume || b !== d.muted) a.Fc.setVolume(c, b), a.Z.start();
                a.Fc.subscribe("remotePlayerChange", a.sE, a)
            }
        },
        YCb = function(a) {
            a.Lc(0);
            a.j.stop();
            a.Cc(new g.YL(64))
        },
        ZCb = function(a, b) {
            if (j$(a) && !a.D) {
                var c = null;
                b && (c = {
                    style: a.J.getSubtitlesUserSettings()
                }, g.vd(c, b));
                a.Fc.oT(a.J.getVideoData(1).videoId, c);
                a.C = M9(a.Fc).trackData
            }
        },
        k$ = function(a, b) {
            var c = a.J.getPlaylist();
            if (null == c ? 0 : c.listId) {
                var d = c.index;
                var e = c.listId.toString()
            }
            c = a.J.getVideoData(1);
            a.Fc.playVideo(c.videoId, b, d, e, c.playerParams, c.Ba, eyb(c));
            a.Cc(new g.YL(1))
        },
        $Cb = function(a, b) {
            if (b) {
                var c = a.J.getOption("captions", "tracklist", {
                    rX: 1
                });
                c && c.length ? (a.J.setOption("captions", "track", b), a.D = !1) : (a.J.loadModule("captions"), a.D = !0)
            } else a.J.setOption("captions", "track", {})
        },
        j$ = function(a) {
            return M9(a.Fc).videoId === a.J.getVideoData(1).videoId
        },
        l$ = function() {
            g.V.call(this, {
                I: "div",
                S: "ytp-mdx-popup-dialog",
                Y: {
                    role: "dialog"
                },
                V: [{
                    I: "div",
                    S: "ytp-mdx-popup-dialog-inner-content",
                    V: [{
                        I: "div",
                        S: "ytp-mdx-popup-title",
                        ya: "You're signed out"
                    }, {
                        I: "div",
                        S: "ytp-mdx-popup-description",
                        ya: "Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer."
                    }, {
                        I: "div",
                        S: "ytp-mdx-privacy-popup-buttons",
                        V: [{
                            I: "button",
                            Ma: ["ytp-button", "ytp-mdx-privacy-popup-cancel"],
                            ya: "Cancel"
                        }, {
                            I: "button",
                            Ma: ["ytp-button",
                                "ytp-mdx-privacy-popup-confirm"
                            ],
                            ya: "Confirm"
                        }]
                    }]
                }]
            });
            this.j = new g.iH(this, 250);
            this.cancelButton = this.Ha("ytp-mdx-privacy-popup-cancel");
            this.confirmButton = this.Ha("ytp-mdx-privacy-popup-confirm");
            g.M(this, this.j);
            this.T(this.cancelButton, "click", this.B);
            this.T(this.confirmButton, "click", this.C)
        },
        m$ = function(a) {
            g.V.call(this, {
                I: "div",
                S: "ytp-remote",
                V: [{
                    I: "div",
                    S: "ytp-remote-display-status",
                    V: [{
                        I: "div",
                        S: "ytp-remote-display-status-icon",
                        V: [g.Kva()]
                    }, {
                        I: "div",
                        S: "ytp-remote-display-status-text",
                        ya: "{{statustext}}"
                    }]
                }]
            });
            this.api = a;
            this.j = new g.iH(this, 250);
            g.M(this, this.j);
            this.T(a, "presentingplayerstatechange", this.onStateChange);
            this.Dc(a.Ub())
        },
        n$ = function(a, b) {
            g.UX.call(this, "Play on", 1, a, b);
            this.J = a;
            this.Nt = {};
            this.T(a, "onMdxReceiversChange", this.D);
            this.T(a, "presentingplayerstatechange", this.D);
            this.D()
        },
        aDb = function(a) {
            g.$V.call(this, a);
            this.Ep = {
                key: Hyb(),
                name: "This computer"
            };
            this.Ml = null;
            this.subscriptions = [];
            this.EQ = this.Fc = null;
            this.Nt = [this.Ep];
            this.xs = this.Ep;
            this.Ge = new g.YL(64);
            this.PX = 0;
            this.Qh = -1;
            this.KE = !1;
            this.IE = this.HA = null;
            if (!g.zS(this.player.U()) && !g.GH(this.player.U())) {
                a = this.player;
                var b = g.zU(a);
                b && (b = b.qp()) && (b = new n$(a, b), g.M(this, b));
                b = new m$(a);
                g.M(this, b);
                g.LU(a, b.element, 4);
                this.HA = new l$;
                g.M(this, this.HA);
                g.LU(a, this.HA.element, 4);
                this.KE = !!c$()
            }
        },
        o$ = function(a) {
            a.IE && (a.player.removeEventListener("presentingplayerstatechange",
                a.IE), a.IE = null)
        },
        bDb = function(a, b, c) {
            a.Ge = c;
            a.player.oa("presentingplayerstatechange", new g.oH(c, b))
        },
        p$ = function(a, b) {
            if (b.key !== a.xs.key)
                if (b.key === a.Ep.key) g$();
                else if (WCb(a) && cDb(a), a.xs = b, !a.player.U().L("disable_mdx_connection_in_mdx_module_for_music_web") || !g.GH(a.player.U())) {
                var c = a.player.getPlaylistId();
                var d = a.player.getVideoData(1);
                var e = d.videoId;
                if (!c && !e || (2 === a.player.getAppState() || 1 === a.player.getAppState()) && a.player.U().L("should_clear_video_data_on_player_cued_unstarted")) d = null;
                else {
                    var f = a.player.getPlaylist();
                    if (f) {
                        var h = [];
                        for (var l = 0; l < f.getLength(); l++) h[l] = g.XV(f, l).videoId
                    } else h = [e];
                    f = a.player.getCurrentTime(1);
                    a = {
                        videoIds: h,
                        listId: c,
                        videoId: e,
                        playerParams: d.playerParams,
                        clickTrackingParams: d.Ba,
                        index: Math.max(a.player.getPlaylistIndex(), 0),
                        currentTime: 0 === f ? void 0 : f
                    };
                    (d = eyb(d)) && (a.locationInfo = d);
                    d = a
                }
                $9("Connecting to: " + g.an(b));
                "cast-selector-receiver" == b.key ? (b$(d || null), b = d || null, D9() ? B9().setLaunchParams(b) : A9("setLaunchParams called before ready.")) : !d && RCb() && Z9() == b.key ? m8("yt-remote-connection-change", !0) : (g$(), b$(d || null), d = Y9().Nk(), (b = h8(d, b.key)) && h$(b, 1))
            }
        },
        WCb = function(a) {
            var b = a.player.U();
            return !b.L("mdx_enable_privacy_disclosure_ui") || a.isLoggedIn() || a.KE || !a.HA ? !1 : g.IS(b) || g.KS(b)
        },
        cDb = function(a) {
            a.player.Ub().isPlaying() ? a.player.pauseVideo() : (a.IE = function(b) {
                !a.KE && g.rH(b, 8) && (a.player.pauseVideo(), o$(a))
            }, a.player.addEventListener("presentingplayerstatechange", a.IE));
            a.HA && a.HA.qd();
            e$() || (i$ = !0)
        };
    g.Sy.prototype.Js = g.ea(0, function() {
        return g.Tj(this, 6)
    });
    var lAb = {
            "\x00": "\\0",
            "\b": "\\b",
            "\f": "\\f",
            "\n": "\\n",
            "\r": "\\r",
            "\t": "\\t",
            "\v": "\\x0B",
            '"': '\\"',
            "\\": "\\\\",
            "<": "\\u003C"
        },
        R8 = {
            "'": "\\'"
        },
        Byb = {
            soa: "atp",
            X4a: "ska",
            A1a: "que",
            NTa: "mus",
            W4a: "sus",
            XEa: "dsp",
            g3a: "seq",
            pSa: "mic",
            Tva: "dpa",
            Npa: "cds",
            DTa: "mlm",
            Hva: "dsdtr",
            nUa: "ntb",
            Ggb: "vsp",
            Iwa: "scn",
            O1a: "rpe",
            Eva: "dcn",
            Fva: "dcp",
            cZa: "pas",
            Gva: "drq"
        },
        Cyb = {
            D4: "u",
            CLASSIC: "cl",
            m4: "k",
            J1: "i",
            q1: "cr",
            s4: "m",
            G1: "g",
            zU: "up"
        },
        Nyb = "",
        l8 = null;
    Vyb.prototype.flush = function(a, b) {
        a = void 0 === a ? [] : a;
        b = void 0 === b ? !1 : b;
        if (g.bC("enable_client_streamz_web")) {
            a = g.u(a);
            for (var c = a.next(); !c.done; c = a.next()) c = g.Nea(c.value), c = {
                serializedIncrementBatch: g.qg(c.j())
            }, g.ID("streamzIncremented", c, {
                sendIsolatedPayload: b
            })
        }
    };
    var n8, czb = Xyb("loadCastFramework") || Xyb("loadCastApplicationFramework"),
        fzb = ["pkedcjkdefgpdelpbcmbmeomcjbeemfm", "enhhojjnijigcajfphajepfemndkmdlo"];
    g.ob(p8, g.I);
    g.k = p8.prototype;
    g.k.A2 = function(a) {
        this.D = arguments;
        this.j = !1;
        this.jd ? this.C = g.nb() + this.Yi : this.jd = g.gg(this.G, this.Yi)
    };
    g.k.stop = function() {
        this.jd && (g.Sa.clearTimeout(this.jd), this.jd = null);
        this.C = null;
        this.j = !1;
        this.D = []
    };
    g.k.pause = function() {
        ++this.B
    };
    g.k.resume = function() {
        this.B && (--this.B, !this.B && this.j && (this.j = !1, this.K.apply(null, this.D)))
    };
    g.k.xa = function() {
        this.stop();
        p8.Lf.xa.call(this)
    };
    g.k.B2 = function() {
        this.jd && (g.Sa.clearTimeout(this.jd), this.jd = null);
        this.C ? (this.jd = g.gg(this.G, this.C - g.nb()), this.C = null) : this.B ? this.j = !0 : (this.j = !1, this.K.apply(null, this.D))
    };
    g.w(q8, g.I);
    g.k = q8.prototype;
    g.k.rL = function(a) {
        this.C = arguments;
        this.jd || this.B ? this.j = !0 : hzb(this)
    };
    g.k.stop = function() {
        this.jd && (g.Sa.clearTimeout(this.jd), this.jd = null, this.j = !1, this.C = null)
    };
    g.k.pause = function() {
        this.B++
    };
    g.k.resume = function() {
        this.B--;
        this.B || !this.j || this.jd || (this.j = !1, hzb(this))
    };
    g.k.xa = function() {
        g.I.prototype.xa.call(this);
        this.stop()
    };
    r8.prototype.stringify = function(a) {
        return g.Sa.JSON.stringify(a, void 0)
    };
    r8.prototype.parse = function(a) {
        return g.Sa.JSON.parse(a, void 0)
    };
    g.ob(izb, g.Ab);
    g.ob(jzb, g.Ab);
    var kzb = null;
    g.ob(mzb, g.Ab);
    g.ob(nzb, g.Ab);
    g.ob(ozb, g.Ab);
    v8.prototype.debug = function() {};
    v8.prototype.info = function() {};
    v8.prototype.warning = function() {};
    var wzb = {},
        vzb = {};
    g.k = w8.prototype;
    g.k.setTimeout = function(a) {
        this.ub = a
    };
    g.k.E2 = function(a) {
        a = a.target;
        var b = this.Xa;
        b && 3 == g.Kn(a) ? b.rL() : this.RS(a)
    };
    g.k.RS = function(a) {
        try {
            if (a == this.j) a: {
                var b = g.Kn(this.j),
                    c = this.j.B,
                    d = this.j.getStatus();
                if (!(3 > b) && (3 != b || g.LS || this.j && (this.B.B || g.Mn(this.j) || g.Nn(this.j)))) {
                    this.La || 4 != b || 7 == c || (8 == c || 0 >= d ? s8(3) : s8(2));
                    A8(this);
                    var e = this.j.getStatus();
                    this.zb = e;
                    b: if (tzb(this)) {
                        var f = g.Nn(this.j);
                        a = "";
                        var h = f.length,
                            l = 4 == g.Kn(this.j);
                        if (!this.B.C) {
                            if ("undefined" === typeof TextDecoder) {
                                y8(this);
                                z8(this);
                                var m = "";
                                break b
                            }
                            this.B.C = new g.Sa.TextDecoder
                        }
                        for (c = 0; c < h; c++) this.B.B = !0, a += this.B.C.decode(f[c], {
                            stream: l &&
                                c == h - 1
                        });
                        f.length = 0;
                        this.B.j += a;
                        this.K = 0;
                        m = this.B.j
                    } else m = g.Mn(this.j);
                    if (this.C = 200 == e) {
                        if (this.Rb && !this.Ua) {
                            b: {
                                if (this.j) {
                                    var n = g.On(this.j, "X-HTTP-Initial-Response");
                                    if (n && !g.hc(n)) {
                                        var p = n;
                                        break b
                                    }
                                }
                                p = null
                            }
                            if (e = p) this.Ua = !0,
                            xzb(this, e);
                            else {
                                this.C = !1;
                                this.N = 3;
                                t8(12);
                                y8(this);
                                z8(this);
                                break a
                            }
                        }
                        this.Ga ? (yzb(this, b, m), g.LS && this.C && 3 == b && (this.bb.Qa(this.ib, "tick", this.D2), this.ib.start())) : xzb(this, m);
                        4 == b && y8(this);
                        this.C && !this.La && (4 == b ? Azb(this.G, this) : (this.C = !1, x8(this)))
                    } else g.Cfa(this.j),
                        400 == e && 0 < m.indexOf("Unknown SID") ? (this.N = 3, t8(12)) : (this.N = 0, t8(13)), y8(this), z8(this)
                }
            }
        } catch (q) {} finally {}
    };
    g.k.D2 = function() {
        if (this.j) {
            var a = g.Kn(this.j),
                b = g.Mn(this.j);
            this.K < b.length && (A8(this), yzb(this, a, b), this.C && 4 != a && x8(this))
        }
    };
    g.k.cancel = function() {
        this.La = !0;
        y8(this)
    };
    g.k.C2 = function() {
        this.ma = null;
        var a = Date.now();
        0 <= a - this.Jb ? (2 != this.Ta && (s8(3), t8(17)), y8(this), this.N = 2, z8(this)) : zzb(this, this.Jb - a)
    };
    g.k.getLastError = function() {
        return this.N
    };
    g.k.iO = function() {
        return this.j
    };
    Jzb.prototype.cancel = function() {
        this.C = Lzb(this);
        if (this.B) this.B.cancel(), this.B = null;
        else if (this.j && 0 !== this.j.size) {
            for (var a = g.u(this.j.values()), b = a.next(); !b.done; b = a.next()) b.value.cancel();
            this.j.clear()
        }
    };
    g.k = Pzb.prototype;
    g.k.SS = 8;
    g.k.Fh = 1;
    g.k.connect = function(a, b, c, d) {
        t8(0);
        this.ac = a;
        this.La = b || {};
        c && void 0 !== d && (this.La.OSID = c, this.La.OAID = d);
        this.Ua = this.Jc;
        this.Na = Fzb(this, null, this.ac);
        E8(this)
    };
    g.k.disconnect = function() {
        Rzb(this);
        if (3 == this.Fh) {
            var a = this.Za++,
                b = this.Na.clone();
            g.Fp(b, "SID", this.D);
            g.Fp(b, "RID", a);
            g.Fp(b, "TYPE", "terminate");
            H8(this, b);
            a = new w8(this, this.D, a);
            a.Ta = 2;
            a.Z = a8(b.clone());
            b = !1;
            if (g.Sa.navigator && g.Sa.navigator.sendBeacon) try {
                b = g.Sa.navigator.sendBeacon(a.Z.toString(), "")
            } catch (c) {}!b && g.Sa.Image && ((new Image).src = a.Z, b = !0);
            b || (a.j = szb(a.G, null), a.j.send(a.Z));
            a.Ba = Date.now();
            x8(a)
        }
        Xzb(this)
    };
    g.k.Ng = function() {
        return 0 == this.Fh
    };
    g.k.getState = function() {
        return this.Fh
    };
    g.k.VS = function(a) {
        if (this.K)
            if (this.K = null, 1 == this.Fh) {
                if (!a) {
                    this.Za = Math.floor(1E5 * Math.random());
                    a = this.Za++;
                    var b = new w8(this, "", a),
                        c = this.X;
                    this.Jb && (c ? (c = g.qd(c), g.vd(c, this.Jb)) : c = this.Jb);
                    null !== this.N || this.qb || (b.Na = c, c = null);
                    var d;
                    if (this.ub) a: {
                        for (var e = d = 0; e < this.C.length; e++) {
                            b: {
                                var f = this.C[e];
                                if ("__data__" in f.map && (f = f.map.__data__, "string" === typeof f)) {
                                    f = f.length;
                                    break b
                                }
                                f = void 0
                            }
                            if (void 0 === f) break;d += f;
                            if (4096 < d) {
                                d = e;
                                break a
                            }
                            if (4096 === d || e === this.C.length - 1) {
                                d = e + 1;
                                break a
                            }
                        }
                        d =
                        1E3
                    }
                    else d = 1E3;
                    d = Uzb(this, b, d);
                    e = this.Na.clone();
                    g.Fp(e, "RID", a);
                    g.Fp(e, "CVER", 22);
                    this.Ga && g.Fp(e, "X-HTTP-Session-Id", this.Ga);
                    H8(this, e);
                    c && (this.qb ? d = "headers=" + g.Ke(g.Dga(c)) + "&" + d : this.N && g.Jp(e, this.N, c));
                    Ezb(this.B, b);
                    this.Qf && g.Fp(e, "TYPE", "init");
                    this.ub ? (g.Fp(e, "$req", d), g.Fp(e, "SID", "null"), b.Rb = !0, rzb(b, e, null)) : rzb(b, e, d);
                    this.Fh = 2
                }
            } else 3 == this.Fh && (a ? Vzb(this, a) : 0 == this.C.length || Kzb(this.B) || Vzb(this))
    };
    g.k.US = function() {
        this.Z = null;
        Wzb(this);
        if (this.Mc && !(this.ib || null == this.j || 0 >= this.Pd)) {
            var a = 2 * this.Pd;
            this.Ea = u8((0, g.jb)(this.n9, this), a)
        }
    };
    g.k.n9 = function() {
        this.Ea && (this.Ea = null, this.Ua = !1, this.ib = !0, t8(10), C8(this), Wzb(this))
    };
    g.k.SP = function(a) {
        this.j == a && this.Mc && !this.ib && (Qzb(this), this.ib = !0, t8(11))
    };
    g.k.F2 = function() {
        null != this.ma && (this.ma = null, C8(this), Czb(this), t8(19))
    };
    g.k.yca = function(a) {
        a ? t8(2) : t8(1)
    };
    g.k.isActive = function() {
        return !!this.G && this.G.isActive(this)
    };
    g.k = Zzb.prototype;
    g.k.ZS = function() {};
    g.k.YS = function() {};
    g.k.XS = function() {};
    g.k.WS = function() {};
    g.k.isActive = function() {
        return !0
    };
    g.k.G2 = function() {};
    g.ob(J8, g.Kd);
    J8.prototype.open = function() {
        this.j.G = this.C;
        this.K && (this.j.Ta = !0);
        this.j.connect(this.G, this.B || void 0)
    };
    J8.prototype.close = function() {
        this.j.disconnect()
    };
    J8.prototype.send = function(a) {
        var b = this.j;
        if ("string" === typeof a) {
            var c = {};
            c.__data__ = a;
            a = c
        } else this.D && (c = {}, c.__data__ = g.an(a), a = c);
        b.C.push(new Izb(b.Of++, a));
        3 == b.Fh && E8(b)
    };
    J8.prototype.xa = function() {
        this.j.G = null;
        delete this.C;
        this.j.disconnect();
        delete this.j;
        J8.Lf.xa.call(this)
    };
    g.ob(aAb, izb);
    g.ob(bAb, jzb);
    g.ob(I8, Zzb);
    I8.prototype.ZS = function() {
        this.j.dispatchEvent("m")
    };
    I8.prototype.YS = function(a) {
        this.j.dispatchEvent(new aAb(a))
    };
    I8.prototype.XS = function(a) {
        this.j.dispatchEvent(new bAb(a))
    };
    I8.prototype.WS = function() {
        this.j.dispatchEvent("n")
    };
    var L8 = new g.Kd;
    g.w(eAb, g.Ab);
    g.k = N8.prototype;
    g.k.Bu = null;
    g.k.cq = !1;
    g.k.Dx = null;
    g.k.tL = null;
    g.k.Bx = null;
    g.k.Cx = null;
    g.k.Nr = null;
    g.k.Pr = null;
    g.k.Cu = null;
    g.k.ij = null;
    g.k.kG = 0;
    g.k.po = null;
    g.k.jG = null;
    g.k.Or = null;
    g.k.JB = -1;
    g.k.q_ = !0;
    g.k.Au = !1;
    g.k.sL = 0;
    g.k.iG = null;
    var jAb = {},
        iAb = {};
    g.k = N8.prototype;
    g.k.setTimeout = function(a) {
        this.B = a
    };
    g.k.I2 = function(a) {
        a = a.target;
        var b = this.iG;
        b && 3 == g.Kn(a) ? b.rL() : this.aT(a)
    };
    g.k.aT = function(a) {
        try {
            if (a == this.ij) a: {
                var b = g.Kn(this.ij),
                    c = this.ij.B,
                    d = this.ij.getStatus();
                if (g.gf && !g.Wc(10) || g.Xc && !g.Tc("420+")) {
                    if (4 > b) break a
                } else if (3 > b || 3 == b && !g.Mn(this.ij)) break a;this.Au || 4 != b || 7 == c || (8 == c || 0 >= d ? this.j.Ln(3) : this.j.Ln(2));oAb(this);
                var e = this.ij.getStatus();this.JB = e;
                var f = g.Mn(this.ij);
                if (this.cq = 200 == e) {
                    4 == b && P8(this);
                    if (this.Ga) {
                        for (a = !0; !this.Au && this.kG < f.length;) {
                            var h = kAb(this, f);
                            if (h == iAb) {
                                4 == b && (this.Or = 4, M8(15), a = !1);
                                break
                            } else if (h == jAb) {
                                this.Or = 4;
                                M8(16);
                                a = !1;
                                break
                            } else pAb(this, h)
                        }
                        4 == b && 0 == f.length && (this.Or = 1, M8(17), a = !1);
                        this.cq = this.cq && a;
                        a || (P8(this), Q8(this))
                    } else pAb(this, f);
                    this.cq && !this.Au && (4 == b ? this.j.lG(this) : (this.cq = !1, O8(this)))
                } else 400 == e && 0 < f.indexOf("Unknown SID") ? (this.Or = 3, M8(13)) : (this.Or = 0, M8(14)),
                P8(this),
                Q8(this)
            }
        } catch (l) {} finally {}
    };
    g.k.Aaa = function(a) {
        K8((0, g.jb)(this.zaa, this, a), 0)
    };
    g.k.zaa = function(a) {
        this.Au || (oAb(this), pAb(this, a), O8(this))
    };
    g.k.lZ = function(a) {
        K8((0, g.jb)(this.yaa, this, a), 0)
    };
    g.k.yaa = function(a) {
        this.Au || (P8(this), this.cq = a, this.j.lG(this), this.j.Ln(4))
    };
    g.k.cancel = function() {
        this.Au = !0;
        P8(this)
    };
    g.k.H2 = function() {
        this.Dx = null;
        var a = Date.now();
        0 <= a - this.tL ? (2 != this.Cx && this.j.Ln(3), P8(this), this.Or = 2, M8(18), Q8(this)) : nAb(this, this.tL - a)
    };
    g.k.getLastError = function() {
        return this.Or
    };
    g.k = sAb.prototype;
    g.k.vL = null;
    g.k.Jj = null;
    g.k.UJ = !1;
    g.k.K_ = null;
    g.k.zH = null;
    g.k.dP = null;
    g.k.wL = null;
    g.k.Kl = null;
    g.k.eq = -1;
    g.k.KB = null;
    g.k.uC = null;
    g.k.connect = function(a) {
        this.wL = a;
        a = T8(this.j, null, this.wL);
        M8(3);
        this.K_ = Date.now();
        var b = this.j.X;
        null != b ? (this.KB = b[0], (this.uC = b[1]) ? (this.Kl = 1, tAb(this)) : (this.Kl = 2, uAb(this))) : (b8(a, "MODE", "init"), this.Jj = new N8(this), this.Jj.Bu = this.vL, hAb(this.Jj, a, !1, null, !0), this.Kl = 0)
    };
    g.k.r5 = function(a) {
        if (a) this.Kl = 2, uAb(this);
        else {
            M8(4);
            var b = this.j;
            b.Eo = b.qs.eq;
            X8(b, 9)
        }
        a && this.Ln(2)
    };
    g.k.uL = function(a) {
        return this.j.uL(a)
    };
    g.k.abort = function() {
        this.Jj && (this.Jj.cancel(), this.Jj = null);
        this.eq = -1
    };
    g.k.Ng = function() {
        return !1
    };
    g.k.bT = function(a, b) {
        this.eq = a.JB;
        if (0 == this.Kl)
            if (b) {
                try {
                    var c = this.B.parse(b)
                } catch (d) {
                    a = this.j;
                    a.Eo = this.eq;
                    X8(a, 2);
                    return
                }
                this.KB = c[0];
                this.uC = c[1]
            } else a = this.j, a.Eo = this.eq, X8(a, 2);
        else if (2 == this.Kl)
            if (this.UJ) M8(7), this.dP = Date.now();
            else if ("11111" == b) {
            if (M8(6), this.UJ = !0, this.zH = Date.now(), a = this.zH - this.K_, !g.gf || g.Wc(10) || 500 > a) this.eq = 200, this.Jj.cancel(), M8(12), U8(this.j, this, !0)
        } else M8(8), this.zH = this.dP = Date.now(), this.UJ = !1
    };
    g.k.lG = function() {
        this.eq = this.Jj.JB;
        if (this.Jj.cq) 0 == this.Kl ? this.uC ? (this.Kl = 1, tAb(this)) : (this.Kl = 2, uAb(this)) : 2 == this.Kl && ((!g.gf || g.Wc(10) ? !this.UJ : 200 > this.dP - this.zH) ? (M8(11), U8(this.j, this, !1)) : (M8(12), U8(this.j, this, !0)));
        else {
            0 == this.Kl ? M8(9) : 2 == this.Kl && M8(10);
            var a = this.j;
            this.Jj.getLastError();
            a.Eo = this.eq;
            X8(a, 2)
        }
    };
    g.k.LB = function() {
        return this.j.LB()
    };
    g.k.isActive = function() {
        return this.j.isActive()
    };
    g.k.Ln = function(a) {
        this.j.Ln(a)
    };
    g.k = vAb.prototype;
    g.k.Do = null;
    g.k.MB = null;
    g.k.Tj = null;
    g.k.Jg = null;
    g.k.xL = null;
    g.k.mG = null;
    g.k.cT = null;
    g.k.nG = null;
    g.k.NB = 0;
    g.k.K2 = 0;
    g.k.Ni = null;
    g.k.Qr = null;
    g.k.fq = null;
    g.k.Eu = null;
    g.k.qs = null;
    g.k.RK = null;
    g.k.Gx = -1;
    g.k.dT = -1;
    g.k.Eo = -1;
    g.k.Fx = 0;
    g.k.Ex = 0;
    g.k.Du = 8;
    g.ob(xAb, g.Ab);
    g.ob(yAb, g.Ab);
    g.k = vAb.prototype;
    g.k.connect = function(a, b, c, d, e) {
        M8(0);
        this.xL = b;
        this.MB = c || {};
        d && void 0 !== e && (this.MB.OSID = d, this.MB.OAID = e);
        this.Z ? (K8((0, g.jb)(this.vV, this, a), 100), AAb(this)) : this.vV(a)
    };
    g.k.disconnect = function() {
        BAb(this);
        if (3 == this.j) {
            var a = this.NB++,
                b = this.mG.clone();
            g.Fp(b, "SID", this.D);
            g.Fp(b, "RID", a);
            g.Fp(b, "TYPE", "terminate");
            W8(this, b);
            a = new N8(this, this.D, a);
            a.Cx = 2;
            a.Nr = a8(b.clone());
            (new Image).src = a.Nr.toString();
            a.Bx = Date.now();
            O8(a)
        }
        LAb(this)
    };
    g.k.vV = function(a) {
        this.qs = new sAb(this);
        this.qs.vL = this.Do;
        this.qs.B = this.G;
        this.qs.connect(a)
    };
    g.k.Ng = function() {
        return 0 == this.j
    };
    g.k.getState = function() {
        return this.j
    };
    g.k.fT = function(a) {
        this.Qr = null;
        GAb(this, a)
    };
    g.k.eT = function() {
        this.fq = null;
        this.Jg = new N8(this, this.D, "rpc", this.N);
        this.Jg.Bu = this.Do;
        this.Jg.sL = 0;
        var a = this.cT.clone();
        g.Fp(a, "RID", "rpc");
        g.Fp(a, "SID", this.D);
        g.Fp(a, "CI", this.RK ? "0" : "1");
        g.Fp(a, "AID", this.Gx);
        W8(this, a);
        if (!g.gf || g.Wc(10)) g.Fp(a, "TYPE", "xmlhttp"), hAb(this.Jg, a, !0, this.nG, !1);
        else {
            g.Fp(a, "TYPE", "html");
            var b = this.Jg,
                c = !!this.nG;
            b.Cx = 3;
            b.Nr = a8(a.clone());
            mAb(b, c)
        }
    };
    g.k.bT = function(a, b) {
        if (0 != this.j && (this.Jg == a || this.Tj == a))
            if (this.Eo = a.JB, this.Tj == a && 3 == this.j)
                if (7 < this.Du) {
                    try {
                        var c = this.G.parse(b)
                    } catch (d) {
                        c = null
                    }
                    if (Array.isArray(c) && 3 == c.length)
                        if (a = c, 0 == a[0]) a: {
                            if (!this.fq) {
                                if (this.Jg)
                                    if (this.Jg.Bx + 3E3 < this.Tj.Bx) V8(this), this.Jg.cancel(), this.Jg = null;
                                    else break a;
                                JAb(this);
                                M8(19)
                            }
                        }
                    else this.dT = a[1], 0 < this.dT - this.Gx && 37500 > a[2] && this.RK && 0 == this.Ex && !this.Eu && (this.Eu = K8((0, g.jb)(this.L2, this), 6E3));
                    else X8(this, 11)
                } else null != b && X8(this, 11);
        else if (this.Jg ==
            a && V8(this), !g.hc(b))
            for (a = this.G.parse(b), b = 0; b < a.length; b++) c = a[b], this.Gx = c[0], c = c[1], 2 == this.j ? "c" == c[0] ? (this.D = c[1], this.nG = c[2], c = c[3], null != c ? this.Du = c : this.Du = 6, this.j = 3, this.Ni && this.Ni.iT(), this.cT = T8(this, this.LB() ? this.nG : null, this.xL), HAb(this)) : "stop" == c[0] && X8(this, 7) : 3 == this.j && ("stop" == c[0] ? X8(this, 7) : "noop" != c[0] && this.Ni && this.Ni.hT(c), this.Ex = 0)
    };
    g.k.L2 = function() {
        null != this.Eu && (this.Eu = null, this.Jg.cancel(), this.Jg = null, JAb(this), M8(20))
    };
    g.k.lG = function(a) {
        if (this.Jg == a) {
            V8(this);
            this.Jg = null;
            var b = 2
        } else if (this.Tj == a) this.Tj = null, b = 1;
        else return;
        this.Eo = a.JB;
        if (0 != this.j)
            if (a.cq)
                if (1 == b) {
                    b = a.Cu ? a.Cu.length : 0;
                    a = Date.now() - a.Bx;
                    var c = L8;
                    c.dispatchEvent(new xAb(c, b, a, this.Fx));
                    zAb(this);
                    this.C.length = 0
                } else HAb(this);
        else {
            c = a.getLastError();
            var d;
            if (!(d = 3 == c || 7 == c || 0 == c && 0 < this.Eo)) {
                if (d = 1 == b) this.Tj || this.Qr || 1 == this.j || 2 <= this.Fx ? d = !1 : (this.Qr = K8((0, g.jb)(this.fT, this, a), IAb(this, this.Fx)), this.Fx++, d = !0);
                d = !(d || 2 == b && JAb(this))
            }
            if (d) switch (c) {
                case 1:
                    X8(this,
                        5);
                    break;
                case 4:
                    X8(this, 10);
                    break;
                case 3:
                    X8(this, 6);
                    break;
                case 7:
                    X8(this, 12);
                    break;
                default:
                    X8(this, 2)
            }
        }
    };
    g.k.J2 = function(a) {
        if (!g.Gb(arguments, this.j)) throw Error("Unexpected channel state: " + this.j);
    };
    g.k.xca = function(a) {
        a ? M8(2) : (M8(1), KAb(this, 8))
    };
    g.k.uL = function(a) {
        if (a) throw Error("Can't create secondary domain capable XhrIo object.");
        a = new g.en;
        a.K = !1;
        return a
    };
    g.k.isActive = function() {
        return !!this.Ni && this.Ni.isActive(this)
    };
    g.k.Ln = function(a) {
        var b = L8;
        b.dispatchEvent(new yAb(b, a))
    };
    g.k.LB = function() {
        return !(!g.gf || g.Wc(10))
    };
    g.k = MAb.prototype;
    g.k.iT = function() {};
    g.k.hT = function() {};
    g.k.gT = function() {};
    g.k.yL = function() {};
    g.k.jT = function() {
        return {}
    };
    g.k.isActive = function() {
        return !0
    };
    g.k = NAb.prototype;
    g.k.isEmpty = function() {
        return 0 === this.j.length && 0 === this.B.length
    };
    g.k.clear = function() {
        this.j = [];
        this.B = []
    };
    g.k.contains = function(a) {
        return g.Gb(this.j, a) || g.Gb(this.B, a)
    };
    g.k.remove = function(a) {
        var b = this.j;
        var c = (0, g.xfb)(b, a);
        0 <= c ? (g.Hb(b, c), b = !0) : b = !1;
        return b || g.Ib(this.B, a)
    };
    g.k.Xl = function() {
        for (var a = [], b = this.j.length - 1; 0 <= b; --b) a.push(this.j[b]);
        var c = this.B.length;
        for (b = 0; b < c; ++b) a.push(this.B[b]);
        return a
    };
    g.w(OAb, g.Ab);
    g.w(PAb, g.Ab);
    g.ob(Y8, g.I);
    g.k = Y8.prototype;
    g.k.saa = function() {
        this.Yi = Math.min(3E5, 2 * this.Yi);
        this.C();
        this.B && this.start()
    };
    g.k.start = function() {
        var a = this.Yi + 15E3 * Math.random();
        g.gv(this.j, a);
        this.B = Date.now() + a
    };
    g.k.stop = function() {
        this.j.stop();
        this.B = 0
    };
    g.k.isActive = function() {
        return this.j.isActive()
    };
    g.k.reset = function() {
        this.j.stop();
        this.Yi = 5E3
    };
    g.ob(RAb, MAb);
    g.k = RAb.prototype;
    g.k.subscribe = function(a, b, c) {
        return this.C.subscribe(a, b, c)
    };
    g.k.unsubscribe = function(a, b, c) {
        return this.C.unsubscribe(a, b, c)
    };
    g.k.Eh = function(a) {
        return this.C.Eh(a)
    };
    g.k.oa = function(a, b) {
        return this.C.oa.apply(this.C, arguments)
    };
    g.k.dispose = function() {
        this.ma || (this.ma = !0, g.vb(this.C), this.disconnect(), g.vb(this.B), this.B = null, this.ra = function() {
            return ""
        })
    };
    g.k.isDisposed = function() {
        return this.ma
    };
    g.k.connect = function(a, b, c) {
        if (!this.j || 2 != this.j.getState()) {
            this.X = "";
            this.B.stop();
            this.K = a || null;
            this.G = b || 0;
            a = this.Ba + "/test";
            b = this.Ba + "/bind";
            var d = new vAb(c ? c.firstTestResults : null, c ? c.secondTestResults : null, this.Ta),
                e = this.j;
            e && (e.Ni = null);
            d.Ni = this;
            this.j = d;
            SAb(this);
            if (this.j) {
                d = g.$B("ID_TOKEN");
                var f = this.j.Do || {};
                d ? f["x-youtube-identity-token"] = d : delete f["x-youtube-identity-token"];
                this.j.Do = f
            }
            e ? (3 != e.getState() && 0 == DAb(e) || e.getState(), this.j.connect(a, b, this.N, e.D, e.Gx)) : c ? this.j.connect(a,
                b, this.N, c.sessionId, c.arrayId) : this.j.connect(a, b, this.N)
        }
    };
    g.k.disconnect = function(a) {
        this.Z = a || 0;
        this.B.stop();
        SAb(this);
        this.j && (3 == this.j.getState() && GAb(this.j), this.j.disconnect());
        this.Z = 0
    };
    g.k.sendMessage = function(a, b) {
        a = {
            _sc: a
        };
        b && g.vd(a, b);
        this.B.isActive() || 2 == (this.j ? this.j.getState() : 0) ? this.D.push(a) : this.Az() && (SAb(this), CAb(this.j, a))
    };
    g.k.iT = function() {
        this.B.reset();
        this.K = null;
        this.G = 0;
        if (this.D.length) {
            var a = this.D;
            this.D = [];
            for (var b = 0, c = a.length; b < c; ++b) CAb(this.j, a[b])
        }
        this.oa("handlerOpened");
        oyb(this.Na, "BROWSER_CHANNEL")
    };
    g.k.gT = function(a) {
        var b = 2 == a && 401 == this.j.Eo;
        4 == a || b || this.B.start();
        this.oa("handlerError", a, b);
        uyb(this.Ga, "BROWSER_CHANNEL")
    };
    g.k.yL = function(a, b) {
        if (!this.B.isActive()) this.oa("handlerClosed");
        else if (b)
            for (var c = 0, d = b.length; c < d; ++c) {
                var e = b[c].map;
                e && this.D.push(e)
            }
        qyb(this.Ea, "BROWSER_CHANNEL");
        a && this.Xa.j.zL("/client_streamz/youtube/living_room/mdx/browser_channel/pending_maps", a.length);
        b && this.Za.j.zL("/client_streamz/youtube/living_room/mdx/browser_channel/undelivered_maps", b.length)
    };
    g.k.jT = function() {
        var a = {
            v: 2
        };
        this.X && (a.gsessionid = this.X);
        0 != this.G && (a.ui = "" + this.G);
        0 != this.Z && (a.ui = "" + this.Z);
        this.K && g.vd(a, this.K);
        return a
    };
    g.k.hT = function(a) {
        "S" == a[0] ? this.X = a[1] : "gracefulReconnect" == a[0] ? (this.B.start(), this.j.disconnect()) : this.oa("handlerMessage", new QAb(a[0], a[1]));
        syb(this.La, "BROWSER_CHANNEL")
    };
    g.k.Az = function() {
        return !!this.j && 3 == this.j.getState()
    };
    g.k.yr = function(a) {
        (this.N.loungeIdToken = a) || this.B.stop();
        if (this.Ua && this.j) {
            var b = this.j.Do || {};
            a ? b["X-YouTube-LoungeId-Token"] = a : delete b["X-YouTube-LoungeId-Token"];
            this.j.Do = b
        }
    };
    g.k.Js = function() {
        return this.N.id
    };
    g.k.Os = function() {
        return this.B.isActive() ? this.B.B - Date.now() : NaN
    };
    g.k.Mw = function() {
        var a = this.B;
        g.hv(a.j);
        a.start()
    };
    g.k.Lba = function() {
        this.B.isActive();
        0 == DAb(this.j) && this.connect(this.K, this.G)
    };
    Z8.prototype.D = function(a, b, c, d) {
        b ? a(d) : a({
            text: c.responseText
        })
    };
    Z8.prototype.C = function(a, b) {
        a(Error("Request error: " + b.status))
    };
    Z8.prototype.G = function(a) {
        a(Error("request timed out"))
    };
    g.w(UAb, g.Kd);
    g.k = UAb.prototype;
    g.k.connect = function(a, b, c) {
        this.Ed.connect(a, b, c)
    };
    g.k.disconnect = function(a) {
        this.Ed.disconnect(a)
    };
    g.k.Mw = function() {
        this.Ed.Mw()
    };
    g.k.Js = function() {
        return this.Ed.Js()
    };
    g.k.Os = function() {
        return this.Ed.Os()
    };
    g.k.Az = function() {
        return this.Ed.Az()
    };
    g.k.O2 = function() {
        this.dispatchEvent("channelOpened");
        var a = this.Ed,
            b = this.j;
        g.oD("yt-remote-session-browser-channel", {
            firstTestResults: [""],
            secondTestResults: !a.j.RK,
            sessionId: a.j.D,
            arrayId: a.j.Gx
        });
        g.oD("yt-remote-session-screen-id", b);
        a = i8();
        b = j8();
        g.Gb(a, b) || a.push(b);
        Myb(a);
        Oyb()
    };
    g.k.M2 = function() {
        this.dispatchEvent("channelClosed")
    };
    g.k.N2 = function(a) {
        this.dispatchEvent(new OAb(a))
    };
    g.k.onError = function(a) {
        this.dispatchEvent(new PAb(a ? 1 : 0))
    };
    g.k.sendMessage = function(a, b) {
        this.Ed.sendMessage(a, b)
    };
    g.k.yr = function(a) {
        this.Ed.yr(a)
    };
    g.k.dispose = function() {
        this.Ed.dispose()
    };
    g.k = VAb.prototype;
    g.k.connect = function(a, b) {
        a = void 0 === a ? {} : a;
        b = void 0 === b ? 0 : b;
        2 !== this.K && (this.C.stop(), this.Z = a, this.N = b, XAb(this), (a = g.$B("ID_TOKEN")) ? this.D["x-youtube-identity-token"] = a : delete this.D["x-youtube-identity-token"], this.j && (this.B.device = this.j.device, this.B.name = this.j.name, this.B.app = this.j.app, this.B.id = this.j.id, this.j.C8 && (this.B.mdxVersion = "" + this.j.C8), this.j.theme && (this.B.theme = this.j.theme), this.j.capabilities && (this.B.capabilities = this.j.capabilities), this.j.H5 && (this.B.cst = this.j.H5),
            this.j.authuser && (this.B.authuser = this.j.authuser), this.j.pageId && (this.B.pageId = this.j.pageId)), 0 !== this.N ? this.B.ui = "" + this.N : delete this.B.ui, Object.assign(this.B, this.Z), this.channel = new J8(this.pathPrefix, {
            M7: "gsessionid",
            G8: this.D,
            H8: this.B
        }), this.channel.open(), this.K = 2, WAb(this))
    };
    g.k.disconnect = function(a) {
        this.X = void 0 === a ? 0 : a;
        this.C.stop();
        XAb(this);
        this.channel && (0 !== this.X ? this.B.ui = "" + this.X : delete this.B.ui, this.channel.close());
        this.X = 0
    };
    g.k.Os = function() {
        return this.C.isActive() ? this.C.B - Date.now() : NaN
    };
    g.k.Mw = function() {
        var a = this.C;
        g.hv(a.j);
        a.start()
    };
    g.k.sendMessage = function(a, b) {
        this.channel && (XAb(this), a = Object.assign({}, {
            _sc: a
        }, b), this.channel.send(a))
    };
    g.k.yr = function(a) {
        a || this.C.stop();
        a ? this.D["X-YouTube-LoungeId-Token"] = a : delete this.D["X-YouTube-LoungeId-Token"]
    };
    g.k.Js = function() {
        return this.j ? this.j.id : ""
    };
    g.k.oa = function(a) {
        return this.G.oa.apply(this.G, [a].concat(g.pa(g.Ia.apply(1, arguments))))
    };
    g.k.subscribe = function(a, b, c) {
        return this.G.subscribe(a, b, c)
    };
    g.k.unsubscribe = function(a, b, c) {
        return this.G.unsubscribe(a, b, c)
    };
    g.k.Eh = function(a) {
        return this.G.Eh(a)
    };
    g.k.dispose = function() {
        this.ma || (this.ma = !0, g.vb(this.G), this.disconnect(), g.vb(this.C), this.Ba = function() {
            return ""
        })
    };
    g.k.isDisposed = function() {
        return this.ma
    };
    g.w(YAb, g.Kd);
    g.k = YAb.prototype;
    g.k.connect = function(a, b) {
        this.j.connect(a, b)
    };
    g.k.disconnect = function(a) {
        this.j.disconnect(a)
    };
    g.k.Mw = function() {
        this.j.Mw()
    };
    g.k.Js = function() {
        return this.j.Js()
    };
    g.k.Os = function() {
        return this.j.Os()
    };
    g.k.Az = function() {
        return 3 === this.j.K
    };
    g.k.R2 = function() {
        this.dispatchEvent("channelOpened")
    };
    g.k.P2 = function() {
        this.dispatchEvent("channelClosed")
    };
    g.k.Q2 = function(a) {
        this.dispatchEvent(new OAb(a))
    };
    g.k.onError = function() {
        this.dispatchEvent(new PAb(401 === this.j.Cg ? 1 : 0))
    };
    g.k.sendMessage = function(a, b) {
        this.j.sendMessage(a, b)
    };
    g.k.yr = function(a) {
        this.j.yr(a)
    };
    g.k.dispose = function() {
        this.j.dispose()
    };
    var fBb = Date.now(),
        a9 = null,
        e9 = Array(50),
        d9 = -1,
        f9 = !1;
    g.ob(g9, g.zG);
    g9.prototype.Nk = function() {
        return this.screens
    };
    g9.prototype.contains = function(a) {
        return !!Jyb(this.screens, a)
    };
    g9.prototype.get = function(a) {
        return a ? h8(this.screens, a) : null
    };
    g9.prototype.info = function(a) {
        b9(this.K, a)
    };
    g.w(jBb, g.zG);
    g.k = jBb.prototype;
    g.k.start = function() {
        !this.j && isNaN(this.jd) && this.GZ()
    };
    g.k.stop = function() {
        this.j && (this.j.abort(), this.j = null);
        isNaN(this.jd) || (g.uC(this.jd), this.jd = NaN)
    };
    g.k.xa = function() {
        this.stop();
        g.zG.prototype.xa.call(this)
    };
    g.k.GZ = function() {
        this.jd = NaN;
        this.j = g.xC($8(this.C, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: this.N
            },
            timeout: 5E3,
            onSuccess: (0, g.jb)(this.T2, this),
            onError: (0, g.jb)(this.S2, this),
            onTimeout: (0, g.jb)(this.U2, this)
        })
    };
    g.k.T2 = function(a, b) {
        this.j = null;
        a = b.screen || {};
        a.dialId = this.D;
        a.name = this.K;
        b = -1;
        this.G && a.shortLivedLoungeToken && a.shortLivedLoungeToken.value && a.shortLivedLoungeToken.refreshIntervalMs && (a.screenIdType = "shortLived", a.loungeToken = a.shortLivedLoungeToken.value, b = a.shortLivedLoungeToken.refreshIntervalMs);
        this.oa("pairingComplete", new e8(a), b)
    };
    g.k.S2 = function(a) {
        this.j = null;
        a.status && 404 == a.status ? this.B >= dDb.length ? this.oa("pairingFailed", Error("DIAL polling timed out")) : (a = dDb[this.B], this.jd = g.sC((0, g.jb)(this.GZ, this), a), this.B++) : this.oa("pairingFailed", Error("Server error " + a.status))
    };
    g.k.U2 = function() {
        this.j = null;
        this.oa("pairingFailed", Error("Server not responding"))
    };
    var dDb = [2E3, 2E3, 1E3, 1E3, 1E3, 2E3, 2E3, 5E3, 5E3, 1E4];
    g.ob(i9, g9);
    g.k = i9.prototype;
    g.k.start = function() {
        h9(this) && this.oa("screenChange");
        !g.pD("yt-remote-lounge-token-expiration") && kBb(this);
        g.uC(this.j);
        this.j = g.sC((0, g.jb)(this.start, this), 1E4)
    };
    g.k.add = function(a, b) {
        h9(this);
        gBb(this, a);
        j9(this, !1);
        this.oa("screenChange");
        b(a);
        a.token || kBb(this)
    };
    g.k.remove = function(a, b) {
        var c = h9(this);
        iBb(this, a) && (j9(this, !1), c = !0);
        b(a);
        c && this.oa("screenChange")
    };
    g.k.QK = function(a, b, c, d) {
        var e = h9(this),
            f = this.get(a.id);
        f ? (f.name != b && (f.name = b, j9(this, !1), e = !0), c(a)) : d(Error("no such local screen."));
        e && this.oa("screenChange")
    };
    g.k.xa = function() {
        g.uC(this.j);
        i9.Lf.xa.call(this)
    };
    g.k.k7 = function(a) {
        h9(this);
        var b = this.screens.length;
        a = a && a.screens || [];
        for (var c = 0, d = a.length; c < d; ++c) {
            var e = a[c],
                f = this.get(e.screenId);
            f && (f.token = e.loungeToken, --b)
        }
        j9(this, !b);
        b && b9(this.K, "Missed " + b + " lounge tokens.")
    };
    g.k.j7 = function(a) {
        b9(this.K, "Requesting lounge tokens failed: " + a)
    };
    g.w(mBb, g.zG);
    g.k = mBb.prototype;
    g.k.start = function() {
        var a = parseInt(g.pD("yt-remote-fast-check-period") || "0", 10);
        (this.D = g.nb() - 144E5 < a ? 0 : a) ? k9(this): (this.D = g.nb() + 3E5, g.oD("yt-remote-fast-check-period", this.D), this.XQ())
    };
    g.k.isEmpty = function() {
        return g.nd(this.j)
    };
    g.k.update = function() {
        lBb("Updating availability on schedule.");
        var a = this.K(),
            b = g.cd(this.j, function(c, d) {
                return c && !!h8(a, d)
            }, this);
        pBb(this, b)
    };
    g.k.xa = function() {
        g.uC(this.C);
        this.C = NaN;
        this.B && (this.B.abort(), this.B = null);
        g.zG.prototype.xa.call(this)
    };
    g.k.XQ = function() {
        g.uC(this.C);
        this.C = NaN;
        this.B && this.B.abort();
        var a = qBb(this);
        if (gyb(a)) {
            var b = $8(this.G, "/pairing/get_screen_availability");
            this.B = TAb(this.G, b, {
                lounge_token: g.id(a).join(",")
            }, (0, g.jb)(this.V$, this, a), (0, g.jb)(this.U$, this))
        } else pBb(this, {}), k9(this)
    };
    g.k.V$ = function(a, b) {
        this.B = null;
        var c = g.id(qBb(this));
        if (g.Zb(c, g.id(a))) {
            b = b.screens || [];
            c = {};
            for (var d = b.length, e = 0; e < d; ++e) c[a[b[e].loungeToken]] = "online" == b[e].status;
            pBb(this, c);
            k9(this)
        } else this.cg("Changing Screen set during request."), this.XQ()
    };
    g.k.U$ = function(a) {
        this.cg("Screen availability failed: " + a);
        this.B = null;
        k9(this)
    };
    g.k.cg = function(a) {
        b9("OnlineScreenService", a)
    };
    g.ob(l9, g9);
    g.k = l9.prototype;
    g.k.start = function() {
        this.B.start();
        this.j.start();
        this.screens.length && (this.oa("screenChange"), this.j.isEmpty() || this.oa("onlineScreenChange"))
    };
    g.k.add = function(a, b, c) {
        this.B.add(a, b, c)
    };
    g.k.remove = function(a, b, c) {
        this.B.remove(a, b, c);
        this.j.update()
    };
    g.k.QK = function(a, b, c, d) {
        this.B.contains(a) ? this.B.QK(a, b, c, d) : (a = "Updating name of unknown screen: " + a.name, b9(this.K, a), d(Error(a)))
    };
    g.k.Nk = function(a) {
        return a ? this.screens : g.Kb(this.screens, g.Bt(this.C, function(b) {
            return !this.contains(b)
        }, this))
    };
    g.k.kT = function() {
        return g.Bt(this.Nk(!0), function(a) {
            return !!this.j.j[a.id]
        }, this)
    };
    g.k.lT = function(a, b, c, d, e, f) {
        var h = this;
        this.info("getDialScreenByPairingCode " + a + " / " + b);
        var l = new jBb(this.D, a, b, c, d);
        l.subscribe("pairingComplete", function(m, n) {
            g.vb(l);
            e(m9(h, m), n)
        });
        l.subscribe("pairingFailed", function(m) {
            g.vb(l);
            f(m)
        });
        l.start();
        return (0, g.jb)(l.stop, l)
    };
    g.k.V2 = function(a, b, c, d) {
        g.xC($8(this.D, "/pairing/get_screen"), {
            method: "POST",
            postParams: {
                pairing_code: a
            },
            timeout: 5E3,
            onSuccess: (0, g.jb)(function(e, f) {
                e = new e8(f.screen || {});
                if (!e.name || uBb(this, e.name)) {
                    a: {
                        f = e.name;
                        for (var h = 2, l = b(f, h); uBb(this, l);) {
                            h++;
                            if (20 < h) break a;
                            l = b(f, h)
                        }
                        f = l
                    }
                    e.name = f
                }
                c(m9(this, e))
            }, this),
            onError: (0, g.jb)(function(e) {
                d(Error("pairing request failed: " + e.status))
            }, this),
            onTimeout: (0, g.jb)(function() {
                d(Error("pairing request timed out."))
            }, this)
        })
    };
    g.k.xa = function() {
        g.vb(this.B);
        g.vb(this.j);
        l9.Lf.xa.call(this)
    };
    g.k.u7 = function() {
        wBb(this);
        this.oa("screenChange");
        this.j.update()
    };
    l9.prototype.dispose = l9.prototype.dispose;
    g.ob(n9, g.zG);
    g.k = n9.prototype;
    g.k.Aj = function(a) {
        this.isDisposed() || (a && (p9(this, "" + a), this.oa("sessionFailed")), this.j = null, this.oa("sessionScreen", null))
    };
    g.k.info = function(a) {
        b9(this.Ga, a)
    };
    g.k.mT = function() {
        return null
    };
    g.k.pR = function(a) {
        var b = this.B;
        a ? (b.displayStatus = new chrome.cast.ReceiverDisplayStatus(a, []), b.displayStatus.showStop = !0) : b.displayStatus = null;
        chrome.cast.setReceiverDisplayStatus(b, (0, g.jb)(function() {
            this.info("Updated receiver status for " + b.friendlyName + ": " + a)
        }, this), (0, g.jb)(function() {
            p9(this, "Failed to update receiver status for: " + b.friendlyName)
        }, this))
    };
    g.k.xa = function() {
        this.pR("");
        n9.Lf.xa.call(this)
    };
    g.w(q9, n9);
    g.k = q9.prototype;
    g.k.nR = function(a) {
        if (this.C) {
            if (this.C == a) return;
            p9(this, "Overriding cast session with new session object");
            IBb(this);
            this.Ba = !1;
            this.X = "unknown";
            this.C.removeUpdateListener(this.ra);
            this.C.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.Ea)
        }
        this.C = a;
        this.C.addUpdateListener(this.ra);
        this.C.addMessageListener("urn:x-cast:com.google.youtube.mdx", this.Ea);
        DBb(this, "getMdxSessionStatus")
    };
    g.k.Lz = function(a) {
        this.info("launchWithParams no-op for Cast: " + g.an(a))
    };
    g.k.stop = function() {
        this.C ? this.C.stop((0, g.jb)(function() {
            this.Aj()
        }, this), (0, g.jb)(function() {
            this.Aj(Error("Failed to stop receiver app."))
        }, this)) : this.Aj(Error("Stopping cast device without session."))
    };
    g.k.pR = function() {};
    g.k.xa = function() {
        this.info("disposeInternal");
        IBb(this);
        this.C && (this.C.removeUpdateListener(this.ra), this.C.removeMessageListener("urn:x-cast:com.google.youtube.mdx", this.Ea));
        this.C = null;
        n9.prototype.xa.call(this)
    };
    g.k.Iaa = function(a, b) {
        if (!this.isDisposed())
            if (b)
                if (b = c8(b), g.cb(b)) switch (a = "" + b.type, b = b.data || {}, this.info("onYoutubeMessage_: " + a + " " + g.an(b)), a) {
                    case "mdxSessionStatus":
                        ABb(this, b);
                        break;
                    case "loungeToken":
                        EBb(this, b);
                        break;
                    default:
                        p9(this, "Unknown youtube message: " + a)
                } else p9(this, "Unable to parse message.");
                else p9(this, "No data in message.")
    };
    g.k.FW = function(a, b, c, d) {
        g.uC(this.Z);
        this.Z = 0;
        tBb(this.D, this.B.label, a, this.B.friendlyName, (0, g.jb)(function(e) {
            e ? b(e) : 0 <= d ? (p9(this, "Screen " + a + " appears to be offline. " + d + " retries left."), this.Z = g.sC((0, g.jb)(this.FW, this, a, b, c, d - 1), 300)) : c(Error("Unable to fetch screen."))
        }, this), c)
    };
    g.k.mT = function() {
        return this.C
    };
    g.k.W2 = function(a) {
        this.isDisposed() || a || (p9(this, "Cast session died."), this.Aj())
    };
    g.w(r9, n9);
    g.k = r9.prototype;
    g.k.nR = function(a) {
        this.C = a;
        this.C.addUpdateListener(this.La)
    };
    g.k.Lz = function(a) {
        this.Na = a;
        this.ma()
    };
    g.k.stop = function() {
        QBb(this);
        this.C ? this.C.stop((0, g.jb)(this.Aj, this, null), (0, g.jb)(this.Aj, this, "Failed to stop DIAL device.")) : this.Aj()
    };
    g.k.xa = function() {
        QBb(this);
        this.C && this.C.removeUpdateListener(this.La);
        this.C = null;
        n9.prototype.xa.call(this)
    };
    g.k.X2 = function(a) {
        this.isDisposed() || a || (p9(this, "DIAL session died."), this.G(), this.G = function() {}, this.Aj())
    };
    g.w(u9, n9);
    u9.prototype.stop = function() {
        this.Aj()
    };
    u9.prototype.nR = function() {};
    u9.prototype.Lz = function() {
        g.uC(this.C);
        this.C = NaN;
        var a = h8(this.D.Nk(), this.B.label);
        a ? o9(this, a) : this.Aj(Error("No such screen"))
    };
    u9.prototype.xa = function() {
        g.uC(this.C);
        this.C = NaN;
        n9.prototype.xa.call(this)
    };
    g.w(v9, g.zG);
    g.k = v9.prototype;
    g.k.init = function(a, b) {
        chrome.cast.timeout.requestSession = 3E4;
        var c = new chrome.cast.SessionRequest(this.Z, [chrome.cast.Capability.AUDIO_OUT]);
        this.X || (c.dialRequest = new chrome.cast.DialRequest("YouTube"));
        var d = chrome.cast.AutoJoinPolicy.TAB_AND_ORIGIN_SCOPED;
        a = a || this.K ? chrome.cast.DefaultActionPolicy.CAST_THIS_TAB : chrome.cast.DefaultActionPolicy.CREATE_SESSION;
        var e = (0, g.jb)(this.E$, this);
        c = new chrome.cast.ApiConfig(c, (0, g.jb)(this.hZ, this), e, d, a);
        c.customDialLaunchCallback = (0, g.jb)(this.B9, this);
        chrome.cast.initialize(c, (0, g.jb)(function() {
            this.isDisposed() || (chrome.cast.addReceiverActionListener(this.G), cBb(), this.B.subscribe("onlineScreenChange", (0, g.jb)(this.nT, this)), this.C = TBb(this), chrome.cast.setCustomReceivers(this.C, function() {}, (0, g.jb)(function(f) {
                this.cg("Failed to set initial custom receivers: " + g.an(f))
            }, this)), this.oa("yt-remote-cast2-availability-change", x9(this)), b(!0))
        }, this), (0, g.jb)(function(f) {
            this.cg("Failed to initialize API: " + g.an(f));
            b(!1)
        }, this))
    };
    g.k.Uba = function(a, b) {
        w9("Setting connected screen ID: " + a + " -> " + b);
        if (this.j) {
            var c = this.j.j;
            if (!a || c && c.id != a) w9("Unsetting old screen status: " + this.j.B.friendlyName), y9(this, null)
        }
        if (a && b) {
            if (!this.j) {
                a = h8(this.B.Nk(), a);
                if (!a) {
                    w9("setConnectedScreenStatus: Unknown screen.");
                    return
                }
                if ("shortLived" == a.idType) {
                    w9("setConnectedScreenStatus: Screen with id type to be short lived.");
                    return
                }
                c = RBb(this, a);
                c || (w9("setConnectedScreenStatus: Connected receiver not custom..."), c = new chrome.cast.Receiver(a.uuid ?
                    a.uuid : a.id, a.name), c.receiverType = chrome.cast.ReceiverType.CUSTOM, this.C.push(c), chrome.cast.setCustomReceivers(this.C, function() {}, (0, g.jb)(function(d) {
                    this.cg("Failed to set initial custom receivers: " + g.an(d))
                }, this)));
                w9("setConnectedScreenStatus: new active receiver: " + c.friendlyName);
                y9(this, new u9(this.B, c), !0)
            }
            this.j.pR(b)
        } else w9("setConnectedScreenStatus: no screen.")
    };
    g.k.Xba = function(a) {
        this.isDisposed() ? this.cg("Setting connection data on disposed cast v2") : this.j ? this.j.Lz(a) : this.cg("Setting connection data without a session")
    };
    g.k.Z2 = function() {
        this.isDisposed() ? this.cg("Stopping session on disposed cast v2") : this.j ? (this.j.stop(), y9(this, null)) : w9("Stopping non-existing session")
    };
    g.k.requestSession = function() {
        chrome.cast.requestSession((0, g.jb)(this.hZ, this), (0, g.jb)(this.Y$, this))
    };
    g.k.xa = function() {
        this.B.unsubscribe("onlineScreenChange", (0, g.jb)(this.nT, this));
        window.chrome && chrome.cast && chrome.cast.removeReceiverActionListener(this.G);
        var a = $Ab,
            b = g.Va("yt.mdx.remote.debug.handlers_");
        g.Ib(b || [], a);
        g.vb(this.j);
        g.zG.prototype.xa.call(this)
    };
    g.k.cg = function(a) {
        b9("Controller", a)
    };
    g.k.jZ = function(a, b) {
        this.j == a && (b || y9(this, null), this.oa("yt-remote-cast2-session-change", b))
    };
    g.k.B$ = function(a, b) {
        if (!this.isDisposed())
            if (a) switch (a.friendlyName = chrome.cast.unescape(a.friendlyName), w9("onReceiverAction_ " + a.label + " / " + a.friendlyName + "-- " + b), b) {
                case chrome.cast.ReceiverAction.CAST:
                    if (this.j)
                        if (this.j.B.label != a.label) w9("onReceiverAction_: Stopping active receiver: " + this.j.B.friendlyName), this.j.stop();
                        else {
                            w9("onReceiverAction_: Casting to active receiver.");
                            this.j.j && this.oa("yt-remote-cast2-session-change", this.j.j);
                            break
                        }
                    switch (a.receiverType) {
                        case chrome.cast.ReceiverType.CUSTOM:
                            y9(this,
                                new u9(this.B, a));
                            break;
                        case chrome.cast.ReceiverType.DIAL:
                            y9(this, new r9(this.B, a, this.D, this.config_));
                            break;
                        case chrome.cast.ReceiverType.CAST:
                            y9(this, new q9(this.B, a, this.config_));
                            break;
                        default:
                            this.cg("Unknown receiver type: " + a.receiverType)
                    }
                    break;
                case chrome.cast.ReceiverAction.STOP:
                    this.j && this.j.B.label == a.label ? this.j.stop() : this.cg("Stopping receiver w/o session: " + a.friendlyName)
            } else this.cg("onReceiverAction_ called without receiver.")
    };
    g.k.B9 = function(a) {
        if (this.isDisposed()) return Promise.reject(Error("disposed"));
        var b = a.receiver;
        b.receiverType != chrome.cast.ReceiverType.DIAL && (this.cg("Not DIAL receiver: " + b.friendlyName), b.receiverType = chrome.cast.ReceiverType.DIAL);
        var c = this.j ? this.j.B : null;
        if (!c || c.label != b.label) return this.cg("Receiving DIAL launch request for non-clicked DIAL receiver: " + b.friendlyName), Promise.reject(Error("illegal DIAL launch"));
        if (c && c.label == b.label && c.receiverType != chrome.cast.ReceiverType.DIAL) {
            if (this.j.j) return w9("Reselecting dial screen."),
                this.oa("yt-remote-cast2-session-change", this.j.j), Promise.resolve(new chrome.cast.DialLaunchResponse(!1));
            this.cg('Changing CAST intent from "' + c.receiverType + '" to "dial" for ' + b.friendlyName);
            y9(this, new r9(this.B, b, this.D, this.config_))
        }
        b = this.j;
        b.Z = a;
        b.Z.appState == chrome.cast.DialAppState.RUNNING ? (a = b.Z.extraData || {}, c = a.screenId || null, s9(b) && a.loungeToken ? a.loungeTokenRefreshIntervalMs ? a = NBb(b, {
                name: b.B.friendlyName,
                screenId: a.screenId,
                loungeToken: a.loungeToken,
                dialId: b.Z.receiver.label,
                screenIdType: "shortLived"
            },
            a.loungeTokenRefreshIntervalMs) : (g.eC(Error("No loungeTokenRefreshIntervalMs presents in additionalData: " + JSON.stringify(a) + ".")), a = OBb(b, c)) : a = OBb(b, c)) : a = LBb(b);
        return a
    };
    g.k.hZ = function(a) {
        var b = this;
        if (!this.isDisposed() && !this.K) {
            w9("New cast session ID: " + a.sessionId);
            var c = a.receiver;
            if (c.receiverType != chrome.cast.ReceiverType.CUSTOM) {
                if (!this.j)
                    if (c.receiverType == chrome.cast.ReceiverType.CAST) w9("Got resumed cast session before resumed mdx connection."), c.friendlyName = chrome.cast.unescape(c.friendlyName), y9(this, new q9(this.B, c, this.config_), !0);
                    else {
                        this.cg("Got non-cast session without previous mdx receiver event, or mdx resume.");
                        return
                    }
                var d = this.j.B,
                    e = h8(this.B.Nk(),
                        d.label);
                e && f8(e, c.label) && d.receiverType != chrome.cast.ReceiverType.CAST && c.receiverType == chrome.cast.ReceiverType.CAST && (w9("onSessionEstablished_: manual to cast session change " + c.friendlyName), g.vb(this.j), this.j = new q9(this.B, c, this.config_), this.j.subscribe("sessionScreen", (0, g.jb)(this.jZ, this, this.j)), this.j.subscribe("sessionFailed", function() {
                    return SBb(b, b.j)
                }), this.j.Lz(null));
                this.j.nR(a)
            }
        }
    };
    g.k.Y2 = function() {
        return this.j ? this.j.mT() : null
    };
    g.k.Y$ = function(a) {
        this.isDisposed() || (this.cg("Failed to estabilish a session: " + g.an(a)), a.code != chrome.cast.ErrorCode.CANCEL && y9(this, null), this.oa("yt-remote-cast2-session-failed"))
    };
    g.k.E$ = function(a) {
        w9("Receiver availability updated: " + a);
        if (!this.isDisposed()) {
            var b = x9(this);
            this.N = a == chrome.cast.ReceiverAvailability.AVAILABLE;
            x9(this) != b && this.oa("yt-remote-cast2-availability-change", x9(this))
        }
    };
    g.k.nT = function() {
        this.isDisposed() || (this.C = TBb(this), w9("Updating custom receivers: " + g.an(this.C)), chrome.cast.setCustomReceivers(this.C, function() {}, (0, g.jb)(function() {
            this.cg("Failed to set custom receivers.")
        }, this)), this.oa("yt-remote-cast2-availability-change", x9(this)))
    };
    v9.prototype.setLaunchParams = v9.prototype.Xba;
    v9.prototype.setConnectedScreenStatus = v9.prototype.Uba;
    v9.prototype.stopSession = v9.prototype.Z2;
    v9.prototype.getCastSession = v9.prototype.Y2;
    v9.prototype.requestSession = v9.prototype.requestSession;
    v9.prototype.init = v9.prototype.init;
    v9.prototype.dispose = v9.prototype.dispose;
    var bCb = [];
    g.k = F9.prototype;
    g.k.reset = function(a) {
        this.listId = "";
        this.index = -1;
        this.videoId = "";
        hCb(this);
        this.volume = -1;
        this.muted = !1;
        a && (this.index = a.index, this.listId = a.listId, this.videoId = a.videoId, this.playerState = a.playerState, this.volume = a.volume, this.muted = a.muted, this.audioTrackId = a.audioTrackId, this.trackData = a.trackData, this.xp = a.hasPrevious, this.Qk = a.hasNext, this.N = a.playerTime, this.K = a.playerTimeAt, this.D = a.seekableStart, this.j = a.seekableEnd, this.G = a.duration, this.Z = a.loadedTime, this.C = a.liveIngestionTime, this.B = !isNaN(this.C))
    };
    g.k.isPlaying = function() {
        return 1 == this.playerState
    };
    g.k.ql = function(a) {
        this.G = isNaN(a) ? 0 : a
    };
    g.k.getDuration = function() {
        return this.B ? this.G + G9(this) : this.G
    };
    g.k.clone = function() {
        return new F9(iCb(this))
    };
    g.w(L9, g.zG);
    g.k = L9.prototype;
    g.k.getState = function() {
        return this.C
    };
    g.k.Os = function() {
        return this.D.getReconnectTimeout()
    };
    g.k.Mw = function() {
        this.D.reconnect()
    };
    g.k.play = function() {
        N9(this) ? (this.j ? this.j.play(null, g.Rd, R9(this, "play")) : Q9(this, "play"), lCb(this, 1, I9(M9(this))), this.oa("remotePlayerChange")) : O9(this, this.play)
    };
    g.k.pause = function() {
        N9(this) ? (this.j ? this.j.pause(null, g.Rd, R9(this, "pause")) : Q9(this, "pause"), lCb(this, 2, I9(M9(this))), this.oa("remotePlayerChange")) : O9(this, this.pause)
    };
    g.k.seekTo = function(a) {
        if (N9(this)) {
            if (this.j) {
                var b = M9(this),
                    c = new chrome.cast.media.SeekRequest;
                c.currentTime = a;
                b.isPlaying() || 3 == b.playerState ? c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_START : c.resumeState = chrome.cast.media.ResumeState.PLAYBACK_PAUSE;
                this.j.seek(c, g.Rd, R9(this, "seekTo", {
                    newTime: a
                }))
            } else Q9(this, "seekTo", {
                newTime: a
            });
            lCb(this, 3, a);
            this.oa("remotePlayerChange")
        } else O9(this, g.kb(this.seekTo, a))
    };
    g.k.stop = function() {
        if (N9(this)) {
            this.j ? this.j.stop(null, g.Rd, R9(this, "stopVideo")) : Q9(this, "stopVideo");
            var a = M9(this);
            a.index = -1;
            a.videoId = "";
            hCb(a);
            P9(this, a);
            this.oa("remotePlayerChange")
        } else O9(this, this.stop)
    };
    g.k.setVolume = function(a, b) {
        if (N9(this)) {
            var c = M9(this);
            if (this.B) {
                if (c.volume != a) {
                    var d = Math.round(a) / 100;
                    this.B.setReceiverVolumeLevel(d, (0, g.jb)(function() {
                        c9("set receiver volume: " + d)
                    }, this), (0, g.jb)(function() {
                        this.cg("failed to set receiver volume.")
                    }, this))
                }
                c.muted != b && this.B.setReceiverMuted(b, (0, g.jb)(function() {
                    c9("set receiver muted: " + b)
                }, this), (0, g.jb)(function() {
                    this.cg("failed to set receiver muted.")
                }, this))
            } else {
                var e = {
                    volume: a,
                    muted: b
                }; - 1 != c.volume && (e.delta = a - c.volume);
                Q9(this, "setVolume", e)
            }
            c.muted = b;
            c.volume = a;
            P9(this, c)
        } else O9(this, g.kb(this.setVolume, a, b))
    };
    g.k.oT = function(a, b) {
        if (N9(this)) {
            var c = M9(this);
            a = {
                videoId: a
            };
            b && (c.trackData = {
                trackName: b.name,
                languageCode: b.languageCode,
                sourceLanguageCode: b.translationLanguage ? b.translationLanguage.languageCode : "",
                languageName: b.languageName,
                kind: b.kind
            }, a.style = g.an(b.style), g.vd(a, c.trackData));
            Q9(this, "setSubtitlesTrack", a);
            P9(this, c)
        } else O9(this, g.kb(this.oT, a, b))
    };
    g.k.setAudioTrack = function(a, b) {
        N9(this) ? (b = b.getLanguageInfo().getId(), Q9(this, "setAudioTrack", {
            videoId: a,
            audioTrackId: b
        }), a = M9(this), a.audioTrackId = b, P9(this, a)) : O9(this, g.kb(this.setAudioTrack, a, b))
    };
    g.k.playVideo = function(a, b, c, d, e, f, h) {
        d = void 0 === d ? null : d;
        e = void 0 === e ? null : e;
        f = void 0 === f ? null : f;
        h = void 0 === h ? null : h;
        var l = M9(this),
            m = {
                videoId: a
            };
        void 0 !== c && (m.currentIndex = c);
        J9(l, a, c || 0);
        void 0 !== b && (H9(l, b), m.currentTime = b);
        d && (m.listId = d);
        e && (m.playerParams = e);
        f && (m.clickTrackingParams = f);
        h && (m.locationInfo = g.an(h));
        Q9(this, "setPlaylist", m);
        d || P9(this, l)
    };
    g.k.OJ = function(a, b) {
        if (N9(this)) {
            if (a && b) {
                var c = M9(this);
                J9(c, a, b);
                P9(this, c)
            }
            Q9(this, "previous")
        } else O9(this, g.kb(this.OJ, a, b))
    };
    g.k.nextVideo = function(a, b) {
        if (N9(this)) {
            if (a && b) {
                var c = M9(this);
                J9(c, a, b);
                P9(this, c)
            }
            Q9(this, "next")
        } else O9(this, g.kb(this.nextVideo, a, b))
    };
    g.k.SG = function() {
        if (N9(this)) {
            Q9(this, "clearPlaylist");
            var a = M9(this);
            a.reset();
            P9(this, a);
            this.oa("remotePlayerChange")
        } else O9(this, this.SG)
    };
    g.k.LV = function() {
        N9(this) ? Q9(this, "dismissAutoplay") : O9(this, this.LV)
    };
    g.k.dispose = function() {
        if (3 != this.C) {
            var a = this.C;
            this.C = 3;
            this.oa("proxyStateChange", a, this.C)
        }
        g.zG.prototype.dispose.call(this)
    };
    g.k.xa = function() {
        kCb(this);
        this.D = null;
        this.G.clear();
        K9(this, null);
        g.zG.prototype.xa.call(this)
    };
    g.k.uR = function(a) {
        if ((a != this.C || 2 == a) && 3 != this.C && 0 != a) {
            var b = this.C;
            this.C = a;
            this.oa("proxyStateChange", b, a);
            if (1 == a)
                for (; !this.G.isEmpty();) b = a = this.G, 0 === b.j.length && (b.j = b.B, b.j.reverse(), b.B = []), a.j.pop().apply(this);
            else 3 == a && this.dispose()
        }
    };
    g.k.z$ = function(a, b) {
        this.oa(a, b)
    };
    g.k.r9 = function(a) {
        if (!a) this.mE(null), K9(this, null);
        else if (this.B.receiver.volume) {
            a = this.B.receiver.volume;
            var b = M9(this),
                c = Math.round(100 * a.level || 0);
            if (b.volume != c || b.muted != a.muted) c9("Cast volume update: " + a.level + (a.muted ? " muted" : "")), b.volume = c, b.muted = !!a.muted, P9(this, b)
        }
    };
    g.k.mE = function(a) {
        c9("Cast media: " + !!a);
        this.j && this.j.removeUpdateListener(this.Z);
        if (this.j = a) this.j.addUpdateListener(this.Z), mCb(this), this.oa("remotePlayerChange")
    };
    g.k.q9 = function(a) {
        a ? (mCb(this), this.oa("remotePlayerChange")) : this.mE(null)
    };
    g.k.TR = function() {
        Q9(this, "sendDebugCommand", {
            debugCommand: "stats4nerds "
        })
    };
    g.k.u9 = function() {
        var a = eCb();
        a && K9(this, a)
    };
    g.k.cg = function(a) {
        b9("CP", a)
    };
    g.w(U9, g.zG);
    g.k = U9.prototype;
    g.k.connect = function(a, b) {
        if (b) {
            var c = b.listId,
                d = b.videoId,
                e = b.videoIds,
                f = b.playerParams,
                h = b.clickTrackingParams,
                l = b.index,
                m = {
                    videoId: d
                },
                n = b.currentTime,
                p = b.locationInfo;
            b = b.loopMode;
            void 0 !== n && (m.currentTime = 5 >= n ? 0 : n);
            f && (m.playerParams = f);
            p && (m.locationInfo = p);
            h && (m.clickTrackingParams = h);
            c && (m.listId = c);
            e && 0 < e.length && (m.videoIds = e.join(","));
            void 0 !== l && (m.currentIndex = l);
            this.La && (m.loopMode = b || "LOOP_MODE_OFF");
            c && (this.j.listId = c);
            this.j.videoId = d;
            this.j.index = l || 0;
            this.j.state = 3;
            H9(this.j,
                n);
            this.G = "UNSUPPORTED";
            c = this.La ? "setInitialState" : "setPlaylist";
            S9("Connecting with " + c + " and params: " + g.an(m));
            this.B.connect({
                method: c,
                params: g.an(m)
            }, a, Pyb())
        } else S9("Connecting without params"), this.B.connect({}, a, Pyb());
        qCb(this)
    };
    g.k.yr = function(a) {
        this.B.yr(a)
    };
    g.k.dispose = function() {
        this.isDisposed() || (g.Ua("yt.mdx.remote.remoteClient_", null), this.oa("beforeDispose"), T9(this, 3));
        g.zG.prototype.dispose.call(this)
    };
    g.k.xa = function() {
        rCb(this);
        tCb(this);
        sCb(this);
        g.uC(this.Z);
        this.Z = NaN;
        g.uC(this.X);
        this.X = NaN;
        this.D = null;
        g.gD(this.ma);
        this.ma.length = 0;
        this.B.dispose();
        g.zG.prototype.xa.call(this);
        this.G = this.N = this.C = this.j = this.B = null
    };
    g.k.DX = function(a) {
        if (!this.C || 0 === this.C.length) return !1;
        for (var b = g.u(this.C), c = b.next(); !c.done; c = b.next())
            if (!c.value.capabilities.has(a)) return !1;
        return !0
    };
    g.k.R6 = function() {
        var a = 3;
        this.isDisposed() || (a = 0, isNaN(this.oD()) ? this.B.Az() && isNaN(this.K) && (a = 1) : a = 2);
        return a
    };
    g.k.Ty = function(a) {
        S9("Disconnecting with " + a);
        g.Ua("yt.mdx.remote.remoteClient_", null);
        rCb(this);
        this.oa("beforeDisconnect", a);
        1 == a && k8();
        this.B.disconnect(a);
        this.dispose()
    };
    g.k.N6 = function() {
        var a = this.j;
        this.D && (a = this.j.clone(), J9(a, this.D, a.index));
        return iCb(a)
    };
    g.k.Zba = function(a) {
        var b = this,
            c = new F9(a);
        c.videoId && c.videoId != this.j.videoId && (this.D = c.videoId, g.uC(this.Z), this.Z = g.sC(function() {
            if (b.D) {
                var e = b.D;
                b.D = null;
                b.j.videoId != e && V9(b, "getNowPlaying")
            }
        }, 5E3));
        var d = [];
        this.j.listId == c.listId && this.j.videoId == c.videoId && this.j.index == c.index || d.push("remoteQueueChange");
        this.j.playerState == c.playerState && this.j.volume == c.volume && this.j.muted == c.muted && I9(this.j) == I9(c) && g.an(this.j.trackData) == g.an(c.trackData) || d.push("remotePlayerChange");
        this.j.reset(a);
        g.cc(d, function(e) {
            this.oa(e)
        }, this)
    };
    g.k.yW = function() {
        var a = this.B.Js(),
            b = g.Db(this.C, function(c) {
                return "REMOTE_CONTROL" == c.type && c.id != a
            });
        return b ? b.id : ""
    };
    g.k.oD = function() {
        return this.B.Os()
    };
    g.k.y6 = function() {
        return this.G || "UNSUPPORTED"
    };
    g.k.z6 = function() {
        return this.N || ""
    };
    g.k.b3 = function() {
        !isNaN(this.oD()) && this.B.Mw()
    };
    g.k.Sba = function(a, b) {
        V9(this, a, b);
        vCb(this)
    };
    g.k.pT = function() {
        var a = g.HC("SID", "") || "",
            b = g.HC("SAPISID", "") || "",
            c = g.HC("__Secure-3PAPISID", "") || "";
        if (!a && !b && !c) return "";
        a = g.qg(g.pg(a), 2);
        b = g.qg(g.pg(b), 2);
        c = g.qg(g.pg(c), 2);
        return g.qg(g.pg(a + "," + b + "," + c), 2)
    };
    U9.prototype.subscribe = U9.prototype.subscribe;
    U9.prototype.unsubscribeByKey = U9.prototype.Eh;
    U9.prototype.getProxyState = U9.prototype.R6;
    U9.prototype.disconnect = U9.prototype.Ty;
    U9.prototype.getPlayerContextData = U9.prototype.N6;
    U9.prototype.setPlayerContextData = U9.prototype.Zba;
    U9.prototype.getOtherConnectedRemoteId = U9.prototype.yW;
    U9.prototype.getReconnectTimeout = U9.prototype.oD;
    U9.prototype.getAutoplayMode = U9.prototype.y6;
    U9.prototype.getAutoplayVideoId = U9.prototype.z6;
    U9.prototype.reconnect = U9.prototype.b3;
    U9.prototype.sendMessage = U9.prototype.Sba;
    U9.prototype.getXsrfToken = U9.prototype.pT;
    U9.prototype.isCapabilitySupportedOnConnectedDevices = U9.prototype.DX;
    g.w(HCb, g9);
    g.k = HCb.prototype;
    g.k.Nk = function(a) {
        return this.dh.$_gs(a)
    };
    g.k.contains = function(a) {
        return !!this.dh.$_c(a)
    };
    g.k.get = function(a) {
        return this.dh.$_g(a)
    };
    g.k.start = function() {
        this.dh.$_st()
    };
    g.k.add = function(a, b, c) {
        this.dh.$_a(a, b, c)
    };
    g.k.remove = function(a, b, c) {
        this.dh.$_r(a, b, c)
    };
    g.k.QK = function(a, b, c, d) {
        this.dh.$_un(a, b, c, d)
    };
    g.k.xa = function() {
        for (var a = 0, b = this.j.length; a < b; ++a) this.dh.$_ubk(this.j[a]);
        this.j.length = 0;
        this.dh = null;
        g9.prototype.xa.call(this)
    };
    g.k.d3 = function() {
        this.oa("screenChange")
    };
    g.k.h$ = function() {
        this.oa("onlineScreenChange")
    };
    l9.prototype.$_st = l9.prototype.start;
    l9.prototype.$_gspc = l9.prototype.V2;
    l9.prototype.$_gsppc = l9.prototype.lT;
    l9.prototype.$_c = l9.prototype.contains;
    l9.prototype.$_g = l9.prototype.get;
    l9.prototype.$_a = l9.prototype.add;
    l9.prototype.$_un = l9.prototype.QK;
    l9.prototype.$_r = l9.prototype.remove;
    l9.prototype.$_gs = l9.prototype.Nk;
    l9.prototype.$_gos = l9.prototype.kT;
    l9.prototype.$_s = l9.prototype.subscribe;
    l9.prototype.$_ubk = l9.prototype.Eh;
    var f$ = null,
        i$ = !1,
        W9 = null,
        X9 = null,
        SCb = null,
        a$ = [];
    g.w(XCb, g.I);
    g.k = XCb.prototype;
    g.k.xa = function() {
        g.I.prototype.xa.call(this);
        this.j.stop();
        this.B.stop();
        this.N.stop();
        var a = this.Fc;
        a.unsubscribe("proxyStateChange", this.gZ, this);
        a.unsubscribe("remotePlayerChange", this.sE, this);
        a.unsubscribe("remoteQueueChange", this.xJ, this);
        a.unsubscribe("previousNextChange", this.dZ, this);
        a.unsubscribe("nowAutoplaying", this.YY, this);
        a.unsubscribe("autoplayDismissed", this.DY, this);
        this.Fc = this.module = null
    };
    g.k.Pk = function(a) {
        var b = g.Ia.apply(1, arguments);
        if (2 != this.Fc.C)
            if (j$(this)) {
                if (1081 != M9(this.Fc).playerState || "control_seek" !== a) switch (a) {
                    case "control_toggle_play_pause":
                        M9(this.Fc).isPlaying() ? this.Fc.pause() : this.Fc.play();
                        break;
                    case "control_play":
                        this.Fc.play();
                        break;
                    case "control_pause":
                        this.Fc.pause();
                        break;
                    case "control_seek":
                        this.K.rL(b[0], b[1]);
                        break;
                    case "control_subtitles_set_track":
                        ZCb(this, b[0]);
                        break;
                    case "control_set_audio_track":
                        this.setAudioTrack(b[0])
                }
            } else switch (a) {
                case "control_toggle_play_pause":
                case "control_play":
                case "control_pause":
                    b =
                        this.J.getCurrentTime();
                    k$(this, 0 === b ? void 0 : b);
                    break;
                case "control_seek":
                    k$(this, b[0]);
                    break;
                case "control_subtitles_set_track":
                    ZCb(this, b[0]);
                    break;
                case "control_set_audio_track":
                    this.setAudioTrack(b[0])
            }
    };
    g.k.o9 = function(a) {
        this.N.A2(a)
    };
    g.k.Wca = function(a) {
        this.Pk("control_subtitles_set_track", g.nd(a) ? null : a)
    };
    g.k.R_ = function() {
        var a = this.J.getOption("captions", "track");
        g.nd(a) || ZCb(this, a)
    };
    g.k.Lc = function(a) {
        this.module.Lc(a, this.J.getVideoData().lengthSeconds)
    };
    g.k.S9 = function() {
        g.nd(this.C) || $Cb(this, this.C);
        this.D = !1
    };
    g.k.gZ = function(a, b) {
        this.B.stop();
        2 === b && this.J_()
    };
    g.k.sE = function() {
        if (j$(this)) {
            this.j.stop();
            var a = M9(this.Fc);
            switch (a.playerState) {
                case 1080:
                case 1081:
                case 1084:
                case 1085:
                    this.module.Qh = 1;
                    break;
                case 1082:
                case 1083:
                    this.module.Qh = 0;
                    break;
                default:
                    this.module.Qh = -1
            }
            switch (a.playerState) {
                case 1081:
                case 1:
                    this.Cc(new g.YL(8));
                    this.I_();
                    break;
                case 1085:
                case 3:
                    this.Cc(new g.YL(9));
                    break;
                case 1083:
                case 0:
                    this.Cc(new g.YL(2));
                    this.K.stop();
                    this.Lc(this.J.getVideoData().lengthSeconds);
                    break;
                case 1084:
                    this.Cc(new g.YL(4));
                    break;
                case 2:
                    this.Cc(new g.YL(4));
                    this.Lc(I9(a));
                    break;
                case -1:
                    this.Cc(new g.YL(64));
                    break;
                case -1E3:
                    this.Cc(new g.YL(128, {
                        errorCode: "mdx.remoteerror",
                        errorMessage: "This video is not available for remote playback.",
                        uH: 2
                    }))
            }
            a = M9(this.Fc).trackData;
            var b = this.C;
            (a || b ? a && b && a.trackName == b.trackName && a.languageCode == b.languageCode && a.languageName == b.languageName && a.kind == b.kind : 1) || (this.C = a, $Cb(this, a));
            a = M9(this.Fc); - 1 === a.volume || Math.round(this.J.getVolume()) === a.volume && this.J.isMuted() === a.muted || this.Z.isActive() || this.B0()
        } else YCb(this)
    };
    g.k.dZ = function() {
        this.J.oa("mdxpreviousnextchange")
    };
    g.k.xJ = function() {
        j$(this) || YCb(this)
    };
    g.k.YY = function(a) {
        isNaN(a) || this.J.oa("mdxnowautoplaying", a)
    };
    g.k.DY = function() {
        this.J.oa("mdxautoplaycanceled")
    };
    g.k.setAudioTrack = function(a) {
        j$(this) && this.Fc.setAudioTrack(this.J.getVideoData(1).videoId, a)
    };
    g.k.seekTo = function(a, b) {
        -1 === M9(this.Fc).playerState ? k$(this, a) : b && this.Fc.seekTo(a)
    };
    g.k.B0 = function() {
        var a = this;
        if (j$(this)) {
            var b = M9(this.Fc);
            this.events.Pc(this.X);
            b.muted ? this.J.mute() : this.J.unMute();
            this.J.setVolume(b.volume);
            this.X = this.events.T(this.J, "onVolumeChange", function(c) {
                VCb(a, c)
            })
        }
    };
    g.k.I_ = function() {
        this.j.stop();
        if (!this.Fc.isDisposed()) {
            var a = M9(this.Fc);
            a.isPlaying() && this.Cc(new g.YL(8));
            this.Lc(I9(a));
            this.j.start()
        }
    };
    g.k.J_ = function() {
        this.B.stop();
        this.j.stop();
        var a = this.Fc.Os();
        2 == this.Fc.C && !isNaN(a) && this.B.start()
    };
    g.k.Cc = function(a) {
        this.B.stop();
        var b = this.G;
        if (!g.fCa(b, a)) {
            var c = g.pH(a, 2);
            c !== g.pH(this.G, 2) && this.J.bB(c);
            this.G = a;
            bDb(this.module, b, a)
        }
    };
    g.w(l$, g.V);
    l$.prototype.qd = function() {
        this.j.show()
    };
    l$.prototype.Pb = function() {
        this.j.hide()
    };
    l$.prototype.B = function() {
        m8("mdx-privacy-popup-cancel");
        this.Pb()
    };
    l$.prototype.C = function() {
        m8("mdx-privacy-popup-confirm");
        this.Pb()
    };
    g.w(m$, g.V);
    m$.prototype.onStateChange = function(a) {
        this.Dc(a.state)
    };
    m$.prototype.Dc = function(a) {
        if (3 === this.api.getPresentingPlayerType()) {
            var b = {
                RECEIVER_NAME: this.api.getOption("remote", "currentReceiver").name
            };
            a = g.pH(a, 128) ? g.GK("Error on $RECEIVER_NAME", b) : a.isPlaying() || a.isPaused() ? g.GK("Playing on $RECEIVER_NAME", b) : g.GK("Connected to $RECEIVER_NAME", b);
            this.updateValue("statustext", a);
            this.j.show()
        } else this.j.hide()
    };
    g.w(n$, g.UX);
    n$.prototype.D = function() {
        var a = this.J.getOption("remote", "receivers");
        a && 1 < a.length && !this.J.getOption("remote", "quickCast") ? (this.Nt = g.dc(a, this.j, this), g.VX(this, g.Nr(a, this.j)), a = this.J.getOption("remote", "currentReceiver"), a = this.j(a), this.options[a] && this.Kj(a), this.enable(!0)) : this.enable(!1)
    };
    n$.prototype.j = function(a) {
        return a.key
    };
    n$.prototype.zk = function(a) {
        return "cast-selector-receiver" === a ? "Cast..." : this.Nt[a].name
    };
    n$.prototype.kh = function(a) {
        g.UX.prototype.kh.call(this, a);
        this.J.setOption("remote", "currentReceiver", this.Nt[a]);
        this.Gb.Pb()
    };
    g.w(aDb, g.$V);
    g.k = aDb.prototype;
    g.k.create = function() {
        var a = this.player.U(),
            b = g.yS(a);
        a = {
            device: "Desktop",
            app: "youtube-desktop",
            loadCastApiSetupScript: a.L("mdx_load_cast_api_bootstrap_script"),
            enableDialLoungeToken: a.L("enable_dial_short_lived_lounge_token"),
            enableCastLoungeToken: a.L("enable_cast_short_lived_lounge_token")
        };
        MCb(b, a);
        this.subscriptions.push(g.dF("yt-remote-before-disconnect", this.m9, this));
        this.subscriptions.push(g.dF("yt-remote-connection-change", this.F$, this));
        this.subscriptions.push(g.dF("yt-remote-receiver-availability-change", this.fZ,
            this));
        this.subscriptions.push(g.dF("yt-remote-auto-connect", this.D$, this));
        this.subscriptions.push(g.dF("yt-remote-receiver-resumed", this.C$, this));
        this.subscriptions.push(g.dF("mdx-privacy-popup-confirm", this.eba, this));
        this.subscriptions.push(g.dF("mdx-privacy-popup-cancel", this.dba, this));
        this.fZ()
    };
    g.k.load = function() {
        this.player.cancelPlayback();
        g.$V.prototype.load.call(this);
        this.Ml = new XCb(this, this.player, this.Fc);
        var a = (a = UCb()) ? a.currentTime : 0;
        var b = RCb() ? new L9(e$(), void 0) : null;
        0 == a && b && (a = I9(M9(b)));
        0 !== a && this.Lc(a);
        bDb(this, this.Ge, this.Ge);
        this.player.Qp(6)
    };
    g.k.unload = function() {
        this.player.oa("mdxautoplaycanceled");
        this.xs = this.Ep;
        g.wb(this.Ml, this.Fc);
        this.Fc = this.Ml = null;
        g.$V.prototype.unload.call(this);
        this.player.Qp(5);
        o$(this)
    };
    g.k.xa = function() {
        g.eF(this.subscriptions);
        g.$V.prototype.xa.call(this)
    };
    g.k.oE = function(a) {
        var b = g.Ia.apply(1, arguments);
        this.loaded && this.Ml.Pk.apply(this.Ml, [a].concat(g.pa(b)))
    };
    g.k.getAdState = function() {
        return this.Qh
    };
    g.k.xp = function() {
        return this.Fc ? M9(this.Fc).xp : !1
    };
    g.k.Qk = function() {
        return this.Fc ? M9(this.Fc).Qk : !1
    };
    g.k.Lc = function(a, b) {
        this.PX = a || 0;
        this.player.oa("progresssync", a, b);
        this.player.wc("onVideoProgress", a || 0)
    };
    g.k.getCurrentTime = function() {
        return this.PX
    };
    g.k.getProgressState = function() {
        var a = M9(this.Fc),
            b = this.player.getVideoData();
        return {
            airingStart: 0,
            airingEnd: 0,
            allowSeeking: 1081 != a.playerState && this.player.Ph(),
            clipEnd: b.clipEnd,
            clipStart: b.clipStart,
            current: this.getCurrentTime(),
            displayedStart: -1,
            duration: a.getDuration(),
            ingestionTime: a.B ? a.C + G9(a) : a.C,
            isAtLiveHead: 1 >= (a.B ? a.j + G9(a) : a.j) - this.getCurrentTime(),
            loaded: a.Z,
            seekableEnd: a.B ? a.j + G9(a) : a.j,
            seekableStart: 0 < a.D ? a.D + G9(a) : a.D,
            offset: 0,
            viewerLivestreamJoinMediaTime: 0
        }
    };
    g.k.nextVideo = function() {
        this.Fc && this.Fc.nextVideo()
    };
    g.k.OJ = function() {
        this.Fc && this.Fc.OJ()
    };
    g.k.m9 = function(a) {
        1 === a && (this.EQ = this.Fc ? M9(this.Fc) : null)
    };
    g.k.F$ = function() {
        var a = RCb() ? new L9(e$(), void 0) : null;
        if (a) {
            var b = this.xs;
            this.loaded && this.unload();
            this.Fc = a;
            this.EQ = null;
            b.key !== this.Ep.key && (this.xs = b, this.load())
        } else g.vb(this.Fc), this.Fc = null, this.loaded && (this.unload(), (a = this.EQ) && a.videoId === this.player.getVideoData().videoId && this.player.cueVideoById(a.videoId, I9(a)));
        this.player.oa("videodatachange", "newdata", this.player.getVideoData(), 3)
    };
    g.k.fZ = function() {
        var a = [this.Ep],
            b = a.concat,
            c = NCb();
        C9() && g.pD("yt-remote-cast-available") && c.push({
            key: "cast-selector-receiver",
            name: "Cast..."
        });
        this.Nt = b.call(a, c);
        a = PCb() || this.Ep;
        p$(this, a);
        this.player.wc("onMdxReceiversChange")
    };
    g.k.D$ = function() {
        var a = PCb();
        p$(this, a)
    };
    g.k.C$ = function() {
        this.xs = PCb()
    };
    g.k.eba = function() {
        this.KE = !0;
        o$(this);
        i$ = !1;
        f$ && h$(f$, 1);
        f$ = null
    };
    g.k.dba = function() {
        this.KE = !1;
        o$(this);
        p$(this, this.Ep);
        this.xs = this.Ep;
        i$ = !1;
        f$ = null;
        this.player.playVideo()
    };
    g.k.Gh = function(a, b) {
        switch (a) {
            case "casting":
                return this.loaded;
            case "receivers":
                return this.Nt;
            case "currentReceiver":
                return b && ("cast-selector-receiver" === b.key ? fCb() : p$(this, b)), this.loaded ? this.xs : this.Ep;
            case "quickCast":
                return 2 === this.Nt.length && "cast-selector-receiver" === this.Nt[1].key ? (b && fCb(), !0) : !1
        }
    };
    g.k.TR = function() {
        this.Fc.TR()
    };
    g.k.rl = function() {
        return !1
    };
    g.k.getOptions = function() {
        return ["casting", "receivers", "currentReceiver", "quickCast"]
    };
    g.k.isLoggedIn = function() {
        var a, b;
        return void 0 !== (null == (a = g.$B("PLAYER_CONFIG")) ? void 0 : null == (b = a.args) ? void 0 : b.authuser) ? !0 : !(!g.$B("SESSION_INDEX") && !g.$B("LOGGED_IN"))
    };
    g.ZV("remote", aDb);
})(_yt_player);