"use strict";
(self.webpackChunkarbitrage_notification = self.webpackChunkarbitrage_notification || []).push([
    [6939], {
        26939: function(t, n, e) {
            e.d(n, {
                g: function() {
                    return ie
                }
            });
            var r = e(95330),
                i = e(47313),
                o = e(42461);

            function a(t) {
                return "undefined" !== typeof PointerEvent && t instanceof PointerEvent ? !("mouse" !== t.pointerType) : t instanceof MouseEvent
            }

            function u(t) {
                return !!t.touches
            }
            var s = {
                pageX: 0,
                pageY: 0
            };

            function l(t, n) {
                void 0 === n && (n = "page");
                var e = t.touches[0] || t.changedTouches[0] || s;
                return {
                    x: e[n + "X"],
                    y: e[n + "Y"]
                }
            }

            function c(t, n) {
                return void 0 === n && (n = "page"), {
                    x: t[n + "X"],
                    y: t[n + "Y"]
                }
            }

            function v(t, n) {
                return void 0 === n && (n = "page"), {
                    point: u(t) ? l(t, n) : c(t, n)
                }
            }
            var d = function(t, n) {
                    void 0 === n && (n = !1);
                    var e, r = function(n) {
                        return t(n, v(n))
                    };
                    return n ? (e = r, function(t) {
                        var n = t instanceof MouseEvent;
                        (!n || n && 0 === t.button) && e(t)
                    }) : r
                },
                f = e(28135),
                p = e(8175);

            function m(t, n, e, r) {
                return t.addEventListener(n, e, r),
                    function() {
                        return t.removeEventListener(n, e, r)
                    }
            }

            function h(t, n, e, r) {
                (0, i.useEffect)((function() {
                    var i = t.current;
                    if (e && i) return m(i, n, e, r)
                }), [t, n, e, r])
            }
            var g = e(88207),
                y = function() {
                    return g.j && null === window.onpointerdown
                },
                E = function() {
                    return g.j && null === window.ontouchstart
                },
                x = function() {
                    return g.j && null === window.onmousedown
                },
                P = {
                    pointerdown: "mousedown",
                    pointermove: "mousemove",
                    pointerup: "mouseup",
                    pointercancel: "mousecancel",
                    pointerover: "mouseover",
                    pointerout: "mouseout",
                    pointerenter: "mouseenter",
                    pointerleave: "mouseleave"
                },
                V = {
                    pointerdown: "touchstart",
                    pointermove: "touchmove",
                    pointerup: "touchend",
                    pointercancel: "touchcancel"
                };

            function w(t) {
                return y() ? t : E() ? V[t] : x() ? P[t] : t
            }

            function A(t, n, e, r) {
                return m(t, w(n), d(e, "pointerdown" === n), r)
            }

            function b(t, n, e, r) {
                return h(t, w(n), e && d(e, "pointerdown" === n), r)
            }
            var C = e(87988),
                T = e(45525),
                R = function() {
                    function t(t, n, e) {
                        var i = this,
                            o = (void 0 === e ? {} : e).transformPagePoint;
                        if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.updatePoint = function() {
                                if (i.lastMoveEvent && i.lastMoveEventInfo) {
                                    var t = L(i.lastMoveEventInfo, i.history),
                                        n = null !== i.startEvent,
                                        e = (0, C.T)(t.offset, {
                                            x: 0,
                                            y: 0
                                        }) >= 3;
                                    if (n || e) {
                                        var o = t.point,
                                            a = (0, f.$B)().timestamp;
                                        i.history.push((0, r.pi)((0, r.pi)({}, o), {
                                            timestamp: a
                                        }));
                                        var u = i.handlers,
                                            s = u.onStart,
                                            l = u.onMove;
                                        n || (s && s(i.lastMoveEvent, t), i.startEvent = i.lastMoveEvent), l && l(i.lastMoveEvent, t)
                                    }
                                }
                            }, this.handlePointerMove = function(t, n) {
                                i.lastMoveEvent = t, i.lastMoveEventInfo = S(n, i.transformPagePoint), a(t) && 0 === t.buttons ? i.handlePointerUp(t, n) : f.ZP.update(i.updatePoint, !0)
                            }, this.handlePointerUp = function(t, n) {
                                i.end();
                                var e = i.handlers,
                                    r = e.onEnd,
                                    o = e.onSessionEnd,
                                    a = L(S(n, i.transformPagePoint), i.history);
                                i.startEvent && r && r(t, a), o && o(t, a)
                            }, !(u(t) && t.touches.length > 1)) {
                            this.handlers = n, this.transformPagePoint = o;
                            var s = S(v(t), this.transformPagePoint),
                                l = s.point,
                                c = (0, f.$B)().timestamp;
                            this.history = [(0, r.pi)((0, r.pi)({}, l), {
                                timestamp: c
                            })];
                            var d = n.onSessionStart;
                            d && d(t, L(s, this.history)), this.removeListeners = (0, T.z)(A(window, "pointermove", this.handlePointerMove), A(window, "pointerup", this.handlePointerUp), A(window, "pointercancel", this.handlePointerUp))
                        }
                    }
                    return t.prototype.updateHandlers = function(t) {
                        this.handlers = t
                    }, t.prototype.end = function() {
                        this.removeListeners && this.removeListeners(), f.qY.update(this.updatePoint)
                    }, t
                }();

            function S(t, n) {
                return n ? {
                    point: n(t.point)
                } : t
            }

            function M(t, n) {
                return {
                    x: t.x - n.x,
                    y: t.y - n.y
                }
            }

            function L(t, n) {
                var e = t.point;
                return {
                    point: e,
                    delta: M(e, D(n)),
                    offset: M(e, k(n)),
                    velocity: I(n, .1)
                }
            }

            function k(t) {
                return t[0]
            }

            function D(t) {
                return t[t.length - 1]
            }

            function I(t, n) {
                if (t.length < 2) return {
                    x: 0,
                    y: 0
                };
                for (var e = t.length - 1, r = null, i = D(t); e >= 0 && (r = t[e], !(i.timestamp - r.timestamp > (0, p.w)(n)));) e--;
                if (!r) return {
                    x: 0,
                    y: 0
                };
                var o = (i.timestamp - r.timestamp) / 1e3;
                if (0 === o) return {
                    x: 0,
                    y: 0
                };
                var a = {
                    x: (i.x - r.x) / o,
                    y: (i.y - r.y) / o
                };
                return a.x === 1 / 0 && (a.x = 0), a.y === 1 / 0 && (a.y = 0), a
            }

            function B(t) {
                var n = null;
                return function() {
                    return null === n && (n = t, function() {
                        n = null
                    })
                }
            }
            var F = B("dragHorizontal"),
                U = B("dragVertical");

            function j(t) {
                var n = !1;
                if ("y" === t) n = U();
                else if ("x" === t) n = F();
                else {
                    var e = F(),
                        r = U();
                    e && r ? n = function() {
                        e(), r()
                    } : (e && e(), r && r())
                }
                return n
            }

            function O() {
                var t = j(!0);
                return !t || (t(), !1)
            }
            var G = e(74269),
                H = e(62866),
                _ = e(72261),
                z = e(67284),
                N = e(61239);

            function $(t, n, e) {
                return {
                    min: void 0 !== n ? t.min + n : void 0,
                    max: void 0 !== e ? t.max + e - (t.max - t.min) : void 0
                }
            }

            function W(t, n) {
                var e, i = n.min - t.min,
                    o = n.max - t.max;
                return n.max - n.min < t.max - t.min && (i = (e = (0, r.CR)([o, i], 2))[0], o = e[1]), {
                    min: i,
                    max: o
                }
            }
            var Y, K = .35;

            function Z(t, n, e) {
                return {
                    min: q(t, n),
                    max: q(t, e)
                }
            }

            function q(t, n) {
                var e;
                return "number" === typeof t ? t : null !== (e = t[n]) && void 0 !== e ? e : 0
            }! function(t) {
                t.Animate = "animate", t.Hover = "whileHover", t.Tap = "whileTap", t.Drag = "whileDrag", t.Focus = "whileFocus", t.InView = "whileInView", t.Exit = "exit"
            }(Y || (Y = {}));
            var J = e(21126),
                X = e(87399);

            function Q(t) {
                var n = t.top;
                return {
                    x: {
                        min: t.left,
                        max: t.right
                    },
                    y: {
                        min: n,
                        max: t.bottom
                    }
                }
            }
            var tt = e(64605);

            function nt(t, n) {
                return Q(function(t, n) {
                    if (!n) return t;
                    var e = n({
                            x: t.left,
                            y: t.top
                        }),
                        r = n({
                            x: t.right,
                            y: t.bottom
                        });
                    return {
                        top: e.y,
                        left: e.x,
                        bottom: r.y,
                        right: r.x
                    }
                }(t.getBoundingClientRect(), n))
            }
            var et = e(27719),
                rt = e(30716),
                it = new WeakMap,
                ot = function() {
                    function t(t) {
                        this.openGlobalLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
                            x: 0,
                            y: 0
                        }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = (0, J.dO)(), this.visualElement = t
                    }
                    return t.prototype.start = function(t, n) {
                        var e = this,
                            r = (void 0 === n ? {} : n).snapToCursor,
                            i = void 0 !== r && r;
                        if (!1 !== this.visualElement.isPresent) {
                            this.panSession = new R(t, {
                                onSessionStart: function(t) {
                                    e.stopAnimation(), i && e.snapToCursor(v(t, "page").point)
                                },
                                onStart: function(t, n) {
                                    var r, i = e.getProps(),
                                        o = i.drag,
                                        a = i.dragPropagation,
                                        u = i.onDragStart;
                                    (!o || a || (e.openGlobalLock && e.openGlobalLock(), e.openGlobalLock = j(o), e.openGlobalLock)) && (e.isDragging = !0, e.currentDirection = null, e.resolveConstraints(), e.visualElement.projection && (e.visualElement.projection.isAnimationBlocked = !0, e.visualElement.projection.target = void 0), (0, X.U)((function(t) {
                                        var n, r, i = e.getAxisMotionValue(t).get() || 0;
                                        if (rt.aQ.test(i)) {
                                            var o = null === (r = null === (n = e.visualElement.projection) || void 0 === n ? void 0 : n.layout) || void 0 === r ? void 0 : r.actual[t];
                                            if (o) i = (0, N.JO)(o) * (parseFloat(i) / 100)
                                        }
                                        e.originPoint[t] = i
                                    })), null === u || void 0 === u || u(t, n), null === (r = e.visualElement.animationState) || void 0 === r || r.setActive(Y.Drag, !0))
                                },
                                onMove: function(t, n) {
                                    var r = e.getProps(),
                                        i = r.dragPropagation,
                                        o = r.dragDirectionLock,
                                        a = r.onDirectionLock,
                                        u = r.onDrag;
                                    if (i || e.openGlobalLock) {
                                        var s = n.offset;
                                        if (o && null === e.currentDirection) return e.currentDirection = function(t, n) {
                                            void 0 === n && (n = 10);
                                            var e = null;
                                            Math.abs(t.y) > n ? e = "y" : Math.abs(t.x) > n && (e = "x");
                                            return e
                                        }(s), void(null !== e.currentDirection && (null === a || void 0 === a || a(e.currentDirection)));
                                        e.updateAxis("x", n.point, s), e.updateAxis("y", n.point, s), e.visualElement.syncRender(), null === u || void 0 === u || u(t, n)
                                    }
                                },
                                onSessionEnd: function(t, n) {
                                    return e.stop(t, n)
                                }
                            }, {
                                transformPagePoint: this.visualElement.getTransformPagePoint()
                            })
                        }
                    }, t.prototype.stop = function(t, n) {
                        var e = this.isDragging;
                        if (this.cancel(), e) {
                            var r = n.velocity;
                            this.startAnimation(r);
                            var i = this.getProps().onDragEnd;
                            null === i || void 0 === i || i(t, n)
                        }
                    }, t.prototype.cancel = function() {
                        var t, n;
                        this.isDragging = !1, this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !1), null === (t = this.panSession) || void 0 === t || t.end(), this.panSession = void 0, !this.getProps().dragPropagation && this.openGlobalLock && (this.openGlobalLock(), this.openGlobalLock = null), null === (n = this.visualElement.animationState) || void 0 === n || n.setActive(Y.Drag, !1)
                    }, t.prototype.updateAxis = function(t, n, e) {
                        var r = this.getProps().drag;
                        if (e && at(t, r, this.currentDirection)) {
                            var i = this.getAxisMotionValue(t),
                                o = this.originPoint[t] + e[t];
                            this.constraints && this.constraints[t] && (o = function(t, n, e) {
                                var r = n.min,
                                    i = n.max;
                                return void 0 !== r && t < r ? t = e ? (0, H.C)(r, t, e.min) : Math.max(t, r) : void 0 !== i && t > i && (t = e ? (0, H.C)(i, t, e.max) : Math.min(t, i)), t
                            }(o, this.constraints[t], this.elastic[t])), i.set(o)
                        }
                    }, t.prototype.resolveConstraints = function() {
                        var t = this,
                            n = this.getProps(),
                            e = n.dragConstraints,
                            r = n.dragElastic,
                            i = (this.visualElement.projection || {}).layout,
                            o = this.constraints;
                        e && (0, G.I)(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : this.constraints = !(!e || !i) && function(t, n) {
                            var e = n.top,
                                r = n.left,
                                i = n.bottom,
                                o = n.right;
                            return {
                                x: $(t.x, r, o),
                                y: $(t.y, e, i)
                            }
                        }(i.actual, e), this.elastic = function(t) {
                            return void 0 === t && (t = K), !1 === t ? t = 0 : !0 === t && (t = K), {
                                x: Z(t, "left", "right"),
                                y: Z(t, "top", "bottom")
                            }
                        }(r), o !== this.constraints && i && this.constraints && !this.hasMutatedConstraints && (0, X.U)((function(n) {
                            t.getAxisMotionValue(n) && (t.constraints[n] = function(t, n) {
                                var e = {};
                                return void 0 !== n.min && (e.min = n.min - t.min), void 0 !== n.max && (e.max = n.max - t.min), e
                            }(i.actual[n], t.constraints[n]))
                        }))
                    }, t.prototype.resolveRefConstraints = function() {
                        var t = this.getProps(),
                            n = t.dragConstraints,
                            e = t.onMeasureDragConstraints;
                        if (!n || !(0, G.I)(n)) return !1;
                        var r = n.current;
                        (0, o.k)(null !== r, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.");
                        var i = this.visualElement.projection;
                        if (!i || !i.layout) return !1;
                        var a = function(t, n, e) {
                                var r = nt(t, e),
                                    i = n.scroll;
                                return i && ((0, tt.am)(r.x, i.x), (0, tt.am)(r.y, i.y)), r
                            }(r, i.root, this.visualElement.getTransformPagePoint()),
                            u = function(t, n) {
                                return {
                                    x: W(t.x, n.x),
                                    y: W(t.y, n.y)
                                }
                            }(i.layout.actual, a);
                        if (e) {
                            var s = e(function(t) {
                                var n = t.x,
                                    e = t.y;
                                return {
                                    top: e.min,
                                    right: n.max,
                                    bottom: e.max,
                                    left: n.min
                                }
                            }(u));
                            this.hasMutatedConstraints = !!s, s && (u = Q(s))
                        }
                        return u
                    }, t.prototype.startAnimation = function(t) {
                        var n = this,
                            e = this.getProps(),
                            i = e.drag,
                            o = e.dragMomentum,
                            a = e.dragElastic,
                            u = e.dragTransition,
                            s = e.dragSnapToOrigin,
                            l = e.onDragTransitionEnd,
                            c = this.constraints || {},
                            v = (0, X.U)((function(e) {
                                var l;
                                if (at(e, i, n.currentDirection)) {
                                    var v = null !== (l = null === c || void 0 === c ? void 0 : c[e]) && void 0 !== l ? l : {};
                                    s && (v = {
                                        min: 0,
                                        max: 0
                                    });
                                    var d = a ? 200 : 1e6,
                                        f = a ? 40 : 1e7,
                                        p = (0, r.pi)((0, r.pi)({
                                            type: "inertia",
                                            velocity: o ? t[e] : 0,
                                            bounceStiffness: d,
                                            bounceDamping: f,
                                            timeConstant: 750,
                                            restDelta: 1,
                                            restSpeed: 10
                                        }, u), v);
                                    return n.startAxisValueAnimation(e, p)
                                }
                            }));
                        return Promise.all(v).then(l)
                    }, t.prototype.startAxisValueAnimation = function(t, n) {
                        var e = this.getAxisMotionValue(t);
                        return (0, et.b8)(t, e, 0, n)
                    }, t.prototype.stopAnimation = function() {
                        var t = this;
                        (0, X.U)((function(n) {
                            return t.getAxisMotionValue(n).stop()
                        }))
                    }, t.prototype.getAxisMotionValue = function(t) {
                        var n, e, r = "_drag" + t.toUpperCase(),
                            i = this.visualElement.getProps()[r];
                        return i || this.visualElement.getValue(t, null !== (e = null === (n = this.visualElement.getProps().initial) || void 0 === n ? void 0 : n[t]) && void 0 !== e ? e : 0)
                    }, t.prototype.snapToCursor = function(t) {
                        var n = this;
                        (0, X.U)((function(e) {
                            if (at(e, n.getProps().drag, n.currentDirection)) {
                                var r = n.visualElement.projection,
                                    i = n.getAxisMotionValue(e);
                                if (r && r.layout) {
                                    var o = r.layout.actual[e],
                                        a = o.min,
                                        u = o.max;
                                    i.set(t[e] - (0, H.C)(a, u, .5))
                                }
                            }
                        }))
                    }, t.prototype.scalePositionWithinConstraints = function() {
                        var t, n = this,
                            e = this.getProps(),
                            r = e.drag,
                            i = e.dragConstraints,
                            o = this.visualElement.projection;
                        if ((0, G.I)(i) && o && this.constraints) {
                            this.stopAnimation();
                            var a = {
                                x: 0,
                                y: 0
                            };
                            (0, X.U)((function(t) {
                                var e = n.getAxisMotionValue(t);
                                if (e) {
                                    var r = e.get();
                                    a[t] = function(t, n) {
                                        var e = .5,
                                            r = (0, N.JO)(t),
                                            i = (0, N.JO)(n);
                                        return i > r ? e = (0, _.Y)(n.min, n.max - r, t.min) : r > i && (e = (0, _.Y)(t.min, t.max - i, n.min)), (0, z.u)(0, 1, e)
                                    }({
                                        min: r,
                                        max: r
                                    }, n.constraints[t])
                                }
                            }));
                            var u = this.visualElement.getProps().transformTemplate;
                            this.visualElement.getInstance().style.transform = u ? u({}, "") : "none", null === (t = o.root) || void 0 === t || t.updateScroll(), o.updateLayout(), this.resolveConstraints(), (0, X.U)((function(t) {
                                if (at(t, r, null)) {
                                    var e = n.getAxisMotionValue(t),
                                        i = n.constraints[t],
                                        o = i.min,
                                        u = i.max;
                                    e.set((0, H.C)(o, u, a[t]))
                                }
                            }))
                        }
                    }, t.prototype.addListeners = function() {
                        var t, n = this;
                        it.set(this.visualElement, this);
                        var e = A(this.visualElement.getInstance(), "pointerdown", (function(t) {
                                var e = n.getProps(),
                                    r = e.drag,
                                    i = e.dragListener;
                                r && (void 0 === i || i) && n.start(t)
                            })),
                            r = function() {
                                var t = n.getProps().dragConstraints;
                                (0, G.I)(t) && (n.constraints = n.resolveRefConstraints())
                            },
                            i = this.visualElement.projection,
                            o = i.addEventListener("measure", r);
                        i && !i.layout && (null === (t = i.root) || void 0 === t || t.updateScroll(), i.updateLayout()), r();
                        var a = m(window, "resize", (function() {
                            n.scalePositionWithinConstraints()
                        }));
                        return i.addEventListener("didUpdate", (function(t) {
                                var e = t.delta,
                                    r = t.hasLayoutChanged;
                                n.isDragging && r && ((0, X.U)((function(t) {
                                    var r = n.getAxisMotionValue(t);
                                    r && (n.originPoint[t] += e[t].translate, r.set(r.get() + e[t].translate))
                                })), n.visualElement.syncRender())
                            })),
                            function() {
                                a(), e(), o()
                            }
                    }, t.prototype.getProps = function() {
                        var t = this.visualElement.getProps(),
                            n = t.drag,
                            e = void 0 !== n && n,
                            i = t.dragDirectionLock,
                            o = void 0 !== i && i,
                            a = t.dragPropagation,
                            u = void 0 !== a && a,
                            s = t.dragConstraints,
                            l = void 0 !== s && s,
                            c = t.dragElastic,
                            v = void 0 === c ? K : c,
                            d = t.dragMomentum,
                            f = void 0 === d || d;
                        return (0, r.pi)((0, r.pi)({}, t), {
                            drag: e,
                            dragDirectionLock: o,
                            dragPropagation: u,
                            dragConstraints: l,
                            dragElastic: v,
                            dragMomentum: f
                        })
                    }, t
                }();

            function at(t, n, e) {
                return (!0 === n || n === t) && (null === e || e === t)
            }
            var ut = e(78998);
            var st = e(48473);

            function lt(t) {
                return (0, i.useEffect)((function() {
                    return function() {
                        return t()
                    }
                }), [])
            }
            var ct = function(t) {
                    return function(n) {
                        return t(n), null
                    }
                },
                vt = {
                    pan: ct((function(t) {
                        var n = t.onPan,
                            e = t.onPanStart,
                            r = t.onPanEnd,
                            o = t.onPanSessionStart,
                            a = t.visualElement,
                            u = n || e || r || o,
                            s = (0, i.useRef)(null),
                            l = (0, i.useContext)(st._).transformPagePoint,
                            c = {
                                onSessionStart: o,
                                onStart: e,
                                onMove: n,
                                onEnd: function(t, n) {
                                    s.current = null, r && r(t, n)
                                }
                            };
                        (0, i.useEffect)((function() {
                            null !== s.current && s.current.updateHandlers(c)
                        })), b(a, "pointerdown", u && function(t) {
                            s.current = new R(t, c, {
                                transformPagePoint: l
                            })
                        }), lt((function() {
                            return s.current && s.current.end()
                        }))
                    })),
                    drag: ct((function(t) {
                        var n = t.dragControls,
                            e = t.visualElement,
                            r = (0, ut.h)((function() {
                                return new ot(e)
                            }));
                        (0, i.useEffect)((function() {
                            return n && n.subscribe(r)
                        }), [r, n]), (0, i.useEffect)((function() {
                            return r.addListeners()
                        }), [r])
                    }))
                },
                dt = e(9806),
                ft = 0,
                pt = function() {
                    return ft++
                },
                mt = function() {
                    return (0, ut.h)(pt)
                };

            function ht() {
                var t = (0, i.useContext)(dt.O);
                if (null === t) return [!0, null];
                var n = t.isPresent,
                    e = t.onExitComplete,
                    r = t.register,
                    o = mt();
                (0, i.useEffect)((function() {
                    return r(o)
                }), []);
                return !n && e ? [!1, function() {
                    return null === e || void 0 === e ? void 0 : e(o)
                }] : [!0]
            }
            var gt = e(32492),
                yt = e(24714),
                Et = e(94705);

            function xt(t, n) {
                return n.max === n.min ? 0 : t / (n.max - n.min) * 100
            }
            var Pt = {
                    correct: function(t, n) {
                        if (!n.target) return t;
                        if ("string" === typeof t) {
                            if (!rt.px.test(t)) return t;
                            t = parseFloat(t)
                        }
                        var e = xt(t, n.target.x),
                            r = xt(t, n.target.y);
                        return "".concat(e, "% ").concat(r, "%")
                    }
                },
                Vt = e(42346);

            function wt(t) {
                return "string" === typeof t && t.startsWith("var(--")
            }
            var At = /var\((--[a-zA-Z0-9-_]+),? ?([a-zA-Z0-9 ()%#.,-]+)?\)/;
            var bt = 4;

            function Ct(t, n, e) {
                void 0 === e && (e = 1), (0, o.k)(e <= bt, 'Max CSS variable fallback depth detected in property "'.concat(t, '". This may indicate a circular fallback dependency.'));
                var i = (0, r.CR)(function(t) {
                        var n = At.exec(t);
                        if (!n) return [, ];
                        var e = (0, r.CR)(n, 3);
                        return [e[1], e[2]]
                    }(t), 2),
                    a = i[0],
                    u = i[1];
                if (a) {
                    var s = window.getComputedStyle(n).getPropertyValue(a);
                    return s ? s.trim() : wt(u) ? Ct(u, n, e + 1) : u
                }
            }
            var Tt = "_$css",
                Rt = {
                    correct: function(t, n) {
                        var e = n.treeScale,
                            r = n.projectionDelta,
                            i = t,
                            o = t.includes("var("),
                            a = [];
                        o && (t = t.replace(At, (function(t) {
                            return a.push(t), Tt
                        })));
                        var u = Vt.P.parse(t);
                        if (u.length > 5) return i;
                        var s = Vt.P.createTransformer(t),
                            l = "number" !== typeof u[0] ? 1 : 0,
                            c = r.x.scale * e.x,
                            v = r.y.scale * e.y;
                        u[0 + l] /= c, u[1 + l] /= v;
                        var d = (0, H.C)(c, v, .5);
                        "number" === typeof u[2 + l] && (u[2 + l] /= d), "number" === typeof u[3 + l] && (u[3 + l] /= d);
                        var f = s(u);
                        if (o) {
                            var p = 0;
                            f = f.replace(Tt, (function() {
                                var t = a[p];
                                return p++, t
                            }))
                        }
                        return f
                    }
                },
                St = e(37948),
                Mt = function(t) {
                    function n() {
                        return null !== t && t.apply(this, arguments) || this
                    }
                    return (0, r.ZT)(n, t), n.prototype.componentDidMount = function() {
                        var t = this,
                            n = this.props,
                            e = n.visualElement,
                            i = n.layoutGroup,
                            o = n.switchLayoutGroup,
                            a = n.layoutId,
                            u = e.projection;
                        (0, St.B)(Lt), u && ((null === i || void 0 === i ? void 0 : i.group) && i.group.add(u), (null === o || void 0 === o ? void 0 : o.register) && a && o.register(u), u.root.didUpdate(), u.addEventListener("animationComplete", (function() {
                            t.safeToRemove()
                        })), u.setOptions((0, r.pi)((0, r.pi)({}, u.options), {
                            onExitComplete: function() {
                                return t.safeToRemove()
                            }
                        }))), Et.VN.hasEverUpdated = !0
                    }, n.prototype.getSnapshotBeforeUpdate = function(t) {
                        var n = this,
                            e = this.props,
                            r = e.layoutDependency,
                            i = e.visualElement,
                            o = e.drag,
                            a = e.isPresent,
                            u = i.projection;
                        return u ? (u.isPresent = a, o || t.layoutDependency !== r || void 0 === r ? u.willUpdate() : this.safeToRemove(), t.isPresent !== a && (a ? u.promote() : u.relegate() || f.ZP.postRender((function() {
                            var t;
                            (null === (t = u.getStack()) || void 0 === t ? void 0 : t.members.length) || n.safeToRemove()
                        }))), null) : null
                    }, n.prototype.componentDidUpdate = function() {
                        var t = this.props.visualElement.projection;
                        t && (t.root.didUpdate(), !t.currentAnimation && t.isLead() && this.safeToRemove())
                    }, n.prototype.componentWillUnmount = function() {
                        var t = this.props,
                            n = t.visualElement,
                            e = t.layoutGroup,
                            r = t.switchLayoutGroup,
                            i = n.projection;
                        i && (i.scheduleCheckAfterUnmount(), (null === e || void 0 === e ? void 0 : e.group) && e.group.remove(i), (null === r || void 0 === r ? void 0 : r.deregister) && r.deregister(i))
                    }, n.prototype.safeToRemove = function() {
                        var t = this.props.safeToRemove;
                        null === t || void 0 === t || t()
                    }, n.prototype.render = function() {
                        return null
                    }, n
                }(i.Component);
            var Lt = {
                    borderRadius: (0, r.pi)((0, r.pi)({}, Pt), {
                        applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
                    }),
                    borderTopLeftRadius: Pt,
                    borderTopRightRadius: Pt,
                    borderBottomLeftRadius: Pt,
                    borderBottomRightRadius: Pt,
                    boxShadow: Rt
                },
                kt = {
                    measureLayout: function(t) {
                        var n = (0, r.CR)(ht(), 2),
                            e = n[0],
                            o = n[1],
                            a = (0, i.useContext)(gt.p);
                        return i.createElement(Mt, (0, r.pi)({}, t, {
                            layoutGroup: a,
                            switchLayoutGroup: (0, i.useContext)(yt.g),
                            isPresent: e,
                            safeToRemove: o
                        }))
                    }
                },
                Dt = e(49233),
                It = e(16494);

            function Bt(t, n) {
                if (!Array.isArray(n)) return !1;
                var e = n.length;
                if (e !== t.length) return !1;
                for (var r = 0; r < e; r++)
                    if (n[r] !== t[r]) return !1;
                return !0
            }
            var Ft = function(t) {
                    return /^0[^.\s]+$/.test(t)
                },
                Ut = e(75196),
                jt = e(33618),
                Ot = e(91260),
                Gt = e(47337),
                Ht = e(81158),
                _t = function(t) {
                    return function(n) {
                        return n.test(t)
                    }
                },
                zt = [Ht.Rx, rt.px, rt.aQ, rt.RW, rt.vw, rt.vh, {
                    test: function(t) {
                        return "auto" === t
                    },
                    parse: function(t) {
                        return t
                    }
                }],
                Nt = function(t) {
                    return zt.find(_t(t))
                },
                $t = (0, r.ev)((0, r.ev)([], (0, r.CR)(zt), !1), [Gt.$, Vt.P], !1),
                Wt = function(t) {
                    return $t.find(_t(t))
                },
                Yt = e(30745);

            function Kt(t, n, e) {
                t.hasValue(n) ? t.getValue(n).set(e) : t.addValue(n, (0, jt.B)(e))
            }

            function Zt(t, n) {
                var e = (0, Yt.x5)(t, n),
                    i = e ? t.makeTargetAnimatable(e, !1) : {},
                    o = i.transitionEnd,
                    a = void 0 === o ? {} : o;
                i.transition;
                var u = (0, r._T)(i, ["transitionEnd", "transition"]);
                for (var s in u = (0, r.pi)((0, r.pi)({}, u), a)) {
                    Kt(t, s, (0, Ut.Y)(u[s]))
                }
            }

            function qt(t, n) {
                if (n) return (n[t] || n.default || n).from
            }
            var Jt = e(11863);

            function Xt(t, n, e) {
                var i;
                void 0 === e && (e = {});
                var o = (0, Yt.x5)(t, n, e.custom),
                    a = (o || {}).transition,
                    u = void 0 === a ? t.getDefaultTransition() || {} : a;
                e.transitionOverride && (u = e.transitionOverride);
                var s = o ? function() {
                        return Qt(t, o, e)
                    } : function() {
                        return Promise.resolve()
                    },
                    l = (null === (i = t.variantChildren) || void 0 === i ? void 0 : i.size) ? function(i) {
                        void 0 === i && (i = 0);
                        var o = u.delayChildren,
                            a = void 0 === o ? 0 : o,
                            s = u.staggerChildren,
                            l = u.staggerDirection;
                        return function(t, n, e, i, o, a) {
                            void 0 === e && (e = 0);
                            void 0 === i && (i = 0);
                            void 0 === o && (o = 1);
                            var u = [],
                                s = (t.variantChildren.size - 1) * i,
                                l = 1 === o ? function(t) {
                                    return void 0 === t && (t = 0), t * i
                                } : function(t) {
                                    return void 0 === t && (t = 0), s - t * i
                                };
                            return Array.from(t.variantChildren).sort(tn).forEach((function(t, i) {
                                u.push(Xt(t, n, (0, r.pi)((0, r.pi)({}, a), {
                                    delay: e + l(i)
                                })).then((function() {
                                    return t.notifyAnimationComplete(n)
                                })))
                            })), Promise.all(u)
                        }(t, n, a + i, s, l, e)
                    } : function() {
                        return Promise.resolve()
                    },
                    c = u.when;
                if (c) {
                    var v = (0, r.CR)("beforeChildren" === c ? [s, l] : [l, s], 2),
                        d = v[0],
                        f = v[1];
                    return d().then(f)
                }
                return Promise.all([s(), l(e.delay)])
            }

            function Qt(t, n, e) {
                var i, o = void 0 === e ? {} : e,
                    a = o.delay,
                    u = void 0 === a ? 0 : a,
                    s = o.transitionOverride,
                    l = o.type,
                    c = t.makeTargetAnimatable(n),
                    v = c.transition,
                    d = void 0 === v ? t.getDefaultTransition() : v,
                    f = c.transitionEnd,
                    p = (0, r._T)(c, ["transition", "transitionEnd"]);
                s && (d = s);
                var m = [],
                    h = l && (null === (i = t.animationState) || void 0 === i ? void 0 : i.getState()[l]);
                for (var g in p) {
                    var y = t.getValue(g),
                        E = p[g];
                    if (!(!y || void 0 === E || h && nn(h, g))) {
                        var x = (0, r.pi)({
                            delay: u
                        }, d);
                        t.shouldReduceMotion && (0, Jt._c)(g) && (x = (0, r.pi)((0, r.pi)({}, x), {
                            type: !1,
                            delay: 0
                        }));
                        var P = (0, et.b8)(g, y, E, x);
                        m.push(P)
                    }
                }
                return Promise.all(m).then((function() {
                    f && Zt(t, f)
                }))
            }

            function tn(t, n) {
                return t.sortNodePosition(n)
            }

            function nn(t, n) {
                var e = t.protectedKeys,
                    r = t.needsAnimating,
                    i = e.hasOwnProperty(n) && !0 !== r[n];
                return r[n] = !1, i
            }
            var en = [Y.Animate, Y.InView, Y.Focus, Y.Hover, Y.Tap, Y.Drag, Y.Exit],
                rn = (0, r.ev)([], (0, r.CR)(en), !1).reverse(),
                on = en.length;

            function an(t) {
                return function(n) {
                    return Promise.all(n.map((function(n) {
                        var e = n.animation,
                            r = n.options;
                        return function(t, n, e) {
                            var r;
                            if (void 0 === e && (e = {}), t.notifyAnimationStart(n), Array.isArray(n)) {
                                var i = n.map((function(n) {
                                    return Xt(t, n, e)
                                }));
                                r = Promise.all(i)
                            } else if ("string" === typeof n) r = Xt(t, n, e);
                            else {
                                var o = "function" === typeof n ? (0, Yt.x5)(t, n, e.custom) : n;
                                r = Qt(t, o, e)
                            }
                            return r.then((function() {
                                return t.notifyAnimationComplete(n)
                            }))
                        }(t, e, r)
                    })))
                }
            }

            function un(t) {
                var n = an(t),
                    e = function() {
                        var t;
                        return (t = {})[Y.Animate] = sn(!0), t[Y.InView] = sn(), t[Y.Hover] = sn(), t[Y.Tap] = sn(), t[Y.Drag] = sn(), t[Y.Focus] = sn(), t[Y.Exit] = sn(), t
                    }(),
                    i = {},
                    o = !0,
                    a = function(n, e) {
                        var i = (0, Yt.x5)(t, e);
                        if (i) {
                            i.transition;
                            var o = i.transitionEnd,
                                a = (0, r._T)(i, ["transition", "transitionEnd"]);
                            n = (0, r.pi)((0, r.pi)((0, r.pi)({}, n), a), o)
                        }
                        return n
                    };

                function u(u, s) {
                    for (var l, c = t.getProps(), v = t.getVariantContext(!0) || {}, d = [], f = new Set, p = {}, m = 1 / 0, h = function(n) {
                            var i = rn[n],
                                h = e[i],
                                g = null !== (l = c[i]) && void 0 !== l ? l : v[i],
                                y = (0, Yt.$L)(g),
                                E = i === s ? h.isActive : null;
                            !1 === E && (m = n);
                            var x = g === v[i] && g !== c[i] && y;
                            if (x && o && t.manuallyAnimateOnMount && (x = !1), h.protectedKeys = (0, r.pi)({}, p), !h.isActive && null === E || !g && !h.prevProp || (0, Dt.H)(g) || "boolean" === typeof g) return "continue";
                            var P = function(t, n) {
                                    if ("string" === typeof n) return n !== t;
                                    if ((0, Yt.A0)(n)) return !Bt(n, t);
                                    return !1
                                }(h.prevProp, g),
                                V = P || i === s && h.isActive && !x && y || n > m && y,
                                w = Array.isArray(g) ? g : [g],
                                A = w.reduce(a, {});
                            !1 === E && (A = {});
                            var b = h.prevResolvedValues,
                                C = void 0 === b ? {} : b,
                                T = (0, r.pi)((0, r.pi)({}, C), A),
                                R = function(t) {
                                    V = !0, f.delete(t), h.needsAnimating[t] = !0
                                };
                            for (var S in T) {
                                var M = A[S],
                                    L = C[S];
                                p.hasOwnProperty(S) || (M !== L ? (0, It.C)(M) && (0, It.C)(L) ? !Bt(M, L) || P ? R(S) : h.protectedKeys[S] = !0 : void 0 !== M ? R(S) : f.add(S) : void 0 !== M && f.has(S) ? R(S) : h.protectedKeys[S] = !0)
                            }
                            h.prevProp = g, h.prevResolvedValues = A, h.isActive && (p = (0, r.pi)((0, r.pi)({}, p), A)), o && t.blockInitialAnimation && (V = !1), V && !x && d.push.apply(d, (0, r.ev)([], (0, r.CR)(w.map((function(t) {
                                return {
                                    animation: t,
                                    options: (0, r.pi)({
                                        type: i
                                    }, u)
                                }
                            }))), !1))
                        }, g = 0; g < on; g++) h(g);
                    if (i = (0, r.pi)({}, p), f.size) {
                        var y = {};
                        f.forEach((function(n) {
                            var e = t.getBaseTarget(n);
                            void 0 !== e && (y[n] = e)
                        })), d.push({
                            animation: y
                        })
                    }
                    var E = Boolean(d.length);
                    return o && !1 === c.initial && !t.manuallyAnimateOnMount && (E = !1), o = !1, E ? n(d) : Promise.resolve()
                }
                return {
                    isAnimated: function(t) {
                        return void 0 !== i[t]
                    },
                    animateChanges: u,
                    setActive: function(n, r, i) {
                        var o;
                        if (e[n].isActive === r) return Promise.resolve();
                        null === (o = t.variantChildren) || void 0 === o || o.forEach((function(t) {
                            var e;
                            return null === (e = t.animationState) || void 0 === e ? void 0 : e.setActive(n, r)
                        })), e[n].isActive = r;
                        var a = u(i, n);
                        for (var s in e) e[s].protectedKeys = {};
                        return a
                    },
                    setAnimateFunction: function(e) {
                        n = e(t)
                    },
                    getState: function() {
                        return e
                    }
                }
            }

            function sn(t) {
                return void 0 === t && (t = !1), {
                    isActive: t,
                    protectedKeys: {},
                    needsAnimating: {},
                    prevResolvedValues: {}
                }
            }
            var ln = {
                animation: ct((function(t) {
                    var n = t.visualElement,
                        e = t.animate;
                    n.animationState || (n.animationState = un(n)), (0, Dt.H)(e) && (0, i.useEffect)((function() {
                        return e.subscribe(n)
                    }), [e])
                })),
                exit: ct((function(t) {
                    var n = t.custom,
                        e = t.visualElement,
                        o = (0, r.CR)(ht(), 2),
                        a = o[0],
                        u = o[1],
                        s = (0, i.useContext)(dt.O);
                    (0, i.useEffect)((function() {
                        var t, r;
                        e.isPresent = a;
                        var i = null === (t = e.animationState) || void 0 === t ? void 0 : t.setActive(Y.Exit, !a, {
                            custom: null !== (r = null === s || void 0 === s ? void 0 : s.custom) && void 0 !== r ? r : n
                        });
                        !a && (null === i || void 0 === i || i.then(u))
                    }), [a])
                }))
            };

            function cn(t, n, e) {
                return function(r, i) {
                    var o;
                    a(r) && !O() && (null === (o = t.animationState) || void 0 === o || o.setActive(Y.Hover, n), null === e || void 0 === e || e(r, i))
                }
            }
            var vn = function t(n, e) {
                return !!e && (n === e || t(n, e.parentElement))
            };
            var dn = new WeakMap,
                fn = new WeakMap,
                pn = function(t) {
                    var n;
                    null === (n = dn.get(t.target)) || void 0 === n || n(t)
                },
                mn = function(t) {
                    t.forEach(pn)
                };

            function hn(t, n, e) {
                var i = function(t) {
                    var n = t.root,
                        e = (0, r._T)(t, ["root"]),
                        i = n || document;
                    fn.has(i) || fn.set(i, {});
                    var o = fn.get(i),
                        a = JSON.stringify(e);
                    return o[a] || (o[a] = new IntersectionObserver(mn, (0, r.pi)({
                        root: n
                    }, e))), o[a]
                }(n);
                return dn.set(t, e), i.observe(t),
                    function() {
                        dn.delete(t), i.unobserve(t)
                    }
            }
            var gn = {
                some: 0,
                all: 1
            };

            function yn(t, n, e, r) {
                var o = r.root,
                    a = r.margin,
                    u = r.amount,
                    s = void 0 === u ? "some" : u,
                    l = r.once;
                (0, i.useEffect)((function() {
                    if (t) {
                        var r = {
                            root: null === o || void 0 === o ? void 0 : o.current,
                            rootMargin: a,
                            threshold: "number" === typeof s ? s : gn[s]
                        };
                        return hn(e.getInstance(), r, (function(t) {
                            var r, i = t.isIntersecting;
                            if (n.isInView !== i && (n.isInView = i, !l || i || !n.hasEnteredView)) {
                                i && (n.hasEnteredView = !0), null === (r = e.animationState) || void 0 === r || r.setActive(Y.InView, i);
                                var o = e.getProps(),
                                    a = i ? o.onViewportEnter : o.onViewportLeave;
                                null === a || void 0 === a || a(t)
                            }
                        }))
                    }
                }), [t, o, a, s])
            }

            function En(t, n, e, r) {
                var o = r.fallback,
                    a = void 0 === o || o;
                (0, i.useEffect)((function() {
                    t && a && requestAnimationFrame((function() {
                        var t;
                        n.hasEnteredView = !0;
                        var r = e.getProps().onViewportEnter;
                        null === r || void 0 === r || r(null), null === (t = e.animationState) || void 0 === t || t.setActive(Y.InView, !0)
                    }))
                }), [t])
            }
            var xn = {
                    inView: ct((function(t) {
                        var n = t.visualElement,
                            e = t.whileInView,
                            r = t.onViewportEnter,
                            o = t.onViewportLeave,
                            a = t.viewport,
                            u = void 0 === a ? {} : a,
                            s = (0, i.useRef)({
                                hasEnteredView: !1,
                                isInView: !1
                            }),
                            l = Boolean(e || r || o);
                        u.once && s.current.hasEnteredView && (l = !1), ("undefined" === typeof IntersectionObserver ? En : yn)(l, s.current, n, u)
                    })),
                    tap: ct((function(t) {
                        var n = t.onTap,
                            e = t.onTapStart,
                            r = t.onTapCancel,
                            o = t.whileTap,
                            a = t.visualElement,
                            u = n || e || r || o,
                            s = (0, i.useRef)(!1),
                            l = (0, i.useRef)(null);

                        function c() {
                            var t;
                            null === (t = l.current) || void 0 === t || t.call(l), l.current = null
                        }

                        function v() {
                            var t;
                            return c(), s.current = !1, null === (t = a.animationState) || void 0 === t || t.setActive(Y.Tap, !1), !O()
                        }

                        function d(t, e) {
                            v() && (vn(a.getInstance(), t.target) ? null === n || void 0 === n || n(t, e) : null === r || void 0 === r || r(t, e))
                        }

                        function f(t, n) {
                            v() && (null === r || void 0 === r || r(t, n))
                        }
                        b(a, "pointerdown", u ? function(t, n) {
                            var r;
                            c(), s.current || (s.current = !0, l.current = (0, T.z)(A(window, "pointerup", d), A(window, "pointercancel", f)), null === (r = a.animationState) || void 0 === r || r.setActive(Y.Tap, !0), null === e || void 0 === e || e(t, n))
                        } : void 0), lt(c)
                    })),
                    focus: ct((function(t) {
                        var n = t.whileFocus,
                            e = t.visualElement;
                        h(e, "focus", n ? function() {
                            var t;
                            null === (t = e.animationState) || void 0 === t || t.setActive(Y.Focus, !0)
                        } : void 0), h(e, "blur", n ? function() {
                            var t;
                            null === (t = e.animationState) || void 0 === t || t.setActive(Y.Focus, !1)
                        } : void 0)
                    })),
                    hover: ct((function(t) {
                        var n = t.onHoverStart,
                            e = t.onHoverEnd,
                            r = t.whileHover,
                            i = t.visualElement;
                        b(i, "pointerenter", n || r ? cn(i, !0, n) : void 0), b(i, "pointerleave", e || r ? cn(i, !1, e) : void 0)
                    }))
                },
                Pn = e(20745),
                Vn = e(28191),
                wn = ["LayoutMeasure", "BeforeLayoutMeasure", "LayoutUpdate", "ViewportBoxUpdate", "Update", "Render", "AnimationComplete", "LayoutAnimationComplete", "AnimationStart", "SetAxisTarget", "Unmount"];
            var An, bn = function(t) {
                    var n = t.treeType,
                        e = void 0 === n ? "" : n,
                        i = t.build,
                        o = t.getBaseTarget,
                        a = t.makeTargetAnimatable,
                        u = t.measureViewportBox,
                        s = t.render,
                        l = t.readValueFromInstance,
                        c = t.removeValueFromRenderState,
                        v = t.sortNodePosition,
                        d = t.scrapeMotionValuesFromProps;
                    return function(t, n) {
                        var p = t.parent,
                            m = t.props,
                            h = t.presenceId,
                            g = t.blockInitialAnimation,
                            y = t.visualState,
                            E = t.shouldReduceMotion;
                        void 0 === n && (n = {});
                        var x, P, V = !1,
                            w = y.latestValues,
                            A = y.renderState,
                            b = function() {
                                var t = wn.map((function() {
                                        return new Vn.L
                                    })),
                                    n = {},
                                    e = {
                                        clearAllListeners: function() {
                                            return t.forEach((function(t) {
                                                return t.clear()
                                            }))
                                        },
                                        updatePropListeners: function(t) {
                                            wn.forEach((function(r) {
                                                var i, o = "on" + r,
                                                    a = t[o];
                                                null === (i = n[r]) || void 0 === i || i.call(n), a && (n[r] = e[o](a))
                                            }))
                                        }
                                    };
                                return t.forEach((function(t, n) {
                                    e["on" + wn[n]] = function(n) {
                                        return t.add(n)
                                    }, e["notify" + wn[n]] = function() {
                                        for (var n = [], e = 0; e < arguments.length; e++) n[e] = arguments[e];
                                        return t.notify.apply(t, (0, r.ev)([], (0, r.CR)(n), !1))
                                    }
                                })), e
                            }(),
                            C = new Map,
                            T = new Map,
                            R = {},
                            S = (0, r.pi)({}, w);

                        function M() {
                            x && V && (L(), s(x, A, m.style, O.projection))
                        }

                        function L() {
                            i(O, A, w, n, m)
                        }

                        function k() {
                            b.notifyUpdate(w)
                        }

                        function D(t, n) {
                            var e = n.onChange((function(n) {
                                    w[t] = n, m.onUpdate && f.ZP.update(k, !1, !0)
                                })),
                                r = n.onRenderRequest(O.scheduleRender);
                            T.set(t, (function() {
                                e(), r()
                            }))
                        }
                        var I = d(m);
                        for (var B in I) {
                            var F = I[B];
                            void 0 !== w[B] && (0, Pn.i)(F) && F.set(w[B], !1)
                        }
                        var U = (0, Yt.O6)(m),
                            j = (0, Yt.e8)(m),
                            O = (0, r.pi)((0, r.pi)({
                                treeType: e,
                                current: null,
                                depth: p ? p.depth + 1 : 0,
                                parent: p,
                                children: new Set,
                                presenceId: h,
                                shouldReduceMotion: E,
                                variantChildren: j ? new Set : void 0,
                                isVisible: void 0,
                                manuallyAnimateOnMount: Boolean(null === p || void 0 === p ? void 0 : p.isMounted()),
                                blockInitialAnimation: g,
                                isMounted: function() {
                                    return Boolean(x)
                                },
                                mount: function(t) {
                                    V = !0, x = O.current = t, O.projection && O.projection.mount(t), j && p && !U && (P = null === p || void 0 === p ? void 0 : p.addVariantChild(O)), C.forEach((function(t, n) {
                                        return D(n, t)
                                    })), null === p || void 0 === p || p.children.add(O), O.setProps(m)
                                },
                                unmount: function() {
                                    var t;
                                    null === (t = O.projection) || void 0 === t || t.unmount(), f.qY.update(k), f.qY.render(M), T.forEach((function(t) {
                                        return t()
                                    })), null === P || void 0 === P || P(), null === p || void 0 === p || p.children.delete(O), b.clearAllListeners(), x = void 0, V = !1
                                },
                                addVariantChild: function(t) {
                                    var n, e = O.getClosestVariantNode();
                                    if (e) return null === (n = e.variantChildren) || void 0 === n || n.add(t),
                                        function() {
                                            return e.variantChildren.delete(t)
                                        }
                                },
                                sortNodePosition: function(t) {
                                    return v && e === t.treeType ? v(O.getInstance(), t.getInstance()) : 0
                                },
                                getClosestVariantNode: function() {
                                    return j ? O : null === p || void 0 === p ? void 0 : p.getClosestVariantNode()
                                },
                                getLayoutId: function() {
                                    return m.layoutId
                                },
                                getInstance: function() {
                                    return x
                                },
                                getStaticValue: function(t) {
                                    return w[t]
                                },
                                setStaticValue: function(t, n) {
                                    return w[t] = n
                                },
                                getLatestValues: function() {
                                    return w
                                },
                                setVisibility: function(t) {
                                    O.isVisible !== t && (O.isVisible = t, O.scheduleRender())
                                },
                                makeTargetAnimatable: function(t, n) {
                                    return void 0 === n && (n = !0), a(O, t, m, n)
                                },
                                measureViewportBox: function() {
                                    return u(x, m)
                                },
                                addValue: function(t, n) {
                                    O.hasValue(t) && O.removeValue(t), C.set(t, n), w[t] = n.get(), D(t, n)
                                },
                                removeValue: function(t) {
                                    var n;
                                    C.delete(t), null === (n = T.get(t)) || void 0 === n || n(), T.delete(t), delete w[t], c(t, A)
                                },
                                hasValue: function(t) {
                                    return C.has(t)
                                },
                                getValue: function(t, n) {
                                    var e = C.get(t);
                                    return void 0 === e && void 0 !== n && (e = (0, jt.B)(n), O.addValue(t, e)), e
                                },
                                forEachValue: function(t) {
                                    return C.forEach(t)
                                },
                                readValue: function(t) {
                                    var e;
                                    return null !== (e = w[t]) && void 0 !== e ? e : l(x, t, n)
                                },
                                setBaseTarget: function(t, n) {
                                    S[t] = n
                                },
                                getBaseTarget: function(t) {
                                    if (o) {
                                        var n = o(m, t);
                                        if (void 0 !== n && !(0, Pn.i)(n)) return n
                                    }
                                    return S[t]
                                }
                            }, b), {
                                build: function() {
                                    return L(), A
                                },
                                scheduleRender: function() {
                                    f.ZP.render(M, !1, !0)
                                },
                                syncRender: M,
                                setProps: function(t) {
                                    (t.transformTemplate || m.transformTemplate) && O.scheduleRender(), m = t, b.updatePropListeners(t), R = function(t, n, e) {
                                        var r;
                                        for (var i in n) {
                                            var o = n[i],
                                                a = e[i];
                                            if ((0, Pn.i)(o)) t.addValue(i, o);
                                            else if ((0, Pn.i)(a)) t.addValue(i, (0, jt.B)(o));
                                            else if (a !== o)
                                                if (t.hasValue(i)) {
                                                    var u = t.getValue(i);
                                                    !u.hasAnimated && u.set(o)
                                                } else t.addValue(i, (0, jt.B)(null !== (r = t.getStaticValue(i)) && void 0 !== r ? r : o))
                                        }
                                        for (var i in e) void 0 === n[i] && t.removeValue(i);
                                        return n
                                    }(O, d(m), R)
                                },
                                getProps: function() {
                                    return m
                                },
                                getVariant: function(t) {
                                    var n;
                                    return null === (n = m.variants) || void 0 === n ? void 0 : n[t]
                                },
                                getDefaultTransition: function() {
                                    return m.transition
                                },
                                getTransformPagePoint: function() {
                                    return m.transformPagePoint
                                },
                                getVariantContext: function(t) {
                                    if (void 0 === t && (t = !1), t) return null === p || void 0 === p ? void 0 : p.getVariantContext();
                                    if (!U) {
                                        var n = (null === p || void 0 === p ? void 0 : p.getVariantContext()) || {};
                                        return void 0 !== m.initial && (n.initial = m.initial), n
                                    }
                                    for (var e = {}, r = 0; r < Tn; r++) {
                                        var i = Cn[r],
                                            o = m[i];
                                        ((0, Yt.$L)(o) || !1 === o) && (e[i] = o)
                                    }
                                    return e
                                }
                            });
                        return O
                    }
                },
                Cn = (0, r.ev)(["initial"], (0, r.CR)(en), !1),
                Tn = Cn.length,
                Rn = e(50357),
                Sn = e(5865),
                Mn = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y"]),
                Ln = function(t) {
                    return Mn.has(t)
                },
                kn = function(t, n) {
                    t.set(n, !1), t.set(n)
                },
                Dn = function(t) {
                    return t === Ht.Rx || t === rt.px
                };
            ! function(t) {
                t.width = "width", t.height = "height", t.left = "left", t.right = "right", t.top = "top", t.bottom = "bottom"
            }(An || (An = {}));
            var In = function(t, n) {
                    return parseFloat(t.split(", ")[n])
                },
                Bn = function(t, n) {
                    return function(e, r) {
                        var i = r.transform;
                        if ("none" === i || !i) return 0;
                        var o = i.match(/^matrix3d\((.+)\)$/);
                        if (o) return In(o[1], n);
                        var a = i.match(/^matrix\((.+)\)$/);
                        return a ? In(a[1], t) : 0
                    }
                },
                Fn = new Set(["x", "y", "z"]),
                Un = Jt.Gl.filter((function(t) {
                    return !Fn.has(t)
                }));
            var jn = {
                    width: function(t, n) {
                        var e = t.x,
                            r = n.paddingLeft,
                            i = void 0 === r ? "0" : r,
                            o = n.paddingRight,
                            a = void 0 === o ? "0" : o;
                        return e.max - e.min - parseFloat(i) - parseFloat(a)
                    },
                    height: function(t, n) {
                        var e = t.y,
                            r = n.paddingTop,
                            i = void 0 === r ? "0" : r,
                            o = n.paddingBottom,
                            a = void 0 === o ? "0" : o;
                        return e.max - e.min - parseFloat(i) - parseFloat(a)
                    },
                    top: function(t, n) {
                        var e = n.top;
                        return parseFloat(e)
                    },
                    left: function(t, n) {
                        var e = n.left;
                        return parseFloat(e)
                    },
                    bottom: function(t, n) {
                        var e = t.y,
                            r = n.top;
                        return parseFloat(r) + (e.max - e.min)
                    },
                    right: function(t, n) {
                        var e = t.x,
                            r = n.left;
                        return parseFloat(r) + (e.max - e.min)
                    },
                    x: Bn(4, 13),
                    y: Bn(5, 14)
                },
                On = function(t, n, e, i) {
                    void 0 === e && (e = {}), void 0 === i && (i = {}), n = (0, r.pi)({}, n), i = (0, r.pi)({}, i);
                    var a = Object.keys(n).filter(Ln),
                        u = [],
                        s = !1,
                        l = [];
                    if (a.forEach((function(r) {
                            var a = t.getValue(r);
                            if (t.hasValue(r)) {
                                var c, v = e[r],
                                    d = Nt(v),
                                    f = n[r];
                                if ((0, It.C)(f)) {
                                    var p = f.length,
                                        m = null === f[0] ? 1 : 0;
                                    v = f[m], d = Nt(v);
                                    for (var h = m; h < p; h++) c ? (0, o.k)(Nt(f[h]) === c, "All keyframes must be of the same type") : (c = Nt(f[h]), (0, o.k)(c === d || Dn(d) && Dn(c), "Keyframes must be of the same dimension as the current value"))
                                } else c = Nt(f);
                                if (d !== c)
                                    if (Dn(d) && Dn(c)) {
                                        var g = a.get();
                                        "string" === typeof g && a.set(parseFloat(g)), "string" === typeof f ? n[r] = parseFloat(f) : Array.isArray(f) && c === rt.px && (n[r] = f.map(parseFloat))
                                    } else(null === d || void 0 === d ? void 0 : d.transform) && (null === c || void 0 === c ? void 0 : c.transform) && (0 === v || 0 === f) ? 0 === v ? a.set(c.transform(v)) : n[r] = d.transform(f) : (s || (u = function(t) {
                                        var n = [];
                                        return Un.forEach((function(e) {
                                            var r = t.getValue(e);
                                            void 0 !== r && (n.push([e, r.get()]), r.set(e.startsWith("scale") ? 1 : 0))
                                        })), n.length && t.syncRender(), n
                                    }(t), s = !0), l.push(r), i[r] = void 0 !== i[r] ? i[r] : n[r], kn(a, f))
                            }
                        })), l.length) {
                        var c = function(t, n, e) {
                            var r = n.measureViewportBox(),
                                i = n.getInstance(),
                                o = getComputedStyle(i),
                                a = o.display,
                                u = {};
                            "none" === a && n.setStaticValue("display", t.display || "block"), e.forEach((function(t) {
                                u[t] = jn[t](r, o)
                            })), n.syncRender();
                            var s = n.measureViewportBox();
                            return e.forEach((function(e) {
                                var r = n.getValue(e);
                                kn(r, u[e]), t[e] = jn[e](s, o)
                            })), t
                        }(n, t, l);
                        return u.length && u.forEach((function(n) {
                            var e = (0, r.CR)(n, 2),
                                i = e[0],
                                o = e[1];
                            t.getValue(i).set(o)
                        })), t.syncRender(), {
                            target: c,
                            transitionEnd: i
                        }
                    }
                    return {
                        target: n,
                        transitionEnd: i
                    }
                };

            function Gn(t, n, e, r) {
                return function(t) {
                    return Object.keys(t).some(Ln)
                }(n) ? On(t, n, e, r) : {
                    target: n,
                    transitionEnd: r
                }
            }
            var Hn = function(t, n, e, i) {
                    var o = function(t, n, e) {
                        var i, o = (0, r._T)(n, []),
                            a = t.getInstance();
                        if (!(a instanceof Element)) return {
                            target: o,
                            transitionEnd: e
                        };
                        for (var u in e && (e = (0, r.pi)({}, e)), t.forEachValue((function(t) {
                                var n = t.get();
                                if (wt(n)) {
                                    var e = Ct(n, a);
                                    e && t.set(e)
                                }
                            })), o) {
                            var s = o[u];
                            if (wt(s)) {
                                var l = Ct(s, a);
                                l && (o[u] = l, e && (null !== (i = e[u]) && void 0 !== i || (e[u] = s)))
                            }
                        }
                        return {
                            target: o,
                            transitionEnd: e
                        }
                    }(t, n, i);
                    return Gn(t, n = o.target, e, i = o.transitionEnd)
                },
                _n = e(18329),
                zn = e(69726),
                Nn = e(87669);
            var $n = {
                    treeType: "dom",
                    readValueFromInstance: function(t, n) {
                        if ((0, Jt._c)(n)) {
                            var e = (0, Nn.A)(n);
                            return e && e.default || 0
                        }
                        var r, i = (r = t, window.getComputedStyle(r));
                        return ((0, Sn.o)(n) ? i.getPropertyValue(n) : i[n]) || 0
                    },
                    sortNodePosition: function(t, n) {
                        return 2 & t.compareDocumentPosition(n) ? 1 : -1
                    },
                    getBaseTarget: function(t, n) {
                        var e;
                        return null === (e = t.style) || void 0 === e ? void 0 : e[n]
                    },
                    measureViewportBox: function(t, n) {
                        return nt(t, n.transformPagePoint)
                    },
                    resetTransform: function(t, n, e) {
                        var r = e.transformTemplate;
                        n.style.transform = r ? r({}, "") : "none", t.scheduleRender()
                    },
                    restoreTransform: function(t, n) {
                        t.style.transform = n.style.transform
                    },
                    removeValueFromRenderState: function(t, n) {
                        var e = n.vars,
                            r = n.style;
                        delete e[t], delete r[t]
                    },
                    makeTargetAnimatable: function(t, n, e, i) {
                        var o = e.transformValues;
                        void 0 === i && (i = !0);
                        var a = n.transition,
                            u = n.transitionEnd,
                            s = (0, r._T)(n, ["transition", "transitionEnd"]),
                            l = function(t, n, e) {
                                var r, i, o = {};
                                for (var a in t) o[a] = null !== (r = qt(a, n)) && void 0 !== r ? r : null === (i = e.getValue(a)) || void 0 === i ? void 0 : i.get();
                                return o
                            }(s, a || {}, t);
                        if (o && (u && (u = o(u)), s && (s = o(s)), l && (l = o(l))), i) {
                            ! function(t, n, e) {
                                var r, i, o, a, u = Object.keys(n).filter((function(n) {
                                        return !t.hasValue(n)
                                    })),
                                    s = u.length;
                                if (s)
                                    for (var l = 0; l < s; l++) {
                                        var c = u[l],
                                            v = n[c],
                                            d = null;
                                        Array.isArray(v) && (d = v[0]), null === d && (d = null !== (i = null !== (r = e[c]) && void 0 !== r ? r : t.readValue(c)) && void 0 !== i ? i : n[c]), void 0 !== d && null !== d && ("string" === typeof d && (/^\-?\d*\.?\d+$/.test(d) || Ft(d)) ? d = parseFloat(d) : !Wt(d) && Vt.P.test(v) && (d = (0, Ot.T)(c, v)), t.addValue(c, (0, jt.B)(d)), null !== (o = (a = e)[c]) && void 0 !== o || (a[c] = d), t.setBaseTarget(c, d))
                                    }
                            }(t, s, l);
                            var c = Hn(t, s, l, u);
                            u = c.transitionEnd, s = c.target
                        }
                        return (0, r.pi)({
                            transition: a,
                            transitionEnd: u
                        }, s)
                    },
                    scrapeMotionValuesFromProps: _n.U,
                    build: function(t, n, e, r, i) {
                        void 0 !== t.isVisible && (n.style.visibility = t.isVisible ? "visible" : "hidden"), (0, Rn.r)(n, e, r, i.transformTemplate)
                    },
                    render: zn.N
                },
                Wn = bn($n),
                Yn = e(40491),
                Kn = e(52411),
                Zn = e(90918),
                qn = e(24605),
                Jn = e(31537),
                Xn = bn((0, r.pi)((0, r.pi)({}, $n), {
                    getBaseTarget: function(t, n) {
                        return t[n]
                    },
                    readValueFromInstance: function(t, n) {
                        var e;
                        return (0, Jt._c)(n) ? (null === (e = (0, Nn.A)(n)) || void 0 === e ? void 0 : e.default) || 0 : (n = qn.s.has(n) ? n : (0, Zn.D)(n), t.getAttribute(n))
                    },
                    scrapeMotionValuesFromProps: Yn.U,
                    build: function(t, n, e, r, i) {
                        (0, Kn.i)(n, e, r, i.transformTemplate)
                    },
                    render: Jn.K
                })),
                Qn = e(99622),
                te = (0, r.pi)((0, r.pi)({
                    renderer: function(t, n) {
                        return (0, Qn.q)(t) ? Xn(n, {
                            enableHardwareAcceleration: !1
                        }) : Wn(n, {
                            enableHardwareAcceleration: !0
                        })
                    }
                }, ln), xn),
                ne = (0, Et.yV)({
                    attachResizeListener: function(t, n) {
                        return t.addEventListener("resize", n, {
                                passive: !0
                            }),
                            function() {
                                return t.removeEventListener("resize", n)
                            }
                    },
                    measureScroll: function() {
                        return {
                            x: document.documentElement.scrollLeft || document.body.scrollLeft,
                            y: document.documentElement.scrollTop || document.body.scrollTop
                        }
                    }
                }),
                ee = {
                    current: void 0
                },
                re = (0, Et.yV)({
                    measureScroll: function(t) {
                        return {
                            x: t.scrollLeft,
                            y: t.scrollTop
                        }
                    },
                    defaultParent: function() {
                        if (!ee.current) {
                            var t = new ne(0, {});
                            t.mount(window), t.setOptions({
                                layoutScroll: !0
                            }), ee.current = t
                        }
                        return ee.current
                    },
                    resetTransform: function(t, n) {
                        t.style.transform = null !== n && void 0 !== n ? n : "none"
                    }
                }),
                ie = (0, r.pi)((0, r.pi)((0, r.pi)((0, r.pi)({}, te), vt), kt), {
                    projectionNodeConstructor: re
                })
        }
    }
]);