(function(sttc) {
    'use strict';
    var aa, ca = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function da(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var ea = da(this),
        fa = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        ia = {},
        ja = {};

    function ka(a, b, c) {
        if (!c || null != a) {
            c = ja[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    }

    function la(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in ia ? f = ia : f = ea;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = fa && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? ca(ia, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === ja[d] && (a = 1E9 * Math.random() >>> 0, ja[d] = fa ? ea.Symbol(d) : "$jscp$" + a + "$" + d), ca(f, ja[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    la("String.prototype.replaceAll", function(a) {
        return a ? a : function(b, c) {
            if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
            return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
        }
    }, "es_2021");
    var na = "function" == typeof Object.create ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        oa;
    if (fa && "function" == typeof Object.setPrototypeOf) oa = Object.setPrototypeOf;
    else {
        var pa;
        a: {
            var qa = {
                    a: !0
                },
                ra = {};
            try {
                ra.__proto__ = qa;
                pa = ra.a;
                break a
            } catch (a) {}
            pa = !1
        }
        oa = pa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ta = oa;

    function ua(a, b) {
        a.prototype = na(b.prototype);
        a.prototype.constructor = a;
        if (ta) ta(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Aj = b.prototype
    }
    la("AggregateError", function(a) {
        function b(c, d) {
            d = Error(d);
            "stack" in d && (this.stack = d.stack);
            this.errors = c;
            this.message = d.message
        }
        if (a) return a;
        ua(b, Error);
        b.prototype.name = "AggregateError";
        return b
    }, "es_2021");
    la("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : Array.from(b);
            return Promise.all(b.map(function(c) {
                return Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new ia.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var r = this || self;

    function va(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = r, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    }

    function xa(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function ya(a) {
        var b = xa(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    }

    function za(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function Aa(a) {
        return Object.prototype.hasOwnProperty.call(a, Ba) && a[Ba] || (a[Ba] = ++Ca)
    }
    var Ba = "closure_uid_" + (1E9 * Math.random() >>> 0),
        Ca = 0;

    function Da(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function Fa(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function Ia(a, b, c) {
        Ia = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Da : Fa;
        return Ia.apply(null, arguments)
    }

    function Ja(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function Ka(a, b, c) {
        a = a.split(".");
        c = c || r;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function La(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.Aj = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.Rn = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    }

    function Ma(a) {
        return a
    };
    var Na = {
        Pm: 0,
        Om: 1,
        Nm: 2
    };

    function Oa(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Oa);
        else {
            const c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        void 0 !== b && (this.cause = b)
    }
    La(Oa, Error);
    Oa.prototype.name = "CustomError";
    var Ra;

    function Sa(a, b) {
        a = a.split("%s");
        let c = "";
        const d = a.length - 1;
        for (let e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        Oa.call(this, c + a[d])
    }
    La(Sa, Oa);
    Sa.prototype.name = "AssertionError";

    function Ta(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Ua(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Va(a, b) {
        var c = a.length;
        const d = "string" === typeof a ? a.split("") : a;
        for (--c; 0 <= c; --c) c in d && b.call(void 0, d[c], c, a)
    }

    function Xa(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = "string" === typeof a ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Za(a, b) {
        const c = a.length,
            d = Array(c),
            e = "string" === typeof a ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function $a(a, b, c) {
        let d = c;
        Ua(a, function(e, f) {
            d = b.call(void 0, d, e, f, a)
        });
        return d
    }

    function ab(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function bb(a, b) {
        return 0 <= Ta(a, b)
    }

    function db(a, b) {
        b = Ta(a, b);
        let c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function eb(a, b) {
        let c = 0;
        Va(a, function(d, e) {
            b.call(void 0, d, e, a) && 1 == Array.prototype.splice.call(a, e, 1).length && c++
        })
    }

    function fb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function gb(a) {
        const b = a.length;
        if (0 < b) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function hb(a, b) {
        for (let c = 1; c < arguments.length; c++) {
            const d = arguments[c];
            if (ya(d)) {
                const e = a.length || 0,
                    f = d.length || 0;
                a.length = e + f;
                for (let g = 0; g < f; g++) a[e + g] = d[g]
            } else a.push(d)
        }
    }

    function ib(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    }

    function jb(a, b, c) {
        c = c || kb;
        let d = 0,
            e = a.length,
            f;
        for (; d < e;) {
            const g = d + (e - d >>> 1);
            let h;
            h = c(b, a[g]);
            0 < h ? d = g + 1 : (e = g, f = !h)
        }
        return f ? d : -d - 1
    }

    function lb(a, b) {
        if (!ya(a) || !ya(b) || a.length != b.length) return !1;
        const c = a.length,
            d = ob;
        for (let e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    }

    function kb(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function ob(a, b) {
        return a === b
    }

    function pb(a) {
        const b = [];
        for (let c = 0; c < arguments.length; c++) {
            const d = arguments[c];
            if (Array.isArray(d))
                for (let e = 0; e < d.length; e += 8192) {
                    const f = pb.apply(null, ib(d, e, e + 8192));
                    for (let g = 0; g < f.length; g++) b.push(f[g])
                } else b.push(d)
        }
        return b
    }

    function qb(a, b) {
        b = b || Math.random;
        for (let c = a.length - 1; 0 < c; c--) {
            const d = Math.floor(b() * (c + 1)),
                e = a[c];
            a[c] = a[d];
            a[d] = e
        }
    };
    var rb = {
        Oj: "google_adtest",
        Sj: "google_ad_client",
        Tj: "google_ad_format",
        Vj: "google_ad_height",
        jk: "google_ad_width",
        Zj: "google_ad_layout",
        ak: "google_ad_layout_key",
        bk: "google_ad_output",
        ck: "google_ad_region",
        fk: "google_ad_slot",
        hk: "google_ad_type",
        ik: "google_ad_url",
        Ek: "google_analytics_domain_name",
        Fk: "google_analytics_uacct",
        Tk: "google_container_id",
        el: "google_gl",
        El: "google_enable_ose",
        Ol: "google_full_width_responsive",
        Sm: "google_rl_filtering",
        Rm: "google_rl_mode",
        Tm: "google_rt",
        Qm: "google_rl_dest_url",
        vm: "google_max_radlink_len",
        Bm: "google_num_radlinks",
        Cm: "google_num_radlinks_per_unit",
        Rj: "google_ad_channel",
        um: "google_max_num_ads",
        wm: "google_max_responsive_height",
        Ok: "google_color_border",
        Dl: "google_enable_content_recommendations",
        al: "google_content_recommendation_ui_type",
        Zk: "google_source_type",
        Yk: "google_content_recommendation_rows_num",
        Xk: "google_content_recommendation_columns_num",
        Wk: "google_content_recommendation_ad_positions",
        bl: "google_content_recommendation_use_square_imgs",
        Qk: "google_color_link",
        Pk: "google_color_line",
        Sk: "google_color_url",
        Pj: "google_ad_block",
        ek: "google_ad_section",
        Qj: "google_ad_callback",
        Lk: "google_captcha_token",
        Rk: "google_color_text",
        wk: "google_alternate_ad_url",
        Yj: "google_ad_host_tier_id",
        Mk: "google_city",
        Wj: "google_ad_host",
        Xj: "google_ad_host_channel",
        xk: "google_alternate_color",
        Nk: "google_color_bg",
        Fl: "google_encoding",
        Ml: "google_font_face",
        il: "google_cust_ch",
        ll: "google_cust_job",
        kl: "google_cust_interests",
        jl: "google_cust_id",
        ml: "google_cust_u_url",
        Ql: "google_hints",
        gm: "google_image_size",
        xm: "google_mtl",
        yn: "google_cpm",
        Vk: "google_contents",
        zm: "google_native_settings_key",
        dl: "google_country",
        pn: "google_targeting",
        Nl: "google_font_size",
        ul: "google_disable_video_autoplay",
        Mn: "google_video_product_type",
        Ln: "google_video_doc_id",
        Kn: "google_cust_gender",
        jn: "google_cust_lh",
        hn: "google_cust_l",
        xn: "google_tfs",
        ym: "google_native_ad_template",
        mm: "google_kw",
        mn: "google_tag_for_child_directed_treatment",
        nn: "google_tag_for_under_age_of_consent",
        Vm: "google_region",
        gl: "google_cust_criteria",
        dk: "google_safe",
        fl: "google_ctr_threshold",
        Wm: "google_resizing_allowed",
        Ym: "google_resizing_width",
        Xm: "google_resizing_height",
        Jn: "google_cust_age",
        pm: "google_language",
        nm: "google_kw_type",
        Km: "google_pucrd",
        Im: "google_page_url",
        on: "google_tag_partner",
        cn: "google_restrict_data_processing",
        Kj: "google_adbreak_test",
        Uj: "google_ad_frequency_hint",
        Mj: "google_admob_interstitial_slot",
        Nj: "google_admob_rewarded_slot",
        Lj: "google_admob_ads_only",
        gk: "google_ad_start_delay_hint",
        tm: "google_max_ad_content_rating",
        Mm: "google_ad_public_floor",
        Lm: "google_ad_private_floor",
        In: "google_traffic_source",
        fn: "google_shadow_mode",
        Fm: "google_overlays",
        Jm: "google_privacy_treatments",
        kn: "google_xz"
    };

    function sb(a, b) {
        this.g = a === ub && b || "";
        this.i = vb
    }
    sb.prototype.toString = function() {
        return this.g
    };

    function yb(a) {
        return a instanceof sb && a.constructor === sb && a.i === vb ? a.g : "type_error:Const"
    }
    var vb = {},
        ub = {};
    var t = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        zb = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Ab = class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        },
        Bb = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var Cb = new t(590317302),
        Db = new t(380025941);

    function Fb() {
        return !1
    }

    function Gb() {
        return !0
    }

    function Hb(a) {
        const b = arguments,
            c = b.length;
        return function() {
            for (let d = 0; d < c; d++)
                if (!b[d].apply(this, arguments)) return !1;
            return !0
        }
    }

    function Ib(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function Jb(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function Mb(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    }

    function Nb(a, b) {
        let c = 0;
        return function(d) {
            r.clearTimeout(c);
            const e = arguments;
            c = r.setTimeout(function() {
                a.apply(b, e)
            }, 63)
        }
    }

    function Ob(a, b) {
        function c() {
            e = r.setTimeout(d, 63);
            let h = g;
            g = [];
            a.apply(b, h)
        }

        function d() {
            e = 0;
            f && (f = !1, c())
        }
        let e = 0,
            f = !1,
            g = [];
        return function(h) {
            g = arguments;
            e ? f = !0 : c()
        }
    };
    var Pb = {
            passive: !0
        },
        Qb = Jb(function() {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
                r.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function Rb(a) {
        return a ? a.passive && Qb() ? a : a.capture || !1 : !1
    }

    function Sb(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, Rb(d)), !0) : !1
    }

    function Tb(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, Rb(d)), !0) : !1
    };

    function Ub(a) {
        Ub[" "](a);
        return a
    }
    Ub[" "] = function() {};

    function Vb(a, b) {
        try {
            return Ub(a[b]), !0
        } catch (c) {}
        return !1
    };
    var u = a => {
        var b = "Le";
        if (a.Le && a.hasOwnProperty(b)) return a.Le;
        b = new a;
        return a.Le = b
    };
    var Wb = class {
        constructor() {
            const a = {};
            this.j = (b, c) => null != a[b] ? a[b] : c;
            this.l = (b, c) => null != a[b] ? a[b] : c;
            this.A = (b, c) => null != a[b] ? a[b] : c;
            this.g = (b, c) => null != a[b] ? a[b] : c;
            this.i = () => {}
        }
    };

    function v(a) {
        return u(Wb).j(a.g, a.defaultValue)
    }

    function w(a) {
        return u(Wb).l(a.g, a.defaultValue)
    }

    function Xb(a) {
        return u(Wb).A(a.g, a.defaultValue)
    };
    var Yb = va(610401301, !1),
        Zb = va(572417392, !0);

    function $b(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function bc(a) {
        if (!cc.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(dc, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(ec, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(fc, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(gc, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(hc, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(ic, "&#0;"));
        return a
    }
    var dc = /&/g,
        ec = /</g,
        fc = />/g,
        gc = /"/g,
        hc = /'/g,
        ic = /\x00/g,
        cc = /[\x00&<>"']/;

    function jc(a, b) {
        return -1 != a.indexOf(b)
    };

    function kc() {
        var a = r.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var lc;
    const mc = r.navigator;
    lc = mc ? mc.userAgentData || null : null;

    function nc(a) {
        return Yb ? lc ? lc.brands.some(({
            brand: b
        }) => b && jc(b, a)) : !1 : !1
    }

    function y(a) {
        return jc(kc(), a)
    };

    function oc() {
        return Yb ? !!lc && 0 < lc.brands.length : !1
    }

    function pc() {
        return oc() ? !1 : y("Opera")
    }

    function qc() {
        return oc() ? !1 : y("Trident") || y("MSIE")
    }

    function vc() {
        return y("Safari") && !(wc() || (oc() ? 0 : y("Coast")) || pc() || (oc() ? 0 : y("Edge")) || (oc() ? nc("Microsoft Edge") : y("Edg/")) || (oc() ? nc("Opera") : y("OPR")) || y("Firefox") || y("FxiOS") || y("Silk") || y("Android"))
    }

    function wc() {
        return oc() ? nc("Chromium") : (y("Chrome") || y("CriOS")) && !(oc() ? 0 : y("Edge")) || y("Silk")
    }

    function xc() {
        return y("Android") && !(wc() || y("Firefox") || y("FxiOS") || pc() || y("Silk"))
    };
    var yc = pc(),
        zc = qc(),
        Ac = y("Edge"),
        Bc = Ac || zc,
        Cc = y("Gecko") && !(jc(kc().toLowerCase(), "webkit") && !y("Edge")) && !(y("Trident") || y("MSIE")) && !y("Edge"),
        Dc = jc(kc().toLowerCase(), "webkit") && !y("Edge");

    function Ec() {
        var a = r.document;
        return a ? a.documentMode : void 0
    }
    var Fc;
    a: {
        var Gc = "",
            Hc = function() {
                var a = kc();
                if (Cc) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Ac) return /Edge\/([\d\.]+)/.exec(a);
                if (zc) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (Dc) return /WebKit\/(\S+)/.exec(a);
                if (yc) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();Hc && (Gc = Hc ? Hc[1] : "");
        if (zc) {
            var Ic = Ec();
            if (null != Ic && Ic > parseFloat(Gc)) {
                Fc = String(Ic);
                break a
            }
        }
        Fc = Gc
    }
    var Jc = Fc,
        Kc;
    if (r.document && zc) {
        var Lc = Ec();
        Kc = Lc ? Lc : parseInt(Jc, 10) || void 0
    } else Kc = void 0;
    var Mc = Kc;

    function Oc(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function Pc(a) {
        var b = Qc;
        a: {
            for (const c in b)
                if (b[c] == a) {
                    a = !0;
                    break a
                }
            a = !1
        }
        return a
    }

    function Rc(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function Sc(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    }
    const Tc = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function Uc(a, b) {
        let c, d;
        for (let e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (let f = 0; f < Tc.length; f++) c = Tc[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    var Vc = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var Wc;

    function Xc() {
        if (void 0 === Wc) {
            var a = null,
                b = r.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: Ma,
                        createScript: Ma,
                        createScriptURL: Ma
                    })
                } catch (c) {
                    r.console && r.console.error(c.message)
                }
                Wc = a
            } else Wc = a
        }
        return Wc
    };
    var Yc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function Zc(a, b) {
        a = $c.exec(ad(a).toString());
        var c = a[3] || "";
        return bd(a[1] + cd("?", a[2] || "", b) + cd("#", c))
    }

    function ad(a) {
        return a instanceof Yc && a.constructor === Yc ? a.g : "type_error:TrustedResourceUrl"
    }

    function dd(a, b) {
        var c = yb(a);
        if (!ed.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(fd, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof sb ? yb(d) : encodeURIComponent(String(d))
        });
        return bd(a)
    }
    var fd = /%{(\w+)}/g,
        ed = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i"),
        $c = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        gd = {};

    function bd(a) {
        const b = Xc();
        a = b ? b.createScriptURL(a) : a;
        return new Yc(a, gd)
    }

    function cd(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var hd = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    };

    function id(a) {
        return a instanceof hd && a.constructor === hd ? a.g : "type_error:SafeUrl"
    }
    var jd = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
        kd = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;

    function ld(a) {
        if (a instanceof hd) return a;
        a = String(a);
        kd.test(a) ? a = new hd(a, md) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(jd) ? new hd(a, md) : null);
        return a
    }
    var md = {},
        nd = new hd("about:invalid#zClosurez", md);
    const od = {};

    function pd(a) {
        return a instanceof qd && a.constructor === qd ? a.g : "type_error:SafeStyle"
    }

    function rd(a) {
        let b = "";
        for (let c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                if (!/^[-_a-zA-Z0-9]+$/.test(c)) throw Error(`Name allows only [-_a-zA-Z0-9], got: ${c}`);
                let d = a[c];
                null != d && (d = Array.isArray(d) ? d.map(sd).join(" ") : sd(d), b += `${c}:${d};`)
            }
        return b ? new qd(b, od) : td
    }
    class qd {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    }
    var td = new qd("", od);

    function sd(a) {
        if (a instanceof hd) return 'url("' + id(a).replace(/</g, "%3c").replace(/[\\"]/g, "\\$&") + '")';
        if (a instanceof sb) a = yb(a);
        else {
            a = String(a);
            var b = a.replace(ud, "$1").replace(ud, "$1").replace(vd, "url");
            if (wd.test(b)) {
                if (b = !xd.test(a)) {
                    let c = b = !0;
                    for (let d = 0; d < a.length; d++) {
                        const e = a.charAt(d);
                        "'" == e && c ? b = !b : '"' == e && b && (c = !c)
                    }
                    b = b && c && yd(a)
                }
                a = b ? zd(a) : "zClosurez"
            } else a = "zClosurez"
        }
        if (/[{;}]/.test(a)) throw new Sa("Value does not allow [{;}], got: %s.", [a]);
        return a
    }

    function yd(a) {
        let b = !0;
        const c = /^[-_a-zA-Z0-9]$/;
        for (let d = 0; d < a.length; d++) {
            const e = a.charAt(d);
            if ("]" == e) {
                if (b) return !1;
                b = !0
            } else if ("[" == e) {
                if (!b) return !1;
                b = !1
            } else if (!b && !c.test(e)) return !1
        }
        return b
    }
    const wd = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$"),
        vd = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g"),
        ud = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g"),
        xd = /\/\*/;

    function zd(a) {
        return a.replace(vd, (b, c, d, e) => {
            let f = "";
            d = d.replace(/^(['"])(.*)\1$/, (g, h, k) => {
                f = h;
                return k
            });
            b = (ld(d) || nd).toString();
            return c + f + b + f + e
        })
    };
    class Ad {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    };
    const Bd = {};

    function Cd(a) {
        return a instanceof Dd && a.constructor === Dd ? a.g : "type_error:SafeHtml"
    }

    function Ed(a) {
        const b = Xc();
        a = b ? b.createHTML(a) : a;
        return new Dd(a, Bd)
    }

    function Fd(a) {
        if (!Gd.test(a)) throw Error("");
        if (a.toUpperCase() in Hd) throw Error("");
    }

    function Id(a, b, c) {
        var d = "";
        if (b)
            for (let g in b)
                if (Object.prototype.hasOwnProperty.call(b, g)) {
                    if (!Gd.test(g)) throw Error("");
                    var e = b[g];
                    if (null != e) {
                        var f = g;
                        if (e instanceof sb) e = yb(e);
                        else if ("style" == f.toLowerCase()) {
                            if (!za(e)) throw Error("");
                            e instanceof qd || (e = rd(e));
                            e = pd(e)
                        } else {
                            if (/^on/i.test(f)) throw Error("");
                            if (f.toLowerCase() in Jd)
                                if (e instanceof Yc) e = ad(e).toString();
                                else if (e instanceof hd) e = id(e);
                            else if ("string" === typeof e) e = (ld(e) || nd).toString();
                            else throw Error("");
                        }
                        f = `${f}="` + bc(String(e)) +
                            '"';
                        d += " " + f
                    }
                }
        b = `<${a}` + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === Vc[a.toLowerCase()] ? b += ">" : (c = Kd(c), b += ">" + Cd(c).toString() + "</" + a + ">");
        return Ed(b)
    }

    function Ld(a) {
        var b = Md;
        b = b instanceof Dd ? b : Ed(bc(String(b)));
        const c = [],
            d = e => {
                Array.isArray(e) ? e.forEach(d) : (e = e instanceof Dd ? e : Ed(bc(String(e))), c.push(Cd(e).toString()))
            };
        a.forEach(d);
        return Ed(c.join(Cd(b).toString()))
    }

    function Kd(a) {
        return Ld(Array.prototype.slice.call(arguments))
    }
    class Dd {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    }
    const Gd = /^[a-zA-Z0-9-]+$/,
        Jd = {
            action: !0,
            cite: !0,
            data: !0,
            formaction: !0,
            href: !0,
            manifest: !0,
            poster: !0,
            src: !0
        },
        Hd = {
            APPLET: !0,
            BASE: !0,
            EMBED: !0,
            IFRAME: !0,
            LINK: !0,
            MATH: !0,
            META: !0,
            OBJECT: !0,
            SCRIPT: !0,
            STYLE: !0,
            SVG: !0,
            TEMPLATE: !0
        };
    var Md = new Dd(r.trustedTypes && r.trustedTypes.emptyHTML || "", Bd),
        Nd = Ed("<br>");
    var Od = Jb(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = Cd(Md);
        return !b.parentElement
    });

    function Pd(a, b) {
        if (Od())
            for (; a.lastChild;) a.removeChild(a.lastChild);
        a.innerHTML = Cd(b)
    }
    var Qd = /^[\w+/_-]+[=]{0,2}$/;

    function Rd(a, b, c) {
        return Math.min(Math.max(a, b), c)
    }

    function Ud(a) {
        return Array.prototype.reduce.call(arguments, function(b, c) {
            return b + c
        }, 0)
    }

    function Vd(a) {
        return Ud.apply(null, arguments) / arguments.length
    };

    function Wd(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    }
    Wd.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    Wd.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    Wd.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };

    function Xd(a, b) {
        this.width = a;
        this.height = b
    }

    function Yd(a, b) {
        return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
    }
    aa = Xd.prototype;
    aa.aspectRatio = function() {
        return this.width / this.height
    };
    aa.isEmpty = function() {
        return !(this.width * this.height)
    };
    aa.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    aa.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    aa.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function Zd(a, b) {
        const c = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        let d;
        d = b ? b.createElement("div") : r.document.createElement("div");
        return a.replace($d, function(e, f) {
            var g = c[e];
            if (g) return g;
            "#" == f.charAt(0) && (f = Number("0" + f.slice(1)), isNaN(f) || (g = String.fromCharCode(f)));
            g || (g = Ed(e + " "), Pd(d, g), g = d.firstChild.nodeValue.slice(0, -1));
            return c[e] = g
        })
    }
    var $d = /&([^;\s<&]+);?/g;

    function ae(a) {
        let b = 0;
        for (let c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
        return b
    }

    function be(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function ce(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };

    function de(a) {
        return a ? new ee(fe(a)) : Ra || (Ra = new ee)
    }

    function ge(a) {
        a = a.document;
        a = "CSS1Compat" == a.compatMode ? a.documentElement : a.body;
        return new Xd(a.clientWidth, a.clientHeight)
    }

    function he(a) {
        var b = a.scrollingElement ? a.scrollingElement : Dc || "CSS1Compat" != a.compatMode ? a.body || a.documentElement : a.documentElement;
        a = ie(a);
        return zc && a.pageYOffset != b.scrollTop ? new Wd(b.scrollLeft, b.scrollTop) : new Wd(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
    }

    function ie(a) {
        return a.parentWindow || a.defaultView
    }

    function je(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function ke(a, b) {
        var c = je(a, "DIV");
        zc ? (b = Kd(Nd, b), Pd(c, b), c.removeChild(c.firstChild)) : Pd(c, b);
        if (1 == c.childNodes.length) c = c.removeChild(c.firstChild);
        else {
            for (a = a.createDocumentFragment(); c.firstChild;) a.appendChild(c.firstChild);
            c = a
        }
        return c
    }

    function fe(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    }
    var le = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        },
        me = {
            IMG: " ",
            BR: "\n"
        };

    function ne(a) {
        var b = [];
        oe(a, b, !0);
        a = b.join("");
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g, "");
        a = a.replace(/ +/g, " ");
        " " != a && (a = a.replace(/^\s*/, ""));
        return a
    }

    function oe(a, b, c) {
        if (!(a.nodeName in le))
            if (3 == a.nodeType) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in me) b.push(me[a.nodeName]);
        else
            for (a = a.firstChild; a;) oe(a, b, c), a = a.nextSibling
    }

    function pe(a, b, c) {
        if (!b && !c) return null;
        var d = b ? String(b).toUpperCase() : null;
        return qe(a, function(e) {
            return (!d || e.nodeName == d) && (!c || "string" === typeof e.className && bb(e.className.split(/\s+/), c))
        })
    }

    function qe(a, b) {
        for (var c = 0; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function ee(a) {
        this.g = a || r.document || document
    }
    aa = ee.prototype;
    aa.wh = function(a) {
        var b = this.g;
        return "string" === typeof a ? b.getElementById(a) : a
    };
    aa.Jj = ee.prototype.wh;

    function re(a, b) {
        return je(a.g, b)
    }

    function se(a, b) {
        return ke(a.g, b)
    }
    aa.da = function() {
        return ie(this.g)
    };
    aa.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    aa.wi = function(a) {
        var b, c = arguments.length;
        if (!c) return null;
        if (1 == c) return arguments[0];
        var d = [],
            e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (var h = 1; h < c; h++)
                if (g != d[h][b]) return f;
            f = g
        }
        return f
    };

    function te() {
        return Yb && lc ? lc.mobile : !ue() && (y("iPod") || y("iPhone") || y("Android") || y("IEMobile"))
    }

    function ue() {
        return Yb && lc ? !lc.mobile && (y("iPad") || y("Android") || y("Silk")) : y("iPad") || y("Android") && !y("Mobile") || y("Silk")
    };
    var ve = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function we(a, b) {
        if (!b) return a;
        var c = a.indexOf("#");
        0 > c && (c = a.length);
        var d = a.indexOf("?");
        if (0 > d || d > c) {
            d = c;
            var e = ""
        } else e = a.substring(d + 1, c);
        a = [a.slice(0, d), e, a.slice(c)];
        c = a[1];
        a[1] = b ? c ? c + "&" + b : b : c;
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    }

    function xe(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) xe(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };

    function ye(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    class ze {
        constructor(a) {
            this.Qi = a
        }
    }

    function Ae(a) {
        return new ze(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const Be = [Ae("data"), Ae("http"), Ae("https"), Ae("mailto"), Ae("ftp"), new ze(a => /^[^:]*([/?#]|$)/.test(a))];

    function Ce(a, b = Be) {
        if (a instanceof hd) return a;
        for (let c = 0; c < b.length; ++c) {
            const d = b[c];
            if (d instanceof ze && d.Qi(a)) return new hd(a, md)
        }
    }

    function De(a) {
        a: {
            try {
                var b = new URL(a)
            } catch (c) {
                b = "https:";
                break a
            }
            b = b.protocol
        }
        if ("javascript:" !== b) return a
    };

    function Ee(a) {
        var b = Ce("#", Be) || nd;
        b = b instanceof hd ? id(b) : De(b);
        void 0 !== b && (a.href = b)
    };
    var Ke = class {};
    class Le extends Ke {
        constructor(a) {
            super();
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Me(a, b, c) {
        var d = [Ne `width`, Ne `height`];
        if (0 === d.length) throw Error("");
        d = d.map(f => {
            if (f instanceof Le) f = f.g;
            else throw Error("");
            return f
        });
        const e = b.toLowerCase();
        if (d.every(f => 0 !== e.indexOf(f))) throw Error(`Attribute "${b}" does not match any of the allowed prefixes.`);
        a.setAttribute(b, c)
    };

    function Oe(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const Pe = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Qe(a, b) {
        a.src = ad(b);
        (void 0) ? .Xn || (b = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };

    function Re(a) {
        try {
            return !!a && null != a.location.href && Vb(a, "foo")
        } catch {
            return !1
        }
    }

    function Se(a, b = r) {
        b = Te(b);
        let c = 0;
        for (; b && 40 > c++ && !a(b);) b = Te(b)
    }

    function Te(a) {
        try {
            const b = a.parent;
            if (b && b != a) return b
        } catch {}
        return null
    }

    function Ue(a) {
        return Re(a.top) ? a.top : null
    }

    function Ve(a, b) {
        const c = We("SCRIPT", a);
        Qe(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    }

    function Xe(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function Ye() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function Ze(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function $e(a) {
        const b = [];
        Ze(a, function(c) {
            b.push(c)
        });
        return b
    }

    function af(a) {
        const b = a.length;
        if (0 == b) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    }
    var cf = Jb(() => ab(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], bf) || 1E-4 > Math.random());
    const bf = a => jc(kc(), a);
    var df = /^([0-9.]+)px$/,
        ef = /^(-?[0-9.]{1,30})$/;

    function ff(a) {
        if (!ef.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function gf(a) {
        return (a = df.exec(a)) ? +a[1] : null
    }
    var hf = {
        kk: "allow-forms",
        lk: "allow-modals",
        mk: "allow-orientation-lock",
        nk: "allow-pointer-lock",
        pk: "allow-popups",
        qk: "allow-popups-to-escape-sandbox",
        rk: "allow-presentation",
        sk: "allow-same-origin",
        tk: "allow-scripts",
        uk: "allow-top-navigation",
        vk: "allow-top-navigation-by-user-activation"
    };
    const jf = Jb(() => $e(hf));

    function kf() {
        var a = ["allow-top-navigation", "allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"];
        const b = jf();
        return a.length ? Xa(b, c => !bb(a, c)) : b
    }

    function lf() {
        const a = We("IFRAME"),
            b = {};
        Ua(jf(), c => {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    }
    var mf = (a, b) => {
            try {
                return !(!a.frames || !a.frames[b])
            } catch {
                return !1
            }
        },
        nf = (a, b) => {
            for (let c = 0; 50 > c; ++c) {
                if (mf(a, b)) return a;
                if (!(a = Te(a))) break
            }
            return null
        },
        of = Jb(() => te() ? 2 : ue() ? 1 : 0),
        A = (a, b) => {
            Ze(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        },
        qf = (a, b) => {
            if ("length" in a.style) {
                a = a.style;
                const c = a.length;
                for (let d = 0; d < c; d++) {
                    const e = a[d];
                    b(a[e], e, a)
                }
            } else a = pf(a.style.cssText), Ze(a, b)
        },
        pf = a => {
            const b = {};
            if (a) {
                const c = /\s*:\s*/;
                Ua((a || "").split(/\s*;\s*/), d => {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d &&
                            e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        rf = a => {
            const b = /!\s*important/i;
            qf(a, (c, d) => {
                b.test(c) ? b.test(c) : a.style.setProperty(d, c, "important")
            })
        };
    const sf = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        tf = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        uf = /.*domain\.test$/,
        vf = /\.prod\.google\.com(:\d+)?$/;
    var wf = a => sf[a] || tf.test(a) || uf.test(a) || vf.test(a);
    let xf = [];
    const yf = () => {
        const a = xf;
        xf = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var zf = () => {
            var a = Math.random;
            return Math.floor(a() * 2 ** 52)
        },
        Af = (a, b) => {
            if ("number" !== typeof a.goog_pvsid) try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: zf(),
                    configurable: !1
                })
            } catch (c) {
                b && b.Ba(784, c)
            }
            a = Number(a.goog_pvsid);
            b && (!a || 0 >= a) && b.Ba(784, Error(`Invalid correlator, ${a}`));
            return a || -1
        },
        Bf = (a, b) => {
            "complete" === a.document.readyState ? (xf.push(b), 1 == xf.length && (window.Promise ? Promise.resolve().then(yf) : window.setImmediate ? setImmediate(yf) : setTimeout(yf, 0))) : a.addEventListener("load", b)
        },
        Cf = (a,
            b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        });

    function We(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    }
    var Df = a => {
            let b = a;
            for (; a && a != a.parent;) a = a.parent, Re(a) && (b = a);
            return b
        },
        Ff = a => v(Cb) || wc() && te() ? Ef(a) : 1,
        Ef = a => {
            var b = Ue(a);
            if (!b) return 1;
            a = 0 === of ();
            const c = !!b.document.querySelector('meta[name=viewport][content*="width=device-width"]'),
                d = b.innerWidth;
            b = b.outerWidth;
            if (0 === d) return 1;
            const e = Math.round(100 * (b / d + Number.EPSILON)) / 100;
            return 1 === e ? 1 : a || c ? e : Math.round(100 * (b / d / .4 + Number.EPSILON)) / 100
        };

    function Gf(a) {
        r.setTimeout(() => {
            throw a;
        }, 0)
    };
    xc();
    wc();
    vc();
    var Hf = {},
        If = null;

    function Jf(a) {
        var b = 3;
        void 0 === b && (b = 0);
        Kf();
        b = Hf[b];
        const c = Array(Math.floor(a.length / 3)),
            d = b[64] || "";
        let e = 0,
            f = 0;
        for (; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function Lf(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            255 < e && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        return Jf(b)
    }

    function Mf(a) {
        var b = [];
        Nf(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Nf(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    m = If[l];
                if (null != m) return m;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
            }
            return k
        }
        Kf();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (64 === h && -1 === e) break;
            b(e << 2 | f >> 4);
            64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
        }
    }

    function Kf() {
        if (!If) {
            If = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                var d = a.concat(b[c].split(""));
                Hf[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e];
                    void 0 === If[f] && (If[f] = e)
                }
            }
        }
    };

    function Of(a) {
        let b = "",
            c = 0;
        const d = a.length - 10240;
        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    }
    const Pf = /[-_.]/g,
        Qf = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Rf(a) {
        return Qf[a] || ""
    }

    function Sf(a) {
        return null != a && a instanceof Uint8Array
    }
    let Tf;
    var Uf = {};
    let Vf;

    function Wf(a) {
        if (a !== Uf) throw Error("illegal external caller");
    }

    function Xf() {
        return Vf || (Vf = new Yf(null, Uf))
    }
    var Yf = class {
        constructor(a, b) {
            Wf(b);
            this.M = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        }
        isEmpty() {
            return null == this.M
        }
    };
    var Zf = !Zb;
    let ng = !Zb;
    let og = 0,
        pg = 0;

    function qg(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        if (b) {
            b = c;
            c = ~a;
            b ? b = ~b + 1 : c += 1;
            const [d, e] = [b, c];
            a = e;
            c = d
        }
        og = c >>> 0;
        pg = a >>> 0
    }

    function rg(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        2097151 >= b ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function sg() {
        var a = og,
            b = pg,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = rg(a, b);
        return c
    }

    function tg(a) {
        16 > a.length ? qg(Number(a)) : (a = BigInt(a), og = Number(a & BigInt(4294967295)) >>> 0, pg = Number(a >> BigInt(32) & BigInt(4294967295)))
    };

    function ug(a) {
        return Array.prototype.slice.call(a)
    };
    var B = Symbol(),
        vg = Symbol(),
        wg = Symbol();

    function xg(a) {
        const b = a[B] | 0;
        1 !== (b & 1) && (Object.isFrozen(a) && (a = ug(a)), a[B] = b | 1)
    }

    function yg(a, b, c) {
        return c ? a | b : a & ~b
    }

    function zg() {
        var a = [];
        a[B] |= 1;
        return a
    }

    function Ag(a) {
        a[B] |= 34;
        return a
    }

    function Bg(a) {
        a[B] |= 32;
        return a
    }

    function Cg(a, b) {
        b[B] = (a | 0) & -14591
    }

    function Dg(a, b) {
        b[B] = (a | 34) & -14557
    }

    function Eg(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var Fg = {},
        Gg = {};

    function Hg(a) {
        return !(!a || "object" !== typeof a || a.Vi !== Gg)
    }

    function Ig(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let Jg, Kg = !Zb;

    function Lg(a, b, c) {
        if (null != a)
            if ("string" === typeof a) a = a ? new Yf(a, Uf) : Xf();
            else if (a.constructor !== Yf)
            if (Sf(a)) {
                var d;
                c ? d = 0 == a.length ? Xf() : new Yf(a, Uf) : d = a.length ? new Yf(new Uint8Array(a), Uf) : Xf();
                a = d
            } else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    }

    function Mg(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        const d = a[B] | 0;
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        a[B] = d | 1;
        return !0
    }
    var Ng;
    const Og = [];
    Og[B] = 55;
    Ng = Object.freeze(Og);

    function Pg(a) {
        if (a & 2) throw Error();
    }
    class Qg {
        constructor(a, b, c) {
            this.j = 0;
            this.g = a;
            this.i = b;
            this.l = c
        }
        next() {
            if (this.j < this.g.length) {
                const a = this.g[this.j++];
                return {
                    done: !1,
                    value: this.i ? this.i.call(this.l, a) : a
                }
            }
            return {
                done: !0,
                value: void 0
            }
        }[Symbol.iterator]() {
            return new Qg(this.g, this.i, this.l)
        }
    }
    var Rg = {};
    class Sg {}
    class Tg {}
    Object.freeze(new Sg);
    Object.freeze(new Tg);
    let Ug;

    function Vg(a) {
        if (Ug) throw Error("");
        Ug = a
    }

    function Wg(a) {
        if (Ug) try {
            Ug(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function Xg() {
        const a = Yg();
        Ug ? r.setTimeout(() => {
            Wg(a)
        }, 0) : Gf(a)
    }

    function Zg(a) {
        a = Error(a);
        ye(a, "warning");
        Wg(a);
        return a
    }

    function Yg() {
        const a = Error();
        ye(a, "incident");
        return a
    };

    function $g(a) {
        if (null != a && "number" !== typeof a) throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);
        return a
    }

    function ah(a) {
        if ("boolean" !== typeof a) throw Error(`Expected boolean but got ${xa(a)}: ${a}`);
        return a
    }
    const bh = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function ch(a) {
        const b = typeof a;
        return "number" === b ? Number.isFinite(a) : "string" !== b ? !1 : bh.test(a)
    }

    function dh(a) {
        if (null != a) {
            if (!Number.isFinite(a)) throw Zg("enum");
            a |= 0
        }
        return a
    }

    function eh(a) {
        return null == a ? a : Number.isFinite(a) ? a | 0 : void 0
    }

    function fh(a) {
        if ("number" !== typeof a) throw Zg("int32");
        if (!Number.isFinite(a)) throw Zg("int32");
        return a | 0
    }

    function gh(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    }

    function hh(a) {
        if ("number" !== typeof a) throw Zg("uint32");
        if (!Number.isFinite(a)) throw Zg("uint32");
        return a >>> 0
    }

    function ih(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a >>> 0 : void 0
    }

    function jh(a, b) {
        b = !!b;
        if (!ch(a)) throw Zg("int64");
        "string" === typeof a ? a = kh(a) : b ? (a = Math.trunc(a), Number.isSafeInteger(a) ? a = String(a) : (b = String(a), lh(b) ? a = b : (qg(a), a = sg()))) : a = mh(a);
        return a
    }

    function nh(a) {
        return "-" === a[0] ? !1 : 20 > a.length ? !0 : 20 === a.length && 184467 > Number(a.substring(0, 6))
    }

    function lh(a) {
        return "-" === a[0] ? 20 > a.length ? !0 : 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length ? !0 : 19 === a.length && 922337 > Number(a.substring(0, 6))
    }

    function oh(a) {
        if (0 > a) {
            qg(a);
            const b = rg(og, pg);
            a = Number(b);
            return Number.isSafeInteger(a) ? a : b
        }
        if (nh(String(a))) return a;
        qg(a);
        return 4294967296 * pg + (og >>> 0)
    }

    function mh(a) {
        a = Math.trunc(a);
        if (!Number.isSafeInteger(a)) {
            qg(a);
            var b = og,
                c = pg;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, 0 == b && (c = c + 1 >>> 0);
            b = 4294967296 * c + (b >>> 0);
            a = a ? -b : b
        }
        return a
    }

    function kh(a) {
        var b = Math.trunc(Number(a));
        if (Number.isSafeInteger(b)) return String(b);
        b = a.indexOf("."); - 1 !== b && (a = a.substring(0, b));
        lh(a) || (tg(a), a = sg());
        return a
    }

    function ph(a) {
        if (null == a) return a;
        if (ch(a)) {
            var b;
            "number" === typeof a ? b = mh(a) : b = kh(a);
            return b
        }
    }

    function qh(a, b) {
        b = !!b;
        if (!ch(a)) throw Zg("uint64");
        "string" === typeof a ? (b = Math.trunc(Number(a)), Number.isSafeInteger(b) && 0 <= b ? a = String(b) : (b = a.indexOf("."), -1 !== b && (a = a.substring(0, b)), nh(a) || (tg(a), a = rg(og, pg)))) : b ? (a = Math.trunc(a), 0 <= a && Number.isSafeInteger(a) ? a = String(a) : (b = String(a), nh(b) ? a = b : (qg(a), a = rg(og, pg)))) : (a = Math.trunc(a), a = 0 <= a && Number.isSafeInteger(a) ? a : oh(a));
        return a
    }

    function rh(a) {
        return null == a ? a : qh(a)
    }

    function sh(a) {
        if ("string" !== typeof a) throw Error();
        return a
    }

    function th(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    }

    function uh(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function vh(a, b, c, d) {
        if (null != a && "object" === typeof a && a.Se === Fg) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? wh(b) : new b : void 0;
        let e = c = a[B] | 0;
        0 === e && (e |= d & 32);
        e |= d & 2;
        e !== c && (a[B] = e);
        return new b(a)
    }

    function wh(a) {
        var b = a[vg];
        if (b) return b;
        b = new a;
        Ag(b.W);
        return a[vg] = b
    }

    function xh(a, b, c) {
        return b ? sh(a) : uh(a) ? ? (c ? "" : void 0)
    };
    const yh = (() => class extends Map {
        constructor() {
            super()
        }
    })();

    function zh(a) {
        return a
    }

    function Ah(a) {
        if (a.Wc & 2) throw Error("Cannot mutate an immutable Map");
    }
    var Eh = class extends yh {
        constructor(a, b, c = zh, d = zh) {
            super();
            let e = a[B] | 0;
            e |= 64;
            this.Wc = a[B] = e;
            this.Vd = b;
            this.Bc = c || zh;
            this.wf = this.Vd ? Bh : d || zh;
            for (let f = 0; f < a.length; f++) {
                const g = a[f],
                    h = c(g[0], !1, !0);
                let k = g[1];
                b ? void 0 === k && (k = null) : k = d(g[1], !1, !0, void 0, void 0, e);
                super.set(h, k)
            }
        }
        ih(a = Ch) {
            return this.sf(a)
        }
        sf(a = Ch) {
            const b = [],
                c = super.entries();
            for (var d; !(d = c.next()).done;) d = d.value, d[0] = a(d[0]), d[1] = a(d[1]), b.push(d);
            return b
        }
        yc() {
            return this.size
        }
        clear() {
            Ah(this);
            super.clear()
        }
        delete(a) {
            Ah(this);
            return super.delete(this.Bc(a, !0, !1))
        }
        entries() {
            var a = this.xg();
            return new Qg(a, Dh, this)
        }
        keys() {
            return this.Ri()
        }
        values() {
            var a = this.xg();
            return new Qg(a, Eh.prototype.get, this)
        }
        forEach(a, b) {
            super.forEach((c, d) => {
                a.call(b, this.get(d), d, this)
            })
        }
        set(a, b) {
            Ah(this);
            a = this.Bc(a, !0, !1);
            return null == a ? this : null == b ? (super.delete(a), this) : super.set(a, this.wf(b, !0, !0, this.Vd, !1, this.Wc))
        }
        has(a) {
            return super.has(this.Bc(a, !1, !1))
        }
        get(a) {
            a = this.Bc(a, !1, !1);
            const b = super.get(a);
            if (void 0 !== b) {
                var c = this.Vd;
                return c ?
                    (c = this.wf(b, !1, !0, c, this.Th, this.Wc), c !== b && super.set(a, c), c) : b
            }
        }
        xg() {
            return Array.from(super.keys())
        }
        Ri() {
            return super.keys()
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    Eh.prototype.toJSON = void 0;
    Eh.prototype.Vi = Gg;

    function Bh(a, b, c, d, e, f) {
        a = vh(a, d, c, f);
        e && (a = Fh(a));
        return a
    }

    function Ch(a) {
        return a
    }

    function Dh(a) {
        return [a, this.get(a)]
    };
    let Gh;

    function Hh(a, b) {
        Gh = b;
        a = new a(b);
        Gh = void 0;
        return a
    };

    function Ih(a, b) {
        return Jh(b)
    }

    function Jh(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return Kg || !Mg(a, void 0, 9999) ? a : void 0;
                    if (Sf(a)) return Of(a);
                    if (a instanceof Yf) {
                        const b = a.M;
                        return null == b ? "" : "string" === typeof b ? b : a.M = Of(b)
                    }
                    if (a instanceof Eh) return a = a.ih(), Zf || 0 !== a.length ? a : void 0
                }
        }
        return a
    };

    function Kh(a, b, c) {
        a = ug(a);
        var d = a.length;
        const e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (const f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    }

    function Lh(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && (a[B] | 0) & 1 ? void 0 : f && (a[B] | 0) & 2 ? a : Mh(a, b, c, void 0 !== d, e, f);
            else if (Ig(a)) {
                const g = {};
                for (let h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = Lh(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function Mh(a, b, c, d, e, f) {
        const g = d || c ? a[B] | 0 : 0;
        d = d ? !!(g & 32) : void 0;
        a = ug(a);
        for (let h = 0; h < a.length; h++) a[h] = Lh(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    }

    function Nh(a) {
        return Lh(a, Oh, void 0, void 0, !1, !1)
    }

    function Oh(a) {
        return a.Se === Fg ? a.toJSON() : a instanceof Eh ? a.ih(Nh) : Jh(a)
    };

    function Ph(a, b, c = Dg) {
        if (null != a) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[B] | 0;
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[B] = (d | 34) & -12293, a) : Mh(a, Ph, d & 4 ? Dg : c, !0, !1, !0)
            }
            a.Se === Fg ? (c = a.W, d = c[B], a = d & 2 ? a : Hh(a.constructor, Qh(c, d, !0))) : a instanceof Eh && (c = Ag(a.sf(Ph)), a = new Eh(c, a.Vd, a.Bc, a.wf));
            return a
        }
    }

    function Rh(a) {
        const b = a.W;
        return Hh(a.constructor, Qh(b, b[B], !1))
    }

    function Qh(a, b, c) {
        const d = c || b & 2 ? Dg : Cg,
            e = !!(b & 32);
        a = Kh(a, b, f => Ph(f, e, d));
        a[B] = a[B] | 32 | (c ? 2 : 0);
        return a
    }

    function Fh(a) {
        const b = a.W,
            c = b[B];
        return c & 2 ? Hh(a.constructor, Qh(b, c, !1)) : a
    };

    function Sh(a, b, c) {
        if (!(4 & b)) return !0;
        if (null == c) return !1;
        0 === c && (4096 & b || 8192 & b) && 5 > (a.constructor[wg] = (a.constructor[wg] | 0) + 1) && Xg();
        return 0 === c ? !1 : !(c & b)
    }

    function Th(a, b) {
        a = a.W;
        return Uh(a, a[B], b)
    }

    function Uh(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= Eg(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    }

    function Vh(a, b, c) {
        const d = a.W;
        let e = d[B];
        Pg(e);
        Wh(d, e, b, c);
        return a
    }

    function Wh(a, b, c, d, e) {
        const f = Eg(b);
        if (c >= f || e) {
            let g = b;
            if (b & 256) e = a[a.length - 1];
            else {
                if (null == d) return g;
                e = a[f + (+!!(b & 512) - 1)] = {};
                g |= 256
            }
            e[c] = d;
            c < f && (a[c + (+!!(b & 512) - 1)] = void 0);
            g !== b && (a[B] = g);
            return g
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    }

    function Xh(a, b, c) {
        return void 0 !== Yh(a, b, c, !1)
    }

    function Zh(a, b) {
        a = a.W;
        let c = a[B];
        const d = Uh(a, c, b);
        var e = null == d || "number" === typeof d ? d : "NaN" === d || "Infinity" === d || "-Infinity" === d ? Number(d) : void 0;
        null != e && e !== d && Wh(a, c, b, e);
        return e
    }

    function $h(a, b) {
        a = Th(a, b);
        return null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0
    }

    function ai(a, b, c, d, e, f, g) {
        const h = a.W;
        let k = h[B];
        d = 2 & k ? 1 : d;
        f = !!f;
        let l = bi(h, k, b, e);
        var m = l[B] | 0;
        if (Sh(a, m, g)) {
            if (4 & m || Object.isFrozen(l)) l = ug(l), m = ci(m, k, f), k = Wh(h, k, b, l, e);
            let p = a = 0;
            for (; a < l.length; a++) {
                const q = c(l[a]);
                null != q && (l[p++] = q)
            }
            p < a && (l.length = p);
            m = di(m, k, f);
            m = yg(m, 20, !0);
            m = yg(m, 4096, !1);
            m = yg(m, 8192, !1);
            g && (m = yg(m, g, !0));
            l[B] = m;
            2 & m && Object.freeze(l)
        }
        ei(m) || (g = m, (c = 1 === d) ? m = yg(m, 2, !0) : f || (m = yg(m, 32, !1)), m !== g && (l[B] = m), c && Object.freeze(l));
        2 === d && ei(m) && (l = ug(l), m = ci(m, k, f), l[B] = m, Wh(h,
            k, b, l, e));
        var n;
        f ? n = l : n = l;
        return n
    }

    function bi(a, b, c, d) {
        a = Uh(a, b, c, d);
        return Array.isArray(a) ? a : Ng
    }

    function di(a, b, c) {
        0 === a && (a = ci(a, b, c));
        return a = yg(a, 1, !0)
    }

    function ei(a) {
        return !!(2 & a) && !!(4 & a) || !!(2048 & a)
    }
    let fi;

    function gi() {
        return fi ? ? (fi = new Eh(Ag([]), void 0, void 0, void 0, Rg))
    }

    function hi(a, b, c) {
        var d = ii,
            e = b & 2;
        let f = !1;
        if (null == c) {
            if (e) return gi();
            c = []
        } else if (c.constructor === Eh) {
            if (0 == (c.Wc & 2) || e) return c;
            c = c.sf()
        } else Array.isArray(c) ? f = !!((c[B] | 0) & 2) : c = [];
        if (e) {
            if (!c.length) return gi();
            f || (f = !0, Ag(c))
        } else if (f) {
            f = !1;
            e = ug(c);
            for (c = 0; c < e.length; c++) {
                const g = e[c] = ug(e[c]);
                Array.isArray(g[1]) && (g[1] = Ag(g[1]))
            }
            c = e
        }
        f || ((c[B] | 0) & 64 ? c[B] &= -33 : 32 & b && Bg(c));
        d = new Eh(c, d, xh, void 0);
        Wh(a, b, 14, d, !1);
        return d
    }

    function ji(a, b, c, d) {
        const e = a.W;
        let f = e[B];
        Pg(f);
        if (null == c) return Wh(e, f, b), a;
        let g = c[B] | 0,
            h = g;
        var k = !!(2 & g) || Object.isFrozen(c);
        const l = !k && !1;
        if (Sh(a, g))
            for (g = 21, k && (c = ug(c), h = 0, g = ci(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        l && (c = ug(c), h = 0, g = ci(g, f, !0));
        g !== h && (c[B] = g);
        Wh(e, f, b, c);
        return a
    }

    function ki(a, b, c, d) {
        const e = a.W;
        let f = e[B];
        Pg(f);
        Wh(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    }

    function li(a, b, c, d) {
        const e = a.W;
        let f = e[B];
        Pg(f);
        (c = mi(e, f, c)) && c !== b && null != d && (f = Wh(e, f, c));
        Wh(e, f, b, d);
        return a
    }

    function ni(a, b, c) {
        a = a.W;
        return mi(a, a[B], b) === c ? c : -1
    }

    function mi(a, b, c) {
        let d = 0;
        for (let e = 0; e < c.length; e++) {
            const f = c[e];
            null != Uh(a, b, f) && (0 !== d && (b = Wh(a, b, d)), d = f)
        }
        return d
    }

    function Yh(a, b, c, d) {
        a = a.W;
        let e = a[B];
        const f = Uh(a, e, c, d);
        b = vh(f, b, !1, e);
        b !== f && null != b && Wh(a, e, c, b, d);
        return b
    }

    function oi(a) {
        var b = pi;
        return (a = Yh(a, b, 1, !1)) ? a : wh(b)
    }

    function C(a, b, c) {
        b = Yh(a, b, c, !1);
        if (null == b) return b;
        a = a.W;
        let d = a[B];
        if (!(d & 2)) {
            const e = Fh(b);
            e !== b && (b = e, Wh(a, d, c, b, !1))
        }
        return b
    }

    function qi(a, b, c, d, e, f, g, h) {
        var k = !!(2 & b),
            l = k ? 1 : e;
        e = 1 === l;
        l = 2 === l;
        g = !!g;
        h && (h = !k);
        k = bi(a, b, d, f);
        var m = k[B] | 0;
        const n = !!(4 & m);
        if (!n) {
            m = di(m, b, g);
            var p = k,
                q = b;
            const x = !!(2 & m);
            x && (q = yg(q, 2, !0));
            let z = !x,
                G = !0,
                F = 0,
                K = 0;
            for (; F < p.length; F++) {
                const H = vh(p[F], c, !1, q);
                if (H instanceof c) {
                    if (!x) {
                        const N = !!((H.W[B] | 0) & 2);
                        z && (z = !N);
                        G && (G = N)
                    }
                    p[K++] = H
                }
            }
            K < F && (p.length = K);
            m = yg(m, 4, !0);
            m = yg(m, 16, G);
            m = yg(m, 8, z);
            p[B] = m;
            x && Object.freeze(p)
        }
        c = !!(8 & m) || e && !k.length;
        if (h && !c) {
            ei(m) && (k = ug(k), m = ci(m, b, g), b = Wh(a, b, d, k, f));
            h =
                k;
            c = m;
            for (p = 0; p < h.length; p++) m = h[p], q = Fh(m), m !== q && (h[p] = q);
            c = yg(c, 8, !0);
            c = yg(c, 16, !h.length);
            m = h[B] = c
        }
        ei(m) || (h = m, e ? m = yg(m, !k.length || 16 & m && (!n || 32 & m) ? 2 : 2048, !0) : g || (m = yg(m, 32, !1)), m !== h && (k[B] = m), e && Object.freeze(k));
        l && ei(m) && (k = ug(k), m = ci(m, b, g), k[B] = m, Wh(a, b, d, k, f));
        return k
    }

    function D(a, b, c) {
        a = a.W;
        const d = a[B];
        return qi(a, d, b, c, 2, void 0, !1, !(2 & d))
    }

    function E(a, b, c) {
        null == c && (c = void 0);
        return Vh(a, b, c)
    }

    function ri(a, b, c, d) {
        null == d && (d = void 0);
        return li(a, b, c, d)
    }

    function si(a, b, c) {
        const d = a.W;
        let e = d[B];
        Pg(e);
        if (null == c) return Wh(d, e, b), a;
        let f = c[B] | 0,
            g = f;
        const h = !!(2 & f) || !!(2048 & f),
            k = h || Object.isFrozen(c);
        let l = !0,
            m = !0;
        for (let p = 0; p < c.length; p++) {
            var n = c[p];
            h || (n = !!((n.W[B] | 0) & 2), l && (l = !n), m && (m = n))
        }
        h || (f = yg(f, 5, !0), f = yg(f, 8, l), f = yg(f, 16, m));
        k && f !== g && (c = ug(c), g = 0, f = ci(f, e, !0));
        f !== g && (c[B] = f);
        Wh(d, e, b, c);
        return a
    }

    function ci(a, b, c) {
        a = yg(a, 2, !!(2 & b));
        a = yg(a, 32, !!(32 & b) && c);
        return a = yg(a, 2048, !1)
    }

    function ti(a, b, c, d, e, f, g) {
        a = a.W;
        const h = a[B];
        Pg(h);
        b = qi(a, h, c, b, 2, f, !0);
        c = null != d ? d : new c;
        if (g && ("number" !== typeof e || 0 > e || e > b.length)) throw Error();
        void 0 != e ? b.splice(e, g, c) : b.push(c);
        b[B] = (c.W[B] | 0) & 2 ? b[B] & -9 : b[B] & -17
    }

    function ui(a, b) {
        return gh(Th(a, b))
    }

    function vi(a, b) {
        return ph(Th(a, b))
    }

    function I(a, b) {
        return uh(Th(a, b))
    }

    function L(a, b) {
        return eh(Th(a, b))
    }

    function wi(a) {
        return a ? ? 0
    }

    function M(a, b, c = !1) {
        return $h(a, b) ? ? c
    }

    function xi(a, b) {
        return wi(ui(a, b))
    }

    function yi(a, b) {
        return wi(vi(a, b))
    }

    function O(a, b) {
        return I(a, b) ? ? ""
    }

    function zi(a, b) {
        return wi(L(a, b))
    }

    function Si(a, b, c, d) {
        return C(a, b, ni(a, d, c))
    }

    function Ti(a, b) {
        a = ui(a, b);
        return null == a ? void 0 : a
    }

    function Ui(a) {
        a = Zh(a, 4);
        return null == a ? void 0 : a
    }

    function Vi(a, b, c) {
        return Vh(a, b, null == c ? c : ah(c))
    }

    function Wi(a, b, c) {
        return ki(a, b, null == c ? c : ah(c), !1)
    }

    function Xi(a, b, c) {
        return Vh(a, b, null == c ? c : fh(c))
    }

    function Yi(a, b, c) {
        return ki(a, b, null == c ? c : fh(c), 0)
    }

    function Zi(a, b, c) {
        return Vh(a, b, null == c ? c : jh(c))
    }

    function P(a, b, c) {
        return ki(a, b, null == c ? c : jh(c), "0")
    }

    function $i(a, b, c) {
        return Vh(a, b, th(c))
    }

    function aj(a, b, c) {
        return ki(a, b, th(c), "")
    }

    function Q(a, b, c) {
        return ki(a, b, dh(c), 0)
    };

    function bj(a) {
        Jg = !0;
        try {
            return JSON.stringify(a.toJSON(), Ih)
        } finally {
            Jg = !1
        }
    }
    var R = class {
        constructor(a) {
            a: {
                null == a && (a = Gh);Gh = void 0;
                if (null == a) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error();
                    b = a[B] | 0;
                    if (b & 64) break a;
                    var c = a;
                    b |= 64;
                    var d = c.length;
                    if (d && (--d, Ig(c[d]))) {
                        b |= 256;
                        c = d - (+!!(b & 512) - 1);
                        if (1024 <= c) throw Error();
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[B] = b
            }
            this.W = a
        }
        toJSON() {
            if (Jg) var a = cj(this, this.W, !1);
            else a = Mh(this.W, Oh, void 0, void 0, !1, !1), a = cj(this, a, !0);
            return a
        }
        i() {
            const a = this.W,
                b = a[B];
            return b & 2 ? this : Hh(this.constructor, Qh(a, b, !0))
        }
    };
    R.prototype.Se = Fg;

    function cj(a, b, c) {
        const d = a.constructor.P;
        var e = (c ? a.W : b)[B],
            f = Eg(e),
            g = !1;
        if (d && Kg) {
            if (!c) {
                b = ug(b);
                var h;
                if (b.length && Ig(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            Object.assign(b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = a.W[B];
            a = Eg(h);
            h = +!!(h & 512) - 1;
            var k;
            for (let F = 0; F < d.length; F++) {
                var l = d[F];
                if (l < a) {
                    l += h;
                    var m = f[l];
                    null == m ? f[l] = c ? Ng : zg() : c && m !== Ng && xg(m)
                } else {
                    if (!k) {
                        var n = void 0;
                        f.length && Ig(n = f[f.length - 1]) ? k = n : f.push(k = {})
                    }
                    m = k[l];
                    null == k[l] ? k[l] = c ? Ng : zg() : c && m !== Ng && xg(m)
                }
            }
        }
        k = b.length;
        if (!k) return b;
        let p, q;
        if (Ig(n = b[k - 1])) {
            a: {
                var x = n;f = {};c = !1;
                for (var z in x)
                    if (Object.prototype.hasOwnProperty.call(x, z)) {
                        a = x[z];
                        if (Array.isArray(a)) {
                            h = a;
                            if (!ng && Mg(a, d, +z) || !Zf && Hg(a) && 0 === a.size) a = null;
                            a != h && (c = !0)
                        }
                        null != a ? f[z] = a : c = !0
                    }
                if (c) {
                    for (let F in f) {
                        x = f;
                        break a
                    }
                    x = null
                }
            }
            x != n && (p = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            z = k - 1;
            n = b[z];
            if (!(null == n || !ng && Mg(n, d, z - e) || !Zf && Hg(n) && 0 === n.size)) break;
            q = !0
        }
        if (!p && !q) return b;
        var G;
        g ? G = b : G = Array.prototype.slice.call(b, 0, k);
        b = G;
        g && (b.length = k);
        x && b.push(x);
        return b
    }

    function dj(a, b) {
        if (null == b) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        b[B] |= 128;
        return Hh(a, Bg(b))
    };

    function ej(a, b) {
        const c = fj;
        fj = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    }
    const gj = a => null !== a && void 0 !== a;
    let fj = void 0;

    function hj(a) {
        return b => {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = Hh(a, Bg(b))
            }
            return b
        }
    };

    function Ne(a) {
        return new Le(a[0].toLowerCase())
    };

    function ij(a) {
        var b = {};
        if (a instanceof Dd) return a;
        a = jj(String(a));
        b.Zn && (a = a.replace(/(^|[\r\n\t ]) /g, "$1&#160;"));
        b.Yn && (a = a.replace(/(\r\n|\n|\r)/g, "<br>"));
        b.ao && (a = a.replace(/(\t+)/g, '<span style="white-space:pre">$1</span>'));
        return Ed(a)
    }

    function jj(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    }

    function kj(a) {
        const b = ij("");
        return Ed(a.map(c => Cd(ij(c))).join(Cd(b).toString()))
    }
    const lj = /^[a-z][a-z\d-]*$/i,
        mj = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" ");
    var nj = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" ");
    const oj = ["action", "formaction", "href"];

    function pj(a, b) {
        if (!lj.test("body")) throw Error("");
        if (-1 !== mj.indexOf("BODY")) throw Error("");
        let c = "<body";
        a && (c += qj(a));
        Array.isArray(b) || (b = void 0 === b ? [] : [b]); - 1 !== nj.indexOf("BODY") ? c += ">" : (a = kj(b.map(d => d instanceof Dd ? d : ij(String(d)))), c += ">" + a.toString() + "</body>");
        return Ed(c)
    }

    function qj(a) {
        var b = "";
        const c = Object.keys(a);
        for (let f = 0; f < c.length; f++) {
            var d = c[f],
                e = a[d];
            if (!lj.test(d)) throw Error("");
            if (void 0 !== e && null !== e) {
                if (/^on/i.test(d)) throw Error(""); - 1 !== oj.indexOf(d.toLowerCase()) && (e = e instanceof hd ? e.toString() : De(String(e)) || "about:invalid#zClosurez");
                e = `${d}="${ij(String(e))}"`;
                b += " " + e
            }
        }
        return b
    };

    function rj(a) {
        const b = a.split(/\?|#/),
            c = /\?/.test(a) ? "?" + b[1] : "";
        return {
            path: b[0],
            params: c,
            hash: /#/.test(a) ? "#" + (c ? b[2] : b[1]) : ""
        }
    }

    function sj(a, ...b) {
        if (0 === b.length) return bd(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return bd(c)
    }

    function tj(a) {
        var b = sj `https://cse.google.com/cse.js`;
        b = rj(ad(b).toString());
        let c = b.params,
            d = c.length ? "&" : "?";
        a.forEach((e, f) => {
            e = e instanceof Array ? e : [e];
            for (let g = 0; g < e.length; g++) {
                const h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return bd(b.path + c + b.hash)
    };

    function uj(a, ...b) {
        let c = a[0];
        for (let d = 0; d < a.length - 1; d++) c += String(b[d]) + a[d + 1];
        if (/[<>]/.test(c)) throw Error("Forbidden characters in style string: " + c);
        return new qd(c, od)
    };
    sj `https://www.google.com/recaptcha/api2/aframe`;

    function vj(a) {
        var b = window;
        new Promise((c, d) => {
            function e() {
                f.onload = null;
                f.onerror = null;
                f.parentElement ? .removeChild(f)
            }
            const f = b.document.createElement("script");
            f.onload = () => {
                e();
                c()
            };
            f.onerror = () => {
                e();
                d(void 0)
            };
            f.type = "text/javascript";
            Qe(f, a);
            "complete" !== b.document.readyState ? Sb(b, "load", () => {
                b.document.body.appendChild(f)
            }) : b.document.body.appendChild(f)
        })
    };
    async function wj(a) {
        var b = "https://pagead2.googlesyndication.com/getconfig/sodar" + `?sv=${200}&tid=${a.g}` + `&tv=${a.i}&st=` + `${a.ec}`;
        let c = void 0;
        try {
            c = await xj(b)
        } catch (g) {}
        if (c) {
            b = a.Ac || c.sodar_query_id;
            var d = void 0 !== c.rc_enable && a.j ? c.rc_enable : "n",
                e = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms,
                f = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
            if (b && c.bg_hash_basename && c.bg_binary) return {
                context: a.l,
                Oh: c.bg_hash_basename,
                Nh: c.bg_binary,
                Ti: a.g + "_" + a.i,
                Ac: b,
                ec: a.ec,
                Cd: d,
                Td: e,
                Ad: f
            }
        }
    }
    let xj = a => new Promise((b, c) => {
        const d = new XMLHttpRequest;
        d.onreadystatechange = () => {
            d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
        };
        d.open("GET", a, !0);
        d.send()
    });
    async function yj(a) {
        var b = await wj(a);
        if (b) {
            a = window;
            let c = a.GoogleGcLKhOms;
            c && "function" === typeof c.push || (c = a.GoogleGcLKhOms = []);
            c.push({
                _ctx_: b.context,
                _bgv_: b.Oh,
                _bgp_: b.Nh,
                _li_: b.Ti,
                _jk_: b.Ac,
                _st_: b.ec,
                _rc_: b.Cd,
                _dl_: b.Td,
                _g2_: b.Ad
            });
            if (b = a.GoogleDX5YKUSk) a.GoogleDX5YKUSk = void 0, b[1]();
            a = sj `https://tpc.googlesyndication.com/sodar/${"sodar2"}.js`;
            vj(a)
        }
    };

    function zj(a, b) {
        return aj(a, 1, b)
    }
    var Aj = class extends R {
        g() {
            return O(this, 1)
        }
    };

    function Bj(a, b) {
        return E(a, 5, b)
    }

    function Cj(a, b) {
        return aj(a, 3, b)
    }

    function Dj(a, b) {
        return Wi(a, 6, b)
    }
    var Ej = class extends R {
        constructor() {
            super()
        }
    };

    function Fj(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    }
    var Gj = class {
            constructor(a) {
                this.g = a.i;
                this.i = a.j;
                this.l = a.l;
                this.Ac = a.Ac;
                this.win = a.da();
                this.ec = a.ec;
                this.Cd = a.Cd;
                this.Td = a.Td;
                this.Ad = a.Ad;
                this.j = a.g
            }
        },
        Hj = class {
            constructor(a, b, c) {
                this.i = a;
                this.j = b;
                this.l = c;
                this.win = window;
                this.ec = "env";
                this.Cd = "n";
                this.Td = "0";
                this.Ad = "1";
                this.g = !0
            }
            da() {
                return this.win
            }
            build() {
                return new Gj(this)
            }
        };

    function Ij(a) {
        var b = new Jj;
        return $i(b, 1, a)
    }

    function Kj(a, b) {
        return Zi(a, 2, b)
    }

    function Lj(a, b) {
        return $i(a, 3, b)
    }

    function Mj(a, b) {
        return $i(a, 4, b)
    }
    var Jj = class extends R {
        getValue() {
            return O(this, 1)
        }
        getVersion() {
            return zi(this, 5)
        }
    };
    var Nj = class extends R {};
    Nj.P = [2, 3, 4];

    function Oj(a, b, c = null, d = !1, e = !1) {
        Pj(a, b, c, d, e)
    }

    function Pj(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = We("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                d && db(a.google_image_requests, f);
                Tb(f, "load", g);
                Tb(f, "error", g)
            };
            Sb(f, "load", g);
            Sb(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var Rj = (a, b) => {
            let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
            Ze(a, (d, e) => {
                if (d || 0 === d) c += `&${e}=${encodeURIComponent(""+d)}`
            });
            Qj(c)
        },
        Qj = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : Oj(b, a, void 0, !1, !1)
        };
    var Sj = window;
    var Tj = class extends R {
        constructor() {
            super()
        }
    };
    Tj.P = [15];
    var Uj = class extends R {
        constructor() {
            super()
        }
        getCorrelator() {
            return yi(this, 1)
        }
        setCorrelator(a) {
            return P(this, 1, a)
        }
    };
    var Vj = class extends R {
        constructor() {
            super()
        }
    };

    function Wj(a) {
        this.g = a || {
            cookie: ""
        }
    }
    aa = Wj.prototype;
    aa.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        "object" === typeof c && (h = c.bo, g = c.bh || !1, f = c.domain || void 0, e = c.path || void 0, d = c.Ed);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === d && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (0 > d ? "" : 0 == d ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * d)).toUTCString()) + (g ? ";secure" : "") + (null != h ? ";samesite=" + h : "")
    };
    aa.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = $b(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    aa.isEmpty = function() {
        return !this.g.cookie
    };
    aa.xc = function() {
        return this.g.cookie ? (this.g.cookie || "").split(";").length : 0
    };
    aa.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [];
        var c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = $b(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (c = b.length - 1; 0 <= c; c--) a = b[c], this.get(a), this.set(a, "", {
            Ed: 0,
            path: void 0,
            domain: void 0
        })
    };

    function Xj(a, b = window) {
        if (M(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    }

    function Yj(a = window) {
        try {
            return a.localStorage
        } catch {
            return null
        }
    }

    function Zj(a) {
        return "null" !== a.origin
    }

    function ak(a, b, c) {
        b = M(b, 5) && Zj(c) ? c.document.cookie : null;
        return null === b ? null : (new Wj({
            cookie: b
        })).get(a) || ""
    }

    function bk(a, b, c, d, e) {
        M(b, 5) && Zj(c) && (b = new Wj(c.document), b.get(a), b.set(a, "", {
            Ed: 0,
            path: d,
            domain: e
        }))
    };
    let ck = null,
        dk = null;

    function ek() {
        if (null != ck) return ck;
        ck = !1;
        try {
            const a = Ue(r);
            a && -1 !== a.location.hash.indexOf("google_logging") && (ck = !0);
            Yj(r) ? .getItem("google_logging") && (ck = !0)
        } catch (a) {}
        return ck
    }

    function fk() {
        if (null != dk) return dk;
        dk = !1;
        try {
            const a = Ue(r),
                b = Yj(r);
            if (a && -1 !== a.location.hash.indexOf("auto_ads_logging") || b && b.getItem("auto_ads_logging")) dk = !0
        } catch (a) {}
        return dk
    }
    var gk = (a, b = []) => {
        let c = !1;
        r.google_logging_queue || (c = !0, r.google_logging_queue = []);
        r.google_logging_queue.push([a, b]);
        c && ek() && Ve(r.document, sj `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function hk(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    aa = hk.prototype;
    aa.getWidth = function() {
        return this.right - this.left
    };
    aa.getHeight = function() {
        return this.bottom - this.top
    };

    function ik(a) {
        return new hk(a.top, a.right, a.bottom, a.left)
    }
    aa.contains = function(a) {
        return this && a ? a instanceof hk ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };

    function jk(a, b) {
        return a.left <= b.right && b.left <= a.right && a.top <= b.bottom && b.top <= a.bottom
    }
    aa.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    aa.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    aa.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };

    function kk(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    }

    function lk(a, b) {
        var c = Math.max(a.left, b.left),
            d = Math.min(a.left + a.width, b.left + b.width);
        if (c <= d) {
            var e = Math.max(a.top, b.top);
            a = Math.min(a.top + a.height, b.top + b.height);
            if (e <= a) return new kk(c, e, d - c, a - e)
        }
        return null
    }

    function mk(a, b) {
        var c = lk(a, b);
        if (!c || !c.height || !c.width) return [new kk(a.left, a.top, a.width, a.height)];
        c = [];
        var d = a.top,
            e = a.height,
            f = a.left + a.width,
            g = a.top + a.height,
            h = b.left + b.width,
            k = b.top + b.height;
        b.top > a.top && (c.push(new kk(a.left, a.top, a.width, b.top - a.top)), d = b.top, e -= b.top - a.top);
        k < g && (c.push(new kk(a.left, k, a.width, g - k)), e = k - d);
        b.left > a.left && c.push(new kk(a.left, d, b.left - a.left, e));
        h < f && c.push(new kk(h, d, f - h, e));
        return c
    }
    kk.prototype.contains = function(a) {
        return a instanceof Wd ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    kk.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    kk.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    kk.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    const nk = {
        "AMP-CAROUSEL": "ac",
        "AMP-FX-FLYING-CARPET": "fc",
        "AMP-LIGHTBOX": "lb",
        "AMP-STICKY-AD": "sa"
    };

    function ok(a = r) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function pk(a = ok()) {
        return a && a.mode ? +a.mode.version || null : null
    }

    function qk(a = ok()) {
        if (a && a.container) {
            a = a.container.split(",");
            const b = [];
            for (let c = 0; c < a.length; c++) b.push(nk[a[c]] || "x");
            return b.join()
        }
        return null
    }

    function rk() {
        var a = ok();
        return a && a.initialIntersection
    }

    function sk() {
        const a = rk();
        return a && za(a.rootBounds) ? new Xd(a.rootBounds.width, a.rootBounds.height) : null
    }

    function tk(a = ok()) {
        return a ? Re(a.master) ? a.master : null : null
    }

    function uk(a, b) {
        const c = a.ampInaboxIframes = a.ampInaboxIframes || [];
        let d = () => {},
            e = () => {};
        b && (c.push(b), e = () => {
            a.AMP && a.AMP.inaboxUnregisterIframe && a.AMP.inaboxUnregisterIframe(b);
            db(c, b);
            d()
        });
        if (a.ampInaboxInitialized) return e;
        a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
        const f = g => {
            if (a.ampInaboxInitialized) g = !0;
            else {
                var h, k = "amp-ini-load" === g.data;
                a.ampInaboxPendingMessages && !k && (h = /^amp-(\d{15,20})?/.exec(g.data)) && (a.ampInaboxPendingMessages.push(g), g = h[1], a.ampInaboxInitialized ||
                    g && !/^\d{15,20}$/.test(g) || a.document.querySelector('script[src$="amp4ads-host-v0.js"]') || Ve(a.document, g ? sj `https://cdn.ampproject.org/rtv/${g}/amp4ads-host-v0.js` : sj `https://cdn.ampproject.org/amp4ads-host-v0.js`));
                g = !1
            }
            g && d()
        };
        c.google_amp_listener_added || (c.google_amp_listener_added = !0, Sb(a, "message", f), d = () => {
            Tb(a, "message", f)
        });
        return e
    };
    var vk = () => a => {
        a = {
            id: "unsafeurl",
            ctx: 638,
            url: a
        };
        var b = [];
        for (c in a) xe(c, a[c], b);
        var c = we("https://pagead2.googlesyndication.com/pagead/gen_204", b.join("&"));
        navigator.sendBeacon && navigator.sendBeacon(c, "")
    };

    function wk(a, b, c) {
        if ("string" === typeof b)(b = xk(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = xk(c, d);
                f && (c.style[f] = e)
            }
    }
    var yk = {};

    function xk(a, b) {
        var c = yk[b];
        if (!c) {
            var d = be(b);
            c = d;
            void 0 === a.style[d] && (d = (Dc ? "Webkit" : Cc ? "Moz" : zc ? "ms" : null) + ce(d), void 0 !== a.style[d] && (c = d));
            yk[b] = c
        }
        return c
    }

    function zk(a, b) {
        var c = a.style[be(b)];
        return "undefined" !== typeof c ? c : a.style[xk(a, b)] || ""
    }

    function Ak(a, b) {
        var c = fe(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    }

    function Bk(a, b) {
        return Ak(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function Ck(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function Dk(a) {
        var b = fe(a),
            c = new Wd(0, 0);
        var d = b ? fe(b) : document;
        d = !zc || 9 <= Number(Mc) || "CSS1Compat" == de(d).g.compatMode ? d.documentElement : d.body;
        if (a == d) return c;
        a = Ck(a);
        b = he(de(b).g);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function Ek(a) {
        var b = Fk;
        if ("none" != Bk(a, "display")) return b(a);
        var c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function Fk(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = Dc && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = Ck(a), new Xd(a.right - a.left, a.bottom - a.top)) : new Xd(b, c)
    }

    function Gk(a, b) {
        if (/^\d+px?$/.test(b)) return parseInt(b, 10);
        var c = a.style.left,
            d = a.runtimeStyle.left;
        a.runtimeStyle.left = a.currentStyle.left;
        a.style.left = b;
        b = a.style.pixelLeft;
        a.style.left = c;
        a.runtimeStyle.left = d;
        return +b
    }

    function Hk(a, b) {
        return (b = a.currentStyle ? a.currentStyle[b] : null) ? Gk(a, b) : 0
    }
    var Ik = {
        thin: 2,
        medium: 4,
        thick: 6
    };

    function Jk(a, b) {
        if ("none" == (a.currentStyle ? a.currentStyle[b + "Style"] : null)) return 0;
        b = a.currentStyle ? a.currentStyle[b + "Width"] : null;
        return b in Ik ? Ik[b] : Gk(a, b)
    };
    var Kk = a => "number" === typeof a && 0 < a,
        Mk = (a, b) => {
            a = Lk(a);
            if (!a) return b;
            const c = b.slice(-1);
            return b + ("?" === c || "#" === c ? "" : "&") + a
        },
        Lk = a => Object.entries(Nk(a)).map(([b, c]) => `${b}=${encodeURIComponent(String(c))}`).join("&"),
        Nk = a => {
            const b = {};
            Ze(a, (c, d) => {
                if (c || 0 === c || !1 === c) "boolean" === typeof c && (c = c ? 1 : 0), b[d] = c
            });
            return b
        },
        Ok = () => {
            try {
                return Sj.history.length
            } catch (a) {
                return 0
            }
        },
        Pk = a => {
            a = tk(ok(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1
        },
        Qk = a => {
            a = a.google_unique_id;
            return "number" === typeof a ? a :
                0
        },
        Rk = a => {
            let b;
            b = 9 !== a.nodeType && a.id;
            a: {
                if (a && a.nodeName && a.parentElement) {
                    var c = a.nodeName.toString().toLowerCase();
                    const d = a.parentElement.childNodes;
                    let e = 0;
                    for (let f = 0; f < d.length; ++f) {
                        const g = d[f];
                        if (g.nodeName && g.nodeName.toString().toLowerCase() === c) {
                            if (a === g) {
                                c = "." + e;
                                break a
                            }++e
                        }
                    }
                }
                c = ""
            }
            return (a.nodeName && a.nodeName.toString().toLowerCase()) + (b ? "/" + b : "") + c
        },
        Sk = () => {
            if (!Sj) return !1;
            try {
                return !(!Sj.navigator.standalone && !Sj.top.navigator.standalone)
            } catch (a) {
                return !1
            }
        },
        Tk = a => (a = a.google_ad_format) ?
        0 < a.indexOf("_0ads") : !1,
        Uk = a => {
            let b = Number(a.google_ad_width),
                c = Number(a.google_ad_height);
            if (!(0 < b && 0 < c)) {
                a: {
                    try {
                        const e = String(a.google_ad_format);
                        if (e && e.match) {
                            const f = e.match(/(\d+)x(\d+)/i);
                            if (f) {
                                const g = parseInt(f[1], 10),
                                    h = parseInt(f[2], 10);
                                if (0 < g && 0 < h) {
                                    var d = {
                                        width: g,
                                        height: h
                                    };
                                    break a
                                }
                            }
                        }
                    } catch (e) {}
                    d = null
                }
                a = d;
                if (!a) return null;b = 0 < b ? b : a.width;c = 0 < c ? c : a.height
            }
            return {
                width: b,
                height: c
            }
        };
    class Vk {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };
    const Wk = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Xk = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        Yk = class {
            constructor(a, b, c) {
                this.url = a;
                this.win = b;
                this.ug = !!c;
                this.depth = null
            }
        };
    let Zk = null;

    function $k() {
        if (null === Zk) {
            Zk = "";
            try {
                let a = "";
                try {
                    a = r.top.location.hash
                } catch (b) {
                    a = r.location.hash
                }
                if (a) {
                    const b = a.match(/\bdeid=([\d,]+)/);
                    Zk = b ? b[1] : ""
                }
            } catch (a) {}
        }
        return Zk
    };

    function al() {
        const a = r.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function bl() {
        const a = r.performance;
        return a && a.now ? a.now() : null
    };
    var cl = class {
        constructor(a, b) {
            var c = bl() || al();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const dl = r.performance,
        el = !!(dl && dl.mark && dl.measure && dl.clearMarks),
        fl = Jb(() => {
            var a;
            if (a = el) a = $k(), a = !!a.indexOf && 0 <= a.indexOf("1337");
            return a
        });

    function gl(a) {
        a && dl && fl() && (dl.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), dl.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function hl(a) {
        a.g = !1;
        a.i != a.j.google_js_reporting_queue && (fl() && Ua(a.i, gl), a.i.length = 0)
    }

    function il(a, b) {
        if (!a.g) return b();
        const c = a.start("491", 3);
        let d;
        try {
            d = b()
        } catch (e) {
            throw gl(c), e;
        }
        a.end(c);
        return d
    }
    class jl {
        constructor(a) {
            this.i = [];
            this.j = a || r;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = fl() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.g) return null;
            a = new cl(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            dl && fl() && dl.mark(b);
            return a
        }
        end(a) {
            if (this.g && "number" === typeof a.value) {
                a.duration = (bl() || al()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                dl && fl() && dl.mark(b);
                !this.g || 2048 < this.i.length ||
                    this.i.push(a)
            }
        }
    };

    function kl(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function ll(a, b, c, d, e) {
        const f = [];
        Ze(a, function(g, h) {
            (g = ml(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function ml(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(ml(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(ll(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function nl(a) {
        let b = 1;
        for (const c in a.i) b = c.length > b ? c.length : b;
        return 3997 - b - a.j.length - 1
    }

    function ol(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = nl(a) - b.length;
        if (0 > d) return "";
        a.g.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.i[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let l = ll(h[k], a.j, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.j;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class pl {
        constructor() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.g = []
        }
    };

    function ql(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        a.stack && (b = rl(a.stack, b));
        return b
    }

    function rl(a, b) {
        try {
            -1 == a.indexOf(b) && (a = b + "\n" + a);
            let c;
            for (; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (c) {
            return b
        }
    }
    var tl = class {
        constructor(a, b, c = null) {
            this.ua = a;
            this.A = b;
            this.i = c;
            this.g = null;
            this.j = !1;
            this.B = this.Ba
        }
        kf(a) {
            this.g = a
        }
        l(a) {
            this.j = a
        }
        Kc(a, b, c) {
            let d, e;
            try {
                this.i && this.i.g ? (e = this.i.start(a.toString(), 3), d = b(), this.i.end(e)) : d = b()
            } catch (f) {
                b = this.A;
                try {
                    gl(e), b = this.B(a, new Vk(f, {
                        message: ql(f)
                    }), void 0, c)
                } catch (g) {
                    this.Ba(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        Oa(a, b, c, d) {
            return (...e) => this.Kc(a, () => b.apply(c, e), d)
        }
        Ba(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const J = new pl;
                var g = J;
                g.g.push(1);
                g.i[1] = kl("context", a);
                b.error && b.meta && b.id || (b = new Vk(b, {
                    message: ql(b)
                }));
                if (b.msg) {
                    let U = b.msg;
                    null == U.substring && (U = `b/320546888 ${typeof U} ${U}`);
                    g = J;
                    var h = U.substring(0, 512);
                    g.g.push(2);
                    g.i[2] = kl("msg", h)
                }
                var k = b.meta || {};
                b = k;
                if (this.g) try {
                    this.g(b)
                } catch (U) {}
                if (d) try {
                    d(b)
                } catch (U) {}
                d = J;
                k = [k];
                d.g.push(3);
                d.i[3] = k;
                d = r;
                k = [];
                b = null;
                do {
                    var l = d;
                    if (Re(l)) {
                        var m = l.location.href;
                        b = l.document && l.document.referrer || null
                    } else m = b, b = null;
                    k.push(new Yk(m || "", l));
                    try {
                        d = l.parent
                    } catch (U) {
                        d = null
                    }
                } while (d &&
                    l != d);
                for (let U = 0, tb = k.length - 1; U <= tb; ++U) k[U].depth = tb - U;
                l = r;
                if (l.location && l.location.ancestorOrigins && l.location.ancestorOrigins.length == k.length - 1)
                    for (m = 1; m < k.length; ++m) {
                        var n = k[m];
                        n.url || (n.url = l.location.ancestorOrigins[m - 1] || "", n.ug = !0)
                    }
                var p = k;
                let Ea = new Yk(r.location.href, r, !1);
                l = null;
                const Ya = p.length - 1;
                for (n = Ya; 0 <= n; --n) {
                    var q = p[n];
                    !l && Wk.test(q.url) && (l = q);
                    if (q.url && !q.ug) {
                        Ea = q;
                        break
                    }
                }
                q = null;
                const Eb = p.length && p[Ya].url;
                0 != Ea.depth && Eb && (q = p[Ya]);
                f = new Xk(Ea, q);
                if (f.i) {
                    p = J;
                    var x = f.i.url ||
                        "";
                    p.g.push(4);
                    p.i[4] = kl("top", x)
                }
                var z = {
                    url: f.g.url || ""
                };
                if (f.g.url) {
                    var G = f.g.url.match(ve),
                        F = G[1],
                        K = G[3],
                        H = G[4];
                    x = "";
                    F && (x += F + ":");
                    K && (x += "//", x += K, H && (x += ":" + H));
                    var N = x
                } else N = "";
                F = J;
                z = [z, {
                    url: N
                }];
                F.g.push(5);
                F.i[5] = z;
                sl(this.ua, e, J, this.j, c)
            } catch (J) {
                try {
                    sl(this.ua, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: ql(J),
                        url: f && f.g.url
                    }, this.j, c)
                } catch (Ea) {}
            }
            return this.A
        }
        Ca(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.Ba(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    var ul = a => "string" === typeof a,
        vl = a => void 0 === a;

    function wl() {
        var a = xl;
        return b => {
            for (const c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }
    };
    var yl = class extends R {
        constructor() {
            super()
        }
    };

    function zl(a, b) {
        try {
            const c = d => [{
                [d.kh]: d.Cg
            }];
            return JSON.stringify([a.filter(d => d.Pe).map(c), b.toJSON(), a.filter(d => !d.Pe).map(c)])
        } catch (c) {
            return Al(c, b), ""
        }
    }

    function Al(a, b) {
        try {
            Rj({
                m: ql(a instanceof Error ? a : Error(String(a))),
                b: zi(b, 1) || null,
                v: O(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }
    var Bl = class {
        constructor(a, b) {
            var c = new yl;
            a = Q(c, 1, a);
            this.j = aj(a, 2, b).i()
        }
    };
    var Cl = class extends R {
        getValue() {
            return zi(this, 1)
        }
    };

    function Dl(a) {
        var b = new El;
        return Vh(b, 1, dh(a))
    }
    var El = class extends R {
        getValue() {
            return zi(this, 1)
        }
    };
    var Fl = class extends R {
        constructor() {
            super()
        }
        getValue() {
            return zi(this, 1)
        }
    };

    function Gl(a, b) {
        return P(a, 1, b)
    }

    function Hl(a, b) {
        return P(a, 2, b)
    }

    function Il(a, b) {
        return P(a, 3, b)
    }

    function Jl(a, b) {
        return P(a, 4, b)
    }

    function Kl(a, b) {
        return P(a, 5, b)
    }

    function Ll(a, b) {
        return ki(a, 8, $g(b), 0)
    }

    function Ml(a, b) {
        return ki(a, 9, $g(b), 0)
    }
    var Nl = class extends R {
        constructor() {
            super()
        }
    };

    function Ol(a, b) {
        return P(a, 1, b)
    }

    function Pl(a, b) {
        return P(a, 2, b)
    }
    var Ql = class extends R {};

    function Rl(a, b) {
        ti(a, 1, Ql, b)
    }
    var ii = class extends R {
        fh(a) {
            ti(this, 1, Ql, void 0, a, !1, 1);
            return this
        }
    };
    ii.P = [1];
    var Sl = class extends R {
        constructor() {
            super()
        }
    };

    function Tl(a, b) {
        return ji(a, 1, b, sh)
    }

    function Ul(a, b) {
        return ji(a, 12, b, qh)
    }

    function Vl() {
        var a = new Wl,
            b = a.W,
            c = "irr",
            d = b[B];
        Pg(d);
        var e = d & 2;
        let f = Uh(b, d, 2);
        Array.isArray(f) || (f = Ng);
        const g = !!(d & 32);
        let h = f[B] | 0;
        0 === h && g && !e ? (h |= 33, f[B] = h) : h & 1 || (h |= 1, f[B] = h);
        if (e) h & 2 || Ag(f), Object.freeze(f);
        else if (2 & h || 2048 & h) f = ug(f), e = 1, g && (e |= 32), f[B] = e, Wh(b, d, 2, f);
        b = f;
        d = b[B] | 0;
        c = sh(c, !!(4 & d) && !!(4096 & d));
        b.push(c);
        return a
    }

    function Xl(a, b) {
        return Wi(a, 3, b)
    }

    function Yl(a, b) {
        return Wi(a, 4, b)
    }

    function Zl(a, b) {
        return Wi(a, 5, b)
    }

    function $l(a, b) {
        return Wi(a, 7, b)
    }

    function am(a, b) {
        return Wi(a, 8, b)
    }

    function bm(a, b) {
        return P(a, 9, b)
    }

    function cm(a, b) {
        return si(a, 10, b)
    }

    function dm(a, b) {
        return ji(a, 11, b, jh)
    }
    var Wl = class extends R {
        constructor() {
            super()
        }
    };
    Wl.P = [1, 12, 2, 10, 11];

    function em(a) {
        var b = fm();
        E(a, 1, b)
    }

    function gm(a, b) {
        return P(a, 2, b)
    }

    function hm(a, b) {
        return si(a, 3, b)
    }

    function im(a, b) {
        return si(a, 4, b)
    }

    function jm(a, b) {
        ti(a, 4, El, b);
        return a
    }

    function km(a, b) {
        return si(a, 5, b)
    }

    function lm(a, b) {
        return ji(a, 6, b, sh)
    }

    function mm(a, b) {
        return P(a, 7, b)
    }

    function nm(a, b) {
        E(a, 9, b)
    }

    function om(a, b) {
        return Wi(a, 10, b)
    }

    function pm(a, b) {
        return Wi(a, 11, b)
    }

    function qm(a, b) {
        return Wi(a, 12, b)
    }

    function rm(a) {
        var b = a.W;
        const c = b[B];
        a = c & 2;
        b = hi(b, c, Uh(b, c, 14));
        null == b ? a = b : (!a && ii && (b.Th = !0), a = b);
        return a
    }
    var sm = class extends R {
        constructor() {
            super()
        }
        H(a) {
            ti(this, 3, Cl, void 0, a, !1, 1);
            return this
        }
        G(a) {
            return P(this, 8, a)
        }
    };
    sm.P = [3, 4, 5, 15, 6];
    var tm = class extends R {
        constructor() {
            super()
        }
    };
    tm.P = [2];
    var um = class extends R {
        constructor() {
            super()
        }
    };
    var vm = class extends R {
            constructor() {
                super()
            }
        },
        wm = [1];

    function xm(a) {
        var b = new ym;
        return Q(b, 1, a)
    }
    var ym = class extends R {
        constructor() {
            super()
        }
    };
    var zm = class extends R {
        constructor() {
            super()
        }
    };
    var Am = class extends R {
        constructor() {
            super()
        }
    };
    var Bm = class extends R {
        constructor() {
            super()
        }
    };
    var Cm = class extends R {
        constructor() {
            super()
        }
    };
    var Dm = class extends R {
        constructor() {
            super()
        }
        getContentUrl() {
            return O(this, 1)
        }
    };
    var Em = class extends R {
        constructor() {
            super()
        }
    };
    Em.P = [1];
    var Fm = class extends R {
        constructor() {
            super()
        }
    };

    function Gm() {
        var a = new Hm,
            b = new Fm;
        return ri(a, 1, Im, b)
    }

    function Jm() {
        var a = new Hm,
            b = new Fm;
        return ri(a, 9, Im, b)
    }

    function ln() {
        var a = new Hm,
            b = new Fm;
        return ri(a, 11, Im, b)
    }

    function mn() {
        var a = new Hm,
            b = new Fm;
        return ri(a, 12, Im, b)
    }

    function nn() {
        var a = new Hm,
            b = new Fm;
        return ri(a, 13, Im, b)
    }
    var Hm = class extends R {
            constructor() {
                super()
            }
        },
        Im = [1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13];
    var on = class extends R {
        constructor() {
            super()
        }
    };
    on.P = [1];
    var pn = class extends R {
        constructor() {
            super()
        }
    };
    pn.P = [2];
    var qn = class extends R {
        constructor() {
            super()
        }
    };
    var rn = class extends R {
        constructor() {
            super()
        }
    };

    function sn(a) {
        var b = new tn;
        return Q(b, 1, a)
    }
    var tn = class extends R {
        constructor() {
            super()
        }
    };
    tn.P = [9];
    var un = class extends R {
        constructor() {
            super()
        }
    };
    var vn = class extends R {
        constructor() {
            super()
        }
    };
    vn.P = [2];
    var wn = class extends R {
        constructor() {
            super()
        }
    };
    var xn = class extends R {
            constructor() {
                super()
            }
        },
        yn = [4, 5];
    var zn = class extends R {
        constructor() {
            super()
        }
    };

    function An(a) {
        var b = new Bn;
        return Yi(b, 2, a)
    }
    var Bn = class extends R {
        constructor() {
            super()
        }
    };
    Bn.P = [3];
    var Cn = class extends R {
        constructor() {
            super()
        }
    };
    var Dn = class extends R {
        constructor() {
            super()
        }
    };
    var En = class extends R {
        constructor() {
            super()
        }
    };
    var Fn = class extends R {
        constructor() {
            super()
        }
    };
    var Gn = class extends R {
            constructor() {
                super()
            }
        },
        Hn = [2, 3];
    var In = class extends R {
            constructor() {
                super()
            }
        },
        Jn = [3, 4, 5, 6, 7, 8, 9, 11, 12, 13];
    var Kn = class extends R {
            constructor() {
                super()
            }
            dc(a) {
                return aj(this, 2, a)
            }
        },
        Ln = [4, 5, 6, 8, 9, 10, 11];
    var Mn = class extends R {
        constructor() {
            super()
        }
    };
    var Nn = class extends R {
        constructor() {
            super()
        }
    };
    Nn.P = [4, 5];
    var On = class extends R {
        constructor() {
            super()
        }
        getTagSessionCorrelator() {
            return yi(this, 1)
        }
    };
    On.P = [2];
    var Pn = class extends R {
            constructor() {
                super()
            }
        },
        Qn = [4, 6];
    class Rn extends Bl {
        constructor() {
            super(...arguments)
        }
    }

    function Sn(a, ...b) {
        Tn(a, ...b.map(c => ({
            Pe: !0,
            kh: 3,
            Cg: c.toJSON()
        })))
    }

    function Un(a, ...b) {
        Tn(a, ...b.map(c => ({
            Pe: !0,
            kh: 7,
            Cg: c.toJSON()
        })))
    }
    var Vn = class extends Rn {};
    var Wn = (a, b) => {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function Tn(a, ...b) {
        try {
            a.C && 65536 <= zl(a.g.concat(b), a.j).length && Xn(a), a.l && !a.A && (a.A = !0, Yn(a.l, () => {
                Xn(a)
            })), a.g.push(...b), a.g.length >= a.B && Xn(a), a.g.length && null === a.i && (a.i = setTimeout(() => {
                Xn(a)
            }, a.F))
        } catch (c) {
            Al(c, a.j)
        }
    }

    function Xn(a) {
        null !== a.i && (clearTimeout(a.i), a.i = null);
        if (a.g.length) {
            var b = zl(a.g, a.j);
            a.G("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.g = []
        }
    }
    var Zn = class extends Vn {
            constructor(a, b, c, d, e) {
                super(2, a);
                this.G = Wn;
                this.F = b;
                this.B = c;
                this.C = d;
                this.l = e;
                this.g = [];
                this.i = null;
                this.A = !1
            }
        },
        $n = class extends Zn {
            constructor(a, b = 1E3, c = 100, d = !1, e) {
                super(a, b, c, d && !0, e)
            }
        };

    function ao(a, b, c) {
        return b[a] || c
    };

    function bo(a, b) {
        a.g = (c, d) => ao(2, b, () => [])(c, 1, d);
        a.i = () => ao(3, b, () => [])(1)
    }
    class co {
        g() {
            return []
        }
        i() {
            return []
        }
    }

    function eo(a, b) {
        return u(co).g(a, b)
    }

    function fo() {
        return u(co).i()
    };

    function sl(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof pl ? f = c : (f = new pl, Ze(c, (h, k) => {
                var l = f;
                const m = l.l++;
                h = kl(k, h);
                l.g.push(m);
                l.i[m] = h
            }));
            const g = ol(f, "/pagead/gen_204?id=" + b + "&");
            g && Oj(r, g)
        } catch (f) {}
    }

    function go(a, b) {
        0 <= b && 1 >= b && (a.g = b)
    }
    class ho {
        constructor() {
            this.g = Math.random()
        }
    };
    let io, jo;
    const ko = new jl(window);
    (a => {
        io = a ? ? new ho;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        go(io, window.google_srt);
        jo = new tl(io, !0, ko);
        jo.kf(() => {});
        jo.l(!0);
        "complete" == window.document.readyState ? window.google_measure_js_timing || hl(ko) : ko.g && Sb(window, "load", () => {
            window.google_measure_js_timing || hl(ko)
        })
    })();
    let lo = (new Date).getTime();
    var mo = {
        bm: 0,
        am: 1,
        Xl: 2,
        Sl: 3,
        Yl: 4,
        Tl: 5,
        Zl: 6,
        Vl: 7,
        Wl: 8,
        Rl: 9,
        Ul: 10,
        cm: 11
    };
    var no = {
        em: 0,
        fm: 1,
        dm: 2
    };

    function oo(a, b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
    }

    function po(a) {
        a = Za(a, b => new hk(b.top, b.right, b.bottom, b.left));
        a = qo(a);
        return {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left
        }
    }

    function qo(a) {
        if (!a.length) throw Error("pso:box:m:nb");
        return $a(a.slice(1), (b, c) => {
            b.left = Math.min(b.left, c.left);
            b.top = Math.min(b.top, c.top);
            b.right = Math.max(b.right, c.right);
            b.bottom = Math.max(b.bottom, c.bottom);
            return b
        }, ik(a[0]))
    };
    var Qc = {
        Um: 0,
        Gl: 1,
        Jl: 2,
        Hl: 3,
        Il: 4,
        Pl: 8,
        en: 9,
        rm: 10,
        sm: 11,
        bn: 16,
        rl: 17,
        ql: 24,
        om: 25,
        Hk: 26,
        Gk: 27,
        xh: 30,
        im: 32,
        lm: 40,
        ln: 41,
        gn: 42
    };
    var ro = {
            overlays: 1,
            interstitials: 2,
            vignettes: 2,
            inserts: 3,
            immersives: 4,
            list_view: 5,
            full_page: 6,
            side_rails: 7
        },
        so = {
            [1]: 1,
            [2]: 1,
            [3]: 7,
            [4]: 7,
            [8]: 2,
            [27]: 3,
            [9]: 4,
            [30]: 5
        };
    var to = 728 * 1.38;

    function uo(a) {
        return a !== a.top ? 512 : 0
    }

    function vo(a, b = 420, c = !1) {
        return (a = wo(a, c)) ? a > b ? 32768 : 320 > a ? 65536 : 0 : 16384
    }

    function xo(a) {
        var b = wo(a);
        a = a.innerWidth;
        return (b = b && a ? b / a : 0) ? 1.05 < b ? 262144 : .95 > b ? 524288 : 0 : 131072
    }

    function yo(a) {
        return Math.max(0, zo(a, !0) - S(a))
    }

    function Ao(a) {
        a = a.document;
        let b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    }

    function S(a) {
        return Ao(a).clientHeight
    }

    function wo(a, b = !1) {
        const c = Ao(a).clientWidth;
        return b ? c * Ff(a) : c
    }

    function zo(a, b) {
        const c = Ao(a);
        return b ? (a = S(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    }

    function Bo(a, b) {
        return Co(b) || 10 === b || !a.adCount ? !1 : 1 == b || 2 == b ? !(!a.adCount[1] && !a.adCount[2]) : (a = a.adCount[b]) ? 1 <= a : !1
    }

    function Do(a, b) {
        return a && a.source ? a.source === b || a.source.parent === b : !1
    }

    function Eo(a) {
        return void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    }

    function Fo(a) {
        return void 0 === a.pageXOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollLeft : a.pageXOffset
    }

    function Go(a) {
        const b = {};
        let c;
        Array.isArray(a) ? c = a : a && a.key_value && (c = a.key_value);
        if (c)
            for (a = 0; a < c.length; a++) {
                const d = c[a];
                if ("key" in d && "value" in d) {
                    const e = d.value;
                    b[d.key] = null == e ? null : String(e)
                }
            }
        return b
    }

    function Ho(a, b, c, d) {
        sl(c, b, {
            c: d.data.substring(0, 500),
            u: a.location.href.substring(0, 500)
        }, !0, .1);
        return !0
    }

    function Io(a) {
        const b = {
            bottom: "auto",
            clear: "none",
            display: "inline",
            "float": "none",
            height: "auto",
            left: "auto",
            margin: 0,
            "margin-bottom": 0,
            "margin-left": 0,
            "margin-right": "0",
            "margin-top": 0,
            "max-height": "none",
            "max-width": "none",
            opacity: 1,
            overflow: "visible",
            padding: 0,
            "padding-bottom": 0,
            "padding-left": 0,
            "padding-right": 0,
            "padding-top": 0,
            position: "static",
            right: "auto",
            top: "auto",
            "vertical-align": "baseline",
            visibility: "visible",
            width: "auto",
            "z-index": "auto"
        };
        Ua(Object.keys(b), c => {
            zk(a, c) || wk(a, c, b[c])
        });
        rf(a)
    }

    function Co(a) {
        return 26 === a || 27 === a || 40 === a || 41 === a
    };

    function Jo(a, b) {
        Ko(a).forEach(b, void 0)
    }

    function Ko(a) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b
    };

    function Lo(a, b) {
        return void 0 !== a.g[Mo(b)]
    }

    function No(a) {
        const b = [];
        for (const c in a.g) void 0 !== a.g[c] && a.g.hasOwnProperty(c) && b.push(a.i[c]);
        return b
    }

    function Oo(a) {
        const b = [];
        for (const c in a.g) void 0 !== a.g[c] && a.g.hasOwnProperty(c) && b.push(a.g[c]);
        return b
    }
    const Po = class {
        constructor() {
            this.g = {};
            this.i = {}
        }
        set(a, b) {
            const c = Mo(a);
            this.g[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = Mo(a);
            return void 0 !== this.g[a] ? this.g[a] : b
        }
        xc() {
            return No(this).length
        }
        clear() {
            this.g = {};
            this.i = {}
        }
    };

    function Mo(a) {
        return a instanceof Object ? String(Aa(a)) : a + ""
    };
    const Qo = class {
        constructor(a) {
            this.g = new Po;
            if (a)
                for (var b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return Lo(this.g, a)
        }
    };
    const Ro = new Qo("IMG AMP-IMG IFRAME AMP-IFRAME HR EMBED OBJECT VIDEO AMP-VIDEO INPUT BUTTON SVG".split(" "));

    function So(a, {
        gb: b,
        Za: c,
        Fb: d
    }) {
        return d && c(b) ? b : (b = b.parentElement) ? To(a, {
            gb: b,
            Za: c,
            Fb: !0
        }) : null
    }

    function To(a, {
        gb: b,
        Za: c,
        Fb: d = !1
    }) {
        const e = Uo({
                gb: b,
                Za: c,
                Fb: d
            }),
            f = a.g.get(e);
        if (f) return f.element;
        b = So(a, {
            gb: b,
            Za: c,
            Fb: d
        });
        a.g.set(e, {
            element: b
        });
        return b
    }
    var Vo = class {
        constructor() {
            this.g = new Map
        }
    };

    function Uo({
        gb: a,
        Za: b,
        Fb: c
    }) {
        a = Aa(a);
        b = Aa(b);
        return `${a}:${b}:${c}`
    };

    function Wo(a) {
        Ub(a.document.body.offsetHeight)
    };

    function Xo(a) {
        a && "function" == typeof a.la && a.la()
    };

    function T() {
        this.B = this.B;
        this.G = this.G
    }
    T.prototype.B = !1;
    T.prototype.la = function() {
        this.B || (this.B = !0, this.i())
    };

    function Yo(a, b) {
        Zo(a, Ja(Xo, b))
    }

    function Zo(a, b) {
        a.B ? b() : (a.G || (a.G = []), a.G.push(b))
    }
    T.prototype.i = function() {
        if (this.G)
            for (; this.G.length;) this.G.shift()()
    };

    function $o(a) {
        a.g.forEach((b, c) => {
            if (b.overrides.delete(a)) {
                b = Array.from(b.overrides.values()).pop() || b.originalValue;
                var d = a.element;
                b ? d.style.setProperty(c, b.value, b.priority) : d.style.removeProperty(c)
            }
        })
    }

    function ap(a, b, c) {
        c = {
            value: c,
            priority: "important"
        };
        var d = a.g.get(b);
        if (!d) {
            d = a.element;
            var e = d.style.getPropertyValue(b);
            d = {
                originalValue: e ? {
                    value: e,
                    priority: d.style.getPropertyPriority(b)
                } : null,
                overrides: new Map
            };
            a.g.set(b, d)
        }
        d.overrides.delete(a);
        d.overrides.set(a, c);
        a = a.element;
        c ? a.style.setProperty(b, c.value, c.priority) : a.style.removeProperty(b)
    }
    var bp = class extends T {
        constructor(a, b) {
            super();
            this.element = b;
            a = a.googTempStyleOverrideInfo = a.googTempStyleOverrideInfo || new Map;
            var c = a.get(b);
            c ? b = c : (c = new Map, a.set(b, c), b = c);
            this.g = b
        }
        i() {
            $o(this);
            super.i()
        }
    };

    function cp(a) {
        const b = new V(a.getValue());
        a.listen(c => b.g(c));
        return b
    }

    function dp(a, b) {
        const c = new V({
            first: a.M,
            second: b.M
        });
        a.listen(() => c.g({
            first: a.M,
            second: b.M
        }));
        b.listen(() => c.g({
            first: a.M,
            second: b.M
        }));
        return c
    }

    function ep(...a) {
        const b = [...a],
            c = () => b.every(f => f.M),
            d = new V(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return fp(d)
    }

    function gp(...a) {
        const b = [...a],
            c = () => -1 !== b.findIndex(f => f.M),
            d = new V(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return fp(d)
    }

    function fp(a, b = hp) {
        var c = a.M;
        const d = new V(a.M);
        a.listen(e => {
            b(e, c) || (c = e, d.g(e))
        });
        return d
    }

    function W(a, b, c) {
        return a.i(d => {
            d === b && c()
        })
    }

    function ip(a, b, c) {
        if (a.M === b) c();
        else {
            var d = {
                cd: null
            };
            d.cd = W(a, b, () => {
                d.cd && (d.cd(), d.cd = null);
                c()
            })
        }
    }

    function jp(a, b, c) {
        fp(a).listen(d => {
            d === b && c()
        })
    }

    function kp(a, b) {
        a.l && a.l();
        a.l = b.listen(c => a.g(c), !0)
    }

    function lp(a, b, c, d) {
        const e = new V(!1);
        var f = null;
        a = a.map(d);
        W(a, !0, () => {
            null === f && (f = b.setTimeout(() => {
                e.g(!0)
            }, c))
        });
        W(a, !1, () => {
            e.g(!1);
            null !== f && (b.clearTimeout(f), f = null)
        });
        return fp(e)
    }

    function mp(a) {
        return {
            listen: b => a.listen(b),
            getValue: () => a.M
        }
    }
    class V {
        constructor(a) {
            this.M = a;
            this.j = new Map;
            this.B = 1;
            this.l = null
        }
        listen(a, b = !1) {
            const c = this.B++;
            this.j.set(c, a);
            b && a(this.M);
            return () => {
                this.j.delete(c)
            }
        }
        i(a) {
            return this.listen(a, !0)
        }
        A() {
            return this.M
        }
        g(a) {
            this.M = a;
            this.j.forEach(b => {
                b(this.M)
            })
        }
        map(a) {
            const b = new V(a(this.M));
            this.listen(c => b.g(a(c)));
            return b
        }
    }

    function hp(a, b) {
        return a == b
    };

    function np(a) {
        return new op(a)
    }

    function pp(a, b) {
        Ua(a.g, c => {
            c(b)
        })
    }
    var qp = class {
        constructor() {
            this.g = []
        }
    };
    class op {
        constructor(a) {
            this.g = a
        }
        listen(a) {
            this.g.g.push(a)
        }
        map(a) {
            const b = new qp;
            this.listen(c => pp(b, a(c)));
            return np(b)
        }
        delay(a, b) {
            const c = new qp;
            this.listen(d => {
                a.setTimeout(() => {
                    pp(c, d)
                }, b)
            });
            return np(c)
        }
    }

    function rp(...a) {
        const b = new qp;
        a.forEach(c => {
            c.listen(d => {
                pp(b, d)
            })
        });
        return np(b)
    };

    function sp(a) {
        return fp(dp(a.g, a.j).map(b => {
            var c = b.first;
            b = b.second;
            return null == c || null == b ? null : tp(c, b)
        }))
    }
    var vp = class {
        constructor(a) {
            this.i = a;
            this.g = new V(null);
            this.j = new V(null);
            this.l = new qp;
            this.C = b => {
                null == this.g.M && 1 == b.touches.length && this.g.g(b.touches[0])
            };
            this.A = b => {
                const c = this.g.M;
                null != c && (b = up(c, b.changedTouches), null != b && (this.g.g(null), this.j.g(null), pp(this.l, tp(c, b))))
            };
            this.B = b => {
                var c = this.g.M;
                null != c && (c = up(c, b.changedTouches), null != c && (this.j.g(c), b.preventDefault()))
            }
        }
    };

    function tp(a, b) {
        return {
            th: b.pageX - a.pageX,
            uh: b.pageY - a.pageY
        }
    }

    function up(a, b) {
        if (null == b) return null;
        for (let c = 0; c < b.length; ++c)
            if (b[c].identifier == a.identifier) return b[c];
        return null
    };

    function wp(a) {
        return fp(dp(a.g, a.i).map(b => {
            var c = b.first;
            b = b.second;
            return null == c || null == b ? null : xp(c, b)
        }))
    }
    var yp = class {
        constructor(a, b) {
            this.l = a;
            this.A = b;
            this.g = new V(null);
            this.i = new V(null);
            this.j = new qp;
            this.G = c => {
                this.g.g(c)
            };
            this.B = c => {
                const d = this.g.M;
                null != d && (this.g.g(null), this.i.g(null), pp(this.j, xp(d, c)))
            };
            this.C = c => {
                null != this.g.M && (this.i.g(c), c.preventDefault())
            }
        }
    };

    function xp(a, b) {
        return {
            th: b.screenX - a.screenX,
            uh: b.screenY - a.screenY
        }
    };
    var Bp = (a, b, c) => {
        const d = new zp(a, b, c);
        return () => Ap(d)
    };

    function Ap(a) {
        if (a.g) return !1;
        if (null == a.i) return Cp(a), !0;
        const b = a.i + a.A - (new Date).getTime();
        if (1 > b) return Cp(a), !0;
        Dp(a, b);
        return !0
    }

    function Cp(a) {
        a.i = (new Date).getTime();
        a.l()
    }

    function Dp(a, b) {
        a.g = !0;
        a.j.setTimeout(() => {
            a.g = !1;
            Cp(a)
        }, b)
    }
    class zp {
        constructor(a, b, c) {
            this.j = a;
            this.A = b;
            this.l = c;
            this.i = null;
            this.g = !1
        }
    };

    function Ep(a) {
        return Fp(wp(a.g), sp(a.i))
    }

    function Gp(a) {
        return rp(np(a.g.j), np(a.i.l))
    }
    var Hp = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function Fp(a, b) {
        return dp(a, b).map(({
            first: c,
            second: d
        }) => c || d || null)
    };
    var Ip = class {
        constructor() {
            this.cache = new Map
        }
        getBoundingClientRect(a) {
            var b = this.cache.get(a);
            if (b) return b;
            b = a.getBoundingClientRect();
            this.cache.set(a, b);
            return b
        }
    };

    function Jp(a) {
        null == a.A && (a.A = new V(a.C.getBoundingClientRect()));
        return a.A
    }
    class Kp extends T {
        constructor(a, b) {
            super();
            this.j = a;
            this.C = b;
            this.F = !1;
            this.A = null;
            this.l = () => {
                Jp(this).g(this.C.getBoundingClientRect())
            }
        }
        g() {
            this.F || (this.F = !0, this.j.addEventListener("resize", this.l), this.j.addEventListener("scroll", this.l));
            return Jp(this)
        }
        i() {
            this.j.removeEventListener("resize", this.l);
            this.j.removeEventListener("scroll", this.l);
            super.i()
        }
    };

    function Lp(a, b) {
        return new Mp(a, b)
    }

    function Np(a) {
        a.win.requestAnimationFrame(() => {
            a.B || a.j.g(new Xd(a.element.offsetWidth, a.element.offsetHeight))
        })
    }

    function Op(a) {
        a.g || (a.g = !0, a.l.observe(a.element));
        return fp(a.j, Yd)
    }
    var Mp = class extends T {
        constructor(a, b) {
            super();
            this.win = a;
            this.element = b;
            this.g = !1;
            this.j = new V(new Xd(this.element.offsetWidth, this.element.offsetHeight));
            this.l = new ResizeObserver(() => {
                Np(this)
            })
        }
        i() {
            this.l.disconnect();
            super.i()
        }
    };

    function Pp(a, b) {
        return {
            top: a.g - b,
            right: a.j + a.i,
            bottom: a.g + b,
            left: a.j
        }
    }
    class Qp {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.i = c
        }
        yc() {
            return this.i
        }
    };

    function Rp(a, b) {
        a = a.getBoundingClientRect();
        return new Sp(a.top + Eo(b), a.bottom - a.top)
    }

    function Tp(a) {
        return new Sp(Math.round(a.g), Math.round(a.i))
    }
    class Sp {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getHeight() {
            return this.i
        }
    };
    var Vp = (a, b) => {
        const c = a.google_pso_loaded_fonts || (a.google_pso_loaded_fonts = []),
            d = new Qo(c);
        b = b.filter(e => !d.contains(e));
        b.length && (Up(a, b), hb(c, b))
    };

    function Up(a, b) {
        for (const f of b) {
            b = We("LINK", a.document);
            b.type = "text/css";
            var c = sj `//fonts.googleapis.com/css`,
                d = vk(),
                e = b;
            c = Zc(c, {
                family: f
            });
            if (c instanceof Yc) d = c;
            else a: {
                if (c instanceof hd) {
                    d = c;
                    break a
                }
                const g = Ce(c, Be) || nd;g === nd && d(c);d = g
            }
            e.rel = "stylesheet";
            if (jc("stylesheet", "stylesheet")) {
                e.href = ad(d).toString();
                a: if (d = (e.ownerDocument && e.ownerDocument.defaultView || r).document, d.querySelector) {
                    if ((d = d.querySelector('style[nonce],link[rel="stylesheet"][nonce]')) && (d = d.nonce || d.getAttribute("nonce")) &&
                        Qd.test(d)) break a;
                    d = ""
                } else d = "";
                d && e.setAttribute("nonce", d)
            } else {
                if (d instanceof Yc) d = ad(d).toString();
                else if (d instanceof hd) d = id(d);
                else {
                    if (!(d instanceof hd)) {
                        d = String(d);
                        b: {
                            c = void 0;
                            try {
                                c = new URL(d)
                            } catch (g) {
                                c = "https:";
                                break b
                            }
                            c = c.protocol
                        }
                        "javascript:" === c && (d = "about:invalid#zClosurez");
                        d = new hd(d, md)
                    }
                    d = id(d)
                }
                e.href = d
            }
            a.document.head.appendChild(b)
        }
    };

    function Wp(a, b) {
        a.F ? b(a.l) : a.j.push(b)
    }

    function Xp(a, b) {
        a.F = !0;
        a.l = b;
        a.j.forEach(c => {
            c(a.l)
        });
        a.j = []
    }
    class Yp extends T {
        constructor(a) {
            super();
            this.g = a;
            this.j = [];
            this.F = !1;
            this.C = this.l = null;
            this.H = Bp(a, 1E3, () => {
                if (null != this.C) {
                    var b = zo(this.g, !0) - this.C;
                    1E3 < b && Xp(this, b)
                }
            });
            this.A = null
        }
        L(a, b) {
            null == a ? (this.C = a = zo(this.g, !0), this.g.addEventListener("scroll", this.H), null != b && b(a)) : this.A = this.g.setTimeout(() => {
                this.L(void 0, b)
            }, a)
        }
        i() {
            null != this.A && this.g.clearTimeout(this.A);
            this.g.removeEventListener("scroll", this.H);
            this.j = [];
            this.l = null;
            super.i()
        }
    };
    var Zp = (a, b) => a.reduce((c, d) => c.concat(b(d)), []);
    class $p {
        constructor(a = 1) {
            this.g = a
        }
        next() {
            var a = 48271 * this.g % 2147483647;
            this.g = 0 > 2147483647 * a ? a + 2147483647 : a;
            return this.g / 2147483647
        }
    };

    function aq(a, b, c) {
        const d = [];
        for (const e of a.g) b(e) ? d.push(e) : c(e);
        return new bq(d)
    }

    function cq(a) {
        return a.g.slice(0)
    }

    function dq(a, b = 1) {
        a = cq(a);
        const c = new $p(b);
        qb(a, () => c.next());
        return new bq(a)
    }
    const bq = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new bq(Xa(this.g, a))
        }
        apply(a) {
            return new bq(a(cq(this)))
        }
        sort(a) {
            return new bq(cq(this).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = cq(this);
            b.push(a);
            return new bq(b)
        }
    };
    class eq {
        constructor(a) {
            this.g = new Qo(a)
        }
        contains(a) {
            return this.g.contains(a)
        }
    };

    function fq(a) {
        return new gq({
            value: a
        }, null)
    }

    function hq(a) {
        return new gq(null, a)
    }

    function iq(a) {
        try {
            return fq(a())
        } catch (b) {
            return hq(b)
        }
    }

    function jq(a) {
        return null != a.g ? a.getValue() : null
    }

    function kq(a, b) {
        null != a.g && b(a.getValue());
        return a
    }

    function lq(a, b) {
        null != a.g || b(a.i);
        return a
    }
    class gq {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return null != this.g ? (a = a(this.getValue()), a instanceof gq ? a : fq(a)) : this
        }
    };
    class mq {
        constructor() {
            this.g = new Po
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new Qo, this.g.set(a, c));
            c.add(b)
        }
    };

    function nq(a) {
        return !a
    }

    function oq(a) {
        return b => {
            for (const c of a) c(b)
        }
    };

    function pq(a) {
        return null !== a
    };
    var qq = class extends R {
        getId() {
            return I(this, 3)
        }
    };
    qq.P = [4];
    class rq {
        constructor(a, {
            Jf: b,
            zh: c,
            Li: d,
            Xg: e
        }) {
            this.A = a;
            this.j = c;
            this.l = new bq(b || []);
            this.i = e;
            this.g = d
        }
    };
    var sq = a => {
            var b = a.split("~").filter(c => 0 < c.length);
            a = new Po;
            for (const c of b) b = c.indexOf("."), -1 == b ? a.set(c, "") : a.set(c.substring(0, b), c.substring(b + 1));
            return a
        },
        uq = a => {
            var b = tq(a);
            a = [];
            for (let c of b) b = String(c.nc), a.push(c.zb + "." + (20 >= b.length ? b : b.slice(0, 19) + "_"));
            return a.join("~")
        };
    const tq = a => {
            const b = [],
                c = a.l;
            c && c.g.length && b.push({
                zb: "a",
                nc: vq(c)
            });
            null != a.j && b.push({
                zb: "as",
                nc: a.j
            });
            null != a.g && b.push({
                zb: "i",
                nc: String(a.g)
            });
            null != a.i && b.push({
                zb: "rp",
                nc: String(a.i)
            });
            b.sort(function(d, e) {
                return d.zb.localeCompare(e.zb)
            });
            b.unshift({
                zb: "t",
                nc: wq(a.A)
            });
            return b
        },
        wq = a => {
            switch (a) {
                case 0:
                    return "aa";
                case 1:
                    return "ma";
                default:
                    throw Error("Invalid slot type" + a);
            }
        },
        vq = a => {
            a = cq(a).map(xq);
            a = JSON.stringify(a);
            return af(a)
        },
        xq = a => {
            const b = {};
            null != I(a, 7) && (b.q = I(a, 7));
            null != ui(a,
                2) && (b.o = ui(a, 2));
            null != ui(a, 5) && (b.p = ui(a, 5));
            return b
        };

    function yq() {
        var a = new zq;
        return Vh(a, 2, dh(1))
    }
    var zq = class extends R {
        g() {
            return L(this, 1)
        }
        setLocation(a) {
            return Vh(this, 1, dh(a))
        }
    };

    function Aq(a) {
        const b = [].slice.call(arguments).filter(Ib(e => null === e));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Rf || []);
            d = Object.assign(d, e.zc())
        });
        return new Bq(c, d)
    }

    function Cq(a) {
        switch (a) {
            case 1:
                return new Bq(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new Bq(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new Bq(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new Bq(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function Dq(a) {
        return null == a ? null : new Bq(null, {
            google_ml_rank: a
        })
    }

    function Eq(a) {
        return null == a ? null : new Bq(null, {
            google_placement_id: uq(a)
        })
    }

    function Fq({
        ei: a,
        ti: b = null
    }) {
        if (null == a) return null;
        a = {
            google_daaos_ts: a
        };
        null != b && (a.google_erank = b + 1);
        return new Bq(null, a)
    }
    class Bq {
        constructor(a, b) {
            this.Rf = a;
            this.g = b
        }
        zc() {
            return this.g
        }
    };
    var Gq = class extends R {};
    var Hq = class extends R {};
    var Iq = class extends R {};
    var Jq = class extends R {};
    var Kq = class extends R {
        A() {
            return I(this, 2)
        }
        l() {
            return I(this, 5)
        }
        g() {
            return D(this, Jq, 3)
        }
        Mb() {
            return ui(this, 4)
        }
        j() {
            return Zh(this, 6)
        }
        B() {
            return Xh(this, Iq, 7)
        }
    };
    Kq.P = [3];
    var Lq = class extends R {};
    var Mq = class extends R {};
    var Nq = class extends R {
        constructor() {
            super()
        }
    };
    var Oq = class extends R {
        g() {
            return L(this, 3)
        }
        Mb() {
            return vi(this, 4)
        }
        j() {
            return $h(this, 6)
        }
    };
    var Pq = class extends R {};
    var Qq = class extends R {};
    var Rq = class extends R {
        ia() {
            return C(this, qq, 1)
        }
        g() {
            return L(this, 2)
        }
    };
    var Sq = class extends R {};
    var Tq = class extends R {};
    var Uq = class extends R {
            getName() {
                return I(this, 4)
            }
        },
        Vq = [1, 2, 3];
    var Wq = class extends R {
        g() {
            return C(this, Oq, 10)
        }
    };
    Wq.P = [2, 5, 6, 11];
    var Xq = class extends R {
        g() {
            return $h(this, 2)
        }
        j() {
            return $h(this, 3)
        }
    };
    var Yq = class extends R {
        g() {
            return vi(this, 1)
        }
    };
    var Zq = class extends R {};
    var $q = class extends R {
        g() {
            return zi(this, 1)
        }
        j() {
            return O(this, 3)
        }
        l() {
            return O(this, 4)
        }
    };
    var ar = class extends R {
        j() {
            return yi(this, 1)
        }
        g() {
            return yi(this, 1)
        }
    };
    var br = class extends R {
        g() {
            return O(this, 1)
        }
        j() {
            return O(this, 2)
        }
        A() {
            return O(this, 3)
        }
        l() {
            return O(this, 4)
        }
    };
    var cr = class extends R {
        j() {
            return C(this, $q, 8)
        }
        l() {
            return C(this, $q, 9)
        }
        B() {
            return C(this, br, 4)
        }
        g() {
            return C(this, ar, 5)
        }
        A() {
            return O(this, 10)
        }
        C() {
            return M(this, 12)
        }
        G() {
            return M(this, 14)
        }
    };
    var dr = class extends R {
        l() {
            return M(this, 1)
        }
        A() {
            return M(this, 3)
        }
        j() {
            return M(this, 4)
        }
        g() {
            return M(this, 5)
        }
    };
    var er = class extends R {
        j() {
            return C(this, br, 5)
        }
        g() {
            return C(this, ar, 6)
        }
        A() {
            return O(this, 8)
        }
        B() {
            return M(this, 9)
        }
        C() {
            return M(this, 11)
        }
        l() {
            return C(this, dr, 12)
        }
    };

    function fr() {
        var a = new gr;
        a = $i(a, 1, "Toggle toolbar expansion");
        a = $i(a, 2, "Toggle privacy and legal settings display");
        return $i(a, 3, "Dismiss privacy and legal settings display")
    }
    var gr = class extends R {};
    var hr = class extends R {
        g() {
            return C(this, gr, 1)
        }
    };
    var ir = class extends R {};
    ir.P = [2];
    var jr = class extends R {};
    var kr = class extends R {
        g() {
            return D(this, jr, 1)
        }
    };
    kr.P = [1];
    var lr = class extends R {
        setProperty(a) {
            return $i(this, 1, a)
        }
        getValue() {
            return I(this, 2)
        }
    };
    var mr = class extends R {};
    mr.P = [3, 4];
    var nr = class extends R {};
    var or = class extends R {
        ia() {
            return C(this, qq, 1)
        }
        g() {
            return L(this, 2)
        }
    };
    or.P = [6, 7, 9, 10, 11];
    var pr = class extends R {};
    pr.P = [4];
    var qr = class extends R {};
    var rr = class extends R {
        g() {
            return ai(this, 6, uh, 2)
        }
    };
    rr.P = [6];
    var sr = class extends R {
        Ie() {
            return Xh(this, qr, 2)
        }
    };
    var tr = class extends R {
        g() {
            return yi(this, 1)
        }
    };
    var ur = class extends R {};
    var wr = class extends R {
            g() {
                return Si(this, ur, 2, vr)
            }
        },
        vr = [1, 2];
    var xr = class extends R {
        g() {
            return C(this, wr, 3)
        }
    };
    var yr = class extends R {};
    var zr = class extends R {
        g() {
            return D(this, yr, 1)
        }
    };
    zr.P = [1];
    var Ar = class extends R {
        g() {
            return ai(this, 1, uh, 2)
        }
        j() {
            return C(this, xr, 3)
        }
    };
    Ar.P = [1, 4];

    function Br(a) {
        return C(a, Hq, 13)
    }

    function Cr(a) {
        return C(a, Mq, 15)
    }
    var Dr = class extends R {},
        Er = hj(Dr);
    Dr.P = [1, 2, 5, 7];
    var Fr = class extends R {},
        Gr = hj(Fr);

    function Hr(a) {
        try {
            const b = a.localStorage.getItem("google_ama_settings");
            return b ? Gr(b) : null
        } catch (b) {
            return null
        }
    }

    function Ir(a, b) {
        if (void 0 !== a.ye) {
            var c = Hr(b);
            c || (c = new Fr);
            void 0 !== a.ye && Vi(c, 2, a.ye);
            a = Date.now() + 864E5;
            Number.isFinite(a) && Zi(c, 1, Math.round(a));
            c = bj(c);
            try {
                b.localStorage.setItem("google_ama_settings", c)
            } catch (d) {}
        } else if ((c = Hr(b)) && vi(c, 1) < Date.now()) try {
            b.localStorage.removeItem("google_ama_settings")
        } catch (d) {}
    };
    var Jr = {
            Va: "ama_success",
            Pa: .1,
            Sa: !0,
            Wa: !0
        },
        Kr = {
            Va: "ama_failure",
            Pa: .1,
            Sa: !0,
            Wa: !0
        },
        Lr = {
            Va: "ama_coverage",
            Pa: .1,
            Sa: !0,
            Wa: !0
        },
        Mr = {
            Va: "ama_opt",
            Pa: .1,
            Sa: !0,
            Wa: !1
        },
        Nr = {
            Va: "ama_auto_rs",
            Pa: 1,
            Sa: !0,
            Wa: !1
        },
        Or = {
            Va: "ama_auto_prose",
            Pa: 1,
            Sa: !0,
            Wa: !1
        },
        Pr = {
            Va: "ama_improv",
            Pa: .1,
            Sa: !0,
            Wa: !1
        },
        Qr = {
            Va: "ama_constraints",
            Pa: 0,
            Sa: !0,
            Wa: !0
        };

    function Rr(a, b, c) {
        var d = 0 === a.i ? a.g.j() : a.g.l(),
            e = a.j,
            f = S(a.win),
            g = a.g.g() ? .g() || 0;
        a: switch (d ? .g()) {
            case 1:
                d = "AUTO_PROSE_TOP_ANCHOR";
                break a;
            case 2:
                d = "AUTO_PROSE_BOTTOM_ANCHOR";
                break a;
            default:
                d = "UNKNOWN_POSITION"
        }
        a: switch (a.i) {
            case 0:
                a = "DESKTOP";
                break a;
            case 2:
                a = "MOBILE";
                break a;
            default:
                a = "OTHER_VIEWPORT"
        }
        Sr(e, Or, { ...c,
            evt: b,
            vh: f,
            eid: g,
            pos: d,
            vpt: a
        })
    }

    function Tr(a, b) {
        Rr(a, "place", {
            sts: b
        })
    }
    var Ur = class {
        constructor(a, b, c) {
            this.win = a;
            this.j = b;
            this.g = c;
            this.i = of ()
        }
    };
    var Vr = {},
        Wr = {},
        Xr = {},
        Yr = {},
        Zr = {};

    function $r() {
        throw Error("Do not instantiate directly");
    }
    $r.prototype.Tf = null;
    $r.prototype.Ma = function() {
        return this.content
    };
    $r.prototype.toString = function() {
        return this.content
    };

    function as(a) {
        if (a.Uf !== Vr) throw Error("Sanitized content was not of kind HTML.");
        return Ed(a.toString())
    }

    function bs() {
        $r.call(this)
    }
    La(bs, $r);
    bs.prototype.Uf = Vr;

    function cs(a, b) {
        return null != a && a.Uf === b
    };

    function ds(a) {
        if (null != a) switch (a.Tf) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function es(a) {
        return cs(a, Vr) ? a : a instanceof Dd ? fs(Cd(a).toString()) : fs(String(String(a)).replace(gs, hs), ds(a))
    }
    var fs = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            void 0 !== d && (c.Tf = d);
            return c
        }
    }(bs);

    function is(a) {
        return a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>")
    }

    function js(a) {
        return cs(a, Vr) ? String(String(a.Ma()).replace(ks, "").replace(ls, "&lt;")).replace(ms, hs) : String(a).replace(gs, hs)
    }

    function ns(a) {
        a = String(a);
        const b = (d, e, f) => {
            const g = Math.min(e.length - f, d.length);
            for (let k = 0; k < g; k++) {
                var h = e[f + k];
                if (d[k] !== ("A" <= h && "Z" >= h ? h.toLowerCase() : h)) return !1
            }
            return !0
        };
        for (var c = 0; - 1 != (c = a.indexOf("<", c));) {
            if (b("\x3c/script", a, c) || b("\x3c!--", a, c)) return "zSoyz";
            c += 1
        }
        return a
    }

    function os(a) {
        if (null == a) return " null ";
        if (cs(a, Wr)) return a.Ma();
        switch (typeof a) {
            case "boolean":
            case "number":
                return " " + a + " ";
            default:
                return "'" + String(String(a)).replace(ps, qs) + "'"
        }
    }

    function X(a) {
        cs(a, Zr) ? a = is(a.Ma()) : null == a ? a = "" : a instanceof qd ? a = is(pd(a)) : a instanceof Ad ? a = is(a instanceof Ad && a.constructor === Ad ? a.g : "type_error:SafeStyleSheet") : (a = String(a), a = rs.test(a) ? a : "zSoyz");
        return a
    }
    const ss = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\v": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    };

    function hs(a) {
        return ss[a]
    }
    const ts = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\v": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    };

    function qs(a) {
        return ts[a]
    }
    const us = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function vs(a) {
        return us[a]
    }
    const gs = /[\x00\x22\x26\x27\x3c\x3e]/g,
        ms = /[\x00\x22\x27\x3c\x3e]/g,
        ws = /[\x00\x09-\x0d \x22\x26\x27\x2d\/\x3c-\x3e`\x85\xa0\u2028\u2029]/g,
        xs = /[\x00\x09-\x0d \x22\x27\x2d\/\x3c-\x3e`\x85\xa0\u2028\u2029]/g,
        ps = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
        ys = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        rs = /^(?!-*(?:expression|(?:moz-)?binding))(?:(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|(?:calc|cubic-bezier|drop-shadow|hsl|hsla|hue-rotate|invert|linear-gradient|max|min|rgb|rgba|rotate|rotateZ|translate|translate3d|translateX|translateY|var)\((?:[-\u0020\t,+.!#%_0-9a-zA-Z]|(?:calc|cubic-bezier|drop-shadow|hsl|hsla|hue-rotate|invert|linear-gradient|max|min|rgb|rgba|rotate|rotateZ|translate|translate3d|translateX|translateY|var)\([-\u0020\t,+.!#%_0-9a-zA-Z]+\))+\)|[-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:e-?[0-9]+)?(?:[a-z]{1,4}|%)?|!important)(?:\s*[,\u0020]\s*|$))*$/i,
        zs =
        /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^ftp:|^data:image\/[a-z0-9+-]+;base64,[a-z0-9+\/]+=*$|^blob:/i,
        ks = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
        ls = /</g;

    function As(a) {
        a = void 0 === a ? "white" : a;
        return fs('<svg width="' + js(18) + '" height="' + js(18) + '" viewBox="0 0 ' + js(18) + " " + js(18) + '"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.76 10.27L17.49 16L16 17.49L10.27 11.76C9.2 12.53 7.91 13 6.5 13C2.91 13 0 10.09 0 6.5C0 2.91 2.91 0 6.5 0C10.09 0 13 2.91 13 6.5C13 7.91 12.53 9.2 11.76 10.27ZM6.5 2C4.01 2 2 4.01 2 6.5C2 8.99 4.01 11 6.5 11C8.99 11 11 8.99 11 6.5C11 4.01 8.99 2 6.5 2Z" fill=' + (cs(a, Vr) ? String(String(a.Ma()).replace(ks, "").replace(ls,
            "&lt;")).replace(xs, hs) : String(a).replace(ws, hs)) + " /></svg>")
    };
    /* 
     
     
     Copyright Mathias Bynens <http://mathiasbynens.be/> 
     
     Permission is hereby granted, free of charge, to any person obtaining 
     a copy of this software and associated documentation files (the 
     "Software"), to deal in the Software without restriction, including 
     without limitation the rights to use, copy, modify, merge, publish, 
     distribute, sublicense, and/or sell copies of the Software, and to 
     permit persons to whom the Software is furnished to do so, subject to 
     the following conditions: 
     
     The above copyright notice and this permission notice shall be 
     included in all copies or substantial portions of the Software. 
     
     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
     EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
     MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
     NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE 
     LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION 
     OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
     WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
    */
    const Bs = Math.floor;
    var Cs = /^xn--/,
        Ds = /[\x2E\u3002\uFF0E\uFF61]/g;
    const Es = {
        Em: "Overflow: input needs wider integers to process",
        Am: "Illegal input >= 0x80 (not a basic code point)",
        km: "Invalid input"
    };

    function Fs(a) {
        throw RangeError(Es[a]);
    }

    function Gs(a, b) {
        const c = a.split("@");
        let d = "";
        1 < c.length && (d = c[0] + "@", a = c[1]);
        a = a.replace(Ds, ".");
        a = a.split(".").map(b).join(".");
        return d + a
    }

    function Hs(a) {
        return Gs(a, b => {
            if (Cs.test(b) && 4 < b.length) {
                b = b.slice(4).toLowerCase();
                const h = [],
                    k = b.length;
                let l = 0,
                    m = 128;
                var c = 72,
                    d = b.lastIndexOf("-");
                0 > d && (d = 0);
                for (var e = 0; e < d; ++e) 128 <= b.charCodeAt(e) && Fs("Illegal input >= 0x80 (not a basic code point)"), h.push(b.charCodeAt(e));
                for (d = 0 < d ? d + 1 : 0; d < k;) {
                    e = l;
                    for (let n = 1, p = 36;; p += 36) {
                        d >= k && Fs("Invalid input");
                        var f = b.charCodeAt(d++);
                        f = 10 > f - 48 ? f - 22 : 26 > f - 65 ? f - 65 : 26 > f - 97 ? f - 97 : 36;
                        (36 <= f || f > Bs((2147483647 - l) / n)) && Fs("Overflow: input needs wider integers to process");
                        l += f * n;
                        var g = p <= c ? 1 : p >= c + 26 ? 26 : p - c;
                        if (f < g) break;
                        f = 36 - g;
                        n > Bs(2147483647 / f) && Fs("Overflow: input needs wider integers to process");
                        n *= f
                    }
                    f = h.length + 1;
                    c = l - e;
                    g = 0;
                    c = 0 == e ? Bs(c / 700) : c >> 1;
                    for (c += Bs(c / f); 455 < c; g += 36) c = Bs(c / 35);
                    c = Bs(g + 36 * c / (c + 38));
                    Bs(l / f) > 2147483647 - m && Fs("Overflow: input needs wider integers to process");
                    m += Bs(l / f);
                    l %= f;
                    h.splice(l++, 0, m)
                }
                b = String.fromCodePoint.apply(null, h)
            }
            return b
        })
    };
    const Is = new sb(ub, "558153351");

    function Js(a, b, c) {
        var d = a.Na.contentWindow;
        const e = !a.B && "number" === typeof a.g;
        a.C ? (b = {
            action: "search",
            searchTerm: b,
            rsToken: c
        }, e && (b.experimentId = a.g), 0 < a.i.length && (b.adfiliateWp = a.i), d.postMessage(b, "https://www.gstatic.com")) : (d = d.google.search.cse.element.getElement(a.G), c = {
            rsToken: c,
            hostName: a.host
        }, e && (c.afsExperimentId = a.g), 0 < a.i.length && (c.adfiliateWp = a.i), d.execute(b, void 0, c))
    }

    function Ks(a, b) {
        if (a.H) {
            const c = a.Na.contentDocument ? .getElementById("prose-empty-serp-container");
            b && c && Sb(b, "input", () => {
                c.style.display = "none"
            })
        }
    }
    var Ls = class {
        constructor(a, b, c, d, e, f, g, h, k, l, m = !1, n = !1, p = !1, q = "") {
            this.Na = a;
            this.l = b;
            this.G = c;
            this.j = d;
            this.O = e;
            this.host = f.host;
            this.origin = f.origin;
            this.A = g;
            this.F = h;
            this.g = k;
            this.I = m;
            this.C = l;
            this.H = n;
            this.B = p;
            this.i = q
        }
        L() {
            this.Na.setAttribute("id", "prose-iframe");
            this.Na.setAttribute("width", "100%");
            this.Na.setAttribute("height", "100%");
            var a = uj `box-sizing:border-box;border:unset;`;
            this.Na.style.cssText = pd(a);
            a = "https://www.google.com/s2/favicons?sz=64&domain_url=" + encodeURIComponent(this.host);
            var b = Ce(a, Be) || nd;
            var c = Hs(this.host.startsWith("www.") ? this.host.slice(4) : this.host);
            a = this.G;
            var d = this.j,
                e = this.O;
            const f = this.host;
            c = this.F.replace("${website}", c);
            const g = this.H;
            var h = fs,
                k = "<style>.cse-favicon {display: block; float: left; height: 16px; position: absolute; left: 15px; width: 16px;}.cse-header {font-size: 16px; font-family: Arial; margin-left: 35px; margin-top: 6px; margin-bottom: unset; line-height: 16px;}.gsc-search-box {max-width: 520px !important;}.gsc-input {padding-right: 0 !important;}.gsc-input-box {border-radius: 16px 0 0 16px !important;}.gsc-search-button-v2 {border-left: 0 !important; border-radius: 0 16px 16px 0 !important; min-height: 30px !important; margin-left: 0 !important;}.gsc-cursor-page, .gsc-cursor-next-page, .gsc-cursor-numbered-page {color: #1a73e8 !important;}.gsc-cursor-chevron {fill: #1a73e8 !important;}.gsc-cursor-box {text-align: center !important;}.gsc-cursor-current-page {color: #000 !important;}.gcsc-find-more-on-google-root, .gcsc-find-more-on-google {display: none !important;}.prose-container {max-width: 652px;}#prose-empty-serp-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 52px; position: relative; width: 248px; height: 259px; margin: auto; top: 100px;}#prose-empty-serp-icon-image {display: flex; flex-direction: row; justify-content: center; align-items: center; padding: 30px; gap: 10px; width: 124px; height: 124px; border-radius: 62px; flex: none; order: 1; flex-grow: 0; position: absolute; top: 0;}#prose-empty-serp-text-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 19px; width: 248px; height: 83px; flex: none; order: 2; align-self: stretch; flex-grow: 0; position: absolute; top: 208px;}#prose-empty-serp-text-div {display: flex; flex-direction: column; align-items: flex-start; padding: 0; gap: 11px; width: 248px; height: 83px; flex: none; order: 0; align-self: stretch; flex-grow: 0;}#prose-empty-serp-supporting-text {width: 248px; height: 40px; font-family: 'Arial'; font-style: normal; font-weight: 400; font-size: 14px; line-height: 20px; text-align: center; letter-spacing: 0.2px; color: #202124; flex: none; order: 1; align-self: stretch; flex-grow: 0;}</style>" +
                (this.I ? '<script>window.__gcse={initializationCallback:function(){top.postMessage({action:"init",adChannel:"' + String(e).replace(ps, qs) + '"},top.location.origin);}};\x3c/script>' : "") + '<div class="prose-container"><img class="cse-favicon" src="';
            cs(b, Xr) || cs(b, Yr) ? b = String(b).replace(ys, vs) : b instanceof hd ? b = String(id(b)).replace(ys, vs) : b instanceof Yc ? b = String(ad(b).toString()).replace(ys, vs) : (b = String(b), b = zs.test(b) ? b.replace(ys, vs) : "about:invalid#zSoyz");
            a = h(k + js(b) + '" alt="' + js(f) + ' icon"><p class="cse-header"><strong>' +
                es(c) + '</strong></p><div class="gcse-search" data-gname="' + js(a) + '" data-adclient="' + js(d) + '" data-adchannel="' + js(e) + '" data-as_sitesearch="' + js(f) + '" data-personalizedAds="false"></div></div>' + (g ? "<div id=\"prose-empty-serp-container\"><img id='prose-empty-serp-icon-image' src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI0IiBoZWlnaHQ9IjEyNCIgdmlld0JveD0iMCAwIDEyNCAxMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMjQiIGhlaWdodD0iMTI0IiByeD0iNjIiIGZpbGw9IiNGMUYzRjQiLz4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik02OS4zNiA2NS4zODY3TDg0LjY0IDgwLjY2NjdMODAuNjY2NyA4NC42NEw2NS4zODY3IDY5LjM2QzYyLjUzMzMgNzEuNDEzMyA1OS4wOTMzIDcyLjY2NjcgNTUuMzMzMyA3Mi42NjY3QzQ1Ljc2IDcyLjY2NjcgMzggNjQuOTA2NyAzOCA1NS4zMzMzQzM4IDQ1Ljc2IDQ1Ljc2IDM4IDU1LjMzMzMgMzhDNjQuOTA2NyAzOCA3Mi42NjY3IDQ1Ljc2IDcyLjY2NjcgNTUuMzMzM0M3Mi42NjY3IDU5LjA5MzMgNzEuNDEzMyA2Mi41MzMzIDY5LjM2IDY1LjM4NjdaTTU1LjMzMzMgNDMuMzMzM0M0OC42OTMzIDQzLjMzMzMgNDMuMzMzMyA0OC42OTMzIDQzLjMzMzMgNTUuMzMzM0M0My4zMzMzIDYxLjk3MzMgNDguNjkzMyA2Ny4zMzMzIDU1LjMzMzMgNjcuMzMzM0M2MS45NzMzIDY3LjMzMzMgNjcuMzMzMyA2MS45NzMzIDY3LjMzMzMgNTUuMzMzM0M2Ny4zMzMzIDQ4LjY5MzMgNjEuOTczMyA0My4zMzMzIDU1LjMzMzMgNDMuMzMzM1oiIGZpbGw9IiM5QUEwQTYiLz4KPC9zdmc+Cg==' alt=''><div id='prose-empty-serp-text-container'><div id='prose-empty-serp-text-div'><div id='prose-empty-serp-supporting-text'>Search this website by entering a keyword.</div></div></div></div>" :
                    ""));
            a = as(a);
            this.C ? (a = this.Na, d = dd(new sb(ub, "https://www.gstatic.com/prose/protected/%{version}/iframe.html?cx=%{cxId}&host=%{host}&hl=%{lang}&lrh=%{lrh}&client=%{client}&origin=%{origin}"), {
                version: Is,
                cxId: this.l,
                host: this.host,
                lang: this.A,
                lrh: this.F,
                client: this.j,
                origin: this.origin
            }), a.src = ad(d).toString()) : (d = new Map([
                    ["cx", this.l],
                    ["language", this.A]
                ]), this.B && (e = Array.isArray(this.g) ? this.g : [this.g], e.length && d.set("fexp", e.join())), e = tj(d), d = {}, e = `<script src="${jj(ad(e).toString())}"`, d.async &&
                (e += " async"), d.ci && (e += ` custom-element="${jj(d.ci)}"`), d.defer && (e += " defer"), d.id && (e += ` id="${jj(d.id)}"`), d.nonce && (e += ` nonce="${jj(d.nonce)}"`), d.type && (e += ` type="${jj(d.type)}"`), d = Ed(e + ">\x3c/script>"), a = pj({
                    style: uj `margin:${0};`
                }, [a, d]), this.Na.srcdoc = Cd(a))
        }
    };

    function Ms(a) {
        var b = [];
        Jo(a.getElementsByTagName("p"), function(c) {
            100 <= Ns(c) && b.push(c)
        });
        return b
    }

    function Ns(a) {
        if (3 == a.nodeType) return a.length;
        if (1 != a.nodeType || "SCRIPT" == a.tagName) return 0;
        var b = 0;
        Jo(a.childNodes, function(c) {
            b += Ns(c)
        });
        return b
    }

    function Os(a) {
        return 0 == a.length || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Ps(a, b) {
        if (null == a.g) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }
    const Qs = class {
        constructor(a, b, c, d) {
            this.l = a;
            this.i = b;
            this.j = c;
            this.g = d
        }
        query(a) {
            var b = [];
            try {
                b = a.querySelectorAll(this.l)
            } catch (f) {}
            if (!b.length) return [];
            a = gb(b);
            a = Ps(this, a);
            "number" === typeof this.i && (b = this.i, 0 > b && (b += a.length), a = 0 <= b && b < a.length ? [a[b]] : []);
            if ("number" === typeof this.j) {
                b = [];
                for (var c = 0; c < a.length; c++) {
                    var d = Ms(a[c]),
                        e = this.j;
                    0 > e && (e += d.length);
                    0 <= e && e < d.length && b.push(d[e])
                }
                a = b
            }
            return a
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.l,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.g
            })
        }
    };

    function Rs(a) {
        if (1 != a.nodeType) var b = !1;
        else if (b = "INS" == a.tagName) a: {
            b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
            for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
            for (d = 0; d < b.length; ++d)
                if (!c[b[d]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    }

    function Ss(a) {
        return Ko(a.querySelectorAll("ins.adsbygoogle-ablated-ad-slot"))
    };
    var Ts = new t(1310, !0),
        Us = new t(1277, !0),
        Vs = new t(1308, !0),
        Ws = new t(1275, !0),
        Xs = new t(1311, !0),
        Ys = new zb(1130, 100),
        Zs = new t(1270, !0),
        $s = new zb(1032, 200),
        at = new Ab(14),
        bt = new zb(1224, .01),
        ct = new t(1260),
        dt = new t(1239),
        et = new t(1196),
        ft = new t(1160),
        gt = new t(316),
        ht = new t(1290),
        it = new t(1312, !0),
        jt = new t(334),
        kt = new zb(1263, -1),
        lt = new zb(54),
        mt = new zb(1265, -1),
        nt = new zb(1264, -1),
        ot = new t(1291),
        pt = new t(1267, !0),
        qt = new t(1268, !0),
        rt = new t(1266),
        st = new t(313),
        tt = new zb(66, -1),
        ut = new zb(65, -1),
        vt = new t(1256),
        wt = new t(369),
        xt = new t(1241, !0),
        yt = new t(368),
        zt = new t(1300, !0),
        At = new Bb(1273, ["en", "de"]),
        Bt = new t(1223, !0),
        Ct = new Bb(1261, ["44786015", "44786016"]),
        Dt = new t(1309),
        Et = new t(1289),
        Ft = new t(1282),
        Gt = new t(1250),
        Ht = new t(1151),
        It = new zb(1072, .75),
        Jt = new t(290),
        Kt = new t(1222),
        Lt = new t(1238),
        Mt = new t(1237),
        Nt = new Ab(1307),
        Ot = new zb(572636916, 25),
        Pt = new zb(595730437),
        Qt = new zb(579884443),
        Rt = new zb(566560958, 3E4),
        St = new zb(508040914, 100),
        Tt = new zb(547455356, 49),
        Ut = new t(595118933),
        Vt = new t(566279275),
        Wt =
        new t(566279276),
        Xt = new t(595118932),
        Yt = new Bb(556791602, ["1", "2", "4", "6"]),
        Zt = new t(45614877),
        $t = new t(561639568, !0),
        au = new t(566560957),
        bu = new Ab(589752731),
        cu = new Ab(589752730),
        du = new t(579884441),
        eu = new zb(571329679),
        fu = new t(556739145),
        gu = new zb(572636915, 150),
        hu = new zb(579884442),
        iu = new zb(595645509, .3),
        ju = new zb(561668774, .1),
        ku = new t(598587325),
        lu = new t(554474127),
        mu = new t(550910941),
        nu = new t(506914611),
        ou = new t(599093330),
        pu = new t(597181299),
        qu = new t(598633105),
        ru = new t(595989603),
        su = new zb(469675170,
            3E4),
        tu = new t(160889229),
        uu = new t(506852289),
        vu = new t(1120),
        wu = new t(597181300),
        xu = new t(586386407, !0),
        yu = new t(573506525, !0),
        zu = new t(573506524, !0),
        Au = new t(562896595),
        Bu = new t(586643641, !0),
        Cu = new t(596652146),
        Du = new zb(592337179),
        Eu = new t(570863962, !0),
        Fu = new Ab(570879859, "control_1\\.\\d"),
        Gu = new zb(570863961, 50),
        Hu = new t(570879858, !0),
        Iu = new t(570804360),
        Ju = new Ab(1166),
        Ku = new t(1E4),
        Lu = new t(562874197),
        Mu = new t(562874196),
        Nu = new t(555237685, !0),
        Ou = new t(45460956),
        Pu = new t(45414947, !0),
        Qu = new zb(472785970,
            500),
        Ru = new t(45545710),
        Su = new t(439828594),
        Tu = new t(483962503),
        Uu = new t(506738118),
        Vu = new t(77),
        Wu = new t(78),
        Xu = new t(83),
        Yu = new t(80),
        Zu = new t(76),
        $u = new t(84),
        av = new t(1973),
        bv = new t(188),
        cv = new t(485990406);

    function dv(a, b) {
        a = re(new ee(a), "DIV");
        const c = a.style;
        c.width = "100%";
        c.height = "auto";
        c.clear = b ? "both" : "none";
        return a
    }

    function ev(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && 8 == d.nodeType;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        Rs(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    }

    function fv(a) {
        if (a && a.parentNode) {
            const b = a.parentNode;
            b.removeChild(a);
            Rs(b) && (b.style.display = b.getAttribute("data-init-display") || "none")
        }
    };
    var hv = (a, b, c, d = 0) => {
            var e = gv(b, c, d);
            if (e.L) {
                for (c = b = e.L; c = e.rd(c);) b = c;
                e = {
                    anchor: b,
                    position: e.Kd
                }
            } else e = {
                anchor: b,
                position: c
            };
            a["google-ama-order-assurance"] = d;
            ev(a, e.anchor, e.position)
        },
        iv = (a, b, c, d = 0) => {
            v(st) ? hv(a, b, c, d) : ev(a, b, c)
        };

    function gv(a, b, c) {
        const d = f => {
                f = jv(f);
                return null == f ? !1 : c < f
            },
            e = f => {
                f = jv(f);
                return null == f ? !1 : c > f
            };
        switch (b) {
            case 0:
                return {
                    L: kv(a.previousSibling, d),
                    rd: f => kv(f.previousSibling, d),
                    Kd: 0
                };
            case 2:
                return {
                    L: kv(a.lastChild, d),
                    rd: f => kv(f.previousSibling, d),
                    Kd: 0
                };
            case 3:
                return {
                    L: kv(a.nextSibling, e),
                    rd: f => kv(f.nextSibling, e),
                    Kd: 3
                };
            case 1:
                return {
                    L: kv(a.firstChild, e),
                    rd: f => kv(f.nextSibling, e),
                    Kd: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function jv(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function kv(a, b) {
        return a && b(a) ? a : null
    };
    var lv = (a, b) => {
            try {
                const c = b.document.documentElement.getBoundingClientRect(),
                    d = a.getBoundingClientRect();
                return {
                    x: d.left - c.left,
                    y: d.top - c.top
                }
            } catch (c) {
                return null
            }
        },
        mv = (a, b) => {
            const c = 40 === a.google_reactive_ad_format,
                d = 16 === a.google_reactive_ad_format;
            return !!a.google_ad_resizable && (!a.google_reactive_ad_format || c) && !d && !!b.navigator && /iPhone|iPod|iPad|Android|BlackBerry/.test(b.navigator.userAgent) && b === b.top
        },
        nv = (a, b, c) => {
            a = a.style;
            "rtl" == b ? a.marginRight = c : a.marginLeft = c
        };
    const ov = (a, b, c) => {
        a = lv(b, a);
        return "rtl" == c ? -a.x : a.x
    };
    var pv = (a, b) => {
            b = b.parentElement;
            return b ? (a = Xe(b, a)) ? a.direction : "" : ""
        },
        qv = (a, b, c) => {
            if (0 !== ov(a, b, c)) {
                nv(b, c, "0px");
                var d = ov(a, b, c);
                nv(b, c, -1 * d + "px");
                a = ov(a, b, c);
                0 !== a && a !== d && nv(b, c, d / (a - d) * d + "px")
            }
        };
    const rv = RegExp("(^| )adsbygoogle($| )");

    function sv(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = be(d.property);
            a[e] = d.value
        }
    }

    function tv(a, b, c, d, e, f) {
        a = uv(a, e);
        a.wa.setAttribute("data-ad-format", d ? d : "auto");
        vv(a, b, c, f);
        return a
    }

    function wv(a, b, c = null) {
        a = uv(a, {});
        vv(a, b, null, c);
        return a
    }

    function vv(a, b, c, d) {
        var e = [];
        if (d = d && d.Rf) a.ob.className = d.join(" ");
        a = a.wa;
        a.className = "adsbygoogle";
        a.setAttribute("data-ad-client", b);
        c && a.setAttribute("data-ad-slot", c);
        e.length && a.setAttribute("data-ad-channel", e.join("+"))
    }

    function uv(a, b) {
        const c = dv(a, b.clearBoth || !1);
        var d = c.style;
        d.textAlign = "center";
        b.Jd && sv(d, b.Jd);
        a = re(new ee(a), "INS");
        d = a.style;
        d.display = "block";
        d.margin = "auto";
        d.backgroundColor = "transparent";
        b.tf && (d.marginTop = b.tf);
        b.je && (d.marginBottom = b.je);
        b.jc && sv(d, b.jc);
        c.appendChild(a);
        return {
            ob: c,
            wa: a
        }
    }

    function xv(a, b, c) {
        b.dataset.adsbygoogleStatus = "reserved";
        b.className += " adsbygoogle-noablate";
        const d = {
            element: b
        };
        c = c && c.zc();
        if (b.hasAttribute("data-pub-vars")) {
            try {
                c = JSON.parse(b.getAttribute("data-pub-vars"))
            } catch (e) {
                return
            }
            b.removeAttribute("data-pub-vars")
        }
        c && (d.params = c);
        (a.adsbygoogle = a.adsbygoogle || []).push(d)
    }

    function yv(a) {
        const b = Ss(a.document);
        Ua(b, function(c) {
            const d = zv(a, c);
            var e;
            if (e = d) {
                e = (e = lv(c, a)) ? e.y : 0;
                const f = S(a);
                e = !(e < f)
            }
            e && (c.setAttribute("data-pub-vars", JSON.stringify(d)), c.removeAttribute("height"), c.style.removeProperty("height"), c.removeAttribute("width"), c.style.removeProperty("width"), xv(a, c))
        })
    }

    function zv(a, b) {
        b = b.getAttribute("google_element_uid");
        a = a.google_sv_map;
        if (!b || !a || !a[b]) return null;
        a = a[b];
        b = {};
        for (let c in rb) a[rb[c]] && (b[rb[c]] = a[rb[c]]);
        return b
    };
    class Av {
        constructor() {
            var a = sj `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
            this.g = null;
            this.i = !1;
            this.A = Math.random();
            this.j = this.Ba;
            this.B = a
        }
        kf(a) {
            this.g = a
        }
        l(a) {
            this.i = a
        }
        Ba(a, b, c = .01, d, e = "jserror") {
            if ((this.i ? this.A : Math.random()) > c) return !1;
            b.error && b.meta && b.id || (b = new Vk(b, {
                context: a,
                id: e
            }));
            if (d || this.g) b.meta = {}, this.g && this.g(b.meta), d && d(b.meta);
            r.google_js_errors = r.google_js_errors || [];
            r.google_js_errors.push(b);
            r.error_rep_loaded || (Ve(r.document, this.B), r.error_rep_loaded = !0);
            return !1
        }
        Kc(a, b, c) {
            try {
                return b()
            } catch (d) {
                if (!this.j(a, d, .01, c, "jserror")) throw d;
            }
        }
        Oa(a, b, c, d) {
            return (...e) => this.Kc(a, () => b.apply(c, e), d)
        }
        Ca(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.Ba(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    const Bv = (a, b) => {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    var Cv = (a, b, c, d, e = !1) => {
            const f = d || window,
                g = "undefined" !== typeof queueMicrotask;
            return function() {
                e && g && queueMicrotask(() => {
                    f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                    f.google_rum_task_id_counter += 1
                });
                const h = bl();
                let k, l = 3;
                try {
                    k = b.apply(this, arguments)
                } catch (m) {
                    l = 13;
                    if (!c) throw m;
                    c(a, m)
                } finally {
                    f.google_measure_js_timing && h && Bv({
                        label: a.toString(),
                        value: h,
                        duration: (bl() || 0) - h,
                        type: l,
                        ...(e && g && {
                            taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                        })
                    }, f)
                }
                return k
            }
        },
        Dv = (a, b, c, d = !1) => Cv(a, b, (e, f) => {
            (new Av).Ba(e, f)
        }, c, d);

    function Ev(a, b, c) {
        return Cv(a, b, void 0, c, !0).apply()
    }

    function Fv(a, b) {
        return Dv(754, a, b, !0).apply()
    }

    function Gv(a) {
        if (!a) return null;
        var b = I(a, 7);
        if (I(a, 1) || a.getId() || 0 < ai(a, 4, uh, 2).length) {
            var c = I(a, 3),
                d = I(a, 1),
                e = ai(a, 4, uh, 2);
            b = ui(a, 2);
            var f = ui(a, 5);
            a = Hv(L(a, 6));
            var g = "";
            d && (g += d);
            c && (g += "#" + Os(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + Os(e[c]);
            b = (e = g) ? new Qs(e, b, f, a) : null
        } else b = b ? new Qs(b, ui(a, 2), ui(a, 5), Hv(L(a, 6))) : null;
        return b
    }
    var Iv = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Hv(a) {
        return null == a ? a : Iv[a]
    }

    function Jv(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = I(a[c], 1),
                e = I(a[c], 2);
            if (d && null != e) {
                var f = {};
                f.property = d;
                f.value = e;
                b.push(f)
            }
        }
        return b
    }

    function Kv(a, b) {
        var c = {};
        a && (c.tf = I(a, 1), c.je = I(a, 2), c.clearBoth = !!$h(a, 3));
        b && (c.Jd = Jv(D(b, lr, 3)), a = D(b, lr, 4), c.jc = Jv(a));
        return c
    }
    var Lv = {
            1: 0,
            2: 1,
            3: 2,
            4: 3
        },
        Mv = {
            0: 1,
            1: 2,
            2: 3,
            3: 4
        };
    const Nv = ["-webkit-text-fill-color"];

    function Ov(a) {
        if (Bc) {
            {
                const c = Xe(a.document.body, a);
                if (c) {
                    a = {};
                    var b = c.length;
                    for (let d = 0; d < b; ++d) a[c[d]] = "initial";
                    a = Pv(a)
                } else a = Qv()
            }
        } else a = Qv();
        return a
    }
    var Qv = () => {
        const a = {
            all: "initial"
        };
        Ua(Nv, b => {
            a[b] = "unset"
        });
        return a
    };

    function Pv(a) {
        Ua(Nv, b => {
            delete a[b]
        });
        return a
    };

    function Rv(a, b) {
        const c = a.document.createElement("div");
        A(c, Ov(a));
        a = c.attachShadow({
            mode: "open"
        });
        b && c.classList.add(b);
        return {
            Ta: c,
            shadowRoot: a
        }
    };

    function Sv({
        hc: a,
        Ib: b,
        Wb: c,
        ic: d,
        Jb: e,
        Xb: f
    }) {
        const g = [];
        for (let n = 0; n < f; n++)
            for (let p = 0; p < c; p++) {
                var h = p,
                    k = c - 1,
                    l = n,
                    m = f - 1;
                g.push({
                    x: a + (0 === k ? 0 : h / k) * (b - a),
                    y: d + (0 === m ? 0 : l / m) * (e - d)
                })
            }
        return g
    }

    function Tv(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };

    function Uv(a, b) {
        for (const c of b)
            if (b = Vv(a, c)) return b;
        return null
    }

    function Wv(a, {
        Si: b,
        Cj: c,
        width: d,
        height: e
    }) {
        b = Sv({
            hc: b,
            Ib: b + d,
            Wb: 10,
            ic: c,
            Jb: c + e,
            Xb: 10
        });
        return Uv(a, b)
    }

    function Xv(a, b) {
        var c = Sv({
            hc: b.left,
            Ib: b.right,
            Wb: 10,
            ic: b.top,
            Jb: b.bottom,
            Xb: 10
        });
        b = new Set;
        for (const d of c)(c = Vv(a, d)) && b.add(c);
        return b
    }

    function Yv(a, b, c) {
        if ("fixed" !== Bk(b, "position")) return null;
        var d = "GoogleActiveViewInnerContainer" === b.getAttribute("class") || 1 >= Ek(b).width && 1 >= Ek(b).height || a.g.ni && !a.g.ni(b) ? !0 : !1;
        a.g.gg && a.g.gg(b, c, d);
        return d ? null : b
    }

    function Vv(a, b) {
        var c = Tv(a.K.document, b);
        if (c) {
            var d;
            if (!(d = Yv(a, c, b))) a: {
                d = a.K.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    const e = Yv(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    }
    var Zv = class {
        constructor(a, b = {}) {
            this.K = a;
            this.g = b
        }
    };

    function $v(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map)) : a.google_reactive_ads_global_state = new aw;
        return a.google_reactive_ads_global_state
    }
    class aw {
        constructor() {
            this.wasPlaTagProcessed = !1;
            this.wasReactiveAdConfigReceived = {};
            this.adCount = {};
            this.wasReactiveAdVisible = {};
            this.stateForType = {};
            this.reactiveTypeEnabledInAsfe = {};
            this.wasReactiveTagRequestSent = !1;
            this.reactiveTypeDisabledByPublisher = {};
            this.tagSpecificState = {};
            this.messageValidationEnabled = !1;
            this.floatingAdsStacking = new bw;
            this.sideRailProcessedFixedElements = new Set;
            this.sideRailAvailableSpace = new Map;
            this.sideRailPlasParam = new Map
        }
    }
    var bw = class {
        constructor() {
            this.maxZIndexRestrictions = {};
            this.nextRestrictionId = 0;
            this.maxZIndexListeners = []
        }
    };

    function cw(a, b) {
        return new dw(a, b)
    }

    function ew(a) {
        const b = fw(a);
        Ua(a.g.maxZIndexListeners, c => c(b))
    }

    function fw(a) {
        a = $e(a.g.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }

    function gw(a, b) {
        eb(a.g.maxZIndexListeners, c => c === b)
    }
    class hw {
        constructor(a) {
            this.g = $v(a).floatingAdsStacking
        }
    }

    function iw(a) {
        if (null == a.g) {
            var b = a.i,
                c = a.j;
            const d = b.g.nextRestrictionId++;
            b.g.maxZIndexRestrictions[d] = c;
            ew(b);
            a.g = d
        }
    }

    function jw(a) {
        if (null != a.g) {
            var b = a.i;
            delete b.g.maxZIndexRestrictions[a.g];
            ew(b);
            a.g = null
        }
    }
    class dw {
        constructor(a, b) {
            this.i = a;
            this.j = b;
            this.g = null
        }
    };

    function kw(a) {
        a = a.activeElement;
        const b = a ? .shadowRoot;
        return b ? kw(b) || a : a
    }

    function lw(a, b) {
        return mw(b, a.document.body).flatMap(c => nw(c))
    }

    function mw(a, b) {
        var c = a;
        for (a = []; c && c !== b;) {
            a.push(c);
            let e;
            var d;
            (d = c.parentElement) || (c = c.getRootNode(), d = (null == (e = c.mode && c.host ? c : null) ? void 0 : e.host) || null);
            c = d
        }
        return c !== b ? [] : a
    }

    function nw(a) {
        const b = a.parentElement;
        return b ? Array.from(b.children).filter(c => c !== a) : []
    };

    function ow(a) {
        null !== a.g && (a.g.ri.forEach(b => {
            b.inert = !1
        }), a.g.lj ? .focus(), a.g = null)
    }

    function pw(a, b) {
        ow(a);
        const c = kw(a.win.document);
        b = lw(a.win, b).filter(d => !d.inert);
        b.forEach(d => {
            d.inert = !0
        });
        a.g = {
            lj: c,
            ri: b
        }
    }
    var qw = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
        Ud() {
            ow(this)
        }
    };

    function rw(a) {
        return new sw(a, new bp(a, a.document.body), new bp(a, a.document.documentElement), new bp(a, a.document.documentElement))
    }

    function tw(a) {
        ap(a.j, "scroll-behavior", "auto");
        const b = uw(a.win);
        b.activePageScrollPreventers.add(a);
        null === b.previousWindowScroll && (b.previousWindowScroll = a.win.scrollY);
        ap(a.g, "position", "fixed");
        ap(a.g, "top", `${-b.previousWindowScroll}px`);
        ap(a.g, "width", "100%");
        ap(a.g, "overflow-x", "hidden");
        ap(a.g, "overflow-y", "hidden");
        ap(a.i, "overflow-x", "hidden");
        ap(a.i, "overflow-y", "hidden")
    }

    function hx(a) {
        $o(a.g);
        $o(a.i);
        const b = uw(a.win);
        b.activePageScrollPreventers.delete(a);
        0 === b.activePageScrollPreventers.size && (a.win.scrollTo(0, b.previousWindowScroll || 0), b.previousWindowScroll = null);
        $o(a.j)
    }
    var sw = class {
        constructor(a, b, c, d) {
            this.win = a;
            this.g = b;
            this.i = c;
            this.j = d
        }
    };

    function uw(a) {
        return a.googPageScrollPreventerInfo = a.googPageScrollPreventerInfo || {
            previousWindowScroll: null,
            activePageScrollPreventers: new Set
        }
    }

    function ix(a) {
        return a.googPageScrollPreventerInfo && 0 < a.googPageScrollPreventerInfo.activePageScrollPreventers.size ? !0 : !1
    };

    function jx(a, b) {
        return kx(`#${a}`, b)
    }

    function lx(a, b) {
        return kx(`.${a}`, b)
    }

    function kx(a, b) {
        b = b.querySelector(a);
        if (!b) throw Error(`Element (${a}) does not exist`);
        return b
    };

    function mx(a, b) {
        b = Rv(a, b);
        a.document.body.appendChild(b.Ta);
        return b
    }

    function nx(a, b) {
        const c = new V(b.M);
        jp(b, !0, () => void c.g(!0));
        jp(b, !1, () => {
            a.setTimeout(() => {
                b.M || c.g(!1)
            }, 700)
        });
        return fp(c)
    };

    function ox(a) {
        const b = a.vc;
        var c = a.Qd,
            d = a.uc;
        const e = a.kc,
            f = a.Nf,
            g = a.fe,
            h = a.Ja;
        a = "<style>#hd-drawer-container {position: fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + X(a.zIndex) + "; pointer-events: none;}#hd-drawer-container.hd-revealed {pointer-events: auto;}#hd-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.hd-revealed > #hd-modal-background {opacity: 0.5;}#hd-drawer {position: absolute; top: 0; height: 100%; width: " +
            X(b) + "; background-color: white; display: flex; flex-direction: column; box-sizing: border-box; padding-bottom: ";
        c = c ? h ? 20 : 16 : 0;
        a += X(c) + "px; transition: transform " + X(g) + "s ease-in-out;" + (d ? "left: 0; border-top-right-radius: " + X(c) + "px; border-bottom-right-radius: " + X(c) + "px; transform: translateX(-100%);" : "right: 0; border-top-left-radius: " + X(c) + "px; border-bottom-left-radius: " + X(c) + "px; transform: translateX(100%);") + "}.hd-revealed > #hd-drawer {transform: translateY(0);}#hd-control-bar {" + (h ?
                "height: 24px;" : "padding: 5px;") + "}.hd-control-button {border: none; background: none; cursor: pointer;" + (h ? "" : "padding: 5px;") + "}#hd-back-arrow-button {" + (d ? "float: right;" : "float: left;") + "}#hd-close-button {" + (d ? "float: left;" : "float: right;") + '}#hd-content-container {flex-grow: 1; overflow: auto;}#hd-content-container::-webkit-scrollbar * {background: transparent;}.hd-hidden {visibility: hidden;}</style><div id="hd-drawer-container" class="hd-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="hd-modal-background"></div><div id="hd-drawer"><div id="hd-control-bar"><button id="hd-back-arrow-button" class="hd-control-button hd-hidden" aria-label="' +
            js(f) + '">';
        d = h ? "#5F6368" : "#444746";
        a += '<svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + js(d) + '"><path d="m12 20-8-8 8-8 1.425 1.4-5.6 5.6H20v2H7.825l5.6 5.6Z"/></svg></button><button id="hd-close-button" class="hd-control-button" aria-label="' + js(e) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + js(d) + '"><path d="M6.4 19 5 17.6 10.6 12 5 6.4 6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4Z"/></svg></button></div><div id="hd-content-container"></div></div></div>';
        return fs(a)
    };

    function px(a) {
        a = a.top;
        if (!a) return null;
        try {
            var b = a.history
        } catch (c) {
            b = null
        }
        b = b && b.pushState && "function" === typeof b.pushState ? b : null;
        if (!b) return null;
        if (a.googNavStack) return a.googNavStack;
        b = new qx(a, b);
        b.L();
        return b ? a.googNavStack = b : null
    }

    function rx(a, b) {
        return b ? b.googNavStackId === a.j ? b : null : null
    }

    function sx(a, b) {
        for (let c = b.length - 1; 0 <= c; --c) {
            const d = 0 === c;
            a.K.requestAnimationFrame(() => void b[c].uj({
                isFinal: d
            }))
        }
    }

    function tx(a, b) {
        b = jb(a.stack, b, (c, d) => c - d.ng.googNavStackStateId);
        if (0 <= b) return a.stack.splice(b, a.stack.length - b);
        b = -b - 1;
        return a.stack.splice(b, a.stack.length - b)
    }
    class qx extends T {
        constructor(a, b) {
            super();
            this.K = a;
            this.g = b;
            this.stack = [];
            this.j = 1E9 * Math.random() >>> 0;
            this.A = 0;
            this.l = c => {
                (c = rx(this, c.state)) ? sx(this, tx(this, c.googNavStackStateId + .5)): sx(this, this.stack.splice(0, this.stack.length))
            }
        }
        pushEvent() {
            const a = {
                    googNavStackId: this.j,
                    googNavStackStateId: this.A++
                },
                b = new Promise(c => {
                    this.stack.push({
                        uj: c,
                        ng: a
                    })
                });
            this.g.pushState(a, "");
            return {
                navigatedBack: b,
                triggerNavigateBack: () => {
                    const c = tx(this, a.googNavStackStateId);
                    var d;
                    if (d = 0 < c.length) {
                        d = c[0].ng;
                        const e = rx(this, this.g.state);
                        d = e && e.googNavStackId === d.googNavStackId && e.googNavStackStateId === d.googNavStackStateId
                    }
                    d && this.g.go(-c.length);
                    sx(this, c)
                }
            }
        }
        L() {
            this.K.addEventListener("popstate", this.l)
        }
        i() {
            this.K.removeEventListener("popstate", this.l);
            super.i()
        }
    };

    function ux(a) {
        return (a = px(a)) ? new vx(a) : null
    }

    function wx(a) {
        if (!a.g) {
            var {
                navigatedBack: b,
                triggerNavigateBack: c
            } = a.l.pushEvent();
            a.g = c;
            b.then(() => {
                a.g && !a.B && (a.g = null, pp(a.j))
            })
        }
    }
    var vx = class extends T {
        constructor(a) {
            super();
            this.l = a;
            this.j = new qp;
            this.g = null
        }
    };

    function xx(a, b, c) {
        var d = c.we ? null : new qw(a);
        const e = cw(new hw(a), c.zIndex - 1);
        b = yx(a, b, c);
        d = new zx(a, b, d, c.tb, rw(a), e);
        d.L();
        (c.kd || void 0 === c.kd) && Ax(d);
        c.qb && ((a = ux(a)) ? Bx(d, a, c.We) : c.We ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function Ax(a) {
        a.A = b => {
            "Escape" === b.key && a.g.M && a.collapse()
        };
        a.win.document.body.addEventListener("keydown", a.A)
    }

    function Bx(a, b, c) {
        jp(a.g, !0, () => {
            try {
                wx(b)
            } catch (d) {
                c ? .(d)
            }
        });
        jp(a.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        np(b.j).listen(() => void a.collapse());
        Yo(a, b)
    }

    function Cx(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.C
    }

    function Dx(a) {
        a.win.setTimeout(() => {
            a.g.M && Cx(a).Ka.focus()
        }, 500)
    }

    function Ex(a) {
        const {
            Ve: b,
            Vh: c
        } = Cx(a);
        b.addEventListener("click", () => void a.collapse());
        c.addEventListener("click", () => void a.collapse())
    }

    function Fx(a) {
        jp(a.j, !1, () => {
            Cx(a).Ka.classList.add("hd-hidden")
        })
    }
    var zx = class extends T {
        constructor(a, b, c, d = !0, e, f) {
            super();
            this.win = a;
            this.C = b;
            this.l = c;
            this.tb = d;
            this.g = new V(!1);
            this.j = nx(a, this.g);
            jp(this.j, !0, () => {
                tw(e);
                iw(f)
            });
            jp(this.j, !1, () => {
                hx(e);
                jw(f)
            })
        }
        show({
            bg: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            Cx(this).Ka.classList.remove("hd-hidden");
            Wo(this.win);
            Cx(this).Ka.classList.add("hd-revealed");
            this.g.g(!0);
            this.l && (pw(this.l, Cx(this).eb.Ta), this.tb && Dx(this));
            a && jp(this.j, !1, () => {
                this.la()
            })
        }
        collapse() {
            Cx(this).Ka.classList.remove("hd-revealed");
            this.g.g(!1);
            this.l ? .Ud()
        }
        isVisible() {
            return this.j
        }
        L() {
            Ex(this);
            Fx(this)
        }
        i() {
            this.A && this.win.document.body.removeEventListener("keydown", this.A);
            const a = this.C.eb.Ta,
                b = a.parentNode;
            b && b.removeChild(a);
            this.l ? .Ud();
            super.i()
        }
    };

    function yx(a, b, c) {
        const d = mx(a, c.xe),
            e = d.shadowRoot;
        e.appendChild(se(new ee(a.document), as(ox({
            vc: c.vc,
            Qd: c.Qd ? ? !0,
            uc: c.uc || !1,
            kc: c.kc,
            Nf: c.Nf || "",
            zIndex: c.zIndex,
            fe: .5,
            Ja: c.Ja || !1
        }))));
        const f = jx("hd-drawer-container", e);
        c.Ce ? .i(g => {
            f.setAttribute("aria-label", g)
        });
        c = jx("hd-content-container", e);
        c.appendChild(b);
        Wo(a);
        return {
            Ka: f,
            Ve: jx("hd-modal-background", e),
            qe: c,
            Vh: jx("hd-close-button", e),
            Qn: jx("hd-back-arrow-button", e),
            eb: d
        }
    };

    function Gx(a) {
        const b = a.fj,
            c = a.zi;
        var d = a.fe;
        const e = a.Ja;
        a = "<style>#ved-drawer-container {position:  fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + X(a.zIndex) + "; pointer-events: none;}#ved-drawer-container.ved-revealed {pointer-events: auto;}#ved-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.ved-revealed > #ved-modal-background {opacity: 0.5;}#ved-ui-revealer {position: absolute; left: 0; bottom: 0; width: 100%; height: " +
            X(c) + "%; transition: transform " + X(d) + "s ease-in-out; transform: translateY(100%);}#ved-ui-revealer.ved-no-animation {transition-property: none;}.ved-revealed > #ved-ui-revealer {transform: translateY(0);}#ved-scroller-container {position: absolute; left: 0; bottom: 0; width: 100%; height: 100%; clip-path: inset(0 0 -50px 0 round ";
        d = e ? 20 : 28;
        a += X(d) + "px);}#ved-scroller {position: relative; width: 100%; height: 100%; overflow-y: scroll; -ms-overflow-style: none; scrollbar-width: none; overflow-y: scroll; overscroll-behavior: none; scroll-snap-type: y mandatory;}#ved-scroller.ved-scrolling-paused {overflow: hidden;}#ved-scroller.ved-no-snap {scroll-snap-type: none;}#ved-scroller::-webkit-scrollbar {display: none;}#ved-scrolled-stack {width: 100%; height: 100%; overflow: visible;}#ved-scrolled-stack.ved-with-background {background-color: white;}.ved-snap-point-top {scroll-snap-align: start;}.ved-snap-point-bottom {scroll-snap-align: end;}#ved-fully-closed-anchor {height: " +
            X(b / c * 100) + "%;}.ved-with-background #ved-fully-closed-anchor {background-color: white;}#ved-partially-extended-anchor {height: " + X((c - b) / c * 100) + "%;}.ved-with-background #ved-partially-extended-anchor {background-color: white;}#ved-moving-handle-holder {scroll-snap-stop: always;}.ved-with-background #ved-moving-handle-holder {background-color: white;}#ved-fixed-handle-holder {position: absolute; left: 0; top: 0; width: 100%;}#ved-visible-scrolled-items {display: flex; flex-direction: column; min-height: " +
            X(b / c * 100) + "%;}#ved-content-background {width: 100%; flex-grow: 1; padding-top: 1px; margin-top: -1px; background-color: white;}#ved-content-sizer {overflow: hidden; width: 100%; height: 100%;}#ved-content-container {width: 100%;}#ved-over-scroll-block {display: flex; flex-direction: column; position: absolute; bottom: 0; left: 0; width: 100%; height: " + X(b / c * 100) + "%; pointer-events: none;}#ved-over-scroll-handle-spacer {height: " + X(80) + "px;}#ved-over-scroll-background {flex-grow: 1; background-color: white;}.ved-handle {align-items: flex-end; border-radius: " +
            X(d) + "px " + X(d) + "px 0 0; background: white; display: flex; height: " + X(30) + "px; justify-content: center; cursor: grab;}.ved-handle-icon {" + (e ? "background: #dadce0; width: 50px;" : "background: #747775; opacity: 0.4; width: 32px;") + 'border-radius: 2px; height: 4px; margin-bottom: 8px;}.ved-hidden {visibility: hidden;}</style><div id="ved-drawer-container" class="ved-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="ved-modal-background"></div><div id="ved-ui-revealer"><div id="ved-over-scroll-block" class="ved-hidden"><div id=\'ved-over-scroll-handle-spacer\'></div><div id=\'ved-over-scroll-background\'></div></div><div id="ved-scroller-container"><div id="ved-scroller"><div id="ved-scrolled-stack"><div id="ved-fully-closed-anchor" class="ved-snap-point-top"></div><div id="ved-partially-extended-anchor" class="ved-snap-point-top"></div><div id="ved-visible-scrolled-items"><div id="ved-moving-handle-holder" class="ved-snap-point-top">' +
            Hx("ved-moving-handle") + '</div><div id="ved-content-background"><div id="ved-content-sizer" class="ved-snap-point-bottom"><div id="ved-content-container"></div></div></div></div></div></div></div><div id="ved-fixed-handle-holder" class="ved-hidden">' + Hx("ved-fixed-handle") + "</div></div></div>";
        return fs(a)
    }

    function Hx(a) {
        return fs('<div class="ved-handle" id="' + js(a) + '"><div class="ved-handle-icon"></div></div>')
    };

    function Ix(a) {
        return Ep(a.g).map(b => b ? Jx(a, b) : 0)
    }

    function Jx(a, b) {
        switch (a.direction) {
            case 0:
                return Kx(-b.uh);
            case 1:
                return Kx(-b.th);
            default:
                throw Error(`Unhandled direction: ${a.direction}`);
        }
    }

    function Lx(a) {
        return Gp(a.g).map(b => Jx(a, b))
    }
    var Mx = class {
        constructor(a) {
            this.g = a;
            this.direction = 0
        }
    };

    function Kx(a) {
        return 0 === a ? 0 : a
    };

    function Y(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.C
    }

    function Nx(a) {
        a.win.setTimeout(() => {
            a.g.M && Y(a).Ka.focus()
        }, 500)
    }

    function Ox(a) {
        Y(a).Ka.classList.remove("ved-hidden");
        Wo(a.win);
        const {
            pa: b,
            bb: c
        } = Y(a);
        c.getBoundingClientRect().top <= b.getBoundingClientRect().top || Px(a);
        Y(a).Ka.classList.add("ved-revealed");
        a.g.g(!0);
        a.j && (pw(a.j, Y(a).eb.Ta), a.tb && Nx(a))
    }

    function Qx(a) {
        return nx(a.win, a.g)
    }

    function Rx(a, b) {
        const c = new V(b());
        np(a.H).listen(() => void c.g(b()));
        return fp(c)
    }

    function Sx(a) {
        const {
            pa: b,
            Id: c
        } = Y(a);
        return Rx(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function Tx(a) {
        const {
            pa: b,
            Id: c
        } = Y(a);
        return Rx(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top - 1)
    }

    function Ux(a) {
        const {
            pa: b
        } = Y(a);
        return Rx(a, () => b.scrollTop === b.scrollHeight - b.clientHeight)
    }

    function Vx(a) {
        return gp(Sx(a), Ux(a))
    }

    function Wx(a) {
        const {
            pa: b,
            bb: c
        } = Y(a);
        return Rx(a, () => c.getBoundingClientRect().top < b.getBoundingClientRect().top - 1)
    }

    function Px(a) {
        Y(a).bb.classList.add("ved-snap-point-top");
        var b = Xx(a, Y(a).bb);
        Y(a).pa.scrollTop = b;
        Yx(a)
    }

    function Zx(a) {
        W(Sx(a), !0, () => {
            const {
                hg: b,
                Mc: c
            } = Y(a);
            b.classList.remove("ved-hidden");
            c.classList.add("ved-with-background")
        });
        W(Sx(a), !1, () => {
            const {
                hg: b,
                Mc: c
            } = Y(a);
            b.classList.add("ved-hidden");
            c.classList.remove("ved-with-background")
        })
    }

    function $x(a) {
        const b = Lp(a.win, Y(a).qe);
        Op(b).i(() => void ay(a));
        Yo(a, b)
    }

    function by(a) {
        W(cy(a), !0, () => {
            Y(a).Og.classList.remove("ved-hidden")
        });
        W(cy(a), !1, () => {
            Y(a).Og.classList.add("ved-hidden")
        })
    }

    function dy(a) {
        const b = () => void pp(a.F),
            {
                Ve: c,
                bb: d,
                yi: e
            } = Y(a);
        c.addEventListener("click", b);
        d.addEventListener("click", b);
        e.addEventListener("click", b);
        jp(ey(a), !0, b)
    }

    function fy(a) {
        jp(Qx(a), !1, () => {
            Px(a);
            Y(a).Ka.classList.add("ved-hidden")
        })
    }

    function Yx(a) {
        ip(a.l, !1, () => void pp(a.H))
    }

    function ay(a) {
        if (!a.l.M) {
            var {
                Vf: b,
                qe: c
            } = Y(a), d = c.getBoundingClientRect().height;
            d = Math.max(gy(a), d);
            a.l.g(!0);
            var e = hy(a);
            b.style.setProperty("height", `${d}px`);
            e();
            a.win.requestAnimationFrame(() => {
                a.win.requestAnimationFrame(() => {
                    a.l.g(!1)
                })
            })
        }
    }

    function cy(a) {
        const {
            pa: b,
            bb: c
        } = Y(a);
        return Rx(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function ey(a) {
        return ep(a.A.map(nq), iy(a))
    }

    function iy(a) {
        return Rx(a, () => 0 === Y(a).pa.scrollTop)
    }

    function Xx(a, b) {
        ({
            Mc: a
        } = Y(a));
        a = a.getBoundingClientRect().top;
        return b.getBoundingClientRect().top - a
    }

    function jy(a, b) {
        a.A.g(!0);
        const {
            Mc: c,
            pa: d
        } = Y(a);
        d.scrollTop = 0;
        d.classList.add("ved-scrolling-paused");
        c.style.setProperty("margin-top", `-${b}px`);
        return () => void ky(a, b)
    }

    function ky(a, b) {
        const {
            Mc: c,
            pa: d
        } = Y(a);
        c.style.removeProperty("margin-top");
        d.classList.remove("ved-scrolling-paused");
        Y(a).pa.scrollTop = b;
        Yx(a);
        a.A.g(!1)
    }

    function hy(a) {
        const b = Y(a).pa.scrollTop;
        jy(a, b);
        return () => void ky(a, b)
    }

    function gy(a) {
        const {
            pa: b,
            Id: c,
            Vf: d,
            bb: e
        } = Y(a);
        a = b.getBoundingClientRect();
        const f = c.getBoundingClientRect();
        var g = d.getBoundingClientRect();
        const h = e.getBoundingClientRect();
        g = g.top - f.top;
        return Math.max(a.height - h.height - g, Math.min(a.height, a.bottom - f.top) - g)
    }
    var ly = class extends T {
        constructor(a, b, c, d, e = !0) {
            super();
            this.win = a;
            this.C = b;
            this.I = c;
            this.j = d;
            this.tb = e;
            this.F = new qp;
            this.H = new qp;
            this.g = new V(!1);
            this.A = new V(!1);
            this.l = new V(!1)
        }
        L() {
            Px(this);
            Zx(this);
            $x(this);
            by(this);
            dy(this);
            fy(this);
            Y(this).pa.addEventListener("scroll", () => void Yx(this))
        }
        i() {
            const a = this.C.eb.Ta,
                b = a.parentNode;
            b && b.removeChild(a);
            this.j ? .Ud();
            super.i()
        }
    };

    function my(a, b, c) {
        const d = mx(a, c.xe),
            e = d.shadowRoot;
        e.appendChild(se(new ee(a.document), as(Gx({
            fj: 100 * c.Ze,
            zi: 100 * c.Fe,
            zIndex: c.zIndex,
            fe: .5,
            Ja: c.Ja || !1
        }))));
        const f = jx("ved-drawer-container", e);
        c.Ce ? .i(g => {
            f.setAttribute("aria-label", g)
        });
        c = jx("ved-content-container", e);
        c.appendChild(b);
        Wo(a);
        return {
            Ka: f,
            Ve: jx("ved-modal-background", e),
            lh: jx("ved-ui-revealer", e),
            pa: jx("ved-scroller", e),
            Mc: jx("ved-scrolled-stack", e),
            yi: jx("ved-fully-closed-anchor", e),
            bb: jx("ved-partially-extended-anchor", e),
            Vf: jx("ved-content-sizer",
                e),
            qe: c,
            Wn: jx("ved-moving-handle", e),
            Id: jx("ved-moving-handle-holder", e),
            xi: jx("ved-fixed-handle", e),
            hg: jx("ved-fixed-handle-holder", e),
            Og: jx("ved-over-scroll-block", e),
            eb: d
        }
    };

    function ny(a, b, c) {
        var d = cw(new hw(a), c.zIndex - 1);
        b = my(a, b, c);
        const e = c.we ? null : new qw(a);
        var f = b.xi;
        f = new Hp(new yp(a, f), new vp(f));
        var g = f.g;
        g.A.addEventListener("mousedown", g.G);
        g.l.addEventListener("mouseup", g.B);
        g.l.addEventListener("mousemove", g.C, {
            passive: !1
        });
        g = f.i;
        g.i.addEventListener("touchstart", g.C);
        g.i.addEventListener("touchend", g.A);
        g.i.addEventListener("touchmove", g.B, {
            passive: !1
        });
        b = new ly(a, b, new Mx(f), e, c.tb);
        b.L();
        d = new oy(a, b, rw(a), d);
        Yo(d, b);
        d.L();
        c.qb && ((a = ux(a)) ? py(d, a, c.We) :
            c.We ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function py(a, b, c) {
        jp(a.g.g, !0, () => {
            try {
                wx(b)
            } catch (d) {
                c ? .(d)
            }
        });
        jp(a.g.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        np(b.j).listen(() => void a.collapse());
        Yo(a, b)
    }

    function qy(a) {
        jp(ep(Vx(a.g), Wx(a.g)), !0, () => {
            Y(a.g).bb.classList.remove("ved-snap-point-top")
        });
        W(Tx(a.g), !0, () => {
            Y(a.g).pa.classList.add("ved-no-snap")
        });
        W(Tx(a.g), !1, () => {
            Y(a.g).pa.classList.remove("ved-no-snap")
        });
        jp(Tx(a.g), !1, () => {
            var b = a.g;
            var c = Y(b).Id;
            c = jy(b, Xx(b, c));
            b.win.setTimeout(c, 100)
        })
    }

    function ry(a) {
        const b = a.g.I;
        Ix(b).listen(c => {
            c = -c;
            if (0 < c) {
                const {
                    lh: d
                } = Y(a.g);
                d.classList.add("ved-no-animation");
                d.style.setProperty("transform", `translateY(${c}px)`)
            } else({
                lh: c
            } = Y(a.g)), c.classList.remove("ved-no-animation"), c.style.removeProperty("transform")
        });
        Lx(b).listen(c => {
            30 < -c && a.collapse()
        })
    }
    var oy = class extends T {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.g = b;
            jp(Qx(b), !0, () => {
                tw(c);
                iw(d)
            });
            jp(Qx(b), !1, () => {
                hx(c);
                jw(d)
            })
        }
        show({
            bg: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            Ox(this.g);
            a && jp(Qx(this.g), !1, () => {
                this.la()
            })
        }
        collapse() {
            var a = this.g;
            Y(a).Ka.classList.remove("ved-revealed");
            a.g.g(!1);
            a.j ? .Ud()
        }
        isVisible() {
            return Qx(this.g)
        }
        L() {
            np(this.g.F).listen(() => {
                this.collapse()
            });
            qy(this);
            ry(this);
            Wo(this.win)
        }
    };
    var sy = class {
        constructor(a, b, c) {
            this.position = a;
            this.Bb = b;
            this.Je = c
        }
    };

    function ty(a, b) {
        this.start = a < b ? a : b;
        this.end = a < b ? b : a
    }
    ty.prototype.yc = function() {
        return this.end - this.start
    };

    function uy(a, b, c) {
        var d = S(a);
        d = new sy(b.cc.Hg(b.mb), b.Bb + 2 * b.mb, Math.min(d, b.Fd) - b.cc.qd() + 2 * b.mb);
        d = d.position.Wf(a, d.Bb, d.Je);
        var e = wo(a),
            f = S(a);
        c = vy(a, new hk(Rd(d.top, 0, f - 1), Rd(d.right, 0, e - 1), Rd(d.bottom, 0, f - 1), Rd(d.left, 0, e - 1)), c);
        f = wy(c);
        let g = d.top;
        e = [];
        for (let h = 0; h < f.length; h++) f[h].start > g && e.push(new ty(g, f[h].start)), g = f[h].end;
        g < d.bottom && e.push(new ty(g, d.bottom));
        a = S(a);
        d = [];
        for (f = e.length - 1; 0 <= f; f--) d.push(new ty(a - e[f].end, a - e[f].start));
        a: {
            for (const h of d)
                if (a = h.start + b.mb, a > b.cc.qd() +
                    b.Qe ? a = null : (d = Math.min(h.end - b.mb, b.Fd) - a, a = d < b.Te ? null : {
                        position: b.cc.sh(a),
                        Gc: d
                    }), a) {
                    b = a;
                    break a
                }
            b = null
        }
        return {
            ie: b,
            Pn: c
        }
    }

    function vy(a, b, c) {
        const d = Xv(new Zv(a), b);
        c.forEach(e => void d.delete(e));
        return d
    }

    function wy(a) {
        return Array.from(a).map(xy).sort((b, c) => b.start - c.start)
    }

    function xy(a) {
        a = a.getBoundingClientRect();
        return new ty(a.top, a.bottom)
    };

    function yy({
        ca: a,
        ta: b
    }) {
        return new zy(a, b)
    }
    var zy = class {
        constructor(a, b) {
            this.ca = a;
            this.ta = b
        }
        Hg(a) {
            return new zy(this.ca - a, this.ta - a)
        }
        Wf(a, b, c) {
            a = S(a) - this.ca - c;
            return new hk(a, this.ta + b, a + c, this.ta)
        }
        Kf(a) {
            a.bottom = `${this.ca}px`;
            a.left = `${this.ta}px`;
            a.right = ""
        }
        jg() {
            return 0
        }
        qd() {
            return this.ca
        }
        sh(a) {
            return new zy(a, this.ta)
        }
    };

    function Ay({
        ca: a,
        Fa: b
    }) {
        return new By(a, b)
    }
    var By = class {
        constructor(a, b) {
            this.ca = a;
            this.Fa = b
        }
        Hg(a) {
            return new By(this.ca - a, this.Fa - a)
        }
        Wf(a, b, c) {
            var d = wo(a);
            a = S(a) - this.ca - c;
            d = d - this.Fa - b;
            return new hk(a, d + b, a + c, d)
        }
        Kf(a) {
            a.bottom = `${this.ca}px`;
            a.right = `${this.Fa}px`;
            a.left = ""
        }
        jg() {
            return 1
        }
        qd() {
            return this.ca
        }
        sh(a) {
            return new By(a, this.Fa)
        }
    };

    function Cy(a) {
        const b = a.si,
            c = a.Xh,
            d = a.Qh,
            e = a.zj,
            f = a.Rh;
        a = a.Ph;
        return fs('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500,700" rel="stylesheet"><style>.ft-styless-button {border: none; background: none; user-select: none; cursor: pointer; border-radius: ' + X(16) + "px;}.ft-container {position: fixed;}.ft-menu {position: absolute; bottom: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); min-height: " +
            X(d) + "px;}.ft-menu:not(.ft-multiple-buttons *) {transition: padding 0.25s 0.25s, margin 0.25s 0.25s, border-radius 0.25s 0.25s, background-color 0s 0.5s; padding: 0; margin: " + X(a) + "px; border-radius: " + X(16) + "px; background-color: rgba(255, 255, 255, 0);}.ft-multiple-buttons .ft-menu {transition: margin 0.25s, padding 0.25s, border-radius 0.25s 0.25s, background-color 0s; padding: " + X(a) + "px; margin: 0; border-radius: " + X(16 + a) + "px; background-color: rgba(255, 255, 255, 1);}.ft-left-pos .ft-menu {left: 0;}.ft-right-pos .ft-menu {right: 0;}.ft-container.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}.ft-container:not(.ft-hidden) {transition: opacity 0.25s, bottom 0.5s ease; opacity: 1;}.google-symbols {font-size: 26px; color: #3c4043;}.ft-button-holder {display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 0;}.ft-flip-vertically {transform: scaleY(-1);}.ft-expand-toggle {width: " +
            X(d) + "px; height: " + X(d) + "px;}.ft-collapsed .ft-expand-icon {transition: transform 0.25s; transform: rotate(180deg);}.ft-expand-icon:not(.ft-collapsed *) {transition: transform 0.25s; transform: rotate(0deg);}.ft-button {position: relative; height: " + X(d) + "px; margin-bottom: " + X(f) + "px; transform: margin 0.25s 0.25s;}.ft-button.ft-last-button {margin-bottom: 0;}.ft-button > button {position: relative; height: " + X(d) + "px; width: " + X(d) + "px; margin: 0; padding: 0; border: none;}.ft-button > button > * {position: relative;}.ft-button .ft-highlighter {position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); height: " +
            X(d - 6) + "px; width: " + X(d - 6) + "px; border-radius: " + X(d / 2) + "px; background-color: #d2e3fc; opacity: 0; transition: opacity 0.25s;}.ft-button.ft-highlighted .ft-highlighter {opacity: 1;}.ft-button-corner-info {display: none;}.ft-button.ft-show-corner-info .ft-button-corner-info {position: absolute; left: -5px; top: 4px; background: #b3261e; border: 1.5px solid #ffffff; box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3), 0 1px 3px 1px rgba(60, 64, 67, 0.15); border-radius: 100px; color: ffffff; font-family: 'Google Sans Text'; font-style: normal; font-weight: 700; font-size: 11px; line-height: 14px; min-width: 16px; height: 16px; display: flex; flex-direction: row; justify-content: center; align-items: center;}.ft-separator {display: block; width: 100%; height: " +
            X(e) + "px;}.ft-separator > span {display: block; width: 28px; margin: 0 auto 10px auto; height: 0; border-bottom: 1px solid #dadce0;}.ft-expand-toggle-container {height: " + X(d) + "px;}.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}:not(.ft-hidden) {transition: opacity 0.25s; opacity: 1;}.ft-collapsed .ft-collapsible, .ft-collapsible.ft-collapsed, .ft-expand-toggle-container.ft-collapsed {transition: opacity 0.25s, margin 0.25s 0.25s, height 0.25s 0.25s, overflow 0.25s 0s, visibility 1s 0s; height: 0; opacity: 0; overflow: hidden; visibility: hidden; margin: 0;}.ft-collapsible:not(.ft-collapsed *):not(.ft-collapsed), .ft-expand-toggle-container:not(.ft-collapsed) {transition: margin 0.25s, height 0.25s, opacity 0.25s 0.25s; opacity: 1;}.ft-symbol-font-load-test {position: fixed; left: -1000px; top: -1000px; font-size: 26px; visibility: hidden;}.ft-reg-bubble {position: absolute; bottom: 0; padding: 10px 10px 0 10px; background: #fff; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); border-radius: " +
            X(16) + "px; max-width: calc(90vw - " + X(2 * d) + "px); width: 300px; height: 200px;}.ft-left-pos .ft-reg-bubble {left: " + X(d + 10 + a) + "px;}.ft-right-pos .ft-reg-bubble {right: " + X(d + 10 + a) + "px;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-collapsed {transition: width 0.25s ease-in 0.25s, height 0.25s ease-in 0.25s, opacity 0.05s linear 0.45s, overflow 0s 0.25s, visibility 0s 0.5s; width: 0; overflow: hidden; opacity: 0; visibility: hidden;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-no-messages {height: 0 !important;}.ft-reg-bubble:not(.ft-collapsed *):not(.ft-collapsed) {transition: width 0.25s ease-out, height 0.25s ease-out, opacity 0.05s linear;}.ft-reg-bubble-content {display: flex; flex-direction: row; max-width: calc(90vw - " +
            X(2 * d) + 'px); width: 300px;}.ft-collapsed .ft-reg-bubble-content {transition: opacity 0.25s; opacity: 0;}.ft-reg-bubble-content:not(.ft-collapsed *) {transition: opacity 0.25s 0.25s; opacity: 1;}.ft-reg-message-holder {flex-grow: 1; display: flex; flex-direction: column; height: auto;}.ft-reg-controls {flex-grow: 0; padding-left: 5px;}.ft-reg-bubble-close-icon {font-size: 16px;}.ft-reg-message {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; padding-bottom: 5px; margin-bottom: 5px; border-bottom: 1px solid #dadce0;}.ft-reg-message:last-of-type {border-bottom: none;}.ft-reg-message-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ft-display-none {display: none;}</style><toolbar id="ft-floating-toolbar" class="ft-container ft-hidden"><div class="ft-menu"><div class="ft-button-holder"></div><div class="ft-separator ft-collapsible ft-collapsed"><span></span></div><div class="ft-bottom-button-holder"></div><div class="ft-expand-toggle-container"><button class="ft-expand-toggle ft-styless-button" aria-controls="ft-floating-toolbar" aria-label="' +
            js(b) + '"><span class="google-symbols ft-expand-icon" aria-hidden="true">expand_more</span></button></div></div><div id="ft-reg-bubble" class="ft-reg-bubble ft-collapsed ft-no-messages"><div class="ft-reg-bubble-content"><div class="ft-reg-message-holder"></div><div class="ft-reg-controls"><button class="ft-reg-bubble-close ft-styless-button" aria-controls="ft-reg-bubble" aria-label="' + js(c) + '"><span class="google-symbols ft-reg-bubble-close-icon" aria-hidden="true">close</span></button></div></div></div></toolbar><span inert class="ft-symbol-font-load-test"><span class="ft-symbol-reference google-symbols" aria-hidden="true">keyboard_double_arrow_right</span><span class="ft-text-reference" aria-hidden="true">keyboard_double_arrow_right</span></span>')
    }

    function Dy(a) {
        const b = a.googleIconName,
            c = a.backgroundColorCss,
            d = a.iconColorCss;
        return fs('<div class="ft-button ft-collapsible ft-collapsed ft-last-button"><button class="ft-styless-button" aria-label="' + js(a.ariaLabel) + '" style="background-color: ' + js(X(c)) + '"><span class="ft-highlighter"></span><span class="google-symbols" style="color: ' + js(X(d)) + '" aria-hidden="true">' + es(b) + '</span></button><span class="ft-button-corner-info"></span></div>')
    };
    const Ey = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500,700"];

    function Fy(a, b) {
        a = new Gy(a, b, Hy(a, b));
        a.L();
        return a
    }

    function Iy() {
        var {
            mc: a
        } = {
            mc: 2
        };
        return 1 < a ? 50 : 120
    }

    function Jy(a, b, c) {
        0 === Ky(a) && b.classList.remove("ft-collapsed");
        Ly(b, c);
        Wo(a.win);
        b.classList.remove("ft-collapsed");
        My(a);
        return () => void Ny(a, b, c)
    }

    function Oy(a) {
        0 === Py(a.g.ma.Gd).length ? (a.l.M ? .oj(), a.l.g(null), a.g.ma.Ie.g(!1), a.g.ma.tg.g(!1), a.g.ma.Me.g(!1)) : (a.g.ma.Ie.g(!0), Qy(a))
    }

    function Ry(a, {
        Ah: b = 0,
        On: c = 0
    }) {
        b = Math.max(Py(a.g.Gb).length + b, 0);
        c = Math.max(Py(a.g.lb).length + c, 0);
        const d = b + c;
        let e = 50 * d;
        0 < b && 0 < c && (e += 11);
        e += 10 * Math.max(0, d - 1);
        d >= a.j.mc && (e += 60);
        1 < d && (e += 10);
        return e
    }

    function Ky(a) {
        const b = a.g.lb;
        return Py(a.g.Gb).length + Py(b).length
    }

    function My(a) {
        const b = a.g.lb,
            c = a.g.separator;
        0 < Py(a.g.Gb).length && 0 < Py(b).length ? c.classList.remove("ft-collapsed") : c.classList.add("ft-collapsed");
        Ky(a) >= a.j.mc ? a.g.sg.g(!0) : a.g.sg.g(!1);
        1 < Ky(a) ? a.g.mg.g(!0) : a.g.mg.g(!1);
        0 < Ky(a) ? a.g.isVisible.g(!0) : a.g.isVisible.g(!1);
        Sy(a);
        Ty(a)
    }

    function Ny(a, b, c) {
        b.classList.contains("ft-removing") || (b.classList.add("ft-removing"), b.classList.add("ft-collapsed"), My(a), a.win.setTimeout(() => {
            c.removeChild(b)
        }, 750))
    }

    function Sy(a) {
        const b = Py(a.g.Gb).concat(Py(a.g.lb));
        b.forEach(c => {
            c.classList.remove("ft-last-button")
        });
        Ky(a) >= a.j.mc || b[b.length - 1] ? .classList.add("ft-last-button")
    }

    function Ty(a) {
        const b = Py(a.g.Gb).concat(Py(a.g.lb)).filter(c => !c.classList.contains("ft-reg-button"));
        a.F.g(0 < b.length)
    }

    function Uy(a) {
        Jo(a.g.ma.Gd.children, b => {
            const c = a.g.ma.Od;
            Ny(a, b, a.g.ma.Gd);
            const d = c.get(b);
            c.delete(b);
            d ? .isDismissed.g(!0)
        });
        Oy(a)
    }

    function Qy(a) {
        if (!a.l.M) {
            var b = Vy(a.win, {
                googleIconName: "verified_user",
                ariaLabel: O(a.j.La, 2),
                orderingIndex: 0,
                onClick: () => {
                    a.g.ma.tg.g(!a.g.ma.isVisible.M);
                    for (const [, c] of a.g.ma.Od) c.wg = !0;
                    a.g.ma.Me.g(!1)
                },
                backgroundColorCss: "#fff"
            });
            b.Yc.classList.add("ft-reg-button");
            Jy(a, b.Yc, a.g.lb);
            kp(b.Pi, a.g.ma.isVisible);
            a.l.g({
                Sn: b,
                oj: () => void Ny(a, b.Yc, a.g.lb)
            })
        }
    }

    function Wy(a) {
        var b = a.g.ma.Me,
            c = b.g;
        a: {
            for ([, d] of a.g.ma.Od)
                if (a = d, a.showUnlessUserInControl && !a.wg) {
                    var d = !0;
                    break a
                }
            d = !1
        }
        c.call(b, d)
    }

    function Xy(a) {
        a.g.ma.Wh.listen(() => {
            Uy(a)
        })
    }
    var Gy = class extends T {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.j = b;
            this.g = c;
            this.l = new V(null);
            this.F = new V(!1)
        }
        addButton(a) {
            a = Vy(this.win, a);
            return Jy(this, a.Yc, this.g.Gb)
        }
        addRegulatoryMessage(a) {
            const b = this.g.ma.Gd,
                c = Yy(this.win, a);
            Ly(c.Bg, b);
            this.g.ma.Od.set(c.Bg, c);
            Oy(this);
            return {
                showUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !0;
                    Wy(this)
                },
                hideUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !1;
                    Wy(this)
                },
                isDismissed: mp(c.isDismissed)
            }
        }
        H() {
            return fp(this.l.map(a => null != a))
        }
        C() {
            return fp(this.F)
        }
        A() {
            return [this.g.container]
        }
        i() {
            const a =
                this.g.eb.Ta;
            a.parentNode ? .removeChild(a);
            super.i()
        }
        L() {
            Vp(this.win, Ey);
            kp(this.g.Fj, this.j.Hc);
            this.win.document.body.appendChild(this.g.eb.Ta);
            Xy(this)
        }
    };

    function Hy(a, b) {
        const c = Rv(a),
            d = c.shadowRoot;
        d.appendChild(se(new ee(a.document), as(Cy({
            si: O(b.La, 1),
            Xh: O(b.La, 3),
            Qh: 50,
            zj: 11,
            Rh: 10,
            Ph: 5
        }))));
        const e = lx("ft-container", d),
            f = lx("ft-expand-toggle", d),
            g = lx("ft-expand-toggle-container", d),
            h = new V(null);
        h.i(p => {
            e.style.zIndex = String(p ? ? 2147483647)
        });
        const k = new V(!0);
        W(k, !0, () => {
            e.classList.remove("ft-collapsed");
            f.setAttribute("aria-expanded", "true")
        });
        W(k, !1, () => {
            e.classList.add("ft-collapsed");
            f.setAttribute("aria-expanded", "false")
        });
        f.addEventListener("click",
            () => {
                k.g(!k.M)
            });
        const l = new V(!1);
        W(l, !0, () => {
            g.classList.remove("ft-collapsed");
            e.classList.add("ft-toolbar-collapsible")
        });
        W(l, !1, () => {
            g.classList.add("ft-collapsed");
            e.classList.remove("ft-toolbar-collapsible");
            k.g(!0)
        });
        const m = new V(!1);
        W(m, !0, () => {
            e.classList.add("ft-multiple-buttons")
        });
        W(m, !1, () => {
            e.classList.remove("ft-multiple-buttons")
        });
        b.position.i(p => {
            if (p) {
                p.Kf(e.style);
                p = p.jg();
                switch (p) {
                    case 0:
                        e.classList.add("ft-left-pos");
                        e.classList.remove("ft-right-pos");
                        break;
                    case 1:
                        e.classList.add("ft-right-pos");
                        e.classList.remove("ft-left-pos");
                        break;
                    default:
                        throw Error(`Unknown HorizontalAnchoring: ${p}`);
                }
                Wo(a)
            }
        });
        const n = new V(!1);
        b = ep(Zy(a, d), n, b.position.map(p => null !== p));
        W(b, !0, () => {
            e.classList.remove("ft-hidden")
        });
        W(b, !1, () => {
            e.classList.add("ft-hidden")
        });
        b = $y(a, lx("ft-reg-bubble", d));
        return {
            container: e,
            Gb: lx("ft-button-holder", d),
            lb: lx("ft-bottom-button-holder", d),
            separator: lx("ft-separator", d),
            eb: c,
            Fj: h,
            Vn: k,
            sg: l,
            mg: m,
            isVisible: n,
            ma: b
        }
    }

    function $y(a, b) {
        const c = new V(!1),
            d = new V(!1),
            e = gp(c, d);
        W(e, !0, () => {
            b.classList.remove("ft-collapsed")
        });
        W(e, !1, () => {
            b.classList.add("ft-collapsed")
        });
        const f = new V(!1);
        W(f, !0, () => {
            b.classList.remove("ft-no-messages")
        });
        W(f, !1, () => {
            b.classList.add("ft-no-messages")
        });
        const g = lx("ft-reg-bubble-close", b),
            h = new qp;
        g.addEventListener("click", () => {
            pp(h)
        });
        const k = lx("ft-reg-message-holder", b);
        Op(Lp(a, k)).i(() => {
            b.style.height = `${k.offsetHeight}px`
        });
        return {
            Gd: k,
            tg: c,
            Me: d,
            isVisible: e,
            Ie: f,
            Od: new Map,
            Wh: np(h)
        }
    }

    function Vy(a, b) {
        const c = se(new ee(a.document), as(Dy({
            googleIconName: b.googleIconName,
            ariaLabel: b.ariaLabel,
            backgroundColorCss: b.backgroundColorCss || "#e2eaf6",
            iconColorCss: b.iconColorCss || "#3c4043"
        })));
        if (void 0 !== b.cornerNumber) {
            const d = Rd(Math.round(b.cornerNumber), 0, 99);
            lx("ft-button-corner-info", c).appendChild(a.document.createTextNode(String(d)));
            c.classList.add("ft-show-corner-info")
        }
        c.orderingIndex = b.orderingIndex;
        b.onClick && kx("BUTTON", c).addEventListener("click", b.onClick);
        a = new V(!1);
        W(a, !0, () => {
            c.classList.add("ft-highlighted")
        });
        W(a, !1, () => {
            c.classList.remove("ft-highlighted")
        });
        return {
            Yc: c,
            Pi: a
        }
    }

    function Yy(a, b) {
        a = new ee(a.document);
        var c = fs('<div class="ft-reg-message"><button class="ft-reg-message-button"></button><div class="ft-reg-message-info"></div></div>');
        a = se(a, as(c));
        c = lx("ft-reg-message-button", a);
        b.regulatoryMessage.actionButton ? (c.appendChild(b.regulatoryMessage.actionButton.buttonText), c.addEventListener("click", b.regulatoryMessage.actionButton.onClick)) : c.classList.add("ft-display-none");
        c = lx("ft-reg-message-info", a);
        b.regulatoryMessage.informationText ? c.appendChild(b.regulatoryMessage.informationText) :
            c.classList.add("ft-display-none");
        a.orderingIndex = b.orderingIndex;
        return {
            Bg: a,
            showUnlessUserInControl: !1,
            wg: !1,
            isDismissed: new V(!1)
        }
    }

    function Ly(a, b) {
        a: {
            var c = Array.from(b.children);
            for (let d = 0; d < c.length; ++d)
                if (c[d].orderingIndex >= a.orderingIndex) {
                    c = d;
                    break a
                }
            c = c.length
        }
        b.insertBefore(a, b.childNodes[c] || null)
    }

    function Py(a) {
        return Array.from(a.children).filter(b => !b.classList.contains("ft-removing"))
    }

    function Zy(a, b) {
        const c = new V(!1),
            d = lx("ft-symbol-font-load-test", b);
        b = lx("ft-symbol-reference", d);
        const e = lx("ft-text-reference", d),
            f = Lp(a, b);
        ip(Op(f).map(g => 0 < g.width && g.width < e.offsetWidth / 2), !0, () => {
            c.g(!0);
            d.parentNode ? .removeChild(d);
            f.la()
        });
        return c
    };

    function az(a) {
        const b = new qp,
            c = Bp(a, 2500, () => void pp(b));
        return new bz(a, () => void cz(a, () => void c()), np(b))
    }

    function dz(a) {
        const b = new MutationObserver(() => {
            a.g()
        });
        b.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class", "style"]
        });
        Zo(a, () => void b.disconnect())
    }

    function ez(a) {
        a.win.addEventListener("resize", a.g);
        Zo(a, () => void a.win.removeEventListener("resize", a.g))
    }
    var bz = class extends T {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.g = b;
            this.l = c;
            this.j = !1
        }
    };

    function cz(a, b) {
        b();
        a.setTimeout(b, 1500)
    };

    function fz(a) {
        return a.g[a.g.length - 1]
    }
    var hz = class {
        constructor() {
            this.j = gz;
            this.g = [];
            this.i = new Set
        }
        add(a) {
            if (this.i.has(a)) return !1;
            const b = jb(this.g, a, this.j);
            this.g.splice(0 <= b ? b : -b - 1, 0, a);
            this.i.add(a);
            return !0
        }
        first() {
            return this.g[0]
        }
        has(a) {
            return this.i.has(a)
        }
        delete(a) {
            eb(this.g, b => b === a);
            return this.i.delete(a)
        }
        clear() {
            this.i.clear();
            return this.g.splice(0, this.g.length)
        }
        size() {
            return this.g.length
        }
    };

    function iz(a) {
        var b = a.Gc.M;
        let c;
        for (; a.j.bi() > b && (c = a.i.first());) {
            var d = a,
                e = c;
            jz(d, e);
            d.g.add(e)
        }
        for (;
            (d = fz(a.g)) && a.j.Ei() <= b;) kz(a, d);
        for (;
            (d = fz(a.g)) && (c = a.i.first()) && d.priority > c.priority;) b = a, e = c, jz(b, e), b.g.add(e), kz(a, d)
    }

    function kz(a, b) {
        a.g.delete(b);
        a.i.add(b) && (b.uf = a.j.addButton(b.buttonSpec));
        b.isInToolbar.g(!0)
    }

    function jz(a, b) {
        b.uf && b.uf();
        b.uf = void 0;
        a.i.delete(b);
        b.isInToolbar.g(!1)
    }
    var lz = class {
        constructor(a, b) {
            this.Gc = a;
            this.j = b;
            this.g = new hz;
            this.i = new hz;
            this.l = 0;
            this.Gc.listen(() => void iz(this))
        }
        addButton(a) {
            const b = {
                buttonSpec: a.buttonSpec,
                priority: a.priority,
                Af: this.l++,
                isInToolbar: new V(!1)
            };
            this.g.add(b);
            iz(this);
            return {
                isInToolbar: mp(fp(b.isInToolbar)),
                removeCallback: () => {
                    jz(this, b);
                    this.g.delete(b);
                    iz(this)
                }
            }
        }
    };

    function gz(a, b) {
        return a.priority === b.priority ? b.Af - a.Af : a.priority - b.priority
    };

    function mz(a) {
        a = new nz(a);
        a.L();
        return a
    }

    function oz(a) {
        if (!ix(a.win)) {
            if (a.j.M) {
                const b = Eo(a.win);
                if (b > a.g + 100 || b < a.g - 100) a.j.g(!1), a.g = yo(a.win)
            }
            a.l && a.win.clearTimeout(a.l);
            a.l = a.win.setTimeout(() => void pz(a), 200)
        }
    }

    function pz(a) {
        if (!ix(a.win)) {
            var b = yo(a.win);
            a.g && a.g > b && (a.g = b);
            b = Eo(a.win);
            b >= a.g - 100 && (a.g = Math.max(a.g, b), a.j.g(!0))
        }
    }
    var nz = class extends T {
        constructor(a) {
            super();
            this.win = a;
            this.j = new V(!1);
            this.g = 0;
            this.l = null;
            this.A = () => void oz(this)
        }
        L() {
            this.win.addEventListener("scroll", this.A);
            this.g = yo(this.win);
            pz(this)
        }
        i() {
            this.win.removeEventListener("scroll", this.A);
            this.j.g(!1);
            super.i()
        }
    };

    function qz(a) {
        if (!a.g) {
            const b = mz(a.win);
            a.g = fp(b.j);
            Yo(a, b)
        }
        return a.g
    }

    function rz(a, b) {
        const c = qz(a),
            d = a.j.addRegulatoryMessage(b.messageSpec),
            e = W(c, !0, () => void d.showUnlessUserInControl()),
            f = W(c, !1, () => void d.hideUnlessUserInControl());
        W(cp(d.isDismissed), !0, () => {
            e();
            f()
        })
    }
    var sz = class extends T {
        constructor(a, b) {
            super();
            this.win = a;
            this.j = b;
            this.g = null
        }
        addRegulatoryMessage(a) {
            ip(qz(this), !0, () => void rz(this, a))
        }
    };

    function tz(a, b) {
        a.googFloatingToolbarManager || (a.googFloatingToolbarManager = new uz(a, b));
        return a.googFloatingToolbarManager
    }

    function vz(a) {
        a.g || (a.g = wz(a.win, a.Kb, a.Hc), Yo(a, a.g.Lb), Yo(a, a.g.Wg), xz(a), yz(a, a.g.Lb));
        return a.g
    }

    function zz(a) {
        var b = [];
        a.g ? .Lb ? .C().A() ? (b.push(() => Az(a)), b.push(() => Bz(a))) : (b.push(() => Bz(a)), b.push(() => Az(a)));
        a.g ? .Lb ? .H() ? .A() && b.push(() => {
            const c = S(a.win);
            return {
                position: yy({
                    ca: Math.floor(c / 3),
                    ta: 10
                }),
                Gc: 0
            }
        });
        for (const c of b)
            if (b = c()) return b;
        return null
    }

    function xz(a) {
        null === a.Hc.M && a.g ? .position.g(zz(a))
    }

    function yz(a, b) {
        const c = az(a.win);
        c.j || (dz(c), ez(c), c.j = !0);
        c.l.listen(() => void xz(a));
        Yo(a, c);
        b.H().listen(() => void xz(a));
        b.C().listen(() => void xz(a));
        a.Hc.listen(() => void xz(a))
    }

    function Az(a) {
        var b = a.win;
        const c = S(a.win);
        return uy(b, {
            cc: Ay({
                ca: 50,
                Fa: 10
            }),
            Qe: Math.floor(c / 3),
            Bb: 60,
            Te: Iy(),
            Fd: Math.floor(c / 2),
            mb: 20
        }, [...(a.g ? .Lb.A() ? ? []), a.win.document.body]).ie
    }

    function Bz(a) {
        var b = a.win;
        const c = S(a.win);
        return uy(b, {
            cc: yy({
                ca: 50,
                ta: 10
            }),
            Qe: Math.floor(c / 3),
            Bb: 60,
            Te: Iy(),
            Fd: Math.floor(c / 2),
            mb: 40
        }, [...(a.g ? .Lb.A() ? ? []), a.win.document.body]).ie
    }
    class uz extends T {
        constructor(a, b) {
            super();
            this.win = a;
            this.Kb = b;
            this.g = null;
            this.Hc = Cz(this.win, this)
        }
        addButton(a) {
            return vz(this).aj.addButton(a)
        }
        addRegulatoryMessage(a) {
            vz(this).Wg.addRegulatoryMessage(a)
        }
    }

    function wz(a, b, c) {
        const d = new V(null),
            e = Fy(a, {
                mc: 2,
                position: d.map(f => f ? .position ? ? null),
                La: b,
                Hc: c
            });
        b = new lz(d.map(f => f ? .Gc || 0), {
            addButton: f => e.addButton(f),
            bi: () => Ry(e, {}),
            Ei: () => Ry(e, {
                Ah: 1
            })
        });
        a = new sz(a, {
            addRegulatoryMessage: f => e.addRegulatoryMessage(f)
        });
        return {
            Lb: e,
            position: d,
            aj: b,
            Wg: a
        }
    }

    function Cz(a, b) {
        const c = new hw(a),
            d = new V(null),
            e = f => void d.g(f);
        Zo(b, () => {
            gw(c, e)
        });
        c.g.maxZIndexListeners.push(e);
        d.g(fw(c));
        return d
    };

    function Dz(a) {
        return tz(a.win, a.La)
    }
    var Ez = class {
        constructor(a, b) {
            this.win = a;
            this.La = b
        }
    };

    function Fz(a) {
        if (a.H) {
            var b = Dz(new Ez(a.g, a.H)).addButton({
                buttonSpec: {
                    googleIconName: "search",
                    ariaLabel: a.Ha,
                    orderingIndex: 0,
                    onClick: () => {
                        Gz(a)
                    }
                },
                priority: 0
            });
            ip(cp(b.isInToolbar), !0, () => {
                Hz(a)
            });
            a.g.setTimeout(() => {
                b.isInToolbar.getValue() || Tr(a.j, "pfmsb")
            }, 5E3);
            Iz(a)
        } else Jz(a)
    }

    function Jz(a) {
        var b = Kz(a);
        b = Wv(new Zv(a.g), b);
        b ? .className.startsWith("adsbygoogle") ? Tr(a.j, "pfeaa") : b ? Tr(a.j, "pfeofe") : (a.Z.appendChild(a.B.Ta), a.B.shadowRoot.appendChild(ke(document, (() => {
            if (a.l) {
                var c = Lz(a),
                    d = {
                        backgroundColor: c.backgroundColor,
                        Ob: c.Ob,
                        offsetTop: c.Kg,
                        Xe: c.Jg,
                        zIndex: 2147483643
                    };
                c = d.zIndex;
                var e = d.bj,
                    f = d.offsetTop,
                    g = d.Xe,
                    h = d.backgroundColor;
                d = d.Ob;
                e = void 0 === e ? 16 : e;
                g = void 0 === g ? 2 : g;
                d = void 0 === d ? "white" : d;
                h = "<style>.autoprose-search-button {background: " + X(void 0 === h ? "#000" : h) + "; border-radius: ";
                h += X(24) + "px;" + (f ? "top: " + X(f) + "%;" : "bottom: " + X(g) + "%;") + "border-width: 0; box-shadow: 0 0 10px rgba(0, 0, 0, 0.35); cursor: pointer; height: " + X(48) + "px; position: fixed; right: " + X(e) + "px; width: 48px; z-index: " + X(c) + ';}.autoprose-search-icon {position: relative;}</style><button class="autoprose-search-button"><div class="autoprose-search-icon">' + As(d) + "</div></button>";
                c = fs(h);
                return as(c)
            }
            c = Lz(a);
            var k = {
                yj: c.xj,
                backgroundColor: c.backgroundColor,
                Ob: c.Ob,
                offsetTop: c.Kg,
                Xe: c.Jg,
                zIndex: 2147483643
            };
            c = k.yj;
            f = k.zIndex;
            g = k.bj;
            h = k.offsetTop;
            d = k.Xe;
            e = k.backgroundColor;
            k = k.Ob;
            g = void 0 === g ? 16 : g;
            d = void 0 === d ? 2 : d;
            k = void 0 === k ? "white" : k;
            e = "<style>.autoprose-search-button {align-items: center; background: " + X(void 0 === e ? "#000" : e) + "; border-radius: ";
            e += X(24) + "px; border-width: 0;" + (h ? "top: " + X(h) + "%;" : "bottom: " + X(d) + "%;") + "box-shadow: 0 0 10px rgba(0, 0, 0, 0.35); cursor: pointer; display: flex; height: " + X(48) + "px; line-height: 1; padding: 0 20px; position: fixed; right: " + X(g) + "px; z-index: " + X(f) +
                ";}.autoprose-search-text {color: " + X(k) + '; font-family: Google Sans, Roboto, sans-serif; font-size: 16px; margin: 10px; user-select: none;}</style><button class="autoprose-search-button"><div class="autoprose-search-icon">' + As(k) + '</div><div class="autoprose-search-text">' + es(c) + "</div></button>";
            c = fs(e);
            return as(c)
        })())), (b = Mz(a)) ? (Hz(a), Sb(b, "click", () => {
            Gz(a)
        })) : Tr(a.j, "pfmsb"), Iz(a))
    }

    function Gz(a) {
        a.I || (Ev(1139, () => a.G.L(), a.g), a.I = !0);
        Rr(a.j, "click", {});
        Nz(a)
    }

    function Hz(a) {
        Rr(a.j, "place", {
            sts: "ok"
        });
        Oz(a)
    }

    function Iz(a) {
        a.l && jp(a.C.isVisible(), !1, () => {
            a.i.contentDocument.activeElement.blur()
        })
    }

    function Kz(a) {
        let b;
        b = a.l ? 50 : 150;
        var c = a.g.innerHeight;
        const d = a.F ? 20 : 2;
        c = 2 === a.A ? .g() ? (100 - d) / 100 * c : .2 * c;
        return {
            Si: a.g.innerWidth - 16 - b,
            Cj: c,
            width: b,
            height: 50
        }
    }

    function Lz(a) {
        const b = a.A ? .j() || void 0,
            c = a.A ? .l() || void 0;
        let d, e;
        2 === a.A ? .g() ? e = a.F ? 20 : 2 : d = 20;
        return {
            backgroundColor: b,
            Ob: c,
            Kg: d,
            Jg: e,
            xj: a.va
        }
    }

    function Mz(a) {
        const b = a.B.shadowRoot.querySelectorAll(".autoprose-search-button")[0];
        return b ? b : a.B.shadowRoot.querySelectorAll(".autoprose-searchbox")[0]
    }

    function Oz(a) {
        Sb(a.g.top, "message", b => {
            b.data && "init" === b.data.action && "AutoProseVariant" === b.data.adChannel && (b = Pz(a), Ks(a.G, b), Qz(a), Rz(a))
        })
    }

    function Nz(a) {
        Qz(a);
        a.C.show();
        Rz(a)
    }

    function Pz(a) {
        if (a = a.i.contentDocument ? .getElementsByTagName("input")[0]) return a;
        console.warn("searchbox missing");
        return null
    }

    function Qz(a) {
        const b = new ResizeObserver(async d => {
                a.i.height = 0;
                await new Promise(e => a.g.requestAnimationFrame(e));
                a.i.height = d[0].target.scrollHeight
            }),
            c = () => {
                const d = a.i.contentDocument ? .documentElement;
                d ? b.observe(d) : (console.warn("iframe body missing"), setTimeout(c, 1E3))
            };
        c()
    }

    function Rz(a) {
        a.C.isVisible() && Pz(a) ? .focus({
            preventScroll: !0
        })
    }
    var Sz = class {
        constructor(a, b, c, d, e, f, g, h) {
            this.g = a;
            this.l = (this.ea = h) ? 500 > this.g.innerWidth : 2 === of ();
            this.F = !!e ? .C();
            this.Ua = !!e ? .G();
            this.I = !1;
            this.Z = c;
            this.B = Rv(this.g);
            this.j = d;
            c = e ? .B();
            this.na = c ? .g() || "en";
            this.Qa = c ? .j() || "Search results from ${website}";
            this.va = c ? .A() || "Search";
            this.Ha = c ? .l() || "Open AutoSearch";
            this.T = b.replace("ca", "partner");
            this.O = new ee(window.document);
            this.i = re(this.O, "IFRAME");
            this.G = new Ls(this.i, e ? .A() || "", "auto-prose", this.T, "AutoProseVariant", a.location, this.na, this.Qa,
                f, !1, !0, !0);
            a = this.i;
            this.C = this.l ? ny(this.g, a, {
                Ze: .95,
                Fe: .95,
                zIndex: 2147483645,
                qb: !0,
                kd: !0,
                tb: !1,
                Ja: !0
            }) : xx(this.g, a, {
                vc: "min(65vw, 768px)",
                kc: "",
                uc: !1,
                zIndex: 2147483645,
                qb: !0,
                kd: !0,
                tb: !1,
                Qd: !1,
                Ja: !0
            });
            this.A = this.l ? e ? .l() : e ? .j();
            this.H = g
        }
        L() {
            this.Ua ? Fz(this) : Jz(this)
        }
    };

    function Tz(a, b) {
        for (var c = 0; c < b.length; c++) a.xa(b[c]);
        return a
    }

    function Uz(a, b) {
        a.j = a.j ? a.j : b;
        return a
    }
    class Vz {
        constructor(a) {
            this.C = {};
            this.C.c = a;
            this.A = [];
            this.j = null;
            this.B = [];
            this.F = 0
        }
        dc(a) {
            this.C.wpc = a;
            return this
        }
        xa(a) {
            for (var b = 0; b < this.A.length; b++)
                if (this.A[b] == a) return this;
            this.A.push(a);
            return this
        }
        l(a) {
            var b = Sc(this.C);
            0 < this.F && (b.t = this.F);
            b.err = this.A.join();
            b.warn = this.B.join();
            this.j && (b.excp_n = this.j.name, b.excp_m = this.j.message && this.j.message.substring(0, 512), b.excp_s = this.j.stack && rl(this.j.stack, ""));
            b.w = 0 < a.innerWidth ? a.innerWidth : null;
            b.h = 0 < a.innerHeight ? a.innerHeight : null;
            return b
        }
    };
    let Wz, Xz;
    const Yz = new jl(r);
    ((a, b = !0) => {
        Wz = a || new ho;
        "number" !== typeof r.google_srt && (r.google_srt = Math.random());
        go(Wz, r.google_srt);
        Xz = new tl(Wz, b, Yz);
        Xz.l(!0);
        "complete" == r.document.readyState ? r.google_measure_js_timing || hl(Yz) : Yz.g && Sb(r, "load", () => {
            r.google_measure_js_timing || hl(Yz)
        })
    })();
    var Zz = (a, b) => Xz.Kc(a, b),
        $z = (a, b) => Xz.Oa(a, b),
        aA = (a, b, c) => {
            const d = fo();
            !b.eid && d.length && (b.eid = d.toString());
            sl(Wz, a, b, !0, c)
        },
        bA = (a, b) => Xz.Ba(a, b, void 0, void 0),
        cA = (a, b, c) => {
            Xz.Ca(a, b, c)
        };

    function Sr(a, b, c) {
        let d = b.Pa;
        b.Wa && v(vt) && (d = 1, "r" in c && (c.r += "F"));
        0 >= d || (!b.Sa || "pvc" in c || (c.pvc = Af(a.g)), aA(b.Va, c, d))
    }

    function dA(a, b, c) {
        c = c.l(a.g);
        b.Sa && (c.pvc = Af(a.g));
        0 <= b.Pa && (c.r = b.Pa, Sr(a, b, c))
    }
    var eA = class {
        constructor(a) {
            this.g = a
        }
    };

    function fA(a) {
        const b = a.i ? .g() ? .j() || 0,
            c = a.j.document,
            d = c.createElement("div");
        d.classList.add("auto-prose-wrapper");
        c.body.appendChild(d);
        Ev(1138, () => (new Sz(a.j, a.A, d, a.l, a.i, b, C(a.g, hr, 33) ? .g() ? .i() ? ? null, C(a.g, Xq, 25) ? .g() || !1)).L(), a.j)
    }
    async function gA(a) {
        await new Promise(b => {
            setTimeout(() => {
                b(fA(a))
            })
        })
    }
    var hA = class {
        constructor(a, b, c, d) {
            this.j = a;
            this.g = c;
            this.i = C(this.g, cr, 31);
            this.l = new Ur(a, b, this.i || new cr);
            this.A = d
        }
    };

    function iA(a, b) {
        Sr(a.i, Nr, { ...b,
            evt: "place",
            vh: S(a.win),
            eid: a.g.g() ? .g() || 0,
            hl: a.g.j() ? .g() || ""
        })
    }

    function jA(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && rl(c.stack, "") || "");
        iA(a, b)
    }
    var kA = class {
        constructor(a, b, c) {
            this.win = a;
            this.i = b;
            this.g = c
        }
    };
    var lA = class {
        constructor(a) {
            this.g = a
        }
        Ma(a) {
            const b = a.document.createElement("div");
            A(b, Ov(a));
            A(b, {
                width: "100%",
                "max-width": "1000px",
                margin: "auto"
            });
            b.appendChild(this.g);
            const c = a.document.createElement("div");
            A(c, Ov(a));
            A(c, {
                width: "100%",
                "text-align": "center",
                display: "block",
                padding: "5px 5px 2px",
                "box-sizing": "border-box",
                "background-color": "#FFF"
            });
            c.appendChild(b);
            return c
        }
    };
    var nA = (a, b, c) => {
        if (!b || !c) return !1;
        var d = b.parentElement;
        const e = c.parentElement;
        if (!d || !e || d != e) return !1;
        d = 0;
        for (b = b.nextSibling; 10 > d && b;) {
            if (b == c) return !0;
            if (mA(a, b)) break;
            b = b.nextSibling;
            d++
        }
        return !1
    };
    const mA = (a, b) => {
        if (3 == b.nodeType) return 3 == b.nodeType ? (b = b.data, a = jc(b, "&") ? Zd(b, a.document) : b, a = /\S/.test(a)) : a = !1, a;
        if (1 == b.nodeType) {
            var c = a.getComputedStyle(b);
            if ("0" == c.opacity || "none" == c.display || "hidden" == c.visibility) return !1;
            if ((c = b.tagName) && Ro.contains(c.toUpperCase())) return !0;
            b = b.childNodes;
            for (c = 0; c < b.length; c++)
                if (mA(a, b[c])) return !0
        }
        return !1
    };
    var oA = a => {
        if (460 <= a) return a = Math.min(a, 1200), Math.ceil(800 > a ? a / 4 : 200);
        a = Math.min(a, 600);
        return 420 >= a ? Math.ceil(a / 1.2) : Math.ceil(a / 1.91) + 130
    };
    const pA = class {
        constructor() {
            this.g = {
                clearBoth: !0
            }
        }
        i(a, b, c, d) {
            return tv(d.document, a, null, null, this.g, b)
        }
        j(a) {
            return oA(Math.min(a.screen.width || 0, a.screen.height || 0))
        }
    };
    const qA = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            return tv(d.document, a, null, null, this.g, b)
        }
        j() {
            return null
        }
    };
    class rA {
        constructor(a) {
            this.i = a
        }
        g(a) {
            a = Math.floor(a.yc());
            const b = oA(a);
            return new Bq(["ap_container"], {
                google_reactive_ad_format: 27,
                google_responsive_auto_format: 16,
                google_max_num_ads: 1,
                google_ad_type: this.i,
                google_ad_format: a + "x" + b,
                google_ad_width: a,
                google_ad_height: b
            })
        }
    };
    const sA = class {
        constructor(a, b) {
            this.l = a;
            this.j = b
        }
        i() {
            return this.l
        }
        g() {
            return this.j
        }
    };
    const tA = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            var e = 0 < D(this.g, mr, 9).length ? D(this.g, mr, 9)[0] : null,
                f = Kv(C(this.g, nr, 3), e);
            if (!e) return null;
            if (e = I(e, 1)) {
                d = d.document;
                var g = c.tagName;
                c = re(new ee(d), g);
                c.style.clear = f.clearBoth ? "both" : "none";
                "A" == g && (c.style.display = "block");
                c.style.padding = "0px";
                c.style.margin = "0px";
                f.Jd && sv(c.style, f.Jd);
                d = re(new ee(d), "INS");
                f.jc && sv(d.style, f.jc);
                c.appendChild(d);
                f = {
                    ob: c,
                    wa: d
                };
                f.wa.setAttribute("data-ad-type", "text");
                f.wa.setAttribute("data-native-settings-key",
                    e);
                vv(f, a, null, b);
                a = f
            } else a = null;
            return a
        }
        j() {
            var a = 0 < D(this.g, mr, 9).length ? D(this.g, mr, 9)[0] : null;
            if (!a) return null;
            a = D(a, lr, 3);
            for (var b = 0; b < a.length; b++) {
                var c = a[b];
                if ("height" == I(c, 1) && 0 < parseInt(I(c, 2), 10)) return parseInt(I(c, 2), 10)
            }
            return null
        }
    };
    const uA = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            if (!this.g) return null;
            const e = this.g.google_ad_format || null,
                f = this.g.google_ad_slot || null;
            if (c = c.style) {
                var g = [];
                for (let h = 0; h < c.length; h++) {
                    const k = c.item(h);
                    "width" !== k && "height" !== k && g.push({
                        property: k,
                        value: c.getPropertyValue(k)
                    })
                }
                c = {
                    jc: g
                }
            } else c = {};
            a = tv(d.document, a, f, e, c, b);
            a.wa.setAttribute("data-pub-vars", JSON.stringify(this.g));
            return a
        }
        j() {
            return this.g ? parseInt(this.g.google_ad_height, 10) || null : null
        }
        zc() {
            return this.g
        }
    };
    class vA {
        constructor(a) {
            this.i = a
        }
        g() {
            return new Bq([], {
                google_ad_type: this.i,
                google_reactive_ad_format: 26,
                google_ad_format: "fluid"
            })
        }
    };
    const wA = class {
        constructor(a, b) {
            this.l = a;
            this.j = b
        }
        g() {
            return this.j
        }
        i(a) {
            a = this.l.query(a.document);
            return 0 < a.length ? a[0] : null
        }
    };

    function xA(a, b, c) {
        const d = [];
        for (let q = 0; q < a.length; q++) {
            var e = a[q];
            var f = q,
                g = b,
                h = c,
                k = e.ia();
            if (k) {
                var l = Gv(k);
                if (l) {
                    var m = L(e, 2);
                    m = Lv[m];
                    var n = void 0 === m ? null : m;
                    if (null === n) e = null;
                    else {
                        m = (m = C(e, nr, 3)) ? $h(m, 3) : null;
                        l = new wA(l, n);
                        n = ai(e, 10, eh, 2).slice(0);
                        null != ui(k, 5) && n.push(1);
                        var p = h ? h : {};
                        h = ui(e, 12);
                        k = Xh(e, zq, 4) ? C(e, zq, 4) : null;
                        1 == L(e, 8) ? (p = p.Lh || null, e = new yA(l, new qA(Kv(C(e, nr, 3), null)), p, m, 0, n, k, g, f, h, e)) : e = 2 == L(e, 8) ? new yA(l, new tA(e), p.Mi || new vA("text"), m, 1, n, k, g, f, h, e) : null
                    }
                } else e = null
            } else e =
                null;
            null !== e && d.push(e)
        }
        return d
    }

    function zA(a) {
        return a.A
    }

    function AA(a) {
        return a.va
    }

    function BA(a) {
        return v(et) ? (a.O || (a.O = a.F.i(a.j)), a.O) : a.F.i(a.j)
    }

    function CA(a) {
        var b = a.H;
        a = a.j.document.createElement("div");
        v(et) ? a.className = "google-auto-placed-ad-placeholder" : a.className = "google-auto-placed";
        var c = a.style;
        c.textAlign = "center";
        c.width = "100%";
        c.height = "0px";
        c.clear = b ? "both" : "none";
        return a
    }

    function DA(a) {
        return a.C instanceof uA ? a.C.zc() : null
    }

    function EA(a, b, c) {
        Lo(a.I, b) || a.I.set(b, []);
        a.I.get(b).push(c)
    }

    function FA(a, b) {
        a.A = !0;
        v(et) && (a.i && fv(a.i), a.i = null);
        null != b && a.Z.push(b)
    }

    function GA(a) {
        return dv(a.j.document, a.H || !1)
    }

    function HA(a) {
        return a.C.j(a.j)
    }

    function IA(a, b = null, c = null) {
        return new yA(a.F, b || a.C, c || a.T, a.H, a.Qb, a.Cc, a.Sd, a.j, a.na, a.G, a.l, a.B, a.ea)
    }
    class yA {
        constructor(a, b, c, d, e, f, g, h, k, l = null, m = null, n = null, p = null) {
            this.F = a;
            this.C = b;
            this.T = c;
            this.H = d;
            this.Qb = e;
            this.Cc = f;
            this.Sd = g ? g : new zq;
            this.j = h;
            this.na = k;
            this.G = l;
            this.l = m;
            (a = !m) || (a = !(m.ia() && null != ui(m.ia(), 5)));
            this.va = !a;
            this.B = n;
            this.ea = p;
            this.Z = [];
            this.A = !1;
            this.I = new Po;
            this.O = this.i = null
        }
        da() {
            return this.j
        }
        g() {
            return this.F.g()
        }
    };

    function JA(a, b, c, d, e, f) {
        const g = yq();
        return new yA(new sA(c, e), new pA, new rA(a), !0, 2, [], g, d, null, null, null, b, f)
    }

    function KA(a, b, c, d, e) {
        const f = yq();
        return new yA(new sA(b, d), new qA({
            clearBoth: !0
        }), null, !0, 2, [], f, c, null, null, null, a, e)
    };
    var LA = class {
        constructor(a, b, c) {
            this.articleStructure = a;
            this.element = b;
            this.win = c
        }
        da() {
            return this.win
        }
        A(a) {
            return JA(a, this.articleStructure, this.element, this.win, 3, null)
        }
        j() {
            return KA(this.articleStructure, this.element, this.win, 3, null)
        }
    };
    const MA = {
        TABLE: {
            rc: new eq([1, 2])
        },
        THEAD: {
            rc: new eq([0, 3, 1, 2])
        },
        TBODY: {
            rc: new eq([0, 3, 1, 2])
        },
        TR: {
            rc: new eq([0, 3, 1, 2])
        },
        TD: {
            rc: new eq([0, 3])
        }
    };

    function NA(a, b, c, d) {
        const e = c.childNodes;
        c = c.querySelectorAll(b);
        b = [];
        for (const f of c) c = Ta(e, f), 0 > c || b.push(new OA(a, [f], c, f, 3, ne(f).trim(), d));
        return b
    }

    function PA(a, b, c) {
        let d = [];
        const e = [],
            f = b.childNodes,
            g = f.length;
        let h = 0,
            k = "";
        for (let n = 0; n < g; n++) {
            var l = f[n];
            if (1 == l.nodeType || 3 == l.nodeType) {
                if (1 != l.nodeType) var m = null;
                else "BR" == l.tagName ? m = l : (m = c.getComputedStyle(l).getPropertyValue("display"), m = "inline" == m || "inline-block" == m ? null : l);
                m ? (d.length && k && e.push(new OA(a, d, n - 1, m, 0, k, c)), d = [], h = n + 1, k = "") : (d.push(l), l = ne(l).trim(), k += l && k ? " " + l : l)
            }
        }
        d.length && k && e.push(new OA(a, d, h, b, 2, k, c));
        return e
    }

    function QA(a, b) {
        return a.g - b.g
    }
    class OA {
        constructor(a, b, c, d, e, f, g) {
            this.l = a;
            this.ed = b.slice(0);
            this.g = c;
            this.Wd = d;
            this.Xd = e;
            this.B = f;
            this.i = g
        }
        da() {
            return this.i
        }
        A(a) {
            return JA(a, this.l, this.Wd, this.i, this.Xd, this.g)
        }
        j() {
            return KA(this.l, this.Wd, this.i, this.Xd, this.g)
        }
    };

    function RA(a) {
        return fb(a.B ? PA(a.i, a.g, a.j) : [], a.A ? NA(a.i, a.A, a.g, a.j) : []).filter(b => {
            var c = b.Wd.tagName;
            c ? (c = MA[c.toUpperCase()], b = null != c && c.rc.contains(b.Xd)) : b = !1;
            return !b
        })
    }
    class SA {
        constructor(a, b, c) {
            this.g = a;
            this.A = b.dd;
            this.B = b.fg;
            this.i = b.articleStructure;
            this.j = c;
            this.l = b.If
        }
    };

    function TA(a, b) {
        if (!b) return !1;
        const c = Aa(b),
            d = a.g.get(c);
        if (null != d) return d;
        if (1 == b.nodeType && ("UL" == b.tagName || "OL" == b.tagName) && "none" != a.i.getComputedStyle(b).getPropertyValue("list-style-type")) return a.g.set(c, !0), !0;
        b = TA(a, b.parentNode);
        a.g.set(c, b);
        return b
    }

    function UA(a, b) {
        return ab(b.ed, c => TA(a, c))
    }
    class VA {
        constructor(a) {
            this.g = new Po;
            this.i = a
        }
    };
    class WA {
        constructor(a, b) {
            this.l = a;
            this.g = [];
            this.i = [];
            this.j = b
        }
    };
    var YA = (a, {
            rg: b = !1,
            lf: c = !1,
            Fg: d = c || v(dt) ? 2 : 3,
            hf: e = null
        } = {}) => {
            a = RA(a);
            return XA(a, {
                rg: b,
                lf: c,
                Fg: d,
                hf: e
            })
        },
        XA = (a, {
            rg: b = !1,
            lf: c = !1,
            Fg: d = c || v(dt) ? 2 : 3,
            hf: e = null
        } = {}) => {
            if (2 > d) throw Error("minGroupSize should be at least 2, found " + d);
            var f = a.slice(0);
            f.sort(QA);
            a = [];
            b = new WA(b, e);
            for (const g of f) {
                e = {
                    Ld: g,
                    yd: 51 > g.B.length ? !1 : null != b.j ? !UA(b.j, g) : !0
                };
                if (b.l || e.yd) b.g.length ? (f = b.g[b.g.length - 1].Ld, f = nA(f.da(), f.ed[f.ed.length - 1], e.Ld.ed[0])) : f = !0, f ? (b.g.push(e), e.yd && b.i.push(e.Ld)) : (b.g = [e], b.i = e.yd ? [e.Ld] : []);
                if (b.i.length >= d) {
                    e = b;
                    f = c || v(dt) ? 0 : 1;
                    if (0 > f || f >= e.i.length) e = null;
                    else {
                        for (f = e.i[f]; e.g.length && !e.g[0].yd;) e.g.shift();
                        e.g.shift();
                        e.i.shift();
                        e = f
                    }
                    e && a.push(e)
                }
            }
            return a
        };
    var $A = (a, b, c = !1) => {
            a = ZA(a, b);
            const d = new VA(b);
            return Zp(a, e => YA(e, {
                lf: c,
                hf: d
            }))
        },
        aB = (a, b) => {
            a = ZA(a, b);
            const c = new VA(b);
            return Zp(a, d => {
                if (d.l) {
                    var e = d.i;
                    var f = d.j;
                    d = d.g.querySelectorAll(d.l);
                    var g = [];
                    for (var h of d) g.push(new LA(e, h, f));
                    e = g
                } else e = [];
                d = e.slice(0);
                if (d.length) {
                    e = [];
                    f = d[0];
                    for (g = 1; g < d.length; g++) {
                        const m = d[g];
                        h = f;
                        b: {
                            if (h.element.hasAttributes())
                                for (l of h.element.attributes)
                                    if ("style" === l.name.toLowerCase() && l.value.toLowerCase().includes("background-image")) {
                                        var k = !0;
                                        break b
                                    }
                            k =
                            h.element.tagName;k = "IMG" === k || "SVG" === k
                        }(k || 1 < h.element.textContent.length) && !TA(c, f.element) && nA(m.da(), f.element, m.element) && e.push(f);
                        f = m
                    }
                    var l = e
                } else l = [];
                return l
            })
        },
        ZA = (a, b) => {
            const c = new Po;
            a.forEach(d => {
                var e = Gv(C(d, qq, 1));
                if (e) {
                    var f = e.toString();
                    Lo(c, f) || c.set(f, {
                        articleStructure: d,
                        Eh: e,
                        dd: null,
                        fg: !1,
                        If: null
                    });
                    e = c.get(f);
                    (f = (f = C(d, qq, 2)) ? I(f, 7) : null) ? e.dd = e.dd ? e.dd + "," + f : f: e.fg = !0;
                    d = C(d, qq, 4);
                    e.If = d ? I(d, 7) : null
                }
            });
            return Oo(c).map(d => {
                const e = d.Eh.query(b.document);
                return e.length ? new SA(e[0],
                    d, b) : null
            }).filter(d => null != d)
        };
    var bB = a => a ? .google_ad_slot ? fq(new rq(1, {
            zh: a.google_ad_slot
        })) : hq(Error("Missing dimension when creating placement id")),
        dB = a => {
            switch (a.Qb) {
                case 0:
                case 1:
                    var b = a.l;
                    null == b ? a = null : (a = b.ia(), null == a ? a = null : (b = L(b, 2), a = null == b ? null : new rq(0, {
                        Jf: [a],
                        Xg: b
                    })));
                    return null != a ? fq(a) : hq(Error("Missing dimension when creating placement id"));
                case 2:
                    return a = cB(a), null != a ? fq(a) : hq(Error("Missing dimension when creating placement id"));
                default:
                    return hq(Error("Invalid type: " + a.Qb))
            }
        };
    const cB = a => {
        if (null == a || null == a.B) return null;
        const b = C(a.B, qq, 1),
            c = C(a.B, qq, 2);
        if (null == b || null == c) return null;
        const d = a.ea;
        if (null == d) return null;
        a = a.g();
        return null == a ? null : new rq(0, {
            Jf: [b, c],
            Li: d,
            Xg: Mv[a]
        })
    };

    function eB(a) {
        const b = DA(a.ga);
        return (b ? bB(b) : dB(a.ga)).map(c => uq(c))
    }

    function fB(a) {
        a.g = a.g || eB(a);
        return a.g
    }

    function gB(a, b) {
        if (a.ga.A) throw Error("AMA:AP:AP");
        iv(b, a.ia(), a.ga.g());
        FA(a.ga, b)
    }
    const hB = class {
        constructor(a, b, c) {
            this.ga = a;
            this.i = b;
            this.ja = c;
            this.g = null
        }
        ia() {
            return this.i
        }
        fill(a, b) {
            var c = this.ga;
            (a = c.C.i(a, b, this.i, c.j)) && gB(this, a.ob);
            return a
        }
    };

    function iB(a, b) {
        return Fv(() => {
            if (v(et)) {
                var c = [],
                    d = [];
                for (var e = 0; e < a.length; e++) {
                    var f = a[e],
                        g = BA(f);
                    if (g) {
                        if (!f.i && !f.A) {
                            var h = null;
                            try {
                                var k = BA(f);
                                if (k) {
                                    h = CA(f);
                                    iv(h, k, f.g());
                                    var l = h
                                } else l = null
                            } catch (q) {
                                throw fv(h), q;
                            }
                            f.i = l
                        }(h = f.i) && d.push({
                            jj: f,
                            anchorElement: g,
                            vi: h
                        })
                    }
                }
                if (0 < d.length)
                    for (l = Eo(b), k = Fo(b), e = 0; e < d.length; e++) {
                        const {
                            jj: q,
                            anchorElement: x,
                            vi: z
                        } = d[e];
                        f = jB(z, k, l);
                        c.push(new hB(q, x, f))
                    }
                l = c
            } else {
                l = [];
                k = [];
                try {
                    const q = [];
                    for (let x = 0; x < a.length; x++) {
                        var m = a[x],
                            n = BA(m);
                        n && q.push({
                            Qg: m,
                            anchorElement: n
                        })
                    }
                    for (n =
                        0; n < q.length; n++) {
                        m = k;
                        g = m.push; {
                            var p = q[n];
                            const x = p.anchorElement,
                                z = p.Qg,
                                G = CA(z);
                            try {
                                iv(G, x, z.g()), h = G
                            } catch (F) {
                                throw fv(G), F;
                            }
                        }
                        g.call(m, h)
                    }
                    c = Eo(b);
                    d = Fo(b);
                    for (g = 0; g < k.length; g++) e = jB(k[g], d, c), f = q[g], l.push(new hB(f.Qg, f.anchorElement, e))
                } finally {
                    for (c = 0; c < k.length; c++) fv(k[c])
                }
            }
            return l
        }, b)
    }

    function jB(a, b, c) {
        a = a.getBoundingClientRect();
        return new Qp(a.left + b, a.top + c, a.right - a.left)
    };
    const kB = {
            1: "0.5vp",
            2: "300px"
        },
        lB = {
            1: 700,
            2: 1200
        },
        mB = {
            [1]: {
                hh: "3vp",
                pf: "1vp",
                gh: "0.3vp"
            },
            [2]: {
                hh: "900px",
                pf: "300px",
                gh: "90px"
            }
        };

    function nB(a, b, c) {
        var d = oB(a),
            e = S(a) || lB[d],
            f = void 0;
        c && (f = (c = (c = pB(D(c, Kq, 2), d)) ? C(c, Iq, 7) : void 0) ? qB(c, e) : void 0);
        c = f;
        f = oB(a);
        a = S(a) || lB[f];
        const g = rB(mB[f].pf, a);
        a = null === g ? sB(f, a) : new tB(g, g, uB(g, 8), 8, .3, c);
        c = rB(mB[d].hh, e);
        f = rB(mB[d].pf, e);
        d = rB(mB[d].gh, e);
        e = a.j;
        c && d && f && void 0 !== b && (e = .5 >= b ? f + (1 - 2 * b) * (c - f) : d + (2 - 2 * b) * (f - d));
        return new tB(e, e, uB(e, a.i), a.i, a.l, a.g)
    }

    function vB(a, b) {
        const c = a.Mb();
        a = Zh(a, 5);
        return null == c || null == a ? b : new tB(a, 0, [], c, 1)
    }

    function wB(a, b) {
        const c = oB(a);
        a = S(a) || lB[c];
        if (!b) return sB(c, a);
        if (b = pB(D(b, Kq, 2), c))
            if (b = xB(b, a)) return b;
        return sB(c, a)
    }

    function yB(a) {
        const b = oB(a);
        a = S(a) || lB[b];
        return sB(b, a)
    }

    function zB(a, b) {
        let c = {
            Ic: a.j,
            vb: a.B
        };
        for (let d of a.A) d.adCount <= b && (c = d.Nc);
        return c
    }

    function AB(a, b, c) {
        var d = $h(b, 2);
        b = C(b, Kq, 1);
        var e = oB(c);
        var f = S(c) || lB[e];
        c = rB(b ? .A(), f) ? ? a.j;
        e = rB(b ? .l(), f) ? ? a.B;
        d = d ? [] : BB(b ? .g(), f) ? ? a.A;
        const g = b ? .Mb() ? ? a.i,
            h = b ? .j() ? ? a.l;
        a = (b ? .B() ? qB(C(b, Iq, 7), f) : null) ? ? a.g;
        return new tB(c, e, d, g, h, a)
    }

    function CB(a, b) {
        var c = oB(b);
        const d = new Lq,
            e = new Kq;
        let f = !1;
        var g = w(kt);
        0 <= g && (Xi(e, 4, g), f = !0);
        g = null;
        1 === c ? (c = w(nt), 0 <= c && (g = c + "vp")) : (c = w(mt), 0 <= c && (g = c + "px"));
        null !== g && ($i(e, 2, g), f = !0);
        c = v(pt) ? "0px" : null;
        null !== c && ($i(e, 5, c), f = !0);
        if (v(rt)) Vi(d, 2, !0), f = !0;
        else if (null !== c || null !== g) {
            const m = [];
            for (const n of a.A) {
                var h = m,
                    k = h.push;
                var l = new Jq;
                l = Xi(l, 1, n.adCount);
                l = $i(l, 3, c ? ? n.Nc.vb + "px");
                l = $i(l, 2, g ? ? n.Nc.Ic + "px");
                k.call(h, l)
            }
            si(e, 3, m)
        }
        return f ? (E(d, 1, e), AB(a, d, b)) : a
    }
    class tB {
        constructor(a, b, c, d, e, f) {
            this.j = a;
            this.B = b;
            this.A = c.sort((g, h) => g.adCount - h.adCount);
            this.i = d;
            this.l = e;
            this.g = f
        }
        Mb() {
            return this.i
        }
    }

    function pB(a, b) {
        for (let c of a)
            if (L(c, 1) == b) return c;
        return null
    }

    function BB(a, b) {
        if (void 0 === a) return null;
        const c = [];
        for (let d of a) {
            a = ui(d, 1);
            const e = rB(I(d, 2), b);
            if ("number" !== typeof a || null === e) return null;
            c.push({
                adCount: a,
                Nc: {
                    Ic: e,
                    vb: rB(I(d, 3), b)
                }
            })
        }
        return c
    }

    function xB(a, b) {
        const c = rB(I(a, 2), b),
            d = rB(I(a, 5), b);
        if (null === c) return null;
        const e = ui(a, 4);
        if (null == e) return null;
        var f = a.g();
        f = BB(f, b);
        if (null === f) return null;
        const g = C(a, Iq, 7);
        b = g ? qB(g, b) : void 0;
        return new tB(c, d, f, e, Zh(a, 6), b)
    }

    function sB(a, b) {
        a = rB(kB[a], b);
        return v(ht) ? new tB(null === a ? Infinity : a, null, [], 8, .3) : new tB(null === a ? Infinity : a, null, [], 3, null)
    }

    function rB(a, b) {
        if (!a) return null;
        const c = parseFloat(a);
        return isNaN(c) ? null : a.endsWith("px") ? c : a.endsWith("vp") ? c * b : null
    }

    function oB(a) {
        a = 900 <= wo(a);
        return te() && !a ? 1 : 2
    }

    function uB(a, b) {
        if (4 > b) return [];
        const c = Math.ceil(b / 2);
        return [{
            adCount: c,
            Nc: {
                Ic: 2 * a,
                vb: 2 * a
            }
        }, {
            adCount: c + Math.ceil((b - c) / 2),
            Nc: {
                Ic: 3 * a,
                vb: 3 * a
            }
        }]
    }

    function qB(a, b) {
        const c = rB(I(a, 2), b) || 0,
            d = ui(a, 3) || 1;
        return {
            Gg: c,
            Ag: d,
            lc: rB(I(a, 1), b) || 0
        }
    };

    function DB(a, b, c) {
        return oo({
            top: a.g.top - (c + 1),
            right: a.g.right + (c + 1),
            bottom: a.g.bottom + (c + 1),
            left: a.g.left - (c + 1)
        }, b.g)
    }

    function EB(a) {
        if (!a.length) return null;
        const b = po(a.map(c => c.g));
        a = a.reduce((c, d) => c + d.i, 0);
        return new FB(b, a)
    }
    class FB {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function GB(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };
    var MB = (a, b) => {
        var c = gb(b.document.querySelectorAll(".google-auto-placed"));
        const d = HB(b),
            e = IB(b),
            f = JB(b),
            g = KB(b),
            h = gb(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = gb(b.document.querySelectorAll("div.googlepublisherpluginad")),
            l = gb(b.document.querySelectorAll("html > ins.adsbygoogle"));
        let m = [].concat(gb(b.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), gb(b.document.querySelectorAll("body ins.adsbygoogle")));
        b = [];
        for (const [n, p] of [
                [a.vd, c],
                [a.Pb,
                    d
                ],
                [a.Ji, e],
                [a.wd, f],
                [a.xd, g],
                [a.Hi, h],
                [a.Ii, k],
                [a.Ki, l]
            ]) !1 === n ? b = b.concat(p) : m = m.concat(p);
        a = LB(m);
        c = LB(b);
        a = a.slice(0);
        for (const n of c)
            for (c = 0; c < a.length; c++)(n.contains(a[c]) || a[c].contains(n)) && a.splice(c, 1);
        return a
    };
    const NB = a => {
            const b = GB(a);
            return b ? Xa(Za(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => null != c) : null
        },
        HB = a => gb(a.document.querySelectorAll("ins.adsbygoogle[data-anchor-shown],ins.adsbygoogle[data-anchor-status]")),
        IB = a => gb(a.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]")),
        JB = a => (NB(a) || gb(a.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(gb(a.document.querySelectorAll("iframe[id^=google_ads_iframe]"))),
        KB = a => gb(a.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]"));
    var LB = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };
    var OB = Xz.Oa(453, MB),
        PB;
    PB = Xz.Oa(454, (a, b) => {
        const c = gb(b.document.querySelectorAll(".google-auto-placed")),
            d = HB(b),
            e = IB(b),
            f = JB(b),
            g = KB(b),
            h = gb(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = gb(b.document.querySelectorAll("div.googlepublisherpluginad"));
        b = gb(b.document.querySelectorAll("html > ins.adsbygoogle"));
        return LB([].concat(!0 === a.vd ? c : [], !0 === a.Pb ? d : [], !0 === a.Ji ? e : [], !0 === a.wd ? f : [], !0 === a.xd ? g : [], !0 === a.Hi ? h : [], !0 === a.Ii ? k : [], !0 === a.Ki ? b : []))
    });

    function QB(a, b, c) {
        const d = RB(a);
        b = SB(d, b, c);
        return new TB(a, d, b)
    }

    function UB(a) {
        return 1 < (a.bottom - a.top) * (a.right - a.left)
    }

    function VB(a) {
        return a.g.map(b => b.box)
    }

    function WB(a) {
        return a.g.reduce((b, c) => b + c.box.bottom - c.box.top, 0)
    }
    class TB {
        constructor(a, b, c) {
            this.j = a;
            this.g = b.slice(0);
            this.l = c.slice(0);
            this.i = null
        }
    }

    function RB(a) {
        const b = OB({
                Pb: !1
            }, a),
            c = Fo(a),
            d = Eo(a);
        return b.map(e => {
            const f = e.getBoundingClientRect();
            return (e = !!e.className && jc(e.className, "google-auto-placed")) || UB(f) ? {
                box: {
                    top: f.top + d,
                    right: f.right + c,
                    bottom: f.bottom + d,
                    left: f.left + c
                },
                Nn: e ? 1 : 0
            } : null
        }).filter(Ib(e => null === e))
    }

    function SB(a, b, c) {
        return void 0 != b && a.length <= (void 0 != c ? c : 8) ? XB(a, b) : Za(a, d => new FB(d.box, 1))
    }

    function XB(a, b) {
        a = Za(a, d => new FB(d.box, 1));
        const c = [];
        for (; 0 < a.length;) {
            let d = a.pop(),
                e = !0;
            for (; e;) {
                e = !1;
                for (let f = 0; f < a.length; f++)
                    if (DB(d, a[f], b)) {
                        d = EB([d, a[f]]);
                        Array.prototype.splice.call(a, f, 1);
                        e = !0;
                        break
                    }
            }
            c.push(d)
        }
        return c
    };

    function YB(a, b, c) {
        const d = Pp(c, b);
        return !ab(a, e => oo(e, d))
    }

    function ZB(a, b, c, d, e) {
        e = e.ja;
        const f = Pp(e, b),
            g = Pp(e, c),
            h = Pp(e, d);
        return !ab(a, k => oo(k, g) || oo(k, f) && !oo(k, h))
    }

    function $B(a, b, c, d) {
        const e = VB(a);
        if (YB(e, b, d.ja)) return !0;
        if (!ZB(e, b, c.Gg, c.lc, d)) return !1;
        const f = new FB(Pp(d.ja, 0), 1);
        a = Xa(a.l, g => DB(g, f, c.lc));
        b = $a(a, (g, h) => g + h.i, 1);
        return 0 === a.length || b > c.Ag ? !1 : !0
    };
    var aC = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function bC(a, b) {
        const c = new mq,
            d = new Qo;
        b.forEach(e => {
            if (Si(e, Sq, 1, Vq)) {
                e = Si(e, Sq, 1, Vq);
                if (C(e, Rq, 1) && C(e, Rq, 1).ia() && C(e, Rq, 2) && C(e, Rq, 2).ia()) {
                    const g = cC(a, C(e, Rq, 1).ia()),
                        h = cC(a, C(e, Rq, 2).ia());
                    if (g && h)
                        for (var f of aC({
                                anchor: g,
                                position: L(C(e, Rq, 1), 2)
                            }, {
                                anchor: h,
                                position: L(C(e, Rq, 2), 2)
                            })) c.set(Aa(f.anchor), f.position)
                }
                C(e, Rq, 3) && C(e, Rq, 3).ia() && (f = cC(a, C(e, Rq, 3).ia())) && c.set(Aa(f), L(C(e, Rq, 3), 2))
            } else Si(e, Tq, 2, Vq) ? dC(a, Si(e, Tq, 2, Vq), c) : Si(e, Qq, 3, Vq) && eC(a, Si(e, Qq, 3, Vq), d)
        });
        return new fC(c,
            d)
    }
    class fC {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    }
    const dC = (a, b, c) => {
            C(b, Rq, 2) ? (b = C(b, Rq, 2), (a = cC(a, b.ia())) && c.set(Aa(a), L(b, 2))) : C(b, qq, 1) && (a = gC(a, C(b, qq, 1))) && a.forEach(d => {
                d = Aa(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        eC = (a, b, c) => {
            C(b, qq, 1) && (a = gC(a, C(b, qq, 1))) && a.forEach(d => {
                c.add(Aa(d))
            })
        },
        cC = (a, b) => (a = gC(a, b)) && 0 < a.length ? a[0] : null,
        gC = (a, b) => (b = Gv(b)) ? b.query(a) : null;
    var hC = class {
        constructor() {
            this.g = zf();
            this.i = 0
        }
    };

    function iC(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (jC(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function kC(a) {
        a = lC(a);
        return a.has("all") || a.has("after")
    }

    function mC(a) {
        a = lC(a);
        return a.has("all") || a.has("before")
    }

    function lC(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function jC(a) {
        const b = lC(a);
        return a && ("AUTO-ADS-EXCLUSION-AREA" === a.tagName || b.has("inside") || b.has("all"))
    }
    var nC = class {
        constructor() {
            this.g = new Set;
            this.i = new hC
        }
    };

    function oC(a) {
        return function(b) {
            return iB(b, a)
        }
    }

    function pC(a) {
        const b = S(a);
        return b ? Ja(qC, b + Eo(a)) : Fb
    }

    function rC(a, b, c) {
        if (0 > a) throw Error("ama::ead:nd");
        if (Infinity === a) return Fb;
        const d = VB(c || QB(b));
        return e => YB(d, a, e.ja)
    }

    function sC(a, b, c, d) {
        if (0 > a || 0 > b.Gg || 0 > b.Ag || 0 > b.lc) throw Error("ama::ead:nd");
        return Infinity === a ? Fb : e => $B(d || QB(c, b.lc), a, b, e)
    }

    function tC(a) {
        if (!a.length) return Fb;
        const b = new eq(a);
        return c => b.contains(c.Qb)
    }

    function uC(a) {
        return function(b) {
            for (let c of b.Cc)
                if (-1 < a.indexOf(c)) return !1;
            return !0
        }
    }

    function vC(a) {
        return a.length ? function(b) {
            const c = b.Cc;
            return a.some(d => -1 < c.indexOf(d))
        } : Gb
    }

    function wC(a, b) {
        if (0 >= a) return Gb;
        const c = Ao(b).scrollHeight - a;
        return function(d) {
            return d.ja.g <= c
        }
    }

    function xC(a) {
        const b = {};
        a && a.forEach(c => {
            b[c] = !0
        });
        return function(c) {
            return !b[L(c.Sd, 2) || 0]
        }
    }

    function yC(a) {
        return a.length ? b => a.includes(L(b.Sd, 1) || 0) : Gb
    }

    function zC(a, b) {
        const c = bC(a, b);
        return function(d) {
            var e = d.ia();
            d = Mv[d.ga.g()];
            var f = c.i,
                g = Aa(e);
            f = f.g.get(g);
            if (!(f = f ? f.contains(d) : !1)) a: {
                if (c.g.contains(Aa(e))) switch (d) {
                    case 2:
                    case 3:
                        f = !0;
                        break a;
                    default:
                        f = !1;
                        break a
                }
                for (e = e.parentElement; e;) {
                    if (c.g.contains(Aa(e))) {
                        f = !0;
                        break a
                    }
                    e = e.parentElement
                }
                f = !1
            }
            return !f
        }
    }

    function AC() {
        const a = new nC;
        return function(b) {
            var c = b.ia(),
                d = Mv[b.ga.g()];
            a: switch (d) {
                case 1:
                    b = kC(c.previousElementSibling) || mC(c);
                    break a;
                case 4:
                    b = kC(c) || mC(c.nextElementSibling);
                    break a;
                case 2:
                    b = mC(c.firstElementChild);
                    break a;
                case 3:
                    b = kC(c.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + d);
            }
            c = iC(a, c, d);
            d = a.i;
            aA("ama_exclusion_zone", {
                typ: b ? c ? "siuex" : "siex" : c ? "suex" : "noex",
                cor: d.g,
                num: d.i++,
                dvc: of ()
            }, .1);
            return !(b || c)
        }
    }
    const qC = (a, b) => b.ja.g >= a,
        BC = (a, b, c) => {
            c = c.ja.yc();
            return a <= c && c <= b
        };

    function CC(a, b, c, d, e) {
        var f = DC({
            mh: e.qh
        }, EC(a, b), a);
        if (0 === f.length) {
            var g = !!C(b, kr, 6) ? .g() ? .length;
            f = C(b, er, 28) ? .l() ? .g() && g ? DC({
                mh: !0
            }, FC(a, b), a) : f
        }
        if (0 === f.length) return jA(d, "pfno"), [];
        b = f;
        a = e.md ? GC(a, b, c) : {
            kb: b,
            nd: null
        };
        const {
            kb: h,
            nd: k
        } = a;
        f = h;
        return 0 === f.length && k ? (jA(d, k), []) : [f[e.qh ? 0 : Math.floor(f.length / 2)]]
    }

    function GC(a, b, c) {
        c = c ? D(c, Uq, 5) : [];
        const d = zC(a.document, c),
            e = AC();
        b = b.filter(f => d(f));
        if (0 === b.length) return {
            kb: [],
            nd: "pfaz"
        };
        b = b.filter(f => e(f));
        return 0 === b.length ? {
            kb: [],
            nd: "pfet"
        } : {
            kb: b,
            nd: null
        }
    }

    function HC(a, b) {
        return a.ja.g - b.ja.g
    }

    function EC(a, b) {
        const c = C(b, kr, 6);
        if (!c) return [];
        b = C(b, er, 28) ? .l();
        return (b ? .j() ? aB(c.g(), a) : $A(c.g(), a, !!b ? .l())).map(d => d.j())
    }

    function FC(a, b) {
        b = D(b, or, 1) || [];
        return xA(b, a, {}).filter(c => !c.Cc.includes(6))
    }

    function DC(a, b, c) {
        b = iB(b, c);
        if (a.mh) {
            const d = pC(c);
            b = b.filter(e => d(e))
        }
        return b.sort(HC)
    };

    function IC(a, b) {
        return 2 === of () ? ny(a.win, b, {
            Ze: .95,
            Fe: .95,
            zIndex: 2147483645,
            qb: !0,
            Ja: !0
        }) : xx(a.win, b, {
            vc: "min(65vw, 768px)",
            kc: "",
            uc: !1,
            zIndex: 2147483645,
            qb: !0,
            Qd: !1,
            Ja: !0
        })
    }

    function JC(a) {
        ((d, e) => {
            d[e] = d[e] || function() {
                (d[e].q = d[e].q || []).push(arguments)
            };
            d[e].t = (new Date).getTime()
        })(a.win, "_googCsa");
        const b = a.na.map(d => ({
                container: d,
                relatedSearches: 5
            })),
            c = {
                pubId: a.H,
                styleId: "5134551505",
                hl: a.ea,
                fexp: a.F,
                channel: "AutoRsVariant",
                resultsPageBaseUrl: "http://google.com",
                resultsPageQueryParam: "q",
                relatedSearchTargeting: "content",
                relatedSearchResultClickedCallback: a.Cb.bind(a),
                relatedSearchUseResultCallback: !0,
                cx: a.I
            };
        a.va && (c.adLoadedCallback = a.Ha.bind(a));
        a.l && a.C instanceof
        Array && (c.fexp = a.C.join(","));
        a.win._googCsa("relatedsearch", c, b)
    }

    function KC(a) {
        a.win.addEventListener("message", b => {
            "https://www.gstatic.com" === b.origin && "resize" === b.data.action && (a.g.style.height = `${Math.ceil(b.data.height)+1}px`)
        })
    }
    var LC = class extends T {
        constructor(a, b, c, d, e, f, g, h, k = () => {}) {
            super();
            this.win = a;
            this.na = b;
            this.Z = e;
            this.F = f;
            this.A = h;
            this.Ua = k;
            this.ea = d ? .g() || "en";
            this.Qa = d ? .j() || "Search results from ${website}";
            this.va = v(xt);
            this.H = c.replace("ca", "partner");
            this.O = new ee(a.document);
            this.g = re(this.O, "IFRAME");
            this.I = g.i ? g.g : "9d449ff4a772956c6";
            this.C = (this.l = v(Dt)) ? fo().concat(this.F) : this.F;
            this.j = new Ls(this.g, this.I, "auto-rs-prose", this.H, "AutoRsVariant", a.location, this.ea, this.Qa, this.C, this.A, this.l);
            this.T =
                IC(this, this.g);
            Yo(this, this.T)
        }
        L() {
            0 !== this.na.length && (this.va || Ev(1075, () => {
                this.j.L()
            }, this.win), Ev(1076, () => {
                const a = re(this.O, "SCRIPT");
                Qe(a, sj `https://www.google.com/adsense/search/async-ads.js`);
                this.win.document.head.appendChild(a)
            }, this.win), JC(this), iA(this.Z, {
                sts: "ok"
            }), this.A && KC(this))
        }
        Ha(a, b) {
            b ? Ev(1075, () => {
                this.j.L()
            }, this.win) : (this.Ua(), jA(this.Z, "pfns"))
        }
        Cb(a, b) {
            Js(this.j, a, b);
            (() => {
                if (!this.A) {
                    const c = new ResizeObserver(async e => {
                            this.g.height = "0";
                            await new Promise(f => {
                                this.win.requestAnimationFrame(f)
                            });
                            this.g.height = e[0].target.scrollHeight.toString()
                        }),
                        d = () => {
                            const e = this.g.contentDocument ? .documentElement;
                            e ? c.observe(e) : (console.warn("iframe body missing"), setTimeout(d, 1E3))
                        };
                    d()
                }
                this.T.show()
            })()
        }
    };
    var MC = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };

    function NC(a) {
        const b = GA(a.l.ga),
            c = a.B.Ma(a.G, () => a.i());
        b.appendChild(c);
        a.A && (b.className = a.A);
        return {
            mi: b,
            ai: c
        }
    }
    class OC {
        constructor(a, b, c, d) {
            this.G = a;
            this.l = b;
            this.B = c;
            this.A = d || null;
            this.g = null;
            this.j = new V(null)
        }
        L() {
            const a = NC(this);
            this.g = a.mi;
            gB(this.l, this.g);
            this.j.g(a.ai)
        }
        i() {
            this.g && this.g.parentNode && this.g.parentNode.removeChild(this.g);
            this.g = null;
            this.j.g(null)
        }
        C() {
            return this.j
        }
    };
    async function PC(a) {
        await new Promise(b => {
            setTimeout(() => {
                try {
                    QC(a)
                } catch (c) {
                    jA(a.i, "pfere", c)
                }
                b()
            })
        })
    }

    function QC(a) {
        if ((!a.md || !RC(a.config, a.X, a.i)) && SC(a.g ? .j(), a.i)) {
            var b = CC(a.win, a.config, a.X, a.i, {
                qh: !!a.g ? .l() ? .A(),
                md: a.md
            });
            b = TC(b, a.win);
            var c = Object.keys(b),
                d = Object.values(b),
                e = a.g ? .g() ? .g() || 0,
                f = UC(a.g),
                g = !!a.g ? .B();
            if (!C(a.config, Xq, 25) ? .g()) {
                var h = () => {
                    d.forEach(k => {
                        k.i()
                    })
                };
                Ev(1074, () => {
                    (new LC(a.win, c, a.webPropertyCode, a.g ? .j(), a.i, e, f, g, h)).L()
                }, a.win)
            }
        }
    }
    var VC = class {
        constructor(a, b, c, d, e, f) {
            this.win = a;
            this.config = c;
            this.webPropertyCode = d;
            this.X = e;
            this.md = f;
            this.i = new kA(a, b, C(this.config, er, 28) || new er);
            this.g = C(this.config, er, 28)
        }
    };

    function RC(a, b, c) {
        a = C(a, er, 28) ? .g() ? .g() || 0;
        const d = u(Wb).g(Ct.g, Ct.defaultValue);
        return d && d.includes(a.toString()) ? !1 : 0 === (b ? ai(b, 2, eh, 2) : []).length ? (jA(c, "pfeu"), !0) : !1
    }

    function SC(a, b) {
        const c = u(Wb).g(At.g, At.defaultValue);
        return c && 0 !== c.length && !c.includes((a ? .g() || "").toString()) ? (jA(b, "pflna"), !1) : !0
    }

    function TC(a, b) {
        const c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            const f = "autors-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            d = new OC(b, d, new lA(g), "autors-widget");
            d.L();
            c[f] = d
        }
        return c
    }

    function UC(a) {
        return new MC(a ? .C() || !1, a ? .A() || "")
    };
    var WC = (a, b) => {
        const c = [];
        C(a, pr, 18) && c.push(2);
        b.X && c.push(0);
        C(a, er, 28) && 1 == zi(C(a, er, 28), 1) && c.push(1);
        C(a, cr, 31) && 1 == zi(C(a, cr, 31), 1) && c.push(5);
        C(a, Zq, 32) && c.push(6);
        C(a, sr, 34) && M(C(a, sr, 34), 3) && c.push(7);
        return c
    };

    function XC(a, b) {
        const c = re(de(a), "IMG");
        YC(a, c);
        c.src = "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg";
        A(c, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: null == b ? "auto" : "pointer"
        });
        b && c.addEventListener("click", d => {
            b();
            d.stopPropagation()
        });
        return c
    }

    function ZC(a, b) {
        const c = b.document.createElement("button");
        YC(b, c);
        A(c, {
            display: "inline",
            "line-height": "24px",
            cursor: "pointer"
        });
        c.appendChild(b.document.createTextNode(a.i));
        c.addEventListener("click", d => {
            a.j();
            d.stopPropagation()
        });
        return c
    }

    function $C(a, b, c) {
        const d = re(de(b), "IMG");
        d.src = "https://www.gstatic.com/adsense/autoads/icons/arrow_left_24px_grey_800.svg";
        d.setAttribute("aria-label", a.l);
        YC(b, d);
        A(d, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: "pointer"
        });
        d.addEventListener("click", e => {
            c();
            e.stopPropagation()
        });
        return d
    }

    function aD(a) {
        const b = a.document.createElement("ins");
        YC(a, b);
        A(b, {
            "float": "left",
            display: "inline-flex",
            padding: "8px 0px",
            "background-color": "#FFF",
            "border-radius": "0px 20px 20px 0px",
            "box-shadow": "0px 1px 2px 0px rgba(60,64,67,0.3), 0px 1px 3px 1px rgba(60,64,67,0.15)"
        });
        return b
    }
    class bD {
        constructor(a, b, c) {
            this.i = a;
            this.l = b;
            this.j = c;
            this.g = new V(!1)
        }
        Ma(a, b, c, d) {
            const e = XC(a, d),
                f = XC(a),
                g = ZC(this, a),
                h = $C(this, a, c);
            a = aD(a);
            a.appendChild(e);
            a.appendChild(f);
            a.appendChild(g);
            a.appendChild(h);
            this.g.listen(k => {
                A(e, {
                    display: k ? "none" : "inline"
                });
                A(f, {
                    display: k ? "inline" : "none"
                });
                k ? (A(g, {
                        "line-height": "24px",
                        "max-width": "100vw",
                        opacity: "1",
                        transition: "line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms"
                    }), A(h, {
                        margin: "0px 12px 0px 8px",
                        opacity: 1,
                        width: "24px",
                        transition: "margin 100ms 50ms, opacity 50ms 50ms, width 100ms 50ms"
                    })) :
                    (A(g, {
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        transition: "line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms"
                    }), A(h, {
                        margin: "0",
                        opacity: "0",
                        width: "0",
                        transition: "margin 100ms, opacity 50ms, width 100ms"
                    }))
            }, !0);
            return a
        }
        ig() {
            return 40
        }
        Mg() {
            this.g.g(!1);
            return 0
        }
        Ng() {
            this.g.g(!0)
        }
    }

    function YC(a, b) {
        A(b, Ov(a));
        A(b, {
            "font-family": "Arial,sans-serif",
            "font-weight": "bold",
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: "#3C4043",
            "user-select": "none"
        })
    };

    function cD(a, b) {
        const c = b.document.createElement("button");
        dD(a, b, c);
        b = {
            width: "100%",
            "text-align": "center",
            display: "block",
            padding: "8px 0px",
            "background-color": a.i
        };
        a.g && (b["border-top"] = a.g, b["border-bottom"] = a.g);
        A(c, b);
        c.addEventListener("click", d => {
            a.B();
            d.stopPropagation()
        });
        return c
    }

    function eD(a, b, c, d) {
        const e = b.document.createElement("div");
        A(e, Ov(b));
        A(e, {
            "align-items": "center",
            "background-color": a.i,
            display: "flex",
            "justify-content": "center"
        });
        const f = b.document.createElement("span");
        f.appendChild(b.document.createTextNode(d));
        A(f, Ov(b));
        A(f, {
            "font-family": "Arial,sans-serif",
            "font-size": "12px",
            padding: "8px 0px"
        });
        b = b.matchMedia("(min-width: 768px)");
        d = g => {
            g.matches ? (A(e, {
                    "flex-direction": "row"
                }), a.g && A(e, {
                    "border-top": a.g,
                    "border-bottom": a.g
                }), A(f, {
                    "margin-left": "8px",
                    "text-align": "start"
                }),
                A(c, {
                    border: "0",
                    "margin-right": "8px",
                    width: "auto"
                })) : (A(e, {
                border: "0",
                "flex-direction": "column"
            }), A(f, {
                "margin-left": "0",
                "text-align": "center"
            }), A(c, {
                "margin-right": "0",
                width: "100%"
            }), a.g && A(c, {
                "border-top": a.g,
                "border-bottom": a.g
            }))
        };
        d(b);
        b.addEventListener("change", d);
        e.appendChild(c);
        e.appendChild(f);
        return e
    }

    function dD(a, b, c) {
        A(c, Ov(b));
        A(c, {
            "font-family": "Arial,sans-serif",
            "font-weight": a.C,
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: a.G,
            "user-select": "none",
            cursor: "pointer"
        })
    }
    class fD {
        constructor(a, b, c, d, e, f = null, g = null, h = null) {
            this.A = a;
            this.B = b;
            this.G = c;
            this.i = d;
            this.C = e;
            this.l = f;
            this.g = g;
            this.j = h
        }
        Ma(a) {
            const b = a.document.createElement("div");
            dD(this, a, b);
            A(b, {
                display: "inline-flex",
                padding: "8px 0px",
                "background-color": this.i
            });
            if (this.l) {
                var c = re(de(a), "IMG");
                c.src = this.l;
                dD(this, a, c);
                A(c, {
                    margin: "0px 8px 0px 0px",
                    width: "24px",
                    height: "24px"
                })
            } else c = null;
            c && b.appendChild(c);
            c = a.document.createElement("span");
            dD(this, a, c);
            A(c, {
                "line-height": "24px"
            });
            c.appendChild(a.document.createTextNode(this.A));
            b.appendChild(c);
            c = cD(this, a);
            c.appendChild(b);
            return this.j ? eD(this, a, c, this.j) : c
        }
    };

    function gD(a, b) {
        b = b.filter(c => 5 === C(c, zq, 4) ? .g() && 1 === L(c, 8));
        b = xA(b, a);
        a = iB(b, a);
        a.sort((c, d) => d.ja.g - c.ja.g);
        return a[0] || null
    };

    function hD({
        K: a,
        Ue: b,
        Re: c,
        Qf: d,
        ua: e,
        Uh: f,
        Dj: g
    }) {
        let h = 0;
        try {
            h |= uo(a);
            const k = Math.min(a.screen.width || 0, a.screen.height || 0);
            h |= k ? 320 > k ? 8192 : 0 : 2048;
            h |= a.navigator && iD(a.navigator.userAgent) ? 1048576 : 0;
            h = b ? h | jD(a, b, g) : h | (a.innerHeight >= a.innerWidth ? 0 : 8);
            h |= vo(a, c, g);
            g || (h |= xo(a))
        } catch {
            h |= 32
        }
        switch (d) {
            case 2:
                kD(a, e) && (h |= 16777216);
                break;
            case 1:
                lD(a, e) && (h |= 16777216)
        }
        f && mD(a, e) && (h |= 16777216);
        return h
    }

    function iD(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    }
    var kD = (a, b = null) => {
            const c = Sv({
                hc: 0,
                Ib: a.innerWidth,
                Wb: 3,
                ic: 0,
                Jb: Math.min(Math.round(a.innerWidth / 320 * 50), nD) + 15,
                Xb: 3
            });
            return null != Uv(oD(a, b), c)
        },
        lD = (a, b = null) => {
            const c = a.innerWidth,
                d = a.innerHeight,
                e = Math.min(Math.round(a.innerWidth / 320 * 50), nD) + 15,
                f = Sv({
                    hc: 0,
                    Ib: c,
                    Wb: 3,
                    ic: d - e,
                    Jb: d,
                    Xb: 3
                });
            25 < e && f.push({
                x: c - 25,
                y: d - 25
            });
            return null != Uv(oD(a, b), f)
        };

    function mD(a, b = null) {
        return null != pD(a, b)
    }

    function pD(a, b = null) {
        var c = a.innerHeight;
        c = Sv({
            hc: 0,
            Ib: a.innerWidth,
            Wb: 10,
            ic: c - 66,
            Jb: c,
            Xb: 10
        });
        return Uv(oD(a, b), c)
    }

    function qD(a, b) {
        var c = v(Ts);
        a: {
            const e = a.innerWidth,
                f = a.innerHeight;
            let g = f;
            for (; g > b;) {
                var d = Sv({
                    hc: 0,
                    Ib: e,
                    Wb: 9,
                    ic: g - b,
                    Jb: g,
                    Xb: 9
                });
                d = Uv(oD(a), d);
                if (!d) {
                    a = f - g;
                    break a
                }
                g = c ? Math.min(d.getBoundingClientRect().top - 1, g - 1) : d.getBoundingClientRect().top - 1
            }
            a = null
        }
        return a
    }

    function oD(a, b = null) {
        return new Zv(a, {
            gg: rD(a, b)
        })
    }

    function rD(a, b = null) {
        if (b) return (c, d, e) => {
            sl(b, "ach_evt", {
                tn: c.tagName,
                id: c.getAttribute("id") ? ? "",
                cls: c.getAttribute("class") ? ? "",
                ign: String(e),
                pw: a.innerWidth,
                ph: a.innerHeight,
                x: d.x,
                y: d.y
            }, !0, 1)
        }
    }

    function jD(a, b, c = !1) {
        const d = a.innerHeight;
        return (c ? Ff(a) * d : d) >= b ? 0 : 1024
    }
    const nD = 90 * 1.38;

    function sD(a) {
        a.g || (a.g = tD(a));
        A(a.g, {
            display: "block"
        });
        a.A.Ng();
        a.j.g(a.B)
    }

    function uD(a) {
        const b = a.A.Mg();
        switch (b) {
            case 0:
                a.j.g(a.B);
                break;
            case 1:
                a.g && (A(a.g, {
                    display: "none"
                }), a.j.g(null));
                break;
            default:
                throw Error("Unhandled OnHideOutcome: " + b);
        }
    }

    function tD(a) {
        var b = qD(a.l, a.A.ig() + 60);
        b = null == b ? 30 : b + 30;
        const c = a.l.document.createElement("div");
        A(c, Ov(a.l));
        A(c, {
            position: "fixed",
            left: "0px",
            bottom: b + "px",
            width: "100vw",
            "text-align": "center",
            "z-index": 2147483642,
            display: "none",
            "pointer-events": "none"
        });
        a.B = a.A.Ma(a.l, () => a.i(), () => {
            a.G.la();
            uD(a)
        }, () => {
            a.G.la();
            sD(a)
        });
        c.appendChild(a.B);
        a.F && (c.className = a.F);
        a.l.document.body.appendChild(c);
        return c
    }
    class vD {
        constructor(a, b, c) {
            this.l = a;
            this.A = b;
            this.B = null;
            this.j = new V(null);
            this.F = c || null;
            this.G = mz(a);
            this.g = null
        }
        L() {
            const a = fp(this.G.j);
            W(a, !0, () => void sD(this));
            jp(a, !1, () => void uD(this))
        }
        i() {
            this.g && this.g.parentNode && this.g.parentNode.removeChild(this.g);
            this.g = null;
            this.G.la();
            this.j.g(null)
        }
        C() {
            return this.j
        }
    };

    function wD(a) {
        a.G.g(0);
        null != a.l && (a.l.i(), a.l = null);
        null != a.j && (a.j.i(), a.j = null)
    }

    function xD(a) {
        a.j = new vD(a.B, a.I, a.F);
        a.j.L();
        kp(a.A, a.j.C());
        a.G.g(2)
    }
    class yD {
        constructor(a, b, c, d, e) {
            this.B = a;
            this.H = b;
            this.O = c;
            this.I = d;
            this.F = e;
            this.G = new V(0);
            this.A = new V(null);
            this.j = this.l = this.g = null
        }
        L() {
            this.H ? (this.l = new OC(this.B, this.H, this.O, this.F), this.l.L(), kp(this.A, this.l.C()), this.G.g(1), null == this.g && (this.g = new Yp(this.B), this.g.L(2E3)), Wp(this.g, () => {
                wD(this);
                xD(this)
            })) : xD(this)
        }
        i() {
            wD(this);
            this.g && (this.g.la(), this.g = null)
        }
        C() {
            return this.A
        }
    };
    var zD = (a, b, c, d, e) => {
        a = new yD(a, gD(a, e), new fD(b, d, "#FFF", "#4A4A4A", "normal"), new bD(b, c, d), "google-dns-link-placeholder");
        a.L();
        return a
    };
    var AD = a => a.googlefc = a.googlefc || {},
        BD = a => {
            a = a.googlefc = a.googlefc || {};
            return a.ccpa = a.ccpa || {}
        };

    function CD(a) {
        var b = BD(a.g);
        if (DD(b.getInitialCcpaStatus(), b.InitialCcpaStatusEnum)) {
            var c = b.getLocalizedDnsText();
            b = b.getLocalizedDnsCollapseText();
            null != c && null != b && (a.i = zD(a.g, c, b, () => ED(a), a.l))
        }
    }

    function FD(a) {
        const b = AD(a.g);
        BD(a.g).overrideDnsLink = !0;
        b.callbackQueue = b.callbackQueue || [];
        b.callbackQueue.push({
            INITIAL_CCPA_DATA_READY: () => CD(a)
        })
    }

    function ED(a) {
        iw(a.j);
        BD(a.g).openConfirmationDialog(b => {
            b && a.i && (a.i.i(), a.i = null);
            jw(a.j)
        })
    }
    class GD {
        constructor(a, b, c) {
            this.g = a;
            this.j = cw(b, 2147483643);
            this.l = c;
            this.i = null
        }
    }

    function DD(a, b) {
        switch (a) {
            case b.CCPA_DOES_NOT_APPLY:
            case b.OPTED_OUT:
                return !1;
            case b.NOT_OPTED_OUT:
                return !0;
            default:
                return !0
        }
    };

    function HD(a) {
        const b = a.document.createElement("ins");
        ID(a, b);
        A(b, {
            display: "flex",
            padding: "8px 0px",
            width: "100%"
        });
        return b
    }

    function JD(a, b, c, d) {
        const e = re(de(a), "IMG");
        e.src = b;
        d && e.setAttribute("aria-label", d);
        ID(a, e);
        A(e, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: "pointer"
        });
        e.addEventListener("click", f => {
            c();
            f.stopPropagation()
        });
        return e
    }

    function KD(a, b) {
        const c = b.document.createElement("span");
        ID(b, c);
        A(c, {
            "line-height": "24px",
            cursor: "pointer"
        });
        c.appendChild(b.document.createTextNode(a.l));
        c.addEventListener("click", d => {
            a.i();
            d.stopPropagation()
        });
        return c
    }

    function LD(a, b) {
        const c = b.document.createElement("span");
        c.appendChild(b.document.createTextNode(a.j));
        A(c, Ov(b));
        A(c, {
            "border-top": "11px solid #ECEDED",
            "font-family": "Arial,sans-serif",
            "font-size": "12px",
            "line-height": "1414px",
            padding: "8px 32px",
            "text-align": "center"
        });
        return c
    }

    function MD(a) {
        const b = a.document.createElement("div");
        A(b, Ov(a));
        A(b, {
            "align-items": "flex-start",
            "background-color": "#FFF",
            "border-radius": "0px 20px 20px 0px",
            "box-shadow": "0px 1px 3px 1px rgba(60,64,67,0.5)",
            display: "inline-flex",
            "flex-direction": "column",
            "float": "left"
        });
        return b
    }
    class ND {
        constructor(a, b, c, d) {
            this.l = a;
            this.A = b;
            this.j = c;
            this.i = d;
            this.g = new V(!1)
        }
        Ma(a, b, c, d) {
            c = HD(a);
            const e = JD(a, "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg", d),
                f = JD(a, "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg", this.i),
                g = KD(this, a),
                h = JD(a, "https://www.gstatic.com/adsense/autoads/icons/close_24px_grey_700.svg", b, this.A);
            A(h, {
                "margin-left": "auto"
            });
            c.appendChild(e);
            c.appendChild(f);
            c.appendChild(g);
            c.appendChild(h);
            const k = LD(this, a);
            a = MD(a);
            a.appendChild(c);
            a.appendChild(k);
            this.g.listen(l => {
                A(e, {
                    display: l ? "none" : "inline"
                });
                A(f, {
                    display: l ? "inline" : "none"
                });
                l ? (A(g, {
                        "line-height": "24px",
                        "max-width": "100vw",
                        opacity: "1",
                        transition: "line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms"
                    }), A(h, {
                        "margin-right": "12px",
                        opacity: 1,
                        width: "24px",
                        transition: "margin 50ms, opacity 50ms 50ms, width 50ms"
                    }), A(k, {
                        "border-width": "1px",
                        "line-height": "14px",
                        "max-width": "100vw",
                        opacity: "1",
                        padding: "8px 32px",
                        transition: "border-width 0s 50ms, line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms, padding 50ms"
                    })) :
                    (A(g, {
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        transition: "line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms"
                    }), A(h, {
                        "margin-right": "0",
                        opacity: "0",
                        width: "0",
                        transition: "margin 50ms 50ms, opacity 50ms, width 50ms 50ms"
                    }), A(k, {
                        "border-width": "0px",
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        padding: "0",
                        transition: "border-width 0s 50ms, line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms, padding 50ms 50ms"
                    }))
            }, !0);
            return a
        }
        ig() {
            return 71
        }
        Mg() {
            this.g.g(!1);
            return 0
        }
        Ng() {
            this.g.g(!0)
        }
    }

    function ID(a, b) {
        A(b, Ov(a));
        A(b, {
            "font-family": "Arial,sans-serif",
            "font-weight": "bold",
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: "#1A73E8",
            "user-select": "none"
        })
    };
    var OD = class extends R {
        constructor() {
            super()
        }
    };

    function PD(a) {
        QD(a.i, b => {
            var c = a.l,
                d = b.vj,
                e = b.Yh,
                f = b.Gh;
            b = b.showRevocationMessage;
            (new yD(c, gD(c, a.j), new fD(d, b, "#1A73E8", "#FFF", "bold", "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_blue_600.svg", "2px solid #ECEDED", f), new ND(d, e, f, b), "google-revocation-link-placeholder")).L()
        }, () => {
            jw(a.g)
        })
    }
    class RD {
        constructor(a, b, c, d) {
            this.l = a;
            this.g = cw(b, 2147483643);
            this.j = c;
            this.i = d
        }
    };
    var SD = a => {
        if (!a || null == L(a, 1)) return !1;
        a = L(a, 1);
        switch (a) {
            case 1:
                return !0;
            case 2:
                return !1;
            default:
                throw Error("Unhandled AutoConsentUiStatus: " + a);
        }
    };

    function TD(a) {
        if (!0 !== a.i.adsbygoogle_ama_fc_has_run) {
            var b = !1;
            SD(a.g) && (b = new RD(a.i, a.A, a.l || D(a.g, or, 4), a.j), iw(b.g), PD(b), b = !0);
            var c;
            a: if ((c = a.g) && null != L(c, 3)) switch (c = L(c, 3), c) {
                case 1:
                    c = !0;
                    break a;
                case 2:
                    c = !1;
                    break a;
                default:
                    throw Error("Unhandled AutoCcpaUiStatus: " + c);
            } else c = !1;
            c && (FD(new GD(a.i, a.A, a.l || D(a.g, or, 4))), b = !0);
            c = (c = a.g) ? !0 === $h(c, 5) : !1;
            var d = a.g;
            d = (d ? !0 === $h(d, 6) : !1) || v(Ht);
            c && (b = !0);
            b && (b = new OD, b = Vi(b, 1, c && d), a.j.start(b), a.i.adsbygoogle_ama_fc_has_run = !0)
        }
    }
    class UD {
        constructor(a, b, c, d, e) {
            this.i = a;
            this.j = b;
            this.g = c;
            this.A = d;
            this.l = e || null
        }
    };

    function VD(a, b, c, d, e, f) {
        try {
            const g = a.g,
                h = We("SCRIPT", g);
            h.async = !0;
            Qe(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", () => {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", () => {
                0 < c ? VD(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (g) {
            f()
        }
    }

    function WD(a, b, c = () => {}, d = () => {}) {
        VD(de(a), b, 0, !1, c, d)
    };

    function XD(a = null) {
        a = a || r;
        return a.googlefc || (a.googlefc = {})
    };
    Rc(mo).map(a => Number(a));
    Rc(no).map(a => Number(a));
    const YD = r.URL;

    function ZD(a) {
        var b = (new YD(a.location.href)).searchParams;
        a = b.get("fcconsent");
        b = b.get("fc");
        return "alwaysshow" === b ? b : "alwaysshow" === a ? a : null
    }

    function $D(a) {
        const b = ["ab", "gdpr", "consent", "ccpa", "monetization"];
        return (a = (new YD(a.location.href)).searchParams.get("fctype")) && -1 !== b.indexOf(a) ? a : null
    };
    var aE = (a, b) => {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = We("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var bE = hj(class extends R {});

    function cE(a) {
        if (a.g) return a.g;
        a.I && a.I(a.l) ? a.g = a.l : a.g = nf(a.l, a.O);
        return a.g ? ? null
    }

    function dE(a) {
        a.C || (a.C = b => {
            try {
                var c = a.H ? a.H(b) : void 0;
                if (c) {
                    var d = c.bf,
                        e = a.F.get(d);
                    e && (e.ij || a.F.delete(d), e.wb ? .(e.gi, c.payload))
                }
            } catch (f) {}
        }, Sb(a.l, "message", a.C))
    }

    function eE(a, b, c) {
        if (cE(a))
            if (a.g === a.l)(b = a.A.get(b)) && b(a.g, c);
            else {
                var d = a.j.get(b);
                if (d && d.Rb) {
                    dE(a);
                    var e = ++a.T;
                    a.F.set(e, {
                        wb: d.wb,
                        gi: d.Dc(c),
                        ij: "addEventListener" === b
                    });
                    a.g.postMessage(d.Rb(c, e), "*")
                }
            }
    }
    var fE = class extends T {
        constructor(a, b, c, d) {
            super();
            this.O = b;
            this.I = c;
            this.H = d;
            this.A = new Map;
            this.T = 0;
            this.j = new Map;
            this.F = new Map;
            this.C = void 0;
            this.l = a
        }
        i() {
            delete this.g;
            this.A.clear();
            this.j.clear();
            this.F.clear();
            this.C && (Tb(this.l, "message", this.C), delete this.C);
            delete this.l;
            delete this.H;
            super.i()
        }
    };
    const gE = (a, b) => {
            const c = {
                cb: d => {
                    d = bE(d);
                    b.callback({
                        nb: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        hE = {
            Dc: a => a.callback,
            Rb: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            wb: (a, b) => {
                a({
                    nb: b
                })
            }
        };

    function iE(a) {
        a = bE(a.data.__fciReturn);
        return {
            payload: a,
            bf: yi(a, 1)
        }
    }

    function jE(a, b = !1) {
        if (b) return !1;
        a.j || (a.g = !!cE(a.caller), a.j = !0);
        return a.g
    }

    function kE(a) {
        return new Promise(b => {
            jE(a) && eE(a.caller, "getDataWithCallback", {
                command: "loaded",
                callback: c => {
                    b(c.nb)
                }
            })
        })
    }

    function lE(a, b) {
        jE(a) && eE(a.caller, "getDataWithCallback", {
            command: "prov",
            spsp: bj(b),
            callback: () => {}
        })
    }
    var mE = class extends T {
        constructor(a) {
            super();
            this.g = this.j = !1;
            this.caller = new fE(a, "googlefcPresent", void 0, iE);
            this.caller.A.set("getDataWithCallback", gE);
            this.caller.j.set("getDataWithCallback", hE)
        }
        i() {
            this.caller.la();
            super.i()
        }
    };
    const nE = a => {
        void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
        void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
        return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
    };

    function oE(a) {
        if (!1 === a.gdprApplies) return !0;
        void 0 === a.internalErrorState && (a.internalErrorState = nE(a));
        return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (Rj({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
    }

    function pE(a, b = {}) {
        return oE(a) ? !1 === a.gdprApplies ? !0 : "tcunavailable" === a.tcString || void 0 === a.gdprApplies && !b.Un || "string" !== typeof a.tcString || !a.tcString.length ? !b.Fi : qE(a, "1") : !1
    }

    function qE(a, b) {
        a: {
            if (a.publisher && a.publisher.restrictions) {
                var c = a.publisher.restrictions[b];
                if (void 0 !== c) {
                    c = c["755"];
                    break a
                }
            }
            c = void 0
        }
        if (0 === c) return !1;a.purpose && a.vendor ? (c = a.vendor.consents, (c = !(!c || !c["755"])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
        return b
    }

    function rE(a) {
        var b = ["3", "4"];
        return !1 === a.gdprApplies ? !0 : b.every(c => qE(a, c))
    }

    function sE(a) {
        if (a.g) return a.g;
        a.g = nf(a.j, "__tcfapiLocator");
        return a.g
    }

    function tE(a) {
        return "function" === typeof a.j.__tcfapi || null != sE(a)
    }

    function uE(a, b, c, d) {
        c || (c = () => {});
        if ("function" === typeof a.j.__tcfapi) a = a.j.__tcfapi, a(b, 2, c, d);
        else if (sE(a)) {
            vE(a);
            const e = ++a.H;
            a.C[e] = c;
            a.g && a.g.postMessage({
                __tcfapiCall: {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }
            }, "*")
        } else c({}, !1)
    }

    function wE(a, b) {
        let c = {
            internalErrorState: 0,
            internalBlockOnErrors: a.A
        };
        const d = Mb(() => b(c));
        let e = 0; - 1 !== a.F && (e = setTimeout(() => {
            e = 0;
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, a.F));
        uE(a, "addEventListener", f => {
            f && (c = f, c.internalErrorState = nE(c), c.internalBlockOnErrors = a.A, oE(c) ? (0 != c.internalErrorState && (c.tcString = "tcunavailable"), uE(a, "removeEventListener", null, c.listenerId), (f = e) && clearTimeout(f), d()) : ("error" === c.cmpStatus || 0 !== c.internalErrorState) && (f = e) && clearTimeout(f))
        })
    }

    function vE(a) {
        a.l || (a.l = b => {
            try {
                var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                a.C[c.callId](c.returnValue, c.success)
            } catch (d) {}
        }, Sb(a.j, "message", a.l))
    }
    class xE extends T {
        constructor(a, b = {}) {
            super();
            this.j = a;
            this.g = null;
            this.C = {};
            this.H = 0;
            this.F = b.timeoutMs ? ? 500;
            this.A = b.Mh ? ? !1;
            this.l = null
        }
        i() {
            this.C = {};
            this.l && (Tb(this.j, "message", this.l), delete this.l);
            delete this.C;
            delete this.j;
            delete this.g;
            super.i()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.A
            };
            const c = Mb(() => a(b));
            let d = 0; - 1 !== this.F && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.F));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = nE(b),
                    b.internalBlockOnErrors = this.A, g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                uE(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && uE(this, "removeEventListener", null, a.listenerId)
        }
    };

    function QD(a, b, c) {
        const d = XD(a.g);
        d.callbackQueue = d.callbackQueue || [];
        d.callbackQueue.push({
            CONSENT_DATA_READY: () => {
                const e = XD(a.g),
                    f = new xE(a.g);
                tE(f) && wE(f, g => {
                    300 === g.cmpId && g.tcString && "tcunavailable" !== g.tcString && b({
                        vj: e.getDefaultConsentRevocationText(),
                        Yh: e.getDefaultConsentRevocationCloseText(),
                        Gh: e.getDefaultConsentRevocationAttestationText(),
                        showRevocationMessage: () => e.showRevocationMessage()
                    })
                });
                c()
            }
        })
    }

    function yE(a, b) {
        var c = ZD(a.g);
        const d = $D(a.g);
        c = zE(a.i, {
            fc: c,
            fctype: d
        });
        WD(a.g, c, () => {}, () => {});
        b && lE(new mE(a.g), b)
    }

    function zE(a, b) {
        b = { ...b,
            ers: 2
        };
        return Zc(dd(new sb(ub, "https://fundingchoicesmessages.google.com/i/%{id}"), {
            id: a
        }), b)
    }
    class AE {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        start(a) {
            if (this.g === this.g.top) try {
                aE(this.g, "googlefcPresent"), yE(this, a)
            } catch (b) {}
        }
    };
    const BE = new Set(["ARTICLE", "SECTION"]);
    var CE = class {
        constructor(a) {
            this.g = a
        }
    };

    function DE(a, b) {
        return Array.from(b.classList).map(c => `${a}=${c}`)
    }

    function EE(a) {
        return 0 < a.classList.length
    }

    function FE(a) {
        return BE.has(a.tagName)
    };
    var GE = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function HE(a) {
        return za(a) && 1 == a.nodeType && "FIGURE" == a.tagName ? a : (a = a.parentNode) ? HE(a) : null
    };
    var IE = a => {
        var b = a.src;
        const c = a.getAttribute("data-src") || a.getAttribute("data-lazy-src");
        (b && b.startsWith("data:") && c ? c : b || c) ? (a.getAttribute("srcset"), b = (b = HE(a)) ? (b = b.getElementsByTagName("figcaption")[0]) ? b.textContent : null : null, a = new GE(a, b || a.getAttribute("alt") || null)) : a = null;
        return a
    };
    var JE = class {
        constructor() {
            this.map = new Map
        }
        clear() {
            this.map.clear()
        }
        delete(a, b) {
            const c = this.map.get(a);
            return c ? (b = c.delete(b), 0 === c.size && this.map.delete(a), b) : !1
        }
        get(a) {
            return [...(this.map.get(a) ? ? [])]
        }
        keys() {
            return this.map.keys()
        }
        add(a, b) {
            let c = this.map.get(a);
            c || this.map.set(a, c = new Set);
            c.add(b)
        }
        get size() {
            let a = 0;
            for (const b of this.map.values()) a += b.size;
            return a
        }
        values() {
            const a = this.map;
            return function*() {
                for (const b of a.values()) yield* b
            }()
        }[Symbol.iterator]() {
            const a = this.map;
            return function*() {
                for (const [b,
                        c
                    ] of a) {
                    const d = b,
                        e = c;
                    for (const f of e) yield [d, f]
                }
            }()
        }
    };

    function KE(a) {
        return [a[0],
            [...a[1]]
        ]
    };

    function LE(a) {
        return Array.from(ME(a).map.values()).filter(b => 3 <= b.size).map(b => [...b])
    }

    function NE(a, b) {
        return b.every(c => {
            var d = a.g.getBoundingClientRect(c.g);
            if (d = 50 <= d.height && d.width >= a.A) {
                var e = a.g.getBoundingClientRect(c.g);
                d = a.l;
                e = new ty(e.left, e.right);
                d = Math.max(d.start, e.start) <= Math.min(d.end, e.end)
            }
            return d && null === To(a.j, {
                gb: c.g,
                Za: OE,
                Fb: !0
            })
        })
    }

    function PE(a) {
        return LE(a).sort(QE).find(b => NE(a, b)) || []
    }

    function ME(a) {
        return RE(Array.from(a.win.document.getElementsByTagName("IMG")).map(IE).filter(pq), b => {
            var c = [...DE("CLASS_NAME", b.g)],
                d = b.g.parentElement;
            d = [...(d ? DE("PARENT_CLASS_NAME", d) : [])];
            var e = b.g.parentElement ? .parentElement;
            e = [...(e ? DE("GRANDPARENT_CLASS_NAME", e) : [])];
            var f = (f = To(a.i.g, {
                gb: b.g,
                Za: EE
            })) ? DE("NEAREST_ANCESTOR_CLASS_NAME", f) : [];
            return [...c, ...d, ...e, ...f, ...(b.i ? ["HAS_CAPTION=true"] : []), ...(To(a.i.g, {
                gb: b.g,
                Za: FE
            }) ? ["ARTICLE_LIKE_ANCESTOR=true"] : [])]
        })
    }
    var SE = class {
        constructor(a, b, c, d, e) {
            var f = new Ip;
            this.win = a;
            this.l = b;
            this.A = c;
            this.g = f;
            this.j = d;
            this.i = e
        }
    };

    function RE(a, b) {
        const c = new JE;
        for (const d of a)
            for (const e of b(d)) c.add(e, d);
        return c
    }

    function OE(a) {
        return "A" === a.tagName && a.hasAttribute("href")
    }

    function QE(a, b) {
        return b.length - a.length
    };

    function TE(a) {
        const b = a.l.parentNode;
        if (!b) throw Error("Image not in the DOM");
        const c = UE(a.j),
            d = VE(a.j);
        c.appendChild(d);
        b.insertBefore(c, a.l.nextSibling);
        a.A.g().i(e => {
            var f = a.j;
            const g = d.getBoundingClientRect(),
                h = g.top - e.top,
                k = g.left - e.left,
                l = g.width - e.width;
            e = g.height - e.height;
            1 > Math.abs(h) && 1 > Math.abs(k) && 1 > Math.abs(l) && 1 > Math.abs(e) || (f = f.getComputedStyle(d), A(d, {
                top: parseInt(f.top, 10) - h + "px",
                left: parseInt(f.left, 10) - k + "px",
                width: parseInt(f.width, 10) - l + "px",
                height: parseInt(f.height, 10) - e + "px"
            }))
        });
        return d
    }

    function WE(a) {
        a.g || (a.g = TE(a));
        return a.g
    }
    var XE = class extends T {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.l = b;
            this.A = c;
            this.g = null
        }
        i() {
            if (this.g) {
                var a = this.g;
                const b = a.parentNode;
                b && b.removeChild(a);
                this.g = null
            }
            super.i()
        }
    };

    function VE(a) {
        const b = a.document.createElement("div");
        A(b, Ov(a));
        A(b, {
            position: "absolute",
            left: "0",
            top: "0",
            width: "0",
            height: "0",
            "pointer-events": "none"
        });
        return b
    }

    function UE(a) {
        const b = a.document.createElement("div");
        A(b, Ov(a));
        A(b, {
            position: "relative",
            width: "0",
            height: "0"
        });
        return b
    };

    function YE(a) {
        const b = new V(a.dataset.adStatus || null);
        (new MutationObserver(() => {
            b.g(a.dataset.adStatus || null)
        })).observe(a, {
            attributes: !0
        });
        return fp(b)
    };
    const ZE = ["Google Material Icons", "Roboto"];

    function $E({
        win: a,
        Aa: b,
        Gi: c,
        webPropertyCode: d,
        La: e,
        ba: f
    }) {
        const g = new Kp(a, c);
        c = new XE(a, c, g);
        Yo(c, g);
        a = new aF(a, d, e, b, c, f);
        Yo(a, c);
        a.L()
    }
    var aF = class extends T {
        constructor(a, b, c, d, e, f) {
            super();
            this.win = a;
            this.webPropertyCode = b;
            this.La = c;
            this.Aa = d;
            this.j = e;
            this.ba = f;
            this.g = new V(!1)
        }
        L() {
            const a = bF(this.win, this.webPropertyCode, this.La);
            WE(this.j).appendChild(a.oi);
            xv(this.win, a.wa);
            YE(a.wa).i(b => {
                if (null !== b) {
                    switch (b) {
                        case "unfilled":
                            this.la();
                            break;
                        case "filled":
                            this.g.g(!0);
                            break;
                        default:
                            this.ba ? .reportError("Unhandled AdStatus: " + String(b)), this.la()
                    }
                    this.ba ? .rj(this.Aa, b)
                }
            });
            ip(this.g, !0, () => void a.Oi.g(!0));
            a.ji.listen(() => void this.la());
            a.ii.listen(() => void this.ba ? .pj(this.Aa))
        }
    };

    function bF(a, b, c) {
        const d = new V(!1),
            e = a.document.createElement("div");
        A(e, Ov(a));
        A(e, {
            position: "absolute",
            top: "50%",
            left: "0",
            transform: "translateY(-50%)",
            width: "100%",
            height: "100%",
            overflow: "hidden",
            "background-color": "rgba(0, 0, 0, 0.75)",
            opacity: "0",
            transition: "opacity 0.25s ease-in-out",
            "box-sizing": "border-box",
            padding: "40px 5px 5px 5px"
        });
        W(d, !0, () => void A(e, {
            opacity: "1"
        }));
        W(d, !1, () => void A(e, {
            opacity: "0"
        }));
        const f = a.document.createElement("div");
        A(f, Ov(a));
        A(f, {
            display: "block",
            width: "100%",
            height: "100%"
        });
        e.appendChild(f);
        const {
            yh: g,
            Ni: h
        } = cF(a, b);
        f.appendChild(g);
        e.appendChild(dF(a, O(c, 1)));
        b = eF(a, O(c, 2));
        e.appendChild(b.Sh);
        b.ne.listen(() => void d.g(!1));
        return {
            Oi: d,
            oi: e,
            wa: h,
            ii: b.ne,
            ji: b.ne.delay(a, 450)
        }
    }

    function dF(a, b) {
        const c = a.document.createElement("div");
        A(c, Ov(a));
        A(c, {
            position: "absolute",
            top: "10px",
            width: "100%",
            color: "white",
            "font-family": "Roboto",
            "font-size": "12px",
            "line-height": "16px",
            "text-align": "center"
        });
        c.appendChild(a.document.createTextNode(b));
        return c
    }

    function eF(a, b) {
        const c = a.document.createElement("button");
        c.setAttribute("aria-label", b);
        A(c, Ov(a));
        A(c, {
            position: "absolute",
            top: "10px",
            right: "10px",
            display: "block",
            cursor: "pointer",
            width: "24px",
            height: "24px",
            "font-size": "24px",
            "user-select": "none",
            color: "white"
        });
        b = a.document.createElement("gm-icon");
        b.className = "google-material-icons";
        b.appendChild(a.document.createTextNode("close"));
        c.appendChild(b);
        const d = new qp;
        c.addEventListener("click", () => void pp(d));
        return {
            Sh: c,
            ne: np(d)
        }
    }

    function cF(a, b) {
        a = tv(a.document, b, null, null, {});
        return {
            yh: a.ob,
            Ni: a.wa
        }
    };

    function fF({
        target: a,
        threshold: b = 0
    }) {
        const c = new gF;
        c.L(a, b);
        return c
    }
    var gF = class extends T {
        constructor() {
            super();
            this.g = new V(!1)
        }
        L(a, b) {
            const c = new IntersectionObserver(d => {
                for (const e of d)
                    if (e.target === a) {
                        this.g.g(e.isIntersecting);
                        break
                    }
            }, {
                threshold: b
            });
            c.observe(a);
            Zo(this, () => void c.disconnect())
        }
    };

    function hF(a) {
        const b = iF(a.win, Ti(a.g, 2) ? ? 250, Ti(a.g, 3) ? ? 300);
        let c = 1;
        return PE(a.l).map(d => ({
            Aa: c++,
            image: d,
            hb: b(d)
        }))
    }

    function jF(a, b) {
        const c = fF({
            target: b.image.g,
            threshold: Ui(a.g) ? ? .8
        });
        a.j.push(c);
        ip(lp(c.g, a.win, Ti(a.g, 5) ? ? 3E3, d => d), !0, () => {
            if (a.i < (Ti(a.g, 1) ? ? 1)) {
                $E({
                    win: a.win,
                    Aa: b.Aa,
                    Gi: b.image.g,
                    webPropertyCode: a.webPropertyCode,
                    La: a.La,
                    ba: a.ba
                });
                a.i++;
                if (!(a.i < (Ti(a.g, 1) ? ? 1)))
                    for (; a.j.length;) a.j.pop() ? .la();
                a.ba ? .qj(b.Aa)
            }
        })
    }

    function kF(a) {
        const b = hF(a);
        b.filter(lF).forEach(c => void jF(a, c));
        a.ba ? .sj(b.map(c => ({
            Aa: c.Aa,
            hb: c.hb
        })))
    }
    var mF = class {
        constructor(a, b, c, d, e, f) {
            this.win = a;
            this.webPropertyCode = b;
            this.g = c;
            this.La = d;
            this.l = e;
            this.ba = f;
            this.j = [];
            this.i = 0
        }
    };

    function lF(a) {
        return 0 === a.hb.rejectionReasons.length
    }

    function iF(a, b, c) {
        const d = S(a);
        return e => {
            e = e.g.getBoundingClientRect();
            const f = [];
            e.width < b && f.push(1);
            e.height < c && f.push(2);
            e.top <= d && f.push(3);
            return {
                Bb: e.width,
                Je: e.height,
                ki: e.top - d,
                rejectionReasons: f
            }
        }
    };

    function nF(a, b) {
        a.Aa = b;
        return a
    }
    var oF = class {
        constructor(a, b, c, d, e) {
            this.A = a;
            this.webPropertyCode = b;
            this.hostname = c;
            this.j = d;
            this.l = e;
            this.errorMessage = this.i = this.Aa = this.g = null
        }
    };

    function pF(a, b) {
        return new oF(b, a.webPropertyCode, a.hostname, a.i, a.l)
    }

    function qF(a, b, c) {
        var d = a.j++;
        null === a.g ? (a.g = al(), a = 0) : a = al() - a.g;
        var e = b.A,
            f = b.webPropertyCode,
            g = b.hostname,
            h = b.j,
            k = b.l.map(encodeURIComponent).join(",");
        if (b.g) {
            var l = {
                imcnt: b.g.length
            };
            var m = Math.min(b.g.length, 10);
            for (let n = 0; n < m; n++) {
                const p = `im${n}`;
                l[`${p}_id`] = b.g[n].Aa;
                l[`${p}_s_w`] = b.g[n].hb.Bb;
                l[`${p}_s_h`] = b.g[n].hb.Je;
                l[`${p}_s_dbf`] = b.g[n].hb.ki;
                0 < b.g[n].hb.rejectionReasons.length && (l[`${p}_s_rej`] = b.g[n].hb.rejectionReasons.join(","))
            }
        } else l = null;
        aA("abg::imovad", {
            typ: e,
            wpc: f,
            hst: g,
            pvsid: h,
            peid: k,
            rate: c,
            num: d,
            tim: a,
            ...(null === b.Aa ? {} : {
                imid: b.Aa
            }),
            ...(null === b.i ? {} : {
                astat: b.i
            }),
            ...(null === b.errorMessage ? {} : {
                errm: b.errorMessage
            }),
            ...l
        }, c)
    }
    var rF = class {
        constructor(a, b, c, d) {
            this.webPropertyCode = a;
            this.hostname = b;
            this.i = c;
            this.l = d;
            this.j = 0;
            this.g = null
        }
        sj(a) {
            var b = pF(this, "fndi");
            b.g = a;
            qF(this, b, 0 < a.length ? 1 : .1)
        }
        qj(a) {
            a = nF(pF(this, "adpl"), a);
            qF(this, a, 1)
        }
        rj(a, b) {
            a = nF(pF(this, "adst"), a);
            a.i = b;
            qF(this, a, 1)
        }
        pj(a) {
            a = nF(pF(this, "adis"), a);
            qF(this, a, 1)
        }
        reportError(a) {
            var b = pF(this, "err");
            b.errorMessage = a;
            qF(this, b, .1)
        }
    };

    function sF(a, b, c) {
        return (a = Cr(a)) && $h(a, 11) ? c.map(d => d.j()) : c.map(d => d.A(b))
    };
    var tF = class extends R {
        getHeight() {
            return xi(this, 2)
        }
    };

    function uF(a, b) {
        return Xi(a, 1, b)
    }

    function vF(a, b) {
        return si(a, 2, b)
    }
    var wF = class extends R {};
    wF.P = [2];
    var xF = class extends R {
        constructor() {
            super()
        }
    };
    xF.P = [5];
    var yF = class extends R {
            constructor() {
                super()
            }
        },
        zF = [1, 2];
    const AF = new Set([7, 1]);
    var BF = class {
        constructor() {
            this.j = new JE;
            this.l = []
        }
        g(a, b) {
            AF.has(b) || lq(kq(fB(a), c => void this.j.add(c, b)), c => void this.l.push(c))
        }
        i(a, b) {
            for (const c of a) this.g(c, b)
        }
    };

    function CF(a) {
        return new Bq(["pedestal_container"], {
            google_reactive_ad_format: 30,
            google_phwr: 2.189,
            google_ad_width: Math.floor(a),
            google_ad_format: "autorelaxed",
            google_full_width_responsive: !0,
            google_enable_content_recommendations: !0,
            google_content_recommendation_ui_type: "pedestal"
        })
    }
    class DF {
        g(a) {
            return CF(Math.floor(a.yc()))
        }
    };
    var EF = class extends R {
        constructor() {
            super()
        }
    };

    function FF(a, b) {
        var c = b.adClient;
        if ("string" !== typeof c || !c) return !1;
        a.Yd = c;
        a.j = !!b.adTest;
        c = b.pubVars;
        za(c) && (a.D = c);
        if (Array.isArray(b.fillMessage) && 0 < b.fillMessage.length) {
            a.B = {};
            for (const d of b.fillMessage) a.B[d.key] = d.value
        }
        a.l = b.adWidth;
        a.i = b.adHeight;
        Kk(a.l) && Kk(a.i) || aA("rctnosize", b);
        return !0
    }
    var GF = class {
        constructor() {
            this.B = this.D = this.j = this.Yd = null;
            this.i = this.l = 0
        }
        C() {
            return !0
        }
    };

    function HF(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            const b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return "__storage_test__" === b
        } catch (b) {
            return !1
        }
    }

    function IF(a, b = []) {
        const c = Date.now();
        return Xa(b, d => c - d < 1E3 * a)
    }

    function JF(a, b) {
        try {
            const c = a.getItem("__lsv__");
            if (!c) return [];
            let d;
            try {
                d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || ab(d, e => !Number.isInteger(e))) return a.removeItem("__lsv__"), [];
            d = IF(b, d);
            d.length || a ? .removeItem("__lsv__");
            return d
        } catch (c) {
            return null
        }
    }

    function KF(a, b) {
        return 0 >= b || null == a || !HF(a) ? null : JF(a, b)
    };
    var LF = (a, b, c) => {
        let d = 0;
        try {
            d |= uo(a);
            d |= xo(a);
            d |= vo(a);
            d |= a.innerHeight >= a.innerWidth ? 0 : 8;
            d |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            var e;
            if (e = b) {
                var f = KF(c, 3600);
                e = !(f && 1 > f.length)
            }
            e && (d |= 134217728);
            v(Db) && (d |= 128)
        } catch (g) {
            d |= 32
        }
        return d
    };
    var MF = class extends GF {
        constructor() {
            super(...arguments);
            this.A = !1;
            this.g = null
        }
        C(a) {
            this.A = !!a.enableAma;
            if (a = a.amaConfig) try {
                var b = Er(a)
            } catch (c) {
                b = null
            } else b = null;
            this.g = b;
            return !0
        }
    };
    const NF = {};

    function OF(a, b, c) {
        let d = PF(a, c, b);
        if (!d) return !0;
        let e = -1;
        const f = c.C.Mb();
        for (; d.Zb && d.Zb.length;) {
            const h = d.Zb.shift();
            var g = HA(h.ga);
            const k = h.ja.g,
                l = !!c.j.mf || !!c.j.vf || c.Xa() || !!c.j.Xf || v(qt) || k > e;
            g = !g || g <= d.Xc;
            if (!l) c.B ? .g(h, 20);
            else if (!g) c.B ? .g(h, 18);
            else if (QF(c, h, {
                    Dd: d.Xc
                })) {
                e = k;
                if (d.Sc.g.length + 1 >= f) return c.B ? .i(d.Zb, 19), !0;
                d = PF(a, c, b);
                if (!d) return !0
            }
        }
        return c.l
    }
    const PF = (a, b, c) => {
        var d = b.C.Mb(),
            e = b.C.l,
            f = b.C;
        f = QB(b.da(), f.g ? f.g.lc : void 0, d);
        if (f.g.length >= d) return b.B ? .i(RF(b, f, {
            types: a
        }, c), 19), null;
        e ? (d = f.i || (f.i = Ao(f.j).scrollHeight || null), e = !d || 0 > d ? -1 : f.i * e - WB(f)) : e = void 0;
        const g = (d = null == e || 50 <= e) ? RF(b, f, {
            types: a
        }, c) : null;
        d || b.B ? .i(RF(b, f, {
            types: a
        }, c), 18);
        return {
            Sc: f,
            Xc: e,
            Zb: g
        }
    };
    NF[2] = Ja(function(a, b) {
        a = RF(b, QB(b.da()), {
            types: a,
            Db: yB(b.da())
        }, 2);
        if (0 == a.length) return !0;
        for (var c = 0; c < a.length; c++)
            if (QF(b, a[c])) return !0;
        return b.l ? (b.A.push(11), !0) : !1
    }, [0]);
    NF[5] = Ja(OF, [0], 5);
    NF[10] = Ja(function(a, b) {
        a = [];
        const c = b.Ha;
        c.includes(3) && a.push(2);
        c.includes(1) && a.push(0);
        c.includes(2) && !v(ft) && a.push(1);
        return OF(a, 10, b)
    }, 10);
    NF[3] = function(a) {
        if (!a.l) return !1;
        var b = RF(a, QB(a.da()), {
            types: [0],
            Db: yB(a.da())
        }, 3);
        if (0 == b.length) return !0;
        for (var c = b.length - 1; 0 <= c; c--)
            if (QF(a, b[c])) return !0;
        a.A.push(11);
        return !0
    };
    const SF = a => {
            var b;
            a.j.oh ? b = v(ht) ? new tB(0, null, [], 8, .3) : new tB(0, null, [], 3, null) : b = yB(a.da());
            return {
                types: [0],
                Db: b
            }
        },
        UF = a => {
            const b = a.da().document.body.getBoundingClientRect().width;
            TF(a, CF(b))
        },
        WF = (a, b) => {
            var c = SF(a);
            c.tj = [5];
            c = RF(a, QB(a.da()), c, 8);
            VF(a, c.reverse(), b)
        },
        VF = (a, b, c) => {
            for (const d of b)
                if (b = c.g(d.ja), QF(a, d, {
                        Zd: b
                    })) return !0;
            return !1
        };
    NF[8] = function(a) {
        var b = a.da().document;
        if ("complete" != b.readyState) return b.addEventListener("readystatechange", () => NF[8](a), {
            once: !0
        }), !0;
        if (!a.l) return !1;
        if (!a.Bd()) return !0;
        b = SF(a);
        b.ef = [2, 4, 5];
        b = RF(a, QB(a.da()), b, 8);
        const c = new DF;
        if (VF(a, b, c)) return !0;
        if (a.j.eg) switch (a.j.Pg || 0) {
            case 1:
                WF(a, c);
                break;
            default:
                UF(a)
        }
        return !0
    };
    NF[6] = Ja(OF, [2], 6);
    NF[7] = Ja(OF, [1], 7);
    NF[9] = function(a) {
        const b = PF([0, 2], a, 9);
        if (!b || !b.Zb) return a.A.push(17), a.l;
        for (const d of b.Zb) {
            var c = a.j.Ee || null;
            null == c ? c = null : (c = IA(d.ga, new XF, new YF(c, a.da())), c = new hB(c, d.ia(), d.ja));
            if (c && !(HA(c.ga) > b.Xc) && QF(a, c, {
                    Dd: b.Xc,
                    me: !0
                })) return a = c.ga.Z, FA(d.ga, 0 < a.length ? a[0] : null), !0
        }
        a.A.push(17);
        return a.l
    };
    class XF {
        i(a, b, c, d) {
            return wv(d.document, a, b)
        }
        j(a) {
            return S(a) || 0
        }
    };
    var ZF = class {
        constructor(a, b, c) {
            this.i = a;
            this.g = b;
            this.Sc = c
        }
        Ea(a) {
            return this.g ? sC(this.i, this.g, a, this.Sc) : rC(this.i, a, this.Sc)
        }
        ya() {
            return this.g ? 16 : 9
        }
    };
    var $F = class {
        constructor(a) {
            this.ae = a
        }
        Ea(a) {
            return zC(a.document, this.ae)
        }
        ya() {
            return 11
        }
    };
    var aG = class {
        constructor(a) {
            this.vb = a
        }
        Ea(a) {
            return wC(this.vb, a)
        }
        ya() {
            return 13
        }
    };
    var bG = class {
        Ea(a) {
            return pC(a)
        }
        ya() {
            return 12
        }
    };
    var cG = class {
        constructor(a) {
            this.tc = a
        }
        Ea() {
            return uC(this.tc)
        }
        ya() {
            return 2
        }
    };
    var dG = class {
        constructor(a) {
            this.g = a
        }
        Ea() {
            return xC(this.g)
        }
        ya() {
            return 3
        }
    };
    var eG = class {
        Ea() {
            return AC()
        }
        ya() {
            return 17
        }
    };
    var fG = class {
        constructor(a) {
            this.g = a
        }
        Ea() {
            return tC(this.g)
        }
        ya() {
            return 1
        }
    };
    var gG = class {
        Ea() {
            return Ib(zA)
        }
        ya() {
            return 7
        }
    };
    var hG = class {
        constructor(a) {
            this.ef = a
        }
        Ea() {
            return vC(this.ef)
        }
        ya() {
            return 6
        }
    };
    var iG = class {
        constructor(a) {
            this.g = a
        }
        Ea() {
            return yC(this.g)
        }
        ya() {
            return 5
        }
    };
    var jG = class {
        constructor(a, b) {
            this.minWidth = a;
            this.maxWidth = b
        }
        Ea() {
            return Ja(BC, this.minWidth, this.maxWidth)
        }
        ya() {
            return 10
        }
    };
    var kG = class {
        constructor(a) {
            this.l = a.i.slice(0);
            this.i = a.g.slice(0);
            this.j = a.j;
            this.A = a.l;
            this.g = a.A
        }
    };

    function lG(a) {
        var b = new mG;
        b.A = a;
        b.i.push(new fG(a));
        return b
    }

    function nG(a, b) {
        a.i.push(new hG(b));
        return a
    }

    function oG(a, b) {
        a.i.push(new cG(b));
        return a
    }

    function pG(a, b) {
        a.i.push(new iG(b));
        return a
    }

    function qG(a, b) {
        a.i.push(new dG(b));
        return a
    }

    function rG(a) {
        a.i.push(new gG);
        return a
    }

    function sG(a) {
        a.g.push(new bG);
        return a
    }

    function tG(a, b = 0, c, d) {
        a.g.push(new ZF(b, c, d));
        return a
    }

    function uG(a, b = 0, c = Infinity) {
        a.g.push(new jG(b, c));
        return a
    }

    function vG(a) {
        a.g.push(new eG);
        return a
    }

    function wG(a, b = 0) {
        a.g.push(new aG(b));
        return a
    }

    function xG(a, b) {
        a.j = b;
        return a
    }
    var mG = class {
        constructor() {
            this.j = 0;
            this.l = !1;
            this.i = [].slice(0);
            this.g = [].slice(0)
        }
        build() {
            return new kG(this)
        }
    };
    class YF {
        constructor(a, b) {
            this.i = a;
            this.j = b
        }
        g() {
            var a = this.i,
                b = this.j;
            const c = a.D || {};
            c.google_ad_client = a.Yd;
            c.google_ad_height = S(b) || 0;
            c.google_ad_width = wo(b) || 0;
            c.google_reactive_ad_format = 9;
            b = new EF;
            b = Vi(b, 1, a.A);
            a.g && E(b, 2, a.g);
            c.google_rasc = bj(b);
            a.j && (c.google_adtest = "on");
            return new Bq(["fsi_container"], c)
        }
    };
    var yG = uq(new rq(0, {})),
        zG = uq(new rq(1, {})),
        AG = a => a === yG || a === zG;

    function BG(a, b, c) {
        Lo(a.g, b) || a.g.set(b, []);
        a.g.get(b).push(c)
    }
    class CG {
        constructor() {
            this.g = new Po
        }
    };

    function DG(a, b) {
        b && (a.g.apv = I(b, 4), Xh(b, Yq, 23) && (a.g.sat = "" + vi(C(b, Yq, 23), 1)));
        return a
    }

    function EG(a, b) {
        a.g.afm = b.join(",");
        return a
    }
    var FG = class extends Vz {
        constructor(a) {
            super(a);
            this.g = {}
        }
        H(a) {
            this.g.a = a.join(",");
            return this
        }
        G(a) {
            null != a && (this.g.allp = a);
            return this
        }
        fh(a) {
            if (a) {
                const b = [];
                for (const c of No(a))
                    if (0 < a.get(c).length) {
                        const d = a.get(c)[0];
                        b.push("(" + [c, d.kb, d.rh].join() + ")")
                    }
                this.g.fd = b.join(",")
            }
            return this
        }
        l(a) {
            try {
                this.g.su = a.location.hostname
            } catch (b) {
                this.g.su = "_ex"
            }
            a = super.l(a);
            Uc(a, this.g);
            return a
        }
    };

    function GG(a) {
        return null == a ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function HG(a, b, c, d = 30) {
        c.length <= d ? a[b] = IG(c) : (a[b] = IG(c.slice(0, d)), a[b + "_c"] = c.length.toString())
    }

    function IG(a) {
        const b = 0 < a.length && "string" === typeof a[0];
        a = a.map(c => c ? .toString() ? ? "null");
        b && (a = a.map(c => ka(c, "replaceAll").call(c, "~", "")));
        return a.join("~")
    }

    function JG(a) {
        return null == a ? "null" : "string" === typeof a ? a : "boolean" === typeof a ? a ? "1" : "0" : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function KG(a, b) {
        a.i.op = JG(b)
    }

    function LG(a, b, c) {
        HG(a.i, "fap", b);
        a.i.fad = JG(c)
    }

    function MG(a, b, c) {
        HG(a.i, "fmp", b);
        a.i.fmd = JG(c)
    }

    function NG(a, b, c) {
        HG(a.i, "vap", b);
        a.i.vad = JG(c)
    }

    function OG(a, b, c) {
        HG(a.i, "vmp", b);
        a.i.vmd = JG(c)
    }

    function PG(a, b, c) {
        HG(a.i, "pap", b);
        a.i.pad = JG(c)
    }

    function QG(a, b, c) {
        HG(a.i, "pmp", b);
        a.i.pmd = JG(c)
    }

    function RG(a, b) {
        HG(a.i, "psq", b)
    }
    var SG = class extends FG {
        constructor(a) {
            super(0);
            Object.assign(this, a);
            this.i = {};
            this.errors = []
        }
        l(a) {
            a = super.l(a);
            Object.assign(a, this.i);
            0 < this.errors.length && (a.e = IG(this.errors));
            return a
        }
    };

    function TG(a, b, c) {
        const d = b.ga;
        Lo(a.g, d) || a.g.set(d, new UG(jq(fB(b)) ? ? ""));
        c(a.g.get(d))
    }

    function VG(a, b) {
        TG(a, b, c => {
            c.g = !0
        })
    }

    function WG(a, b) {
        TG(a, b, c => {
            c.i = !0
        })
    }

    function XG(a, b) {
        TG(a, b, c => {
            c.j = !0
        });
        a.I.push(b.ga)
    }

    function YG(a, b, c) {
        TG(a, b, d => {
            d.Sb = c
        })
    }

    function ZG(a, b, c) {
        const d = [];
        let e = 0;
        for (const f of c.filter(b)) AG(f.Sb ? ? "") ? ++e : (b = a.i.get(f.Sb ? ? "", null), d.push(b));
        return {
            list: d.sort((f, g) => (f ? ? -1) - (g ? ? -1)),
            Tb: e
        }
    }

    function $G(a, b) {
        KG(b, a.i.xc());
        var c = Oo(a.g).filter(f => 0 === (f.yb.startsWith(yG) ? 0 : 1)),
            d = Oo(a.g).filter(f => 1 === (f.yb.startsWith(yG) ? 0 : 1)),
            e = ZG(a, f => f.g, c);
        LG(b, e.list, e.Tb);
        e = ZG(a, f => f.g, d);
        MG(b, e.list, e.Tb);
        e = ZG(a, f => f.i, c);
        NG(b, e.list, e.Tb);
        e = ZG(a, f => f.i, d);
        OG(b, e.list, e.Tb);
        c = ZG(a, f => f.j, c);
        PG(b, c.list, c.Tb);
        d = ZG(a, f => f.j, d);
        QG(b, d.list, d.Tb);
        RG(b, a.I.map(f => a.g.get(f) ? .Sb).map(f => a.i.get(f) ? ? null))
    }

    function fm() {
        var a = u(aH);
        if (!a.A) return Vl();
        const b = dm(cm(bm(am($l(Zl(Yl(Xl(Ul(Tl(new Wl, a.A ? ? []), a.H ? ? []), a.B), a.G), a.F), a.O), a.T), a.C ? ? 0), Oo(a.g).map(c => {
            var d = new Sl;
            d = aj(d, 1, c.yb);
            var e = a.i.get(c.Sb ? ? "", -1);
            d = P(d, 2, e);
            d = Wi(d, 3, c.g);
            return Wi(d, 4, c.i)
        })), a.I.map(c => a.g.get(c) ? .Sb).map(c => a.i.get(c) ? ? -1));
        null != a.j && Wi(b, 6, a.j);
        null != a.l && ki(b, 13, rh(a.l), "0");
        return b
    }
    var aH = class {
        constructor() {
            this.l = this.H = this.A = null;
            this.F = this.G = !1;
            this.j = null;
            this.T = this.B = this.O = !1;
            this.C = null;
            this.i = new Po;
            this.g = new Po;
            this.I = []
        }
    };
    class UG {
        constructor(a) {
            this.j = this.i = this.g = !1;
            this.Sb = null;
            this.yb = a
        }
    };
    class bH {
        constructor(a = 0) {
            this.g = a
        }
    };
    class cH {
        constructor(a) {
            this.i = a;
            this.g = -1
        }
    };

    function dH(a) {
        let b = 0;
        for (; a;)(!b || a.previousElementSibling || a.nextElementSibling) && b++, a = a.parentElement;
        return b
    };

    function eH(a, b) {
        const c = a.H.filter(d => No(d.hd).every(e => d.hd.get(e) === b.get(e)));
        return 0 === c.length ? (a.i.push(19), null) : c.reduce((d, e) => d.hd.xc() > e.hd.xc() ? d : e, c[0])
    }

    function fH(a, b) {
        b = fB(b);
        if (null == b.g) return a.i.push(18), null;
        b = b.getValue();
        if (Lo(a.j, b)) return a.j.get(b);
        var c = sq(b);
        c = eH(a, c);
        a.j.set(b, c);
        return c
    }
    var gH = class {
        constructor(a) {
            this.g = a;
            this.j = new Po;
            this.H = (C(a, zr, 2) ? .g() || []).map(b => {
                const c = sq(O(b, 1)),
                    d = yi(b, 2);
                return {
                    hd: c,
                    Ug: d,
                    yb: O(b, 1)
                }
            });
            this.i = []
        }
        F() {
            const a = u(aH);
            var b = this.l();
            a.A = b;
            b = this.B();
            a.H = b;
            b = this.A();
            null != b && (a.l = b);
            b = !!this.g.j() ? .g() ? .g();
            a.F = b;
            b = new Po;
            for (const c of C(this.g, zr, 2) ? .g() ? ? []) b.set(O(c, 1), yi(c, 2));
            a.i = b
        }
        C() {
            return [...this.i]
        }
        l() {
            return [...this.g.g()]
        }
        B() {
            return [...ai(this.g, 4, ph, 2, void 0, void 0, 0)]
        }
        A() {
            return C(this.g, tr, 5) ? .g() ? ? null
        }
        G(a) {
            const b = fH(this,
                a);
            null != b ? .yb && YG(u(aH), a, b.yb)
        }
        I(a) {
            const b = w(It) || 0;
            if (0 == a.length || 0 == b) return !0;
            const c = (new bq(a)).filter(d => {
                d = fH(this, d) ? .yb || "";
                return "" != d && !(d === yG || d === zG)
            });
            return b <= c.g.length / a.length
        }
    };

    function hH(a, b) {
        return 0 == b.g.length ? b : b.sort((c, d) => (fH(a.g, c) ? .Ug ? ? Number.MAX_VALUE) - (fH(a.g, d) ? .Ug ? ? Number.MAX_VALUE))
    }

    function iH(a, b) {
        var c = b.ja.g,
            d = Math,
            e = d.min;
        const f = b.ia(),
            g = b.ga.g();
        c += 200 * e.call(d, 20, 0 == g || 3 == g ? dH(f.parentElement) : dH(f));
        d = a.j;
        0 > d.g && (d.g = Ao(d.i).scrollHeight || 0);
        d = d.g - b.ja.g;
        c += 1E3 < d ? 0 : 2 * (1E3 - d);
        a = a.i;
        b = b.ia();
        return c + ("string" === typeof b.className && 0 <= b.className.indexOf("adsbygoogle-ablated-ad-slot") ? a.g : 0)
    }

    function jH(a, b) {
        return 0 == b.g.length ? b : b.sort((c, d) => iH(a, c) - iH(a, d))
    }

    function kH(a, b) {
        return b.sort((c, d) => {
            const e = c.ga.G,
                f = d.ga.G;
            var g;
            null == e || null == f ? g = null == e && null == f ? iH(a, c) - iH(a, d) : null == e ? 1 : -1 : g = e - f;
            return g
        })
    }
    class lH {
        constructor(a, b = 0, c = null) {
            this.j = new cH(a);
            this.i = new bH(b);
            this.g = c && new gH(c)
        }
    };

    function mH(a, b, c = 0, d) {
        var e = a.i;
        for (var f of b.l) e = aq(e, f.Ea(a.j), nH(f.ya(), c));
        f = e = e.apply(oC(a.j));
        for (const g of b.i) f = aq(f, g.Ea(a.j), oq([oH(g.ya(), c), h => {
            d ? .g(h, g.ya())
        }]));
        switch (b.j) {
            case 1:
                f = jH(a.g, f);
                break;
            case 2:
                f = kH(a.g, f);
                break;
            case 3:
                const g = u(aH);
                f = hH(a.g, f);
                e.forEach(h => {
                    VG(g, h);
                    a.g.g ? .G(h)
                });
                f.forEach(h => WG(g, h))
        }
        b.A && (f = dq(f, ae(a.j.location.href + a.j.localStorage.google_experiment_mod)));
        1 === b.g ? .length && BG(a.l, b.g[0], {
            kb: e.g.length,
            rh: f.g.length
        });
        return cq(f)
    }
    class pH {
        constructor(a, b, c = 0, d = null) {
            this.i = new bq(a);
            this.g = new lH(b, c, d);
            this.j = b;
            this.l = new CG
        }
        A() {
            this.i.forEach(a => {
                a.i && fv(a.i);
                a.i = null
            })
        }
    }
    const nH = (a, b) => c => EA(c, b, a),
        oH = (a, b) => c => EA(c.ga, b, a);

    function qH(a, b, c, d) {
        a: {
            switch (b) {
                case 0:
                    a = rH(sH(c), a);
                    break a;
                case 3:
                    a = rH(c, a);
                    break a;
                case 2:
                    var e = c.lastChild;
                    a = rH(e ? 1 == e.nodeType ? e : sH(e) : null, a);
                    break a
            }
            a = !1
        }
        if (d = !a && !(!d && 2 == b && !tH(c))) b = 1 == b || 2 == b ? c : c.parentNode,
        d = !(b && !Rs(b) && 0 >= b.offsetWidth);
        return d
    }

    function rH(a, b) {
        if (!a) return !1;
        a = Xe(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return "left" == a || "right" == a
    }

    function sH(a) {
        for (a = a.previousSibling; a && 1 != a.nodeType;) a = a.previousSibling;
        return a ? a : null
    }

    function tH(a) {
        return !!a.nextSibling || !!a.parentNode && tH(a.parentNode)
    };
    var uH = !zc && !vc();

    function vH(a) {
        if (/-[a-z]/.test("adFormat")) return null;
        if (uH && a.dataset) {
            if (xc() && !("adFormat" in a.dataset)) return null;
            a = a.dataset.adFormat;
            return void 0 === a ? null : a
        }
        return a.getAttribute("data-" + "adFormat".replace(/([A-Z])/g, "-$1").toLowerCase())
    };
    var wH = (a, b, c) => {
            if (!b) return null;
            const d = je(document, "INS");
            d.id = "google_pedestal_container";
            d.style.width = "100%";
            d.style.zIndex = "-1";
            if (c) {
                var e = a.getComputedStyle(c),
                    f = "";
                if (e && "static" != e.position) {
                    var g = c.parentNode.lastElementChild;
                    for (f = e.position; g && g != c;) {
                        if ("none" != a.getComputedStyle(g).display) {
                            f = a.getComputedStyle(g).position;
                            break
                        }
                        g = g.previousElementSibling
                    }
                }
                if (c = f) d.style.position = c
            }
            b.appendChild(d);
            if (d) {
                var h = a.document;
                f = h.createElement("div");
                f.style.width = "100%";
                f.style.height =
                    "2000px";
                c = S(a);
                e = h.body.scrollHeight;
                a = a.innerHeight;
                g = h.body.getBoundingClientRect().bottom;
                d.appendChild(f);
                var k = f.getBoundingClientRect().top;
                h = h.body.getBoundingClientRect().top;
                d.removeChild(f);
                f = e;
                e <= a && 0 < c && 0 < g && (f = g - h);
                a = k - h >= .8 * f
            } else a = !1;
            return a ? d : (b.removeChild(d), null)
        },
        xH = a => {
            const b = a.document.body;
            var c = wH(a, b, null);
            if (c) return c;
            if (a.document.body) {
                c = Math.floor(a.document.body.getBoundingClientRect().width);
                for (var d = [{
                        element: a.document.body,
                        depth: 0,
                        height: 0
                    }], e = -1, f = null; 0 < d.length;) {
                    const h =
                        d.pop(),
                        k = h.element;
                    var g = h.height;
                    0 < h.depth && g > e && (e = g, f = k);
                    if (5 > h.depth)
                        for (g = 0; g < k.children.length; g++) {
                            const l = k.children[g],
                                m = l.getBoundingClientRect().width;
                            (null == m || null == c ? 0 : m >= .9 * c && m <= 1.01 * c) && d.push({
                                element: l,
                                depth: h.depth + 1,
                                height: l.getBoundingClientRect().height
                            })
                        }
                }
                c = f
            } else c = null;
            return c ? wH(a, c.parentNode || b, c) : null
        },
        zH = a => {
            let b = 0;
            try {
                b |= uo(a), te() || (b |= 1048576), 1200 >= Math.floor(a.document.body.getBoundingClientRect().width) || (b |= 32768), yH(a) && (b |= 33554432)
            } catch (c) {
                b |= 32
            }
            return b
        },
        yH = a => {
            a = a.document.getElementsByClassName("adsbygoogle");
            for (let b = 0; b < a.length; b++)
                if ("autorelaxed" == vH(a[b])) return !0;
            return !1
        };

    function AH(a) {
        const b = zo(a, !0),
            c = Ao(a).scrollWidth,
            d = Ao(a).scrollHeight;
        let e = "unknown";
        a && a.document && a.document.readyState && (e = a.document.readyState);
        var f = Eo(a);
        const g = [];
        var h = [];
        const k = [],
            l = [];
        var m = [],
            n = [],
            p = [];
        let q = 0,
            x = 0,
            z = Infinity,
            G = Infinity,
            F = null;
        var K = MB({
            Pb: !1
        }, a);
        for (var H of K) {
            K = H.getBoundingClientRect();
            const Ea = b - (K.bottom + f);
            var N = void 0,
                J = void 0;
            if (H.className && jc(H.className, "adsbygoogle-ablated-ad-slot")) {
                N = H.getAttribute("google_element_uid");
                J = a.google_sv_map;
                if (!N || !J ||
                    !J[N]) continue;
                N = (J = Uk(J[N])) ? J.height : 0;
                J = J ? J.width : 0
            } else if (N = K.bottom - K.top, J = K.right - K.left, 1 >= N || 1 >= J) continue;
            g.push(N);
            k.push(J);
            l.push(N * J);
            H.className && jc(H.className, "google-auto-placed") ? (x += 1, H.className && jc(H.className, "pedestal_container") && (F = N)) : (z = Math.min(z, Ea), n.push(K), q += 1, h.push(N), m.push(N * J));
            G = Math.min(G, Ea);
            p.push(K)
        }
        z = Infinity === z ? null : z;
        G = Infinity === G ? null : G;
        f = BH(n);
        p = BH(p);
        h = CH(b, h);
        n = CH(b, g);
        m = CH(b * c, m);
        H = CH(b * c, l);
        return new DH(a, {
            li: e,
            Jc: b,
            ej: c,
            dj: d,
            Ui: q,
            Hh: x,
            Jh: EH(g),
            Kh: EH(k),
            Ih: EH(l),
            Zi: f,
            Yi: p,
            Xi: z,
            Wi: G,
            ue: h,
            te: n,
            Ch: m,
            Bh: H,
            gj: F
        })
    }

    function FH(a, b, c, d) {
        const e = te() && !(900 <= wo(a.i));
        d = Xa(d, f => bb(a.j, f)).join(",");
        return {
            wpc: b,
            su: c,
            eid: d,
            doc: a.g.li,
            pg_h: GH(a.g.Jc),
            pg_w: GH(a.g.ej),
            pg_hs: GH(a.g.dj),
            c: GH(a.g.Ui),
            aa_c: GH(a.g.Hh),
            av_h: GH(a.g.Jh),
            av_w: GH(a.g.Kh),
            av_a: GH(a.g.Ih),
            s: GH(a.g.Zi),
            all_s: GH(a.g.Yi),
            b: GH(a.g.Xi),
            all_b: GH(a.g.Wi),
            d: GH(a.g.ue),
            all_d: GH(a.g.te),
            ard: GH(a.g.Ch),
            all_ard: GH(a.g.Bh),
            pd_h: GH(a.g.gj),
            dt: e ? "m" : "d"
        }
    }
    class DH {
        constructor(a, b) {
            this.i = a;
            this.g = b;
            this.j = "633794002 633794005 21066126 21066127 21065713 21065714 21065715 21065716 42530887 42530888 42530889 42530890 42530891 42530892 42530893".split(" ")
        }
    }

    function EH(a) {
        return Vd.apply(null, Xa(a, b => 0 < b)) || null
    }

    function CH(a, b) {
        return 0 >= a ? null : Ud.apply(null, b) / a
    }

    function BH(a) {
        let b = Infinity;
        for (let e = 0; e < a.length - 1; e++)
            for (let f = e + 1; f < a.length; f++) {
                var c = a[e],
                    d = a[f];
                c = Math.max(Math.max(0, c.left - d.right, d.left - c.right), Math.max(0, c.top - d.bottom, d.top - c.bottom));
                0 < c && (b = Math.min(c, b))
            }
        return Infinity !== b ? b : null
    }

    function GH(a) {
        return null == a ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function HH(a, b) {
        b = (S(b) || 0) - Eo(b);
        let c = 0;
        for (let d = 0; d < a.length; d++) {
            const e = a[d].getBoundingClientRect();
            UB(e) && e.top <= b && (c += 1)
        }
        return c
    }

    function IH(a) {
        const b = {};
        var c = OB({
            Pb: !1,
            vd: !1,
            wd: !1,
            xd: !1
        }, a).map(d => d.getBoundingClientRect()).filter(UB);
        b.Bf = c.length;
        c = PB({
            wd: !0
        }, a).map(d => d.getBoundingClientRect()).filter(UB);
        b.dg = c.length;
        c = PB({
            xd: !0
        }, a).map(d => d.getBoundingClientRect()).filter(UB);
        b.Ig = c.length;
        c = PB({
            vd: !0
        }, a).map(d => d.getBoundingClientRect()).filter(UB);
        b.Gf = c.length;
        c = (S(a) || 0) - Eo(a);
        c = OB({
            Pb: !1
        }, a).map(d => d.getBoundingClientRect()).filter(UB).filter(Ia(JH, null, c));
        b.Cf = c.length;
        a = AH(a);
        c = null != a.g.ue ? a.g.ue : null;
        null !=
            c && (b.zg = c);
        a = null != a.g.te ? a.g.te : null;
        null != a && (b.Df = a);
        return b
    }

    function QF(a, b, {
        Dd: c,
        Zd: d,
        me: e
    } = {}) {
        return Ev(997, () => KH(a, b, {
            Dd: c,
            Zd: d,
            me: e
        }), a.g)
    }

    function RF(a, b, c, d) {
        var e = c.Db ? c.Db : a.C;
        const f = zB(e, b.g.length);
        e = a.j.Ef ? e.g : void 0;
        const g = vG(wG(sG(uG(tG(rG(pG(qG(nG(oG(lG(c.types), a.ea), c.ef || []), a.Z), c.tj || [])), f.Ic || void 0, e, b), c.minWidth, c.maxWidth)), f.vb || void 0));
        a.T && g.g.push(new $F(a.T));
        b = 1;
        a.j.vf ? b = 2 : a.Xa() && (b = 3);
        xG(g, b);
        a.j.mf && (g.l = !0);
        return Ev(995, () => mH(a.i, g.build(), d, a.B || void 0), a.g)
    }

    function TF(a, b) {
        const c = xH(a.g);
        if (c) {
            const d = Aq(a.I, b),
                e = tv(a.g.document, a.G, null, null, {}, d);
            e && (iv(e.ob, c, 2, 256), Ev(996, () => LH(a, e, d), a.g))
        }
    }

    function MH(a) {
        return a.F ? a.F : a.F = a.g.google_ama_state
    }

    function KH(a, b, {
        Dd: c,
        Zd: d,
        me: e
    } = {}) {
        const f = b.ga;
        if (f.A) return !1;
        var g = b.ia(),
            h = f.g();
        if (!qH(a.g, h, g, a.l)) return !1;
        h = null;
        f.Cc ? .includes(6) ? (h = Math.round(g.getBoundingClientRect().height), h = new Bq(null, {
            google_max_responsive_height: null == c ? h : Math.min(c, h),
            google_full_width_responsive: "false"
        })) : h = null == c ? null : new Bq(null, {
            google_max_responsive_height: c
        });
        c = Cq(L(f.Sd, 2) || 0);
        g = Dq(f.G);
        const k = NH(a, f),
            l = OH(a),
            m = Aq(a.I, f.T ? f.T.g(b.ja) : null, h, d || null, c, g, k, l),
            n = b.fill(a.G, m);
        if (e && !PH(a, n, m) || !Ev(996,
                () => LH(a, n, m), a.g)) return !1;
        gk(9, [f.G, f.Qb]);
        a.Xa() && XG(u(aH), b);
        return !0
    }

    function NH(a, b) {
        return jq(lq(dB(b).map(Eq), () => {
            a.A.push(18)
        }))
    }

    function OH(a) {
        if (!a.Xa()) return null;
        var b = a.i.g.g ? .B();
        if (null == b) return null;
        b = b.join("~");
        a = a.i.g.g ? .A() ? ? null;
        return Fq({
            ei: b,
            ti: a
        })
    }

    function PH(a, b, c) {
        if (!b) return !1;
        var d = b.wa,
            e = d.style.width;
        d.style.width = "100%";
        var f = d.offsetWidth;
        d.style.width = e;
        d = a.g;
        e = b.wa;
        c = c && c.zc() || {};
        if (d !== d.top) var g = Ue(d) ? 3 : 16;
        else if (488 > wo(d))
            if (d.innerHeight >= d.innerWidth)
                if (g = wo(d), !g || .3 < (g - f) / g) g = 6;
                else {
                    if (g = "true" != c.google_full_width_responsive) b: {
                        var h = e.parentElement;
                        for (g = wo(d); h; h = h.parentElement) {
                            const k = Xe(h, d);
                            if (!k) continue;
                            const l = gf(k.width);
                            if (l && !(l >= g) && "visible" != k.overflow) {
                                g = !0;
                                break b
                            }
                        }
                        g = !1
                    }
                    g = g ? 7 : !0
                }
        else g = 5;
        else g = 4;
        if (!0 !==
            g) f = g;
        else {
            if (!(c = "true" == c.google_full_width_responsive)) a: {
                do
                    if ((c = Xe(e, d)) && "fixed" == c.position) {
                        c = !1;
                        break a
                    }
                while (e = e.parentElement);
                c = !0
            }
            c ? (d = wo(d), f = d - f, f = d && 0 <= f ? !0 : d ? -10 > f ? 11 : 0 > f ? 14 : 12 : 10) : f = 9
        }
        if (f) {
            a = a.g;
            b = b.wa;
            if (f = pv(a, b)) b.style.border = b.style.borderStyle = b.style.outline = b.style.outlineStyle = b.style.transition = "none", b.style.borderSpacing = b.style.padding = "0", nv(b, f, "0px"), b.style.width = wo(a) + "px", qv(a, b, f), b.style.zIndex = 30;
            return !0
        }
        fv(b.ob);
        return !1
    }

    function LH(a, b, c) {
        if (!b) return !1;
        try {
            xv(a.g, b.wa, c)
        } catch (d) {
            return fv(b.ob), a.A.push(6), !1
        }
        return !0
    }
    class QH {
        constructor(a, b, c, d, e = {}, f = [], g = !1) {
            this.i = a;
            this.G = b;
            this.g = c;
            this.C = d.Db;
            this.ea = d.tc || [];
            this.I = d.ui || null;
            this.Z = d.hi || [];
            this.T = d.ae || [];
            this.j = e;
            this.l = !1;
            this.O = [];
            this.A = [];
            this.H = this.F = void 0;
            this.Ha = f;
            this.B = g ? new BF : null
        }
        va() {
            return this.i
        }
        da() {
            return this.g
        }
        xa(a) {
            this.O.push(a)
        }
        Xa() {
            if (0 == (this.i.g.g ? .l().length ? ? 0)) return !1;
            if (0 == (w(It) || 0)) return !0;
            if (void 0 === this.H) {
                const a = xG(sG(rG(lG([0, 1, 2]))), 1).build(),
                    b = Ev(995, () => mH(this.i, a), this.g);
                this.H = this.i.g.g ? .I(b) || !1
            }
            return this.H
        }
        Ne() {
            return !!this.j.Yg
        }
        Bd() {
            return !yH(this.g)
        }
        na() {
            return this.B
        }
    }
    const JH = (a, b) => b.top <= a;

    function RH(a, b, c, d, e, f = 0, g = 0) {
        this.Ra = a;
        this.Nd = f;
        this.Md = g;
        this.errors = b;
        this.Ab = c;
        this.g = d;
        this.i = e
    };
    var SH = (a, {
        Bd: b = !1,
        Ne: c = !1,
        wj: d = !1,
        Xa: e = !1
    } = {}) => {
        const f = [];
        d && f.push(9);
        if (e) {
            a.includes(4) && !c && b && f.push(8);
            a.includes(1) && f.push(1);
            d = a.includes(3);
            e = a.includes(2) && !v(ft);
            const g = a.includes(1);
            (d || e || g) && f.push(10)
        } else a.includes(3) && f.push(6), a.includes(4) && !c && b && f.push(8), a.includes(1) && f.push(1, 5), a.includes(2) && !v(ft) && f.push(7);
        a.includes(4) && c && b && f.push(8);
        return f
    };

    function TH(a, b, c) {
        a = SH(a, {
            Bd: b.Bd(),
            Ne: b.Ne(),
            wj: !!b.j.Ee,
            Xa: b.Xa()
        });
        return new UH(a, b, c)
    }

    function VH(a, b) {
        const c = NF[b];
        return c ? Ev(998, () => c(a.g), a.A) : (a.g.xa(12), !0)
    }

    function WH(a, b) {
        return new Promise(c => {
            setTimeout(() => {
                c(VH(a, b))
            })
        })
    }

    function XH(a) {
        a.g.l = !0;
        return Promise.all(a.i.map(b => WH(a, b))).then(b => {
            b.includes(!1) && a.g.xa(5);
            a.i.splice(0, a.i.length)
        })
    }
    class UH {
        constructor(a, b, c) {
            this.l = a.slice(0);
            this.i = a.slice(0);
            this.j = db(this.i, 1);
            this.g = b;
            this.A = c
        }
    };
    const YH = class {
        constructor(a) {
            this.g = a;
            this.exception = void 0
        }
    };

    function ZH(a) {
        return XH(a).then(() => {
            var b = a.g.i.i.filter(zA).g.length;
            var c = a.g.O.slice(0);
            var d = a.g;
            d = [...d.A, ...(d.i.g.g ? .C() || [])];
            b = new RH(b, c, d, a.g.i.i.g.length, a.g.i.l.g, a.g.i.i.filter(zA).filter(AA).g.length, a.g.i.i.filter(AA).g.length);
            return new YH(b)
        })
    };
    var $H = a => {
            let b = 0;
            a.forEach(c => b = Math.max(b, c.getBoundingClientRect().width));
            return c => c.getBoundingClientRect().width > .5 * b
        },
        aI = a => {
            const b = S(a) || 0;
            return c => c.getBoundingClientRect().height >= .75 * b
        };
    var bI = (a, b) => {
        b = ZA(b, a);
        const c = b.map(d => d.g);
        b = b.filter(d => {
            d = d.g.getBoundingClientRect();
            return 0 < d.width && 0 < d.height
        }).filter(d => $H(c)(d.g)).filter(d => aI(a)(d.g));
        b.sort((d, e) => {
            e = e.g;
            return d.g.getBoundingClientRect().top - e.getBoundingClientRect().top
        });
        return b
    };

    function cI(a) {
        return a.reduce((b, c) => b.g.getBoundingClientRect().bottom < c.g.getBoundingClientRect().bottom ? c : b)
    }

    function dI(a, b, c, d) {
        let e = !1;
        const f = new IntersectionObserver(g => {
            for (const h of g)
                if (h.isIntersecting) e = !0;
                else {
                    if (g = e) g = a, g = b.getBoundingClientRect().bottom <= S(g.win) / 2;
                    g && (eI(a.ba, {
                        typ: "cee",
                        cet: c
                    }), e = !1)
                }
        }, {
            rootMargin: d
        });
        f.observe(b);
        Zo(a, () => {
            f.disconnect()
        })
    }
    var fI = class extends T {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.g = b;
            this.ba = c
        }
    };

    function gI(a, b) {
        eI(a, {
            typ: "cdr",
            af: b.he,
            ...(0 < b.he ? {
                vh: b.U,
                ph: b.Jc,
                ah: b.Dh,
                at: b.Fh
            } : {})
        })
    }

    function eI(a, b) {
        a = { ...b,
            wpc: a.webPropertyCode,
            cor: a.g,
            tim: Math.round(bl() ? ? -1),
            num: a.i++
        };
        aA("ama_vignette", a, 1)
    }
    var hI = class {
        constructor(a) {
            var b = zf();
            this.webPropertyCode = a;
            this.g = b;
            this.i = 0
        }
    };
    class iI {
        g() {
            return new Bq([], {
                google_reactive_ad_format: 40,
                google_tag_origin: "qs"
            })
        }
    };
    class jI {
        g() {
            return new Bq(["adsbygoogle-resurrected-ad-slot"], {})
        }
    };

    function kI(a) {
        return Ss(a.g.document).map(b => {
            const c = new sA(b, 3);
            b = new uA(zv(a.g, b));
            return new yA(c, b, a.i, !1, 0, [], null, a.g, null)
        })
    }
    class lI {
        constructor(a) {
            var b = new jI;
            this.g = a;
            this.i = b || null
        }
    };
    const mI = {
        tf: "10px",
        je: "10px"
    };

    function nI(a) {
        return Ko(a.g.document.querySelectorAll("INS.adsbygoogle-placeholder")).map(b => new yA(new sA(b, 1), new qA(mI), a.i, !1, 0, [], null, a.g, null))
    }
    class oI {
        constructor(a, b) {
            this.g = a;
            this.i = b || null
        }
    };

    function pI(a, b) {
        const c = [];
        b.forEach((d, e) => {
            c.push(ka(e, "replaceAll").call(e, "~", "_") + "--" + d.map(f => Number(f)).join("_"))
        });
        HG(a.i, "cnstr", c, 80)
    }
    var qI = class extends Vz {
        constructor() {
            super(-1);
            this.i = {}
        }
        l(a) {
            a = super.l(a);
            Object.assign(a, this.i);
            return a
        }
    };

    function rI(a, b) {
        return null == a ? b + "ShouldNotBeNull" : 0 == a ? b + "ShouldNotBeZero" : -1 > a ? b + "ShouldNotBeLessMinusOne" : null
    }

    function sI(a, b, c) {
        const d = rI(c.pd, "gapsMeasurementWindow") || rI(c.wc, "gapsPerMeasurementWindow") || rI(c.Fc, "maxGapsToReport");
        return null != d ? hq(Error(d)) : c.Ff || -1 != c.wc || -1 != c.Fc ? fq(new tI(a, b, c)) : hq(Error("ShouldHaveLimits"))
    }

    function uI(a) {
        return MH(a.j) && MH(a.j).placed || []
    }

    function vI(a) {
        return uI(a).map(b => Tp(Rp(b.element, a.g)))
    }

    function wI(a) {
        return uI(a).map(b => b.index)
    }

    function xI(a, b) {
        const c = b.ga;
        return !a.B && c.l && null != L(c.l, 8) && 1 == L(c.l, 8) ? [] : c.A ? (c.Z || []).map(d => Tp(Rp(d, a.g))) : [Tp(new Sp(b.ja.g, 0))]
    }

    function yI(a) {
        a.sort((e, f) => e.g - f.g);
        const b = [];
        let c = 0;
        for (let e = 0; e < a.length; ++e) {
            var d = a[e];
            let f = d.g;
            d = d.g + d.i;
            f <= c ? c = Math.max(c, d) : (b.push(new Sp(c, f - c)), c = d)
        }
        return b
    }

    function zI(a, b) {
        b = b.map(c => {
            var d = new tF;
            d = Xi(d, 1, c.g);
            c = c.getHeight();
            return Xi(d, 2, c)
        });
        return vF(uF(new wF, a), b)
    }

    function AI(a) {
        const b = D(a, tF, 2).map(c => `G${xi(c,1)}~${c.getHeight()}`);
        return `W${xi(a,1)}${b.join("")}`
    }

    function BI(a, b) {
        const c = [];
        let d = 0;
        for (const e of No(b)) {
            const f = b.get(e);
            f.sort((g, h) => h.getHeight() - g.getHeight());
            a.F || f.splice(a.A, f.length);
            !a.C && d + f.length > a.i && f.splice(a.i - d, f.length);
            c.push(zI(e, f));
            d += f.length;
            if (!a.C && d >= a.i) break
        }
        return c
    }

    function CI(a) {
        const b = D(a, wF, 5).map(c => AI(c));
        return `M${xi(a,1)}H${xi(a,2)}C${xi(a,3)}B${Number(!!M(a,4))}${b.join("")}`
    }

    function DI(a) {
        var b = iB(cq(a.j.i.i), a.g),
            c = vI(a),
            d = new Qo(wI(a));
        for (var e = 0; e < b.length; ++e)
            if (!d.contains(e)) {
                var f = xI(a, b[e]);
                c.push(...f)
            }
        c.push(new Sp(0, 0));
        c.push(Tp(new Sp(Ao(a.g).scrollHeight, 0)));
        b = yI(c);
        c = new Po;
        for (d = 0; d < b.length; ++d) e = b[d], f = a.G ? 0 : Math.floor(e.g / a.l), Lo(c, f) || c.set(f, []), c.get(f).push(e);
        b = BI(a, c);
        c = new xF;
        c = Xi(c, 1, a.i);
        c = Xi(c, 2, a.l);
        c = Xi(c, 3, a.A);
        a = Vi(c, 4, a.B);
        return si(a, 5, b)
    }

    function EI(a) {
        a = DI(a);
        return CI(a)
    }
    var tI = class {
        constructor(a, b, c) {
            this.G = -1 == c.pd;
            this.l = c.pd;
            this.F = -1 == c.wc;
            this.A = c.wc;
            this.C = -1 == c.Fc;
            this.i = c.Fc;
            this.B = c.qg;
            this.j = b;
            this.g = a
        }
    };
    const FI = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function GI(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        aA("ama", b, .01)
    }

    function HI(a) {
        const b = {};
        Ze(FI, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };

    function II(a) {
        const b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                const e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function JI(a) {
        let b = "";
        const c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            const e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function KI(a, b) {
        a = ai(a, 2, eh, 2);
        if (!a) return !1;
        for (let c = 0; c < a.length; c++)
            if (a[c] == b) return !0;
        return !1
    }

    function LI(a, b) {
        a = JI(II(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        const c = af(a),
            d = MI(a);
        return b.find(e => {
            const f = Xh(e, Pq, 7) ? ih(Th(C(e, Pq, 7), 1)) : ih(Th(e, 1));
            e = Xh(e, Pq, 7) ? L(C(e, Pq, 7), 2) : 2;
            if ("number" !== typeof f) return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function MI(a) {
        const b = {};
        for (;;) {
            b[af(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };
    var OI = a => {
            try {
                NI(a, a.localStorage)
            } catch (b) {
                GI(a, {
                    lserr: 1
                })
            }
        },
        NI = (a, b) => {
            try {
                b.removeItem("google_ama_config")
            } catch (c) {
                GI(a, {
                    lserr: 1
                })
            }
        };

    function PI(a) {
        if (v(gt)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? Er(b) : null
        } catch (d) {
            c = null
        }
        return c
    };

    function QI(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function RI(a, b) {
        a = QI(a);
        a.processed_sra_frame_pingbacks = a.processed_sra_frame_pingbacks || {};
        const c = !a.processed_sra_frame_pingbacks[b];
        a.processed_sra_frame_pingbacks[b] = !0;
        return c
    };

    function SI(a) {
        let b = a.location.href;
        if (a === a.top) return {
            url: b,
            Oe: !0
        };
        let c = !1;
        const d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        (a = a.location.ancestorOrigins) && (a = a[a.length - 1]) && -1 === b.indexOf(a) && (c = !1, b = a);
        return {
            url: b,
            Oe: c
        }
    };

    function TI(a, b) {
        Ze(a, (c, d) => {
            b[d] = c
        })
    }
    var UI = a => {
        if (a == a.top) return 0;
        for (; a && a != a.top && Re(a); a = a.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function VI() {
        if (WI) return WI;
        const a = tk() || window,
            b = a.google_persistent_state_async;
        return null != b && "object" == typeof b && null != b.S && "object" == typeof b.S ? WI = b : a.google_persistent_state_async = WI = new XI
    }

    function YI(a, b, c) {
        b = ZI[b] || `google_ps_${b}`;
        a = a.S;
        const d = a[b];
        return void 0 === d ? (a[b] = c(), a[b]) : d
    }

    function Z(a, b, c) {
        return YI(a, b, () => c)
    }

    function $I(a, b, c) {
        return a.S[ZI[b] || `google_ps_${b}`] = c
    }

    function aJ(a, b) {
        return $I(a, b, Z(a, b, 0) + 1)
    }

    function bJ() {
        var a = VI();
        return Z(a, 20, {})
    }

    function cJ() {
        var a = VI();
        const b = Z(a, 31, !1);
        b || $I(a, 31, !0);
        return !b
    }

    function dJ() {
        var a = VI();
        return Z(a, 26)
    }

    function eJ() {
        var a = VI();
        return Z(a, 28, [])
    }

    function fJ() {
        var a = VI();
        return YI(a, 39, gJ)
    }
    var XI = class {
            constructor() {
                this.S = {}
            }
        },
        WI = null;
    const ZI = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };
    var hJ = {
            google_ad_block: "ad_block",
            google_ad_client: "client",
            google_ad_output: "output",
            google_ad_callback: "callback",
            google_ad_height: "h",
            google_ad_resize: "twa",
            google_ad_slot: "slotname",
            google_ad_unit_key: "adk",
            google_ad_dom_fingerprint: "adf",
            google_placement_id: "pi",
            google_daaos_ts: "daaos",
            google_erank: "epr",
            google_ad_width: "w",
            google_captcha_token: "captok",
            google_content_recommendation_columns_num: "cr_col",
            google_content_recommendation_rows_num: "cr_row",
            google_ctr_threshold: "ctr_t",
            google_cust_criteria: "cust_params",
            gfwrnwer: "fwrn",
            gfwrnher: "fwrnh",
            google_image_size: "image_size",
            google_last_modified_time: "lmt",
            google_loeid: "loeid",
            google_max_num_ads: "num_ads",
            google_max_radlink_len: "max_radlink_len",
            google_mtl: "mtl",
            google_native_settings_key: "nsk",
            google_enable_content_recommendations: "ecr",
            google_num_radlinks: "num_radlinks",
            google_num_radlinks_per_unit: "num_radlinks_per_unit",
            google_pucrd: "pucrd",
            google_reactive_plaf: "plaf",
            google_reactive_plat: "plat",
            google_reactive_fba: "fba",
            google_reactive_sra_channels: "plach",
            google_responsive_auto_format: "rafmt",
            armr: "armr",
            google_plas: "plas",
            google_rl_dest_url: "rl_dest_url",
            google_rl_filtering: "rl_filtering",
            google_rl_mode: "rl_mode",
            google_rt: "rt",
            google_video_play_muted: "vpmute",
            google_source_type: "src_type",
            google_restrict_data_processing: "rdp",
            google_tag_for_child_directed_treatment: "tfcd",
            google_tag_for_under_age_of_consent: "tfua",
            google_tag_origin: "to",
            google_ad_semantic_area: "sem",
            google_tfs: "tfs",
            google_package: "pwprc",
            google_tag_partner: "tp",
            fra: "fpla",
            google_ml_rank: "mlr",
            google_apsail: "psa",
            google_ad_channel: "channel",
            google_ad_type: "ad_type",
            google_ad_format: "format",
            google_color_bg: "color_bg",
            google_color_border: "color_border",
            google_color_link: "color_link",
            google_color_text: "color_text",
            google_color_url: "color_url",
            google_page_url: "url",
            google_ad_section: "region",
            google_cpm: "cpm",
            google_encoding: "oe",
            google_safe: "adsafe",
            google_font_face: "f",
            google_font_size: "fs",
            google_hints: "hints",
            google_ad_host: "host",
            google_ad_host_channel: "h_ch",
            google_ad_host_tier_id: "ht_id",
            google_kw_type: "kw_type",
            google_kw: "kw",
            google_contents: "contents",
            google_targeting: "targeting",
            google_adtest: "adtest",
            google_alternate_color: "alt_color",
            google_alternate_ad_url: "alternate_ad_url",
            google_cust_age: "cust_age",
            google_cust_ch: "cust_ch",
            google_cust_gender: "cust_gender",
            google_cust_interests: "cust_interests",
            google_cust_job: "cust_job",
            google_cust_l: "cust_l",
            google_cust_lh: "cust_lh",
            google_cust_u_url: "cust_u_url",
            google_cust_id: "cust_id",
            google_language: "hl",
            google_city: "gcs",
            google_country: "gl",
            google_region: "gr",
            google_content_recommendation_ad_positions: "ad_pos",
            google_content_recommendation_columns_num: "cr_col",
            google_content_recommendation_rows_num: "cr_row",
            google_content_recommendation_ui_type: "crui",
            google_content_recommendation_use_square_imgs: "cr_sq_img",
            google_color_line: "color_line",
            google_disable_video_autoplay: "disable_video_autoplay",
            google_full_width_responsive_allowed: "fwr",
            google_full_width_responsive: "fwrattr",
            efwr: "efwr",
            google_pgb_reactive: "pra",
            google_resizing_allowed: "rs",
            google_resizing_height: "rh",
            google_resizing_width: "rw",
            rpe: "rpe",
            google_responsive_formats: "resp_fmts",
            google_safe_for_responsive_override: "sfro",
            google_video_doc_id: "video_doc_id",
            google_video_product_type: "video_product_type",
            google_webgl_support: "wgl",
            easpi: "easpi",
            asptt: "asptt",
            asro: "asro",
            sugawps: "aseaascu",
            asla: "aslmt",
            asaa: "asamt",
            sedf: "asedf",
            sefa: "asefa",
            seiel: "aseiel",
            slcwct: "aslcwct",
            sacwct: "asacwct",
            slmct: "aslmct",
            samct: "asamct",
            vmsli: "itsi"
        },
        iJ = a => (a = a.innerText || a.innerHTML) && (a = a.replace(/^\s+/,
            "").split(/\r?\n/, 1)[0].match(/^\x3c!--+(.*?)(?:--+>)?\s*$/)) && RegExp("google_ad_client").test(a[1]) ? a[1] : null,
        jJ = a => {
            if (a = a.innerText || a.innerHTML)
                if (a = a.replace(/^\s+|\s+$/g, "").replace(/\s*(\r?\n)+\s*/g, ";"), (a = a.match(/^\x3c!--+(.*?)(?:--+>)?$/) || a.match(/^\/*\s*<!\[CDATA\[(.*?)(?:\/*\s*\]\]>)?$/i)) && RegExp("google_ad_client").test(a[1])) return a[1];
            return null
        },
        kJ = a => {
            switch (a) {
                case "true":
                    return !0;
                case "false":
                    return !1;
                case "null":
                    return null;
                case "undefined":
                    break;
                default:
                    try {
                        const b = a.match(/^(?:'(.*)'|"(.*)")$/);
                        if (b) return b[1] || b[2] || "";
                        if (/^[-+]?\d*(\.\d+)?$/.test(a)) {
                            const c = parseFloat(a);
                            return c === c ? c : void 0
                        }
                    } catch (b) {}
            }
        };

    function Yn(a, b) {
        0 < a.g.size || lJ(a);
        const c = a.g.get(0);
        c ? c.push(b) : a.g.set(0, [b])
    }

    function mJ(a, b, c, d) {
        Sb(b, c, d);
        Zo(a, () => Tb(b, c, d))
    }

    function nJ(a, b) {
        1 !== a.j && (a.j = 1, 0 < a.g.size && oJ(a, b))
    }

    function lJ(a) {
        a.win.document.visibilityState ? mJ(a, a.win.document, "visibilitychange", b => {
            "hidden" === a.win.document.visibilityState && nJ(a, b);
            "visible" === a.win.document.visibilityState && (a.j = 0)
        }) : "onpagehide" in a.win ? (mJ(a, a.win, "pagehide", b => {
            nJ(a, b)
        }), mJ(a, a.win, "pageshow", () => {
            a.j = 0
        })) : mJ(a, a.win, "beforeunload", b => {
            nJ(a, b)
        })
    }

    function oJ(a, b) {
        for (let c = 9; 0 <= c; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var pJ = class extends T {
        constructor(a) {
            super();
            this.win = a;
            this.j = 0;
            this.g = new Map
        }
    };
    async function qJ(a, b) {
        var c = 10;
        return 0 >= c ? Promise.reject() : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e())
            }, 200)
        })
    };

    function rJ(a) {
        const b = a.g.pc;
        return null !== b && 0 !== b ? b : a.g.pc = Af(a.win)
    }

    function sJ(a) {
        var b = a.g.wpc;
        if (null === b || "" === b) {
            b = a.g;
            var c = a.win;
            if (c.google_ad_client) a = String(c.google_ad_client);
            else {
                if (null == (a = QI(c).head_tag_slot_vars ? .google_ad_client ? ? c.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client"))) {
                    b: {
                        a = c.document.getElementsByTagName("script");c = c.navigator && c.navigator.userAgent || "";c = RegExp("appbankapppuzdradb|daumapps|fban|fbios|fbav|fb_iab|gsa/|messengerforios|naver|niftyappmobile|nonavigation|pinterest|twitter|ucbrowser|yjnewsapp|youtube", "i").test(c) ||
                        /i(phone|pad|pod)/i.test(c) && /applewebkit/i.test(c) && !/version|safari/i.test(c) && !Sk() ? iJ : jJ;
                        for (var d = a.length - 1; 0 <= d; d--) {
                            var e = a[d];
                            if (!e.google_parsed_script_for_pub_code && (e.google_parsed_script_for_pub_code = !0, e = c(e))) {
                                a = e;
                                break b
                            }
                        }
                        a = null
                    }
                    if (a) {
                        c = /(google_\w+) *= *(['"]?[\w.-]+['"]?) *(?:;|$)/gm;
                        for (d = {}; e = c.exec(a);) d[e[1]] = kJ(e[2]);
                        a = d;
                        a = a.google_ad_client ? a.google_ad_client : ""
                    } else a = ""
                }
                a = a ? ? ""
            }
            b = b.wpc = a
        }
        return b
    }

    function tJ(a, b) {
        var c = new Kn,
            d = rJ(a);
        c = P(c, 1, d).dc(sJ(a));
        c = P(c, 3, a.g.sd);
        return P(c, 7, Math.round(b || a.win.performance.now()))
    }
    async function uJ(a) {
        await qJ(a.win, () => !(!rJ(a) || !sJ(a)))
    }
    async function vJ(a, b, c) {
        if (a.i && c.length && !a.g.lgdp.includes(Number(b))) {
            a.g.lgdp.push(Number(b));
            var d = a.win.performance.now();
            await uJ(a);
            var e = a.ua;
            a = tJ(a, d);
            d = new tm;
            b = Q(d, 1, b);
            c = ji(b, 2, c, fh);
            c = ri(a, 9, Ln, c);
            Un(e, c)
        }
    }
    async function wJ(a, b) {
        await uJ(a);
        var c = tJ(a);
        b = ri(c, 5, Ln, b);
        a.i && !a.g.le.includes(2) && (a.g.le.push(2), Un(a.ua, b))
    }
    async function xJ(a, b, c) {
        await uJ(a);
        var d = a.ua;
        a = tJ(a, c);
        a = P(a, 3, 1);
        b = ri(a, 6, Ln, b);
        Un(d, b)
    }
    async function yJ(a, b) {
        if (a.i) {
            await uJ(a);
            var c = a.ua;
            a = tJ(a);
            b = ri(a, 11, Ln, b);
            Un(c, b)
        }
    }
    var zJ = class {
        constructor(a, b) {
            this.win = tk() || window;
            this.j = b ? ? new pJ(this.win);
            this.ua = a ? ? new $n("m202401220101", 100, 100, !0, this.j);
            this.g = YI(VI(), 33, () => {
                const c = w(Ys);
                return {
                    sd: c,
                    ssp: 0 < c && Ye() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null
                }
            })
        }
        get i() {
            return this.g.ssp
        }
        get gd() {
            return this.g.cu
        }
        set gd(a) {
            this.g.cu = a
        }
    };
    var BJ = (a, b, c, d, e, f = null, g = null) => {
            AJ(a, new eA(a), b, c, d, e, f, g)
        },
        AJ = (a, b, c, d, e, f, g = null, h = null) => {
            if (c)
                if (d) {
                    var k = WC(d, e);
                    try {
                        const l = new CJ(a, b, c, d, e, k, f, g, h);
                        Ev(990, () => DJ(l), a)
                    } catch (l) {
                        fk() && gk(15, [l]), dA(b, Kr, Uz(EG(DG((new FG(0)).dc(c), d), k).xa(1), l)), wJ(u(zJ), jm(new sm, Dl(1)))
                    }
                } else dA(b, Kr, (new FG(0)).dc(c).xa(8)), wJ(u(zJ), jm(new sm, Dl(8)));
            else dA(b, Kr, (new FG(0)).xa(9)), wJ(u(zJ), jm(new sm, Dl(9)))
        };

    function DJ(a) {
        a.F.forEach(b => {
            switch (b) {
                case 0:
                    Ev(991, () => EJ(a), a.g);
                    break;
                case 1:
                    Ev(1073, () => {
                        const c = v(Bt);
                        PC(new VC(a.g, a.B, a.i, a.A, a.j.X, c))
                    }, a.g);
                    break;
                case 5:
                    Ev(1137, () => {
                        gA(new hA(a.g, a.B, a.i, a.A))
                    }, a.g);
                    break;
                case 2:
                    FJ(a);
                    break;
                case 6:
                    a.runAutoGames();
                    break;
                case 7:
                    Ev(1203, () => {
                        var c = C(a.i, sr, 34);
                        if (c) {
                            var d = a.g,
                                e = a.A,
                                f = c.i();
                            c = d.location.hostname;
                            var g = C(f, rr, 1) ? .g() ? ? [];
                            c = new rF(e, c, Af(r), g);
                            if (g = C(f, rr, 1))
                                if (f = C(f, qr, 2)) {
                                    Vp(d, ZE);
                                    const l = new Vo;
                                    var h = d.innerWidth;
                                    var k = .375 * h;
                                    h = new ty(k,
                                        h - k);
                                    k = d.innerWidth;
                                    k = 900 <= wo(d) ? .2 * k : .5 * k;
                                    kF(new mF(d, e, g, f, new SE(d, h, k, l, new CE(l)), c))
                                } else c.reportError("No messages");
                            else c.reportError("No settings")
                        }
                    }, a.g)
            }
        })
    }

    function EJ(a) {
        if (Br(a.i) && 1 === L(Br(a.i), 1)) {
            var b = C(Br(a.i), Gq, 6);
            b && 2 === L(b, 1) && (yv(a.g), a.C = "b")
        }
        var c = v(ht) ? void 0 : a.j.kj;
        b = null;
        b = v(ht) ? yB(a.g) : wB(a.g, c);
        if (a.j.X && Xh(a.j.X, Oq, 10)) {
            var d = Zh(a.j.X.g(), 1);
            null !== d && void 0 !== d && (b = nB(a.g, d, c));
            v(zt) && 2 === a.j.X.g() ? .g() && (b = vB(a.j.X.g(), b))
        }
        Xh(a.i, Lq, 26) && (b = AB(b, C(a.i, Lq, 26), a.g));
        b = CB(b, a.g);
        c = a.j.X ? ai(a.j.X, 6, eh, 2) : [];
        d = a.j.X ? D(a.j.X, Uq, 5) : [];
        const e = a.j.X ? ai(a.j.X, 2, eh, 2) : [],
            f = Ev(993, () => {
                var g = a.i,
                    h = D(g, or, 1),
                    k = a.j.X && KI(a.j.X, 1);
                k = v(Gt) ? "" :
                    k ? "text_image" : "text";
                var l = new iI,
                    m = xA(h, a.g, {
                        Lh: l,
                        Mi: new vA(k)
                    });
                h.length != m.length && a.H.push(13);
                m = m.concat(nI(new oI(a.g, l)));
                h = 0;
                l = v(wt);
                var n = !1;
                if (Br(g) && 1 === L(Br(g), 1)) {
                    var p = C(Br(g), Gq, 6);
                    p && (h = ui(p, 2) || 0, 1 === L(p, 1) && (n = !0))
                }
                p = C(g, Ar, 24) ? .j() ? .g() ? .g() || !1;
                if (l || n || p) l = kI(new lI(a.g)), n = u(aH), m = m.concat(l), n.O = !0, n.C = l.length, "n" === a.C && (a.C = C(g, Ar, 24) ? .g() ? .length ? "o" : "p");
                l = v(zt) && 2 === a.j.X.g() ? .g() && a.j.X.g() ? .j();
                l = v(ct) || l;
                a: {
                    if (n = C(g, kr, 6))
                        for (q of n.g())
                            if (Xh(q, qq, 4)) {
                                var q = !0;
                                break a
                            }
                    q = !1
                }
                l && q ? (q = m.concat, l = a.g, (n = C(g, kr, 6)) ? (l = aB(n.g(), l), k = sF(g, k, l)) : k = [], k = q.call(m, k)) : (q = m.concat, l = a.g, (n = C(g, kr, 6)) ? (l = $A(n.g(), l), k = sF(g, k, l)) : k = [], k = q.call(m, k));
                m = k;
                g = C(g, Ar, 24);
                return new pH(m, a.g, h, g)
            }, a.g);
        a.l = new QH(f, a.A, a.g, {
            Db: b,
            ui: a.O,
            tc: a.j.tc,
            hi: c,
            ae: d
        }, GJ(a), e, v(vt));
        MH(a.l) ? .optimization ? .ablatingThisPageview && !a.l.Xa() && (yv(a.g), u(aH).B = !0, a.C = "f");
        a.G = TH(e, a.l, a.g);
        Ev(992, () => ZH(a.G), a.g).then(Ev(994, () => a.ea.bind(a), a.g), a.Z.bind(a));
        HJ(a)
    }

    function FJ(a) {
        const b = C(a.i, pr, 18);
        b && TD(new UD(a.g, new AE(a.g, a.A), b, new hw(a.g), D(a.i, or, 1)))
    }

    function GJ(a) {
        const b = v(yt);
        if (!Cr(a.i)) return {
            mf: b,
            vf: !1,
            Xf: !1,
            oh: !1,
            eg: !1,
            Yg: !1,
            hj: 0,
            Pg: 0,
            Ef: IJ(a),
            Ee: a.I
        };
        const c = Cr(a.i);
        return {
            mf: b || M(c, 14, !1),
            vf: M(c, 2, !1),
            Xf: M(c, 3, !1),
            oh: M(c, 4, !1),
            eg: M(c, 5, !1),
            Yg: M(c, 6, !1),
            hj: wi(Zh(c, 8)),
            Pg: L(c, 10),
            Ef: IJ(a),
            Ee: a.I
        }
    }

    function HJ(a) {
        if (v(Ru)) {
            var b = new hI(a.A);
            const e = C(a.i, kr, 6) ? .g(),
                f = 0 < e ? .length;
            var c = b,
                d = !!$v(a.g).reactiveTypeEnabledInAsfe[8];
            eI(c, {
                typ: "pv",
                asp: Number(f),
                ve: Number(d)
            });
            f && (a = new fI(a.g, e, b), b = bI(a.win, a.g), 0 === b.length ? gI(a.ba, {
                he: 0
            }) : (c = cI(b), d = c.g.getBoundingClientRect(), gI(a.ba, {
                he: b.length,
                U: S(a.win),
                Jc: Ao(a.win).scrollHeight,
                Dh: d.height,
                Fh: a.win.scrollY + d.top
            }), c = c.g, dI(a, c, 0, "-50% 0px 0px 0px"), dI(a, c, 1, "0px 0px 0px 0px")))
        }
    }

    function IJ(a) {
        return v(ot) || v(zt) && 2 === a.j.X ? .g() ? .g() ? !1 : a.j.X && Xh(a.j.X, Oq, 10) ? .5 <= (Zh(a.j.X.g(), 1) || 0) : !0
    }

    function JJ(a, b) {
        for (var c = Tz(Tz(new FG(b.Ra), b.errors), a.H), d = b.Ab, e = 0; e < d.length; e++) a: {
            for (var f = c, g = d[e], h = 0; h < f.B.length; h++)
                if (f.B[h] == g) break a;f.B.push(g)
        }
        c.g.pp = b.Md;
        c.g.ppp = b.Nd;
        c.g.ppos = b.placementPositionDiffs;
        c.g.eatf = b.oc;
        c.g.eatfAbg = b.qc;
        c.g.reatf = b.Nb;
        c = EG(DG(c.H(a.G.l.slice(0)), a.i), a.F).dc(a.A);
        if (d = b.Ia) c.g.as_count = d.Bf, c.g.d_count = d.dg, c.g.ng_count = d.Ig, c.g.am_count = d.Gf, c.g.atf_count = d.Cf, c.g.mdns = GG(d.zg), c.g.alldns = GG(d.Df);
        c = c.G(b.Yb).fh(b.od);
        d = b.Jc;
        null != d && (c.g.pgh = d);
        c.g.abl = b.lg;
        c.g.rr = a.C;
        void 0 !== b.exception && Uz(c, b.exception).xa(1);
        return c
    }

    function KJ(a, b) {
        var c = JJ(a, b);
        dA(a.B, 0 < b.errors.length || 0 < a.H.length || void 0 !== b.exception ? Kr : Jr, c);
        if (C(a.i, Ar, 24)) {
            a.l.i.g.g ? .F();
            b = MH(a.l);
            const d = u(aH);
            d.j = !!b ? .optimization ? .ablationFromStorage;
            b ? .optimization ? .ablatingThisPageview && (d.G = !0);
            d.T = !!b ? .optimization ? .availableAbg;
            b = u(aH);
            c = new SG(c);
            b.A ? (c.i.sl = IG(b.A ? ? []), c.i.daaos = IG(b.H ? ? []), c.i.ab = JG(b.G), c.i.rr = JG(b.O), c.i.oab = JG(b.F), null != b.j && (c.i.sab = JG(b.j)), b.B && (c.i.fb = JG(b.B)), c.i.ls = JG(b.T), KG(c, b.i.xc()), null != b.C && (c.i.rp = JG(b.C)),
                null != b.l && (c.i.expl = JG(b.l)), $G(b, c)) : c.errors.push("irr");
            dA(a.B, Mr, c)
        }
        c = a.l ? .na();
        v(vt) && null != c && (c = new Map([...c.j.map.entries()].map(KE)), b = new qI, pI(b, c), dA(a.B, Qr, b))
    }

    function LJ(a, b) {
        const c = u(zJ);
        if (c.i) {
            var d = new sm,
                e = b.Ab.filter(g => null !== g),
                f = a.H.concat(b.errors, b.exception ? [1] : []).filter(g => null !== g);
            nm(lm(qm(pm(om(mm(gm(im(km(hm(d, a.G.l.slice(0).map(g => {
                var h = new Cl;
                return Vh(h, 1, dh(g))
            })), e.map(g => {
                var h = new Fl;
                return Vh(h, 1, dh(g))
            })), f.map(g => Dl(g))), C(a.i, Yq, 23) ? .g()), b.Ra).G(b.Yb), b.Nb), b.oc), b.qc), a.F.map(g => g.toString())), Ml(Ll(Kl(Jl(Il(Hl(Gl(new Nl, b.Ia ? .Bf), b.Ia ? .dg), b.Ia ? .Ig), b.Ia ? .Gf), b.Ia ? .Cf), b.Ia ? .zg), b.Ia ? .Df));
            if (b.od)
                for (let g of No(b.od)) {
                    e =
                        new ii;
                    for (let h of b.od.get(g)) Rl(e, Pl(Ol(new Ql, h.kb), h.rh));
                    rm(d).set(g.toString(), e)
                }
            C(a.i, Ar, 24) && em(d);
            wJ(c, d)
        }
    }

    function MJ(a) {
        return Br(a.i) && 1 === L(Br(a.i), 1) ? !(C(Br(a.i), Gq, 6) && 1 <= (ui(C(Br(a.i), Gq, 6), 3) || 0)) : !1
    }

    function NJ(a) {
        if (MJ(a)) {
            a = a.l;
            var b = PB({
                wd: !0,
                xd: !0
            }, a.g);
            a = 0 < HH(b, a.g)
        } else a = a.l.g, b = OB({
            Pb: !1,
            vd: !1
        }, a), a = 0 < HH(b, a);
        return a
    }

    function OJ(a, b) {
        try {
            v(et) && a.l ? .va() ? .A()
        } catch (c) {
            dA(a.B, Pr, Uz(EG(DG((new FG(b)).dc(a.A), a.i), a.F).xa(14), c))
        }
    }

    function PJ(a, b, c) {
        {
            var d = MH(a.l),
                e = b.g;
            const f = e.g,
                g = e.Md;
            let h = e.Ra,
                k = e.Nd,
                l = e.errors.slice(),
                m = e.Ab.slice(),
                n = b.exception;
            const p = QI(a.g).had_ads_ablation ? ? !1;
            d ? (d.numAutoAdsPlaced ? h += d.numAutoAdsPlaced : a.G.j && m.push(13), void 0 !== d.exception && (n = d.exception), d.numPostPlacementsPlaced && (k += d.numPostPlacementsPlaced), c = {
                Ra: h,
                Md: g,
                Nd: k,
                Yb: f,
                errors: e.errors.slice(),
                Ab: m,
                exception: n,
                Nb: c,
                oc: !!d.eatf,
                qc: !!d.eatfAbg,
                lg: p
            }) : (m.push(12), a.G.j && m.push(13), c = {
                Ra: h,
                Md: g,
                Nd: k,
                Yb: f,
                errors: l,
                Ab: m,
                exception: n,
                Nb: c,
                oc: !1,
                qc: !1,
                lg: p
            })
        }
        c.Ia = IH(a.l.g);
        if (b = b.g.i) c.od = b;
        c.Jc = Ao(a.g).scrollHeight;
        if (fk() || C(a.i, Xq, 25) ? .j()) {
            d = cq(a.l.i.i);
            b = [];
            for (const f of d) {
                d = {};
                e = f.I;
                for (const g of No(e)) d[g] = e.get(g);
                d = {
                    anchorElement: BA(f),
                    position: f.g(),
                    clearBoth: f.H,
                    locationType: f.Qb,
                    placed: f.A,
                    placementProto: f.l ? f.l.toJSON() : null,
                    articleStructure: f.B ? f.B.toJSON() : null,
                    rejectionReasons: d
                };
                b.push(d)
            }
            gk(14, [{
                placementIdentifiers: b
            }, a.l.G, c.Ia])
        }
        return c
    }

    function QJ(a, b) {
        var c = a.l.g;
        c = c.googleSimulationState = c.googleSimulationState || {};
        c.amaConfigPlacementCount = b.Yb;
        c.numAutoAdsPlaced = b.Ra;
        c.hasAtfAd = b.Nb;
        void 0 !== b.exception && (c.exception = b.exception);
        null != a.l && (a = sI(a.g, a.l, {
            pd: -1,
            wc: -1,
            Fc: -1,
            qg: !0,
            Ff: !0
        }), null != a.g ? (c.placementPositionDiffs = EI(a.getValue()), b = DI(a.getValue()), a = new yF, a = ri(a, 2, zF, b), c.placementPositionDiffsReport = bj(a)) : (b = a.i.message, c.placementPositionDiffs = "E" + b, a = new yF, a = li(a, 1, zF, th(b)), c.placementPositionDiffsReport = bj(a)))
    }

    function RJ(a, b) {
        KJ(a, {
            Ra: 0,
            Yb: void 0,
            errors: [],
            Ab: [],
            exception: b,
            Nb: void 0,
            oc: void 0,
            qc: void 0,
            Ia: void 0
        });
        LJ(a, {
            Ra: 0,
            Yb: void 0,
            errors: [],
            Ab: [],
            exception: b,
            Nb: void 0,
            oc: void 0,
            qc: void 0,
            Ia: void 0
        })
    }
    class CJ {
        constructor(a, b, c, d, e, f, g, h, k) {
            this.g = a;
            this.B = b;
            this.A = c;
            this.i = d;
            this.j = e;
            this.F = f;
            this.O = h || null;
            this.H = [];
            this.I = k;
            this.T = g;
            this.C = "n"
        }
        runAutoGames() {
            const a = C(this.i, Zq, 32);
            a && this.T.runAutoGames({
                win: this.g,
                webPropertyCode: this.A,
                Lf: a,
                Kb: (C(this.i, hr, 33) ? .g() ? .i() ? ? null) || fr().i()
            })
        }
        ea(a) {
            try {
                OJ(this, a.g.Ra);
                const b = NJ(this) || MJ(this) ? NJ(this) : void 0;
                Ir({
                    ye: b
                }, this.g);
                const c = PJ(this, a, NJ(this));
                Xh(this.i, Xq, 25) && $h(C(this.i, Xq, 25), 1) && QJ(this, c);
                KJ(this, c);
                LJ(this, c);
                $z(753, () => {
                    if (v(jt) &&
                        null != this.l) {
                        var d = sI(this.g, this.l, {
                                pd: w(ut),
                                wc: w(tt),
                                Fc: w(lt),
                                qg: !0,
                                Ff: !1
                            }),
                            e = Sc(c);
                        null != d.g ? (d = EI(d.getValue()), e.placementPositionDiffs = d) : e.placementPositionDiffs = "E" + d.i.message;
                        e = JJ(this, e);
                        dA(this.B, Lr, e)
                    }
                })()
            } catch (b) {
                RJ(this, b)
            }
        }
        Z(a) {
            OJ(this, 0);
            RJ(this, a)
        }
    };
    var SJ = class extends R {},
        TJ = hj(SJ);

    function UJ(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? iq(() => TJ(c)) : fq(null)
    };

    function VJ(a, b) {
        return Vi(a, 5, b)
    }
    var WJ = class extends R {
        constructor() {
            super()
        }
        j() {
            return null != $h(this, 3)
        }
        g() {
            return M(this, 6)
        }
    };
    WJ.P = [10];
    var ZJ = ({
        win: a,
        zd: b,
        og: c = !1,
        pg: d = !1
    }) => XJ({
        win: a,
        zd: b,
        og: c,
        pg: d
    }) ? (b = Z(VI(), 24)) ? YJ(a, VJ(new WJ, pE(b))) : hq(Error("tcunav")) : YJ(a, VJ(new WJ, !0));

    function XJ({
        win: a,
        zd: b,
        og: c,
        pg: d
    }) {
        if (!(d = !d && tE(new xE(a)))) {
            if (c = !c) {
                if (b) {
                    a = UJ(a);
                    if (null != a.g)
                        if ((a = a.getValue()) && null != L(a, 1)) b: switch (a = L(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else bA(806, a.i), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function YJ(a, b) {
        return (a = Xj(b, a)) ? fq(a) : hq(Error("unav"))
    };
    var $J = class extends R {};
    class aK {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.l = b;
            this.B = c;
            this.i = !1;
            this.j = d;
            this.A = e
        }
    };
    class bK {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.g = b
            })
        }
    };

    function cK() {
        const {
            promise: a,
            resolve: b
        } = new bK;
        return {
            promise: a,
            resolve: b
        }
    };

    function dK(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        let d = b[a];
        if (d) return d;
        d = cK();
        b[a] = d;
        c();
        return d
    }

    function eK(a, b, c) {
        return dK(a, b, () => {
            Ve(b.document, c)
        }).promise
    };

    function fK() {
        const a = {};
        Xb(at) && (a.bust = Xb(at));
        var b = VI();
        b = Z(b, 38, "");
        "" !== b && (a.sbust = b);
        return a
    }
    const gK = new Map([
        [2, 7],
        [3, 1],
        [4, 3],
        [5, 12]
    ]);

    function hK(a, b, c) {
        c = Zc(c, fK());
        if (1 === a) return {
            co: Ve(b.document, c),
            Vc: new Promise(() => {})
        };
        if (gK.has(a)) return {
            Vc: eK(gK.get(a), b, c)
        };
        throw Error(`Unexpected chunkId: ${a}`);
    };
    var iK = class {
        constructor(a) {
            this.jb = a
        }
        runAutoGames({
            win: a,
            webPropertyCode: b,
            Lf: c,
            Kb: d
        }) {
            cA(1116, hK(5, a, this.jb).Vc.then(e => {
                e.runAutoGames({
                    win: a,
                    webPropertyCode: b,
                    serializedAutoGamesConfig: bj(c),
                    serializedFloatingToolbarMessages: bj(d)
                })
            }))
        }
    };
    var jK = {
            Ik: "google_ads_preview",
            vl: "google_mc_lab",
            Ll: "google_anchor_debug",
            Kl: "google_bottom_anchor_debug",
            INTERSTITIAL: "google_ia_debug",
            hm: "google_scr_debug",
            jm: "google_ia_debug_allow_onclick",
            Hm: "googleads",
            xh: "google_pedestal_debug",
            an: "google_responsive_slot_preview",
            Zm: "google_responsive_dummy_ad",
            yk: "google_audio_sense",
            Bk: "google_auto_gallery",
            Dk: "google_auto_storify_swipeable",
            Ck: "google_auto_storify_scrollable",
            Ak: "google_games_single_game",
            zk: "google_games_catalog"
        },
        kK = {
            google_bottom_anchor_debug: 1,
            google_anchor_debug: 2,
            google_ia_debug: 8,
            google_scr_debug: 9,
            googleads: 2,
            google_pedestal_debug: 30
        };
    var lK = {
        INTERSTITIAL: 1,
        BOTTOM_ANCHOR: 2,
        TOP_ANCHOR: 3,
        1: "INTERSTITIAL",
        2: "BOTTOM_ANCHOR",
        3: "TOP_ANCHOR"
    };

    function mK(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (-1 != a.indexOf(b)) return !0;
        b = nK(b);
        return "go" != b && -1 != a.indexOf(b) ? !0 : !1
    }

    function nK(a) {
        let b = "";
        Ze(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    }

    function oK() {
        var a = r.location;
        let b = !1;
        Ze(jK, c => {
            mK(a, c) && (b = !0)
        });
        return b
    }

    function pK(a, b) {
        switch (a) {
            case 1:
                return mK(b, "google_ia_debug");
            case 2:
                return mK(b, "google_bottom_anchor_debug");
            case 3:
                return mK(b, "google_anchor_debug") || mK(b, "googleads")
        }
    };

    function qK({
        win: a,
        webPropertyCode: b,
        jb: c
    }) {
        mK(a.location, "google_games_single_game") ? rK(a, b, 1, c) : mK(a.location, "google_games_catalog") && rK(a, b, 2, c)
    }

    function rK(a, b, c, d) {
        var e = new Zq;
        c = Vh(e, 1, dh(c));
        (new iK(d)).runAutoGames({
            win: a,
            webPropertyCode: b,
            Lf: c,
            Kb: fr().i()
        })
    };
    var sK = class extends R {
        constructor() {
            super()
        }
        Ai() {
            return zi(this, 3)
        }
    };
    const tK = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var uK = class extends R {
        constructor() {
            super()
        }
        getVersion() {
            return xi(this, 2)
        }
    };
    uK.P = [3];

    function vK(a) {
        return a.includes("~") ? a.split("~").slice(1) : []
    };

    function wK(a) {
        return Mf(0 !== a.length % 4 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function xK(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function yK(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    }

    function zK(a, b) {
        a = wK(a);
        return a.length < b ? a.padEnd(b, "0") : a
    };

    function AK(a) {
        var b = wK(a),
            c = xK(b.slice(0, 6));
        a = xK(b.slice(6, 12));
        var d = new uK;
        c = Yi(d, 1, c);
        a = Yi(c, 2, a);
        b = b.slice(12);
        c = xK(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (0 === e.length) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = 0 === xK(e[0]);
            e = e.slice(1);
            var g = BK(e, b),
                h = 0 === d.length ? 0 : d[d.length - 1];
            h = yK(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = BK(e, b);
                g = yK(f);
                for (let l = 0; l <= g; l++) d.push(h + l);
                e = e.slice(f.length)
            }
        }
        if (0 <
            e.length) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return ji(a, 3, d, fh)
    }

    function BK(a, b) {
        const c = a.indexOf("11");
        if (-1 === c) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var CK = class extends R {
        constructor() {
            super()
        }
    };
    var DK = class extends R {
        constructor() {
            super()
        }
    };
    var EK = class extends R {
        getVersion() {
            return xi(this, 1)
        }
    };
    var FK = class extends R {
        constructor() {
            super()
        }
    };

    function GK(a) {
        var b = new HK;
        return E(b, 1, a)
    }
    var HK = class extends R {
        constructor() {
            super()
        }
    };
    const IK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        JK = 6 + IK.reduce((a, b) => a + b);
    var KK = class extends R {
        constructor() {
            super()
        }
    };
    var LK = class extends R {
        getVersion() {
            return xi(this, 1)
        }
    };
    var MK = class extends R {
        constructor() {
            super()
        }
    };

    function NK(a) {
        var b = new OK;
        return E(b, 1, a)
    }
    var OK = class extends R {
        constructor() {
            super()
        }
    };
    const PK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        QK = 6 + PK.reduce((a, b) => a + b);
    var RK = class extends R {
        constructor() {
            super()
        }
    };
    var SK = class extends R {
        constructor() {
            super()
        }
    };
    var TK = class extends R {
        getVersion() {
            return xi(this, 1)
        }
    };
    var UK = class extends R {
        constructor() {
            super()
        }
    };

    function VK(a) {
        var b = new WK;
        return E(b, 1, a)
    }
    var WK = class extends R {
        constructor() {
            super()
        }
    };
    const XK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        YK = 6 + XK.reduce((a, b) => a + b);
    var ZK = class extends R {
        constructor() {
            super()
        }
    };
    var $K = class extends R {
        constructor() {
            super()
        }
        getVersion() {
            return xi(this, 1)
        }
    };
    const aL = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        bL = 6 + aL.reduce((a, b) => a + b);
    var cL = "a".charCodeAt(),
        dL = Rc(mo),
        eL = Rc(no);

    function fL() {
        var a = new gL;
        return P(a, 1, 0)
    }

    function hL(a) {
        const b = yi(a, 1);
        a = xi(a, 2);
        return new Date(1E3 * b + a / 1E6)
    }
    var gL = class extends R {};

    function iL(a, b) {
        if (a.g + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.i.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function jL(a) {
        let b = iL(a, 12);
        const c = [];
        for (; b--;) {
            var d = !0 === !!iL(a, 1),
                e = iL(a, 16);
            if (d)
                for (d = iL(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function kL(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (iL(a, 1)) {
                const f = e + 1;
                if (c && -1 === c.indexOf(f)) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function lL(a) {
        const b = iL(a, 16);
        return !0 === !!iL(a, 1) ? (a = jL(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : kL(a, b)
    }
    class mL {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.i = a;
            this.g = 0
        }
        skip(a) {
            this.g += a
        }
    };
    var oL = (a, b) => {
        try {
            var c = Mf(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new mL(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = !0;
            d.skip(78);
            c.cmpId = iL(d, 12);
            c.cmpVersion = iL(d, 12);
            d.skip(30);
            c.tcfPolicyVersion = iL(d, 6);
            c.isServiceSpecific = !!iL(d, 1);
            c.useNonStandardStacks = !!iL(d, 1);
            c.specialFeatureOptins = nL(kL(d, 12, eL), eL);
            c.purpose = {
                consents: nL(kL(d, 24, dL), dL),
                legitimateInterests: nL(kL(d, 24, dL), dL)
            };
            c.purposeOneTreatment = !!iL(d, 1);
            c.publisherCC = String.fromCharCode(cL + iL(d, 6)) + String.fromCharCode(cL +
                iL(d, 6));
            c.vendor = {
                consents: nL(lL(d), b),
                legitimateInterests: nL(lL(d), b)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const nL = (a, b) => {
        const c = {};
        if (Array.isArray(b) && 0 !== b.length)
            for (const d of b) c[d] = -1 !== a.indexOf(d);
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var pL = class extends R {
        g() {
            return null != I(this, 2)
        }
    };
    var qL = class extends R {
        g() {
            return null != I(this, 2)
        }
    };
    var rL = class extends R {};
    var sL = class extends R {},
        tL = hj(sL);
    sL.P = [7];

    function uL(a) {
        a = vL(a);
        try {
            var b = a ? tL(a) : null
        } catch (c) {
            b = null
        }
        return b ? C(b, rL, 4) || null : null
    }

    function vL(a) {
        a = (new Wj(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function wL(a) {
        a.__uspapiPostMessageReady || xL(new yL(a))
    }

    function xL(a) {
        a.g = b => {
            const c = "string" === typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && "getUSPData" === e.command && a.win.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.win.addEventListener("message", a.g);
        a.win.__uspapiPostMessageReady = !0
    }
    var yL = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
    };

    function zL(a) {
        a.__tcfapiPostMessageReady || AL(new BL(a))
    }

    function AL(a) {
        a.i = b => {
            const c = "string" == typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.g.__tcfapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = "removeEventListener" === e.command ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.g.addEventListener("message", a.i);
        a.g.__tcfapiPostMessageReady = !0
    }
    var BL = class {
        constructor(a) {
            this.g = a;
            this.i = null
        }
    };
    var CL = class extends R {};
    var DL = class extends R {
            g() {
                return null != I(this, 1)
            }
        },
        EL = hj(DL);
    DL.P = [2];

    function FL(a, b, c) {
        function d(m) {
            if (10 > m.length) return null;
            var n = g(m.slice(0, 4));
            n = h(n);
            m = g(m.slice(6, 10));
            m = k(m);
            return "1" + n + m + "N"
        }

        function e(m) {
            if (10 > m.length) return null;
            var n = g(m.slice(0, 6));
            n = h(n);
            m = g(m.slice(6, 10));
            m = k(m);
            return "1" + n + m + "N"
        }

        function f(m) {
            if (12 > m.length) return null;
            var n = g(m.slice(0, 6));
            n = h(n);
            m = g(m.slice(8, 12));
            m = k(m);
            return "1" + n + m + "N"
        }

        function g(m) {
            const n = [];
            let p = 0;
            for (let q = 0; q < m.length / 2; q++) n.push(xK(m.slice(p, p + 2))), p += 2;
            return n
        }

        function h(m) {
            return m.every(n => 1 === n) ?
                "Y" : "N"
        }

        function k(m) {
            return m.some(n => 1 === n) ? "Y" : "N"
        }
        if (0 === a.length) return null;
        a = a.split(".");
        if (2 < a.length) return null;
        a = wK(a[0]);
        const l = xK(a.slice(0, 6));
        a = a.slice(6);
        if (1 !== l) return null;
        switch (b) {
            case 8:
                return d(a);
            case 10:
            case 12:
            case 9:
                return e(a);
            case 11:
                return c ? f(a) : null;
            default:
                return null
        }
    };

    function GL(a) {
        var b = v(Vs);
        a !== a.top || a.__uspapi || a.frames.__uspapiLocator || (a = new HL(a, b), IL(a), JL(a))
    }

    function IL(a) {
        !a.l || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", aE(a.g, "__uspapiLocator"), Ka("__uspapi", (...b) => KL(a, ...b), a.g), wL(a.g))
    }

    function JL(a) {
        !a.i || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", aE(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], Ka("__tcfapi", (...b) => LL(a, ...b), a.g), zL(a.g))
    }

    function KL(a, b, c, d) {
        "function" === typeof d && "getUSPData" === b && d({
            version: 1,
            uspString: a.l
        }, !0)
    }

    function ML(a, b) {
        if (!b ? .g() || 0 === O(b, 1).length || 0 == D(b, CL, 2).length) return null;
        const c = O(b, 1);
        let d;
        try {
            var e = AK(c.split("~")[0]);
            d = vK(c)
        } catch (f) {
            return null
        }
        b = D(b, CL, 2).reduce((f, g) => yi(NL(f), 1) > yi(NL(g), 1) ? f : g);
        e = ai(e, 3, gh, 2).indexOf(xi(b, 1));
        return -1 === e || e >= d.length ? null : {
            uspString: FL(d[e], xi(b, 1), a.A),
            se: hL(NL(b))
        }
    }

    function OL(a) {
        a = a.find(b => 13 === zi(b, 1));
        if (a ? .g()) try {
            return EL(O(a, 2))
        } catch (b) {}
        return null
    }

    function NL(a) {
        return Xh(a, gL, 2) ? C(a, gL, 2) : fL()
    }

    function LL(a, b, c, d, e = null) {
        if ("function" === typeof d)
            if (c && (2.1 < c || 1 >= c)) d(null, !1);
            else switch (c = a.g.__tcfapiEventListeners, b) {
                case "getTCData":
                    !e || Array.isArray(e) && e.every(f => "number" === typeof f) ? d(PL(a, e, null), !0) : d(null, !1);
                    break;
                case "ping":
                    d({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.1",
                        cmpVersion: 2,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    b = c.push(d);
                    d(PL(a, null, b - 1), !0);
                    break;
                case "removeEventListener":
                    c[e] ? (c[e] = null, d(!0)) : d(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    d(null, !1)
            }
    }

    function PL(a, b, c) {
        if (!a.i) return null;
        b = oL(a.i, b);
        b.addtlConsent = null != a.j ? a.j : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    }
    class HL {
        constructor(a, b) {
            this.g = a;
            this.A = b;
            b = vL(this.g.document);
            try {
                var c = b ? tL(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = C(b, qL, 5) || null, b = D(b, pL, 7), b = OL(b ? ? []), c = {
                Pf: c,
                kg: b
            }) : c = {
                Pf: null,
                kg: null
            };
            b = c;
            c = ML(this, b.kg);
            b = b.Pf;
            if (b ? .g() && 0 !== O(b, 2).length) {
                var d = Xh(b, gL, 1) ? C(b, gL, 1) : fL();
                b = {
                    uspString: O(b, 2),
                    se: hL(d)
                }
            } else b = null;
            this.l = b && c ? c.se > b.se ? c.uspString : b.uspString : b ? b.uspString : c ? c.uspString : null;
            this.i = (c = uL(a.document)) && null != I(c, 1) ? O(c, 1) : null;
            this.j = (a = uL(a.document)) && null != I(a, 2) ? O(a, 2) : null
        }
    };
    const QL = a => {
        const b = a[0] / 255,
            c = a[1] / 255;
        a = a[2] / 255;
        return .2126 * (.03928 >= b ? b / 12.92 : Math.pow((b + .055) / 1.055, 2.4)) + .7152 * (.03928 >= c ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4)) + .0722 * (.03928 >= a ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4))
    };
    var RL = (a, b) => {
        a = QL(a);
        b = QL(b);
        return (Math.max(a, b) + .05) / (Math.min(a, b) + .05)
    };
    var SL = Promise;
    class TL {
        constructor(a) {
            this.j = a
        }
        i(a, b, c) {
            this.j.then(d => {
                d.i(a, b, c)
            })
        }
        g(a, b) {
            return this.j.then(c => c.g(a, b))
        }
    };
    class UL {
        constructor(a) {
            this.data = a
        }
    };

    function VL(a, b) {
        WL(a, b);
        return new XL(a)
    }
    class XL {
        constructor(a) {
            this.j = a
        }
        i(a, b, c = []) {
            const d = new MessageChannel;
            WL(d.port1, b);
            this.j.postMessage(a, [d.port2].concat(c))
        }
        g(a, b) {
            return new SL(c => {
                this.i(a, c, b)
            })
        }
    }

    function WL(a, b) {
        b && (a.onmessage = c => {
            b(new UL(c.data, VL(c.ports[0])))
        })
    };
    var $L = ({
        destination: a,
        Na: b,
        origin: c,
        ke: d = "ZNWN1d",
        onMessage: e,
        Lg: f
    }) => YL({
        destination: a,
        Bi: () => b.contentWindow,
        cj: ZL(c),
        ke: d,
        onMessage: e,
        Lg: f
    });
    const YL = ({
            destination: a,
            Bi: b,
            cj: c,
            fo: d,
            ke: e,
            onMessage: f,
            Lg: g
        }) => {
            const h = Object.create(null);
            c.forEach(k => {
                h[k] = !0
            });
            return new TL(new SL((k, l) => {
                const m = n => {
                    n.source && n.source === b() && !0 === h[n.origin] && (n.data.n || n.data) === e && (a.removeEventListener("message", m, !1), d && n.data.t !== d ? l(Error(`Token mismatch while establishing channel "${e}". Expected ${d}, but received ${n.data.t}.`)) : (k(VL(n.ports[0], f)), g && g(n)))
                };
                a.addEventListener("message", m, !1)
            }))
        },
        ZL = a => {
            a = "string" === typeof a ? [a] : a;
            const b = Object.create(null);
            a.forEach(c => {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };

    function aM(a, b, c, d, e, f, g = null) {
        if (v(it)) var h = e ? PI(e) : null;
        else {
            try {
                h = a.localStorage
            } catch (m) {
                h = null
            }
            h = h ? PI(h) : null
        }
        a: {
            if (d) try {
                var k = Er(d);
                break a
            } catch (m) {
                GI(a, {
                    cfg: 1,
                    inv: 1
                })
            }
            k = null
        }
        if (d = k) {
            if (e) {
                k = new Nq;
                E(d, 3, k);
                h = Cr(d) && vi(Cr(d), 13) ? vi(Cr(d), 13) : 1;
                h = Date.now() + 864E5 * h;
                Number.isFinite(h) && Zi(k, 1, Math.round(h));
                k = Rh(d);
                if (Cr(d)) {
                    h = new Mq;
                    var l = Cr(d);
                    l = $h(l, 23);
                    h = Vi(h, 23, null == l ? void 0 : l);
                    l = M(Cr(d), 12, !1);
                    h = Vi(h, 12, l);
                    l = M(Cr(d), 15, !1);
                    h = Vi(h, 15, l);
                    E(k, 15, h)
                }
                h = D(k, or, 1);
                for (l = 0; l < h.length; l++) Vh(h[l],
                    11);
                Vh(k, 22);
                if (v(gt)) OI(a);
                else try {
                    (e || a.localStorage).setItem("google_ama_config", bj(k))
                } catch (m) {
                    GI(a, {
                        lserr: 1
                    })
                }
            }
            e = LI(a, D(d, Wq, 7));
            k = {};
            v(ht) || (k.kj = C(d, ir, 8) || new ir);
            e && (k.X = e);
            e && KI(e, 3) && (k.tc = [1]);
            e = k;
            if (7 === c.google_pgb_reactive && !e.X) return !1;
            RI(a, 2) && (gk(5, [d.toJSON()]), c = HI(c), f = new iK(f), k = e.X, c.google_package = k && I(k, 4) || "", BJ(a, b, d, e, f, new Bq(["google-auto-placed"], c), g));
            return !0
        }
        h && (GI(a, {
            cfg: 1,
            cl: 1
        }), v(it) ? null != e && NI(a, e) : OI(a));
        return !1
    };
    var cM = a => {
        const b = a.D;
        null == b.google_ad_output && (b.google_ad_output = "html");
        if (null != b.google_ad_client) {
            var c;
            (c = String(b.google_ad_client)) ? (c = c.toLowerCase(), "ca-" != c.substring(0, 3) && (c = "ca-" + c)) : c = "";
            b.google_ad_client = c
        }
        null != b.google_ad_slot && (b.google_ad_slot = String(b.google_ad_slot));
        b.google_webgl_support = !!Sj.WebGLRenderingContext;
        b.google_ad_section = b.google_ad_section || b.google_ad_region || "";
        b.google_country = b.google_country || b.google_gl || "";
        c = (new Date).getTime();
        Array.isArray(b.google_color_bg) &&
            (b.google_color_bg = bM(a, b.google_color_bg, c));
        Array.isArray(b.google_color_text) && (b.google_color_text = bM(a, b.google_color_text, c));
        Array.isArray(b.google_color_link) && (b.google_color_link = bM(a, b.google_color_link, c));
        Array.isArray(b.google_color_url) && (b.google_color_url = bM(a, b.google_color_url, c));
        Array.isArray(b.google_color_border) && (b.google_color_border = bM(a, b.google_color_border, c));
        Array.isArray(b.google_color_line) && (b.google_color_line = bM(a, b.google_color_line, c))
    };

    function bM(a, b, c) {
        a.i |= 2;
        return b[c % b.length]
    };
    var dM = (a, b = !1) => {
        try {
            return b ? (new Xd(a.innerWidth, a.innerHeight)).round() : ge(a || window).round()
        } catch (c) {
            return new Xd(-12245933, -12245933)
        }
    };

    function eM(a = r) {
        a = a.devicePixelRatio;
        return "number" === typeof a ? +a.toFixed(3) : null
    }

    function fM(a, b = r) {
        a = a.scrollingElement || ("CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return new Wd(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
    }

    function gM(a) {
        try {
            return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
        } catch (b) {
            return !1
        }
    };

    function hM(a, b) {
        var c = Xz,
            d;
        var e;
        d = (e = (e = ok()) && (d = e.initialLayoutRect) && "number" === typeof d.top && "number" === typeof d.left && "number" === typeof d.width && "number" === typeof d.height ? new kk(d.left, d.top, d.width, d.height) : null) ? new Wd(e.left, e.top) : (d = rk()) && za(d.rootBounds) ? new Wd(d.rootBounds.left + d.boundingClientRect.left, d.rootBounds.top + d.boundingClientRect.top) : null;
        if (d) return d;
        try {
            var f = new Wd(0, 0),
                g = fe(b);
            var h = g ? ie(g) : window;
            if (Vb(h, "parent")) {
                do {
                    if (h == a) var k = Dk(b);
                    else {
                        var l = Ck(b);
                        k = new Wd(l.left,
                            l.top)
                    }
                    g = k;
                    f.x += g.x;
                    f.y += g.y
                } while (h && h != a && h != h.parent && (b = h.frameElement) && (h = h.parent))
            }
            return f
        } catch (m) {
            return c.Ba(888, m), new Wd(-12245933, -12245933)
        }
    };

    function iM(a, b, c) {
        return c ? ak(b, c, a.g) : null
    }

    function jM(a, b, c, d) {
        if (d) {
            var e = yi(c, 2) - Date.now() / 1E3;
            e = {
                Ed: Math.max(e, 0),
                path: O(c, 3),
                domain: O(c, 4),
                bh: !1
            };
            c = c.getValue();
            a = a.g;
            M(d, 5) && Zj(a) && (new Wj(a.document)).set(b, c, e)
        }
    }

    function kM(a, b, c) {
        if (c && ak(b, c, a.g))
            for (const d of lM(a.g.location.hostname)) bk(b, c, a.g, "/", d)
    }
    var mM = class {
        constructor(a) {
            this.g = a;
            this.i = 0
        }
    };

    function lM(a) {
        if ("localhost" === a) return ["localhost"];
        a = a.split(".");
        if (2 > a.length) return [];
        const b = [];
        for (let c = 0; c < a.length - 1; ++c) b.push(a.slice(c).join("."));
        return b
    };

    function nM(a, b, c) {
        return $z(629, function(d) {
            delete a._gfp_s_;
            if (v(Zs) && Z(VI(), 37, !1)) return Promise.resolve();
            if (!d) throw Error("Invalid JSONP response");
            d = d._cookies_;
            if (!d) return Promise.resolve();
            if (0 === d.length) throw Error("Invalid JSONP response");
            for (const f of d) {
                var e = f._domain_;
                const g = f._value_,
                    h = f._expires_,
                    k = f._path_;
                d = f._version_ || 1;
                if ("string" !== typeof e || "string" !== typeof g || "number" !== typeof h || "string" !== typeof k || "number" !== typeof d || !g) throw Error("Invalid JSONP response");
                e = Mj(Lj(Kj(Ij(g),
                    h), k), e);
                switch (d) {
                    case 1:
                        jM(c, "__gads", e, b);
                        break;
                    case 2:
                        jM(c, "__gpi", e, b)
                }
            }
            return Promise.resolve()
        })
    }

    function oM(a, b, c) {
        let d;
        if (0 === a.i) {
            if (iM(a, "__gads", b)) var e = !0;
            else e = a.g, M(b, 5) && Zj(e) && (new Wj(e.document)).set("GoogleAdServingTest", "Good", void 0), (e = "Good" === ak("GoogleAdServingTest", b, a.g)) && bk("GoogleAdServingTest", b, a.g);
            a.i = e ? 2 : 1
        }
        2 === a.i && (d = nM(c, b, a));
        c._gfp_p_ = !0;
        return d
    }

    function pM(a, b, c, d) {
        d = {
            domain: c.location.hostname,
            callback: "_gfp_s_",
            client: d
        };
        var e = iM(b, "__gads", a);
        e && (d.cookie = e);
        (e = iM(b, "__gpi", a)) && !e.includes("&") && (d.gpic = e);
        const f = Zc(sj `https://partner.googleadservices.com/gampad/cookie.js`, d),
            g = oM(b, a, c);
        g ? new Promise(h => {
            c._gfp_s_ = k => {
                g(k).then(h)
            };
            Ve(c.document, f)
        }) : Promise.resolve()
    }

    function qM(a, b, c) {
        "_gfp_p_" in b || (b._gfp_p_ = !1);
        var d = new mM(b);
        c = b.google_ad_client || c;
        const e = b._gfp_p_;
        if ("boolean" !== typeof e) throw Error(`Illegal value of ${"_gfp_p_"}: ${e}`);
        e ? Promise.resolve() : pM(a, d, b, c)
    };
    const rM = (a, b) => {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        sM = (a, b) => {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        tM = (a, b) => {
            (0, a.__gpp)("getSection", c => {
                b.callback({
                    nb: c ? ? void 0,
                    ld: c ? void 0 : 4
                })
            }, b.apiPrefix)
        },
        uM = {
            Dc: a => a.listener,
            Rb: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }
            }),
            wb: (a, b) => {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        vM = {
            Dc: a => a.listener,
            Rb: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }
            }),
            wb: (a, b) => {
                b = b.__gppReturn;
                const c = b.returnValue.data;
                a ? .(c, b.success)
            }
        },
        wM = {
            Dc: a => a.callback,
            Rb: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "getSection",
                    version: "1.1",
                    parameter: a.apiPrefix
                }
            }),
            wb: (a, b) => {
                b = b.__gppReturn;
                a({
                    nb: b.returnValue ? ? void 0,
                    ld: b.success ? void 0 : 2
                })
            }
        };

    function xM(a) {
        let b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            bf: b.__gppReturn.callId
        }
    }

    function yM(a) {
        if (!a) return !1;
        const b = AK(a.split("~")[0]),
            c = vK(a);
        for (let Ai = 0; Ai < ai(b, 3, gh, 2).length; ++Ai) {
            const VP = ai(b, 3, gh, 2)[Ai],
                ac = c[Ai];
            switch (VP) {
                case 8:
                    if (0 === ac.length) throw Error("Cannot decode empty USCA section string.");
                    const $f = ac.split(".");
                    if (2 < $f.length) throw Error(`Expected at most 1 sub-section but got ${$f.length-1} when decoding ${ac}.`);
                    var d = void 0,
                        e = void 0,
                        f = void 0,
                        g = void 0,
                        h = void 0,
                        k = void 0,
                        l = void 0,
                        m = void 0,
                        n = void 0,
                        p = void 0,
                        q = void 0,
                        x = void 0,
                        z = void 0,
                        G = void 0,
                        F = void 0,
                        K = void 0,
                        H = void 0,
                        N = void 0,
                        J = void 0,
                        Ea = void 0,
                        Ya = void 0,
                        Eb = void 0,
                        U = void 0,
                        tb = $f[0];
                    if (0 === tb.length) throw Error("Cannot decode empty core segment string.");
                    let Bi = zK(tb, JK);
                    const Km = xK(Bi.slice(0, 6));
                    Bi = Bi.slice(6);
                    if (1 !== Km) throw Error(`Unable to decode unsupported USCA Section specification version ${Km} - only version 1 is supported.`);
                    let Lm = 0;
                    const sa = [];
                    for (let ma = 0; ma < IK.length; ma++) {
                        const ha = IK[ma];
                        sa.push(xK(Bi.slice(Lm, Lm + ha)));
                        Lm += ha
                    }
                    var rc = new EK;
                    U = Yi(rc, 1, Km);
                    var sc = sa.shift();
                    Eb = Q(U,
                        2, sc);
                    var Sd = sa.shift();
                    Ya = Q(Eb, 3, Sd);
                    var ba = sa.shift();
                    Ea = Q(Ya, 4, ba);
                    var tc = sa.shift();
                    J = Q(Ea, 5, tc);
                    var Mm = sa.shift();
                    N = Q(J, 6, Mm);
                    var Nm = new DK,
                        Om = sa.shift();
                    H = Q(Nm, 1, Om);
                    var Pm = sa.shift();
                    K = Q(H, 2, Pm);
                    var Qm = sa.shift();
                    F = Q(K, 3, Qm);
                    var Rm = sa.shift();
                    G = Q(F, 4, Rm);
                    var Sm = sa.shift();
                    z = Q(G, 5, Sm);
                    var Tm = sa.shift();
                    x = Q(z, 6, Tm);
                    var Um = sa.shift();
                    q = Q(x, 7, Um);
                    var Vm = sa.shift();
                    p = Q(q, 8, Vm);
                    var Wm = sa.shift();
                    n = Q(p, 9, Wm);
                    m = E(N, 7, n);
                    var Xm = new CK,
                        Ym = sa.shift();
                    l = Q(Xm, 1, Ym);
                    var Zm = sa.shift();
                    k = Q(l, 2, Zm);
                    h = E(m, 8,
                        k);
                    var $m = sa.shift();
                    g = Q(h, 9, $m);
                    var an = sa.shift();
                    f = Q(g, 10, an);
                    var bn = sa.shift();
                    e = Q(f, 11, bn);
                    var ag = sa.shift();
                    const vw = d = Q(e, 12, ag);
                    if (1 === $f.length) var Ci = GK(vw);
                    else {
                        var Di = GK(vw),
                            Ei = void 0,
                            Fe = void 0,
                            Fi = void 0,
                            Gi = $f[1];
                        if (0 === Gi.length) throw Error("Cannot decode empty GPC segment string.");
                        const ma = zK(Gi, 3),
                            ha = xK(ma.slice(0, 2));
                        if (0 > ha || 1 < ha) throw Error(`Attempting to decode unknown GPC segment subsection type ${ha}.`);
                        Fi = ha + 1;
                        const bg = xK(ma.charAt(2));
                        var cn = new FK;
                        Fe = Q(cn, 2, Fi);
                        Ei = Wi(Fe, 1, !!bg);
                        Ci = E(Di, 2, Ei)
                    }
                    const ww = C(Ci, EK, 1);
                    if (1 === zi(ww, 5) || 1 === zi(ww, 6)) return !0;
                    break;
                case 10:
                    if (0 === ac.length) throw Error("Cannot decode empty USCO section string.");
                    const cg = ac.split(".");
                    if (2 < cg.length) throw Error(`Expected at most 2 segments but got ${cg.length} when decoding ${ac}.`);
                    var Ge = void 0,
                        He = void 0,
                        Hi = void 0,
                        Wa = void 0,
                        dg = void 0,
                        Ii = void 0,
                        Ji = void 0,
                        eg = void 0,
                        fg = void 0,
                        gg = void 0,
                        hg = void 0,
                        ig = void 0,
                        Kb = void 0,
                        uc = void 0,
                        wb = void 0,
                        mb = void 0,
                        Ki = void 0,
                        Ie = void 0,
                        Je = cg[0];
                    if (0 === Je.length) throw Error("Cannot decode empty core segment string.");
                    let Li = zK(Je, QK);
                    const dn = xK(Li.slice(0, 6));
                    Li = Li.slice(6);
                    if (1 !== dn) throw Error(`Unable to decode unsupported USCO Section specification version ${dn} - only version 1 is supported.`);
                    let en = 0;
                    const Pa = [];
                    for (let ma = 0; ma < PK.length; ma++) {
                        const ha = PK[ma];
                        Pa.push(xK(Li.slice(en, en + ha)));
                        en += ha
                    }
                    var xb = new LK;
                    Ie = Yi(xb, 1, dn);
                    var Ga = Pa.shift();
                    Ki = Q(Ie, 2, Ga);
                    var cb = Pa.shift();
                    mb = Q(Ki, 3, cb);
                    var nb = Pa.shift();
                    wb = Q(mb, 4, nb);
                    var Qa = Pa.shift();
                    uc = Q(wb, 5, Qa);
                    var Lb = Pa.shift();
                    Kb = Q(uc, 6, Lb);
                    var Mi = new KK,
                        Ni = Pa.shift();
                    ig = Q(Mi, 1, Ni);
                    var Nc = Pa.shift();
                    hg = Q(ig, 2, Nc);
                    var Oi = Pa.shift();
                    gg = Q(hg, 3, Oi);
                    var jg = Pa.shift();
                    fg = Q(gg, 4, jg);
                    var kg = Pa.shift();
                    eg = Q(fg, 5, kg);
                    var Td = Pa.shift();
                    Ji = Q(eg, 6, Td);
                    var fn = Pa.shift();
                    Ii = Q(Ji, 7, fn);
                    dg = E(Kb, 7, Ii);
                    var lg = Pa.shift();
                    Wa = Q(dg, 8, lg);
                    var Pi = Pa.shift();
                    Hi = Q(Wa, 9, Pi);
                    var WP = Pa.shift();
                    He = Q(Hi, 10, WP);
                    var XP = Pa.shift();
                    const xw = Ge = Q(He, 11, XP);
                    if (1 === cg.length) var yw = NK(xw);
                    else {
                        var YP = NK(xw),
                            zw = void 0,
                            Aw = void 0,
                            Bw = void 0,
                            Cw = cg[1];
                        if (0 === Cw.length) throw Error("Cannot decode empty GPC segment string.");
                        const ma = zK(Cw, 3),
                            ha = xK(ma.slice(0, 2));
                        if (0 > ha || 1 < ha) throw Error(`Attempting to decode unknown GPC segment subsection type ${ha}.`);
                        Bw = ha + 1;
                        const bg = xK(ma.charAt(2));
                        var ZP = new MK;
                        Aw = Q(ZP, 2, Bw);
                        zw = Wi(Aw, 1, !!bg);
                        yw = E(YP, 2, zw)
                    }
                    const Dw = C(yw, LK, 1);
                    if (1 === zi(Dw, 5) || 1 === zi(Dw, 6)) return !0;
                    break;
                case 12:
                    if (0 === ac.length) throw Error("Cannot decode empty usct section string.");
                    const mg = ac.split(".");
                    if (2 < mg.length) throw Error(`Expected at most 2 segments but got ${mg.length} when decoding ${ac}.`);
                    var $P =
                        void 0,
                        Ew = void 0,
                        Fw = void 0,
                        Gw = void 0,
                        Hw = void 0,
                        Iw = void 0,
                        Jw = void 0,
                        Kw = void 0,
                        Lw = void 0,
                        Mw = void 0,
                        Nw = void 0,
                        Ow = void 0,
                        Pw = void 0,
                        Qw = void 0,
                        Rw = void 0,
                        Sw = void 0,
                        Tw = void 0,
                        Uw = void 0,
                        Vw = void 0,
                        Ww = void 0,
                        Xw = void 0,
                        Yw = void 0,
                        Zw = mg[0];
                    if (0 === Zw.length) throw Error("Cannot decode empty core segment string.");
                    let Qi = zK(Zw, YK);
                    const gn = xK(Qi.slice(0, 6));
                    Qi = Qi.slice(6);
                    if (1 !== gn) throw Error(`Unable to decode unsupported USCT Section specification version ${gn} - only version 1 is supported.`);
                    let hn = 0;
                    const wa = [];
                    for (let ma = 0; ma < XK.length; ma++) {
                        const ha = XK[ma];
                        wa.push(xK(Qi.slice(hn, hn + ha)));
                        hn += ha
                    }
                    var aQ = new TK;
                    Yw = Yi(aQ, 1, gn);
                    var bQ = wa.shift();
                    Xw = Q(Yw, 2, bQ);
                    var cQ = wa.shift();
                    Ww = Q(Xw, 3, cQ);
                    var dQ = wa.shift();
                    Vw = Q(Ww, 4, dQ);
                    var eQ = wa.shift();
                    Uw = Q(Vw, 5, eQ);
                    var fQ = wa.shift();
                    Tw = Q(Uw, 6, fQ);
                    var gQ = new SK,
                        hQ = wa.shift();
                    Sw = Q(gQ, 1, hQ);
                    var iQ = wa.shift();
                    Rw = Q(Sw, 2, iQ);
                    var jQ = wa.shift();
                    Qw = Q(Rw, 3, jQ);
                    var kQ = wa.shift();
                    Pw = Q(Qw, 4, kQ);
                    var lQ = wa.shift();
                    Ow = Q(Pw, 5, lQ);
                    var mQ = wa.shift();
                    Nw = Q(Ow, 6, mQ);
                    var nQ = wa.shift();
                    Mw =
                        Q(Nw, 7, nQ);
                    var oQ = wa.shift();
                    Lw = Q(Mw, 8, oQ);
                    Kw = E(Tw, 7, Lw);
                    var pQ = new RK,
                        qQ = wa.shift();
                    Jw = Q(pQ, 1, qQ);
                    var rQ = wa.shift();
                    Iw = Q(Jw, 2, rQ);
                    var sQ = wa.shift();
                    Hw = Q(Iw, 3, sQ);
                    Gw = E(Kw, 8, Hw);
                    var tQ = wa.shift();
                    Fw = Q(Gw, 9, tQ);
                    var uQ = wa.shift();
                    Ew = Q(Fw, 10, uQ);
                    var vQ = wa.shift();
                    const $w = $P = Q(Ew, 11, vQ);
                    if (1 === mg.length) var ax = VK($w);
                    else {
                        var wQ = VK($w),
                            bx = void 0,
                            cx = void 0,
                            dx = void 0,
                            ex = mg[1];
                        if (0 === ex.length) throw Error("Cannot decode empty GPC segment string.");
                        const ma = zK(ex, 3),
                            ha = xK(ma.slice(0, 2));
                        if (0 > ha || 1 < ha) throw Error(`Attempting to decode unknown GPC segment subsection type ${ha}.`);
                        dx = ha + 1;
                        const bg = xK(ma.charAt(2));
                        var xQ = new UK;
                        cx = Q(xQ, 2, dx);
                        bx = Wi(cx, 1, !!bg);
                        ax = E(wQ, 2, bx)
                    }
                    const fx = C(ax, TK, 1);
                    if (1 === zi(fx, 5) || 1 === zi(fx, 6)) return !0;
                    break;
                case 9:
                    if (0 === ac.length) throw Error("Cannot decode empty USVA section string.");
                    let Ri = zK(ac, bL);
                    const jn = xK(Ri.slice(0, 6));
                    Ri = Ri.slice(6);
                    if (1 !== jn) throw Error(`Unable to decode unsupported USVA Section specification version ${jn} - only version 1 is supported.`);
                    let kn = 0;
                    const Ha = [];
                    for (let ma = 0; ma < aL.length; ma++) {
                        const ha = aL[ma];
                        Ha.push(xK(Ri.slice(kn,
                            kn + ha)));
                        kn += ha
                    }
                    var yQ = jn,
                        zQ = new $K,
                        AQ = Yi(zQ, 1, yQ),
                        BQ = Ha.shift(),
                        CQ = Q(AQ, 2, BQ),
                        DQ = Ha.shift(),
                        EQ = Q(CQ, 3, DQ),
                        FQ = Ha.shift(),
                        GQ = Q(EQ, 4, FQ),
                        HQ = Ha.shift(),
                        IQ = Q(GQ, 5, HQ),
                        JQ = Ha.shift();
                    var KQ = Q(IQ, 6, JQ);
                    var LQ = new ZK,
                        MQ = Ha.shift(),
                        NQ = Q(LQ, 1, MQ),
                        OQ = Ha.shift(),
                        PQ = Q(NQ, 2, OQ),
                        QQ = Ha.shift(),
                        RQ = Q(PQ, 3, QQ),
                        SQ = Ha.shift(),
                        TQ = Q(RQ, 4, SQ),
                        UQ = Ha.shift(),
                        VQ = Q(TQ, 5, UQ),
                        WQ = Ha.shift(),
                        XQ = Q(VQ, 6, WQ),
                        YQ = Ha.shift(),
                        ZQ = Q(XQ, 7, YQ),
                        $Q = Ha.shift();
                    var aR = Q(ZQ, 8, $Q);
                    var bR = E(KQ, 7, aR),
                        cR = Ha.shift(),
                        dR = Q(bR, 8, cR),
                        eR = Ha.shift(),
                        fR = Q(dR,
                            9, eR),
                        gR = Ha.shift(),
                        hR = Q(fR, 10, gR),
                        iR = Ha.shift(),
                        gx = Q(hR, 11, iR);
                    if (1 === zi(gx, 5) || 1 === zi(gx, 6)) return !0
            }
        }
        return !1
    }
    var CM = class extends T {
        constructor(a) {
            var {
                gppApiDetectionMode: b,
                timeoutMs: c
            } = {};
            super();
            this.caller = new fE(a, b && 1 !== b && 3 !== b ? "__gppLocator_non_existent" : "__gppLocator", b && 1 !== b && 2 !== b ? void 0 : d => "function" === typeof d.__gpp, xM);
            this.caller.A.set("addEventListener", rM);
            this.caller.j.set("addEventListener", uM);
            this.caller.A.set("removeEventListener", sM);
            this.caller.j.set("removeEventListener", vM);
            this.caller.A.set("getDataWithCallback", tM);
            this.caller.j.set("getDataWithCallback", wM);
            this.timeoutMs = c ? ?
                500
        }
        i() {
            this.caller.la();
            super.i()
        }
        addEventListener(a) {
            const b = Mb(() => {
                    a(zM, !0)
                }),
                c = -1 === this.timeoutMs ? void 0 : setTimeout(() => {
                    b()
                }, this.timeoutMs);
            eE(this.caller, "addEventListener", {
                listener: (d, e) => {
                    clearTimeout(c);
                    try {
                        if (void 0 === d.pingData ? .gppVersion || "1" === d.pingData.gppVersion || "1.0" === d.pingData.gppVersion) {
                            this.removeEventListener(d.listenerId);
                            var f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 1,
                                    gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                    applicableSections: [-1]
                                }
                            }
                        } else Array.isArray(d.pingData.applicableSections) &&
                            0 !== d.pingData.applicableSections.length ? f = d : (this.removeEventListener(d.listenerId), f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 2,
                                    gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                                    applicableSections: [-1]
                                }
                            });
                        a(f, e)
                    } catch {
                        if (d ? .listenerId) try {
                            this.removeEventListener(d.listenerId)
                        } catch {
                            a(AM, !0);
                            return
                        }
                        a(BM, !0)
                    }
                }
            })
        }
        removeEventListener(a) {
            eE(this.caller, "removeEventListener", {
                listenerId: a
            })
        }
    };
    const BM = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        zM = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        AM = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function DM(a) {
        return !a || 1 === a.length && -1 === a[0]
    };

    function EM(a, b) {
        if (b.internalErrorState) $i(a, 11, b.gppString);
        else if (DM(b.applicableSections)) {
            var c = ji(a, 10, b.applicableSections, jh);
            Vi(c, 12, !1)
        } else {
            c = !1;
            try {
                c = yM(b.gppString)
            } catch (d) {
                bA(1182, d)
            }
            a = ji(a, 10, b.applicableSections, jh);
            b = $i(a, 11, b.gppString);
            Vi(b, 12, c)
        }
    }

    function FM(a) {
        const b = new CM(a.pubWin);
        if (!cE(b.caller)) return Promise.resolve(null);
        const c = VI(),
            d = Z(c, 35);
        if (d) return Promise.resolve(d);
        const e = new Promise(f => {
            f = {
                resolve: f
            };
            const g = Z(c, 36, []);
            g.push(f);
            $I(c, 36, g)
        });
        d || null === d || ($I(c, 35, null), b.addEventListener(f => {
            if ("ready" === f.pingData.signalStatus || DM(f.pingData.applicableSections)) {
                f = f.pingData;
                $I(c, 35, f);
                EM(a.g, f);
                for (const g of Z(c, 36, [])) g.resolve(f);
                $I(c, 36, [])
            }
        }));
        return e
    };

    function GM(a) {
        a.easpi = v(vu);
        a.asla = .4;
        a.asaa = -1;
        a.sedf = !1;
        a.asro = v(nu);
        a.sefa = !0;
        v(uu) && (a.sugawps = !0);
        const b = u(Wb).g(Yt.g, Yt.defaultValue);
        b.length && (a.seiel = b.join("~"));
        a.slcwct = w(gu);
        a.sacwct = w(Ot);
        v(du) && (a.slmct = w(hu), a.samct = w(Qt))
    };

    function HM(a, b) {
        return hD({
            K: a,
            Re: 3E3,
            Ue: a.innerWidth > to ? 650 : 0,
            ua: Wz,
            Qf: b,
            Dj: v(yu)
        })
    };
    var IM = a => {
        let b = 0;
        try {
            b |= uo(a)
        } catch (c) {
            b |= 32
        }
        return b
    };
    var JM = a => {
        let b = 0;
        try {
            b |= uo(a), b |= vo(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function KM(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    }

    function LM(a) {
        let b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function MM(a) {
        return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
    }

    function NM(a, b) {
        if (3 == KM(b)) var c = !1;
        else a(), c = !0;
        if (!c) {
            const d = () => {
                Tb(b, "prerenderingchange", d);
                a()
            };
            Sb(b, "prerenderingchange", d)
        }
    };
    var OM = (a, b, c = !0, d = !1) => {
        let e = 0;
        try {
            e |= uo(a);
            var f;
            if (!(f = !a.navigator)) {
                var g = a.navigator;
                f = "brave" in g && "isBrave" in g.brave || !1
            }
            e |= f || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            e |= vo(a, 2500, d);
            d || (e |= xo(a));
            !c || b && HF(b) || (e |= 4194304)
        } catch (h) {
            e |= 32
        }
        return e
    };

    function PM(a, b, c, d = null) {
        let e = uo(a);
        iD(a.navigator ? .userAgent) && (e |= 1048576);
        const f = a.innerWidth;
        1200 > f && (e |= 65536);
        const g = a.innerHeight;
        650 > g && (e |= 2097152);
        d && 0 === e && (d = 3 === d ? "left" : "right", (b = QM({
            K: a,
            vg: b,
            Zg: 1,
            position: d,
            R: f,
            U: g,
            sb: new Set,
            minWidth: 120,
            minHeight: 500
        })) ? c && $v(a).sideRailPlasParam.set(d, `${b.width}x${b.height}_${String(d).charAt(0)}`) : e |= 16);
        return e
    }

    function RM(a) {
        if (v(Lt)) return [...$v(a).sideRailPlasParam.values()].join("|");
        if (0 !== PM(a, !0, !1)) return "";
        const b = [],
            c = a.innerWidth,
            d = a.innerHeight;
        for (const e of ["left", "right"]) {
            const f = QM({
                K: a,
                vg: !0,
                Zg: 1,
                position: e,
                R: c,
                U: d,
                sb: new Set,
                minWidth: 120,
                minHeight: 500
            });
            f && b.push(`${f.width}x${f.height}_${String(e).charAt(0)}`)
        }
        return b.join("|")
    }

    function SM(a, b) {
        return null !== qe(a, c => c.nodeType === Node.ELEMENT_NODE && b.has(c))
    }

    function TM(a, b) {
        return qe(a, c => c.nodeType === Node.ELEMENT_NODE && "fixed" === b.getComputedStyle(c, null).position)
    }

    function UM(a) {
        const b = [];
        for (const c of a.document.querySelectorAll("*")) {
            const d = a.getComputedStyle(c, null);
            "fixed" === d.position && "none" !== d.display && "hidden" !== d.visibility && b.push(c)
        }
        return b
    }

    function VM(a) {
        return Math.round(10 * Math.round(a / 10))
    }

    function WM(a) {
        return `${a.position}-${VM(a.R)}x${VM(a.U)}-${VM(a.scrollY+a.ac)}Y`
    }

    function XM(a) {
        return `f-${WM({position:a.position,ac:a.ac,scrollY:0,R:a.R,U:a.U})}`
    }

    function YM(a, b) {
        a = Math.min(a ? ? Infinity, b ? ? Infinity);
        return Infinity !== a ? a : 0
    }

    function ZM(a, b, c) {
        const d = $v(c.K).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.max(e.top - 10, 0),
                    g = Math.min(e.bottom + 10, c.U),
                    h = Math.max(e.left - 10, 0);
                e = Math.min(e.right + 10, c.R);
                for (var k = .3 * c.R; f <= g; f += 10) {
                    if (0 < e && h < k) {
                        var l = XM({
                            position: "left",
                            ac: f,
                            R: c.R,
                            U: c.U
                        });
                        b.set(l, YM(b.get(l), h))
                    }
                    if (h < c.R && e > c.R - k) {
                        l = XM({
                            position: "right",
                            ac: f,
                            R: c.R,
                            U: c.U
                        });
                        const m = c.R - e;
                        b.set(l, YM(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    }

    function QM(a) {
        if (1200 > a.R || 650 > a.U) return null;
        var b = $v(a.K).sideRailAvailableSpace;
        if (!a.vg) {
            var c = {
                    K: a.K,
                    R: a.R,
                    U: a.U,
                    sb: a.sb
                },
                d = `f-${VM(c.R)}x${VM(c.U)}`;
            if (!b.has(d)) {
                b.set(d, 0);
                $v(c.K).sideRailProcessedFixedElements.clear();
                d = new Set([...Array.from(c.K.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]")), ...c.sb]);
                for (var e of UM(c.K)) SM(e, d) || ZM(e, b, c)
            }
        }
        c = [];
        d = .9 * a.U;
        var f = Eo(a.K),
            g = e = (a.U - d) / 2,
            h = d / 7;
        for (var k = 0; 8 > k; k++) {
            var l = c,
                m = l.push;
            a: {
                var n = g;
                var p = a.position,
                    q = b,
                    x = {
                        K: a.K,
                        R: a.R,
                        U: a.U,
                        sb: a.sb
                    };
                const G = XM({
                        position: p,
                        ac: n,
                        R: x.R,
                        U: x.U
                    }),
                    F = WM({
                        position: p,
                        ac: n,
                        scrollY: f,
                        R: x.R,
                        U: x.U
                    });
                if (q.has(F)) {
                    n = YM(q.get(G), q.get(F));
                    break a
                }
                const K = "left" === p ? 20 : x.R - 20;
                let H = K;p = .3 * x.R / 5 * ("left" === p ? 1 : -1);
                for (let N = 0; 6 > N; N++) {
                    const J = Tv(x.K.document, {
                        x: Math.round(H),
                        y: Math.round(n)
                    });
                    var z = SM(J, x.sb);
                    const Ea = TM(J, x.K);
                    if (!z && null !== Ea) {
                        ZM(Ea, q, x);
                        q.delete(F);
                        break
                    }
                    z || (z = J.offsetHeight >= .25 * x.U, z = J.offsetWidth >= .9 * x.R && z);
                    if (z) q.set(F, Math.round(Math.abs(H - K) + 20));
                    else if (H !==
                        K) H -= p, p /= 2;
                    else {
                        q.set(F, 0);
                        break
                    }
                    H += p
                }
                n = YM(q.get(G), q.get(F))
            }
            m.call(l, n);
            g += h
        }
        b = a.Zg;
        f = a.position;
        d = Math.round(d / 8);
        e = Math.round(e);
        g = a.minWidth;
        a = a.minHeight;
        m = [];
        h = Array(c.length).fill(0);
        for (l = 0; l < c.length; l++) {
            for (; 0 !== m.length && c[m[m.length - 1]] >= c[l];) m.pop();
            h[l] = 0 === m.length ? 0 : m[m.length - 1] + 1;
            m.push(l)
        }
        m = [];
        k = c.length - 1;
        l = Array(c.length).fill(0);
        for (n = k; 0 <= n; n--) {
            for (; 0 !== m.length && c[m[m.length - 1]] >= c[n];) m.pop();
            l[n] = 0 === m.length ? k : m[m.length - 1] - 1;
            m.push(n)
        }
        m = null;
        for (k = 0; k < c.length; k++)
            if (n = {
                    position: f,
                    width: Math.round(c[k]),
                    height: Math.round((l[k] - h[k] + 1) * d),
                    offsetY: e + h[k] * d
                }, q = n.width >= g && n.height >= a, 0 === b && q) {
                m = n;
                break
            } else 1 === b && q && (!m || n.width * n.height > m.width * m.height) && (m = n);
        return m
    };
    const $M = {
        [27]: 512,
        [26]: 128
    };
    var aN = (a, b, c, d) => {
            switch (c) {
                case 1:
                case 2:
                    return 0 === HM(a, c);
                case 3:
                case 4:
                    return 0 === PM(a, !1, !1, c);
                case 8:
                    return 0 == OM(a, d, !("on" === b.google_adtest || mK(a.location, "google_ia_debug")), v(zu));
                case 9:
                    return b = !("on" === b.google_adtest || mK(a.location, "google_scr_debug")), !LF(a, b, d);
                case 30:
                    return 0 == zH(a);
                case 26:
                    return 0 == JM(a);
                case 27:
                    return 0 === IM(a);
                case 40:
                    return !0;
                default:
                    return !1
            }
        },
        bN = (a, b, c, d) => {
            switch (c) {
                case 0:
                case 40:
                case 10:
                case 11:
                    return 0;
                case 1:
                case 2:
                    return HM(a, c);
                case 3:
                case 4:
                    return PM(a,
                        v(Mt), v(Lt), c);
                case 8:
                    return OM(a, d, !("on" === b.google_adtest || mK(a.location, "google_ia_debug")), v(zu));
                case 9:
                    return LF(a, !("on" === b.google_adtest || mK(a.location, "google_scr_debug")), d);
                case 16:
                    return mv(b, a) ? 0 : 8388608;
                case 30:
                    return zH(a);
                case 26:
                    return JM(a);
                case 27:
                    return IM(a);
                default:
                    return 32
            }
        },
        cN = (a, b, c) => {
            const d = b.google_reactive_ad_format;
            if (!Pc(d)) return !1;
            a = Ue(a);
            if (!a || !aN(a, b, d, c)) return !1;
            b = $v(a);
            if (Bo(b, d)) return !1;
            b.adCount[d] || (b.adCount[d] = 0);
            b.adCount[d]++;
            return !0
        },
        eN = a => {
            const b =
                a.google_reactive_ad_format;
            return !a.google_reactive_ads_config && dN(a) && 16 !== b && 10 !== b && 11 !== b && 40 !== b && 41 !== b
        },
        fN = a => {
            if (!a.hash) return null;
            let b = null;
            Ze(jK, c => {
                !b && mK(a, c) && (b = kK[c])
            });
            return b
        },
        hN = (a, b) => {
            const c = $v(a).tagSpecificState[1] || null;
            null != c && null == c.debugCard && Ze(lK, d => {
                !c.debugCardRequested && "number" === typeof d && pK(d, a.location) && (c.debugCardRequested = !0, gN(a, b, e => {
                    c.debugCard = e.createDebugCard(d, a)
                }))
            })
        },
        jN = (a, b, c) => {
            if (!b) return null;
            const d = $v(b);
            let e = 0;
            Ze(Qc, f => {
                const g = $M[f];
                g && 0 === iN(a, b, f, c) && (e |= g)
            });
            d.wasPlaTagProcessed && (e |= 256);
            a.google_reactive_tag_first && (e |= 1024);
            return e ? "" + e : null
        },
        kN = (a, b, c) => {
            const d = [];
            Ze(Qc, e => {
                const f = iN(b, a, e, c);
                0 !== f && d.push(e + ":" + f)
            });
            return d.join(",") || null
        },
        lN = a => {
            const b = [],
                c = {};
            Ze(a, (d, e) => {
                if ((e = ro[e]) && !c[e]) {
                    c[e] = !0;
                    if (d) d = 1;
                    else if (!1 === d) d = 2;
                    else return;
                    b.push(e + ":" + d)
                }
            });
            return b.join(",")
        },
        mN = a => {
            a = a.overlays;
            if (!a) return "";
            a = a.bottom;
            return "boolean" === typeof a ? a ? "1" : "0" : ""
        },
        iN = (a, b, c, d) => {
            if (!b) return 256;
            let e = 0;
            const f =
                $v(b),
                g = Bo(f, c);
            if (a.google_reactive_ad_format == c || g) e |= 64;
            let h = !1;
            Ze(f.reactiveTypeDisabledByPublisher, (k, l) => {
                String(c) === String(l) && (h = !0)
            });
            return h && fN(b.location) !== c && (e |= 128, 2 == c || 1 == c || 3 == c || 4 == c || 8 == c) ? e : e | bN(b, a, c, d)
        },
        nN = (a, b) => {
            if (a) {
                var c = $v(a),
                    d = {};
                Ze(b, (e, f) => {
                    (f = ro[f]) && (!1 === e || /^false$/i.test(e)) && (d[f] = !0)
                });
                Ze(Qc, e => {
                    d[so[e]] && (c.reactiveTypeDisabledByPublisher[e] = !0)
                })
            }
        },
        oN = (a, b, c) => {
            b = Xz.Oa(b, c);
            return hK(3, window, a).Vc.then(b)
        },
        gN = (a, b, c) => {
            c = Xz.Oa(212, c);
            hK(4, a, b).Vc.then(c)
        },
        pN = a => {
            a = a.google_reactive_ad_format;
            return Pc(a) ? "" + a : null
        },
        dN = a => !!pN(a) || null != a.google_pgb_reactive,
        qN = a => {
            a = pN(a);
            return 26 == a || 27 == a || 30 == a || 16 == a || 40 == a || 41 == a
        };
    var rN = (a, b, c, d = null) => {
            const e = g => {
                let h;
                try {
                    h = JSON.parse(g.data)
                } catch (k) {
                    return
                }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
            };
            Sb(a, "message", e);
            let f = !1;
            return () => {
                let g = !1;
                f || (f = !0, g = Tb(a, "message", e));
                return g
            }
        },
        sN = (a, b, c, d = null) => {
            const e = rN(a, b, Hb(c, () => e()), d);
            return e
        },
        tN = (a, b, c, d, e) => {
            if (!(0 >= e) && (c.googMsgType = b, a.postMessage(JSON.stringify(c), d), a = a.frames))
                for (let f = 0; f < a.length; ++f) 1 < e && tN(a[f], b, c, d, --e)
        };

    function uN(a) {
        return "number" === typeof a.google_reactive_sra_index
    }

    function vN(a, b, c) {
        const d = b.K || b.pubWin,
            e = b.D;
        var f = kN(d, e, c);
        e.google_reactive_plat = f;
        (f = lN(a)) && (e.google_reactive_plaf = f);
        (f = mN(a)) && (e.google_reactive_fba = f);
        (f = RM(d)) && (e.google_plas = f);
        wN(a, e);
        f = fN(b.pubWin.location);
        xN(a, f, e);
        f ? (e.fra = f, e.google_pgb_reactive = 6) : e.google_pgb_reactive = 5;
        GM(e);
        e.fsapi = !0;
        8 !== f && (f = KF(c, 86400), f ? .length && (e.vmsli = Math.floor((Date.now() - Math.max(...f)) / 6E4)));
        sk() || dM(b.pubWin.top);
        f = sN(b.pubWin, "rsrai", $z(429, (g, h) => yN(b, d, e.google_ad_client, a, g, h, c)), $z(430,
            (g, h) => Ho(b.pubWin, "431", Wz, h)));
        b.j.push(f);
        $v(d).wasReactiveTagRequestSent = !0;
        zN(b, a, c)
    }

    function zN(a, b, c) {
        const d = a.D,
            e = za(b.page_level_pubvars) ? b.page_level_pubvars : {};
        b = sN(a.pubWin, "apcnf", $z(353, (f, g) => {
            const h = Zc(a.ra.jb, fK());
            var k = a.pubWin,
                l = d.google_ad_client;
            return wf(g.origin) ? aM(k, l, e, f.config, c, h, null) : !1
        }), $z(353, (f, g) => Ho(a.pubWin, "353", Wz, g)));
        a.j.push(b)
    }

    function yN(a, b, c, d, e, f, g) {
        if (!wf(f.origin)) return !1;
        f = e.data;
        if (!Array.isArray(f)) return !1;
        if (!RI(b, 1)) return !0;
        f && gk(6, [f]);
        e = e.amaConfig;
        const h = [],
            k = [],
            l = $v(b);
        let m = null;
        for (let n = 0; n < f.length; n++) {
            if (!f[n]) continue;
            const p = f[n],
                q = p.adFormat;
            l && p.enabledInAsfe && (l.reactiveTypeEnabledInAsfe[q] = !0);
            if (!p.noCreative) {
                p.google_reactive_sra_index = n;
                if (9 === q && e) {
                    p.pubVars = Object.assign(p.pubVars || {}, AN(d, p));
                    const x = new MF;
                    if (FF(x, p) && x.C(p)) {
                        m = x;
                        continue
                    }
                }
                h.push(p);
                k.push(q)
            }
        }
        h.length && oN(a.ra.Vg,
            522, n => {
                BN(h, b, n, d, g)
            });
        e && aM(b, c, d, e, g, a.ra.jb, m);
        return !0
    }

    function AN(a, b) {
        const c = b.adFormat,
            d = b.adKey;
        delete b.adKey;
        const e = {};
        a = a.page_level_pubvars;
        za(a) && Object.assign(e, a);
        e.google_ad_unit_key = d;
        e.google_reactive_sra_index = b.google_reactive_sra_index;
        30 === c && (e.google_reactive_ad_format = 30);
        e.google_pgb_reactive = e.google_pgb_reactive || 5;
        return b.pubVars = e
    }

    function BN(a, b, c, d, e) {
        const f = [];
        for (let g = 0; g < a.length; g++) {
            const h = a[g],
                k = h.adFormat,
                l = h.adKey,
                m = c.configProcessorForAdFormat(k);
            k && m && l && (h.pubVars = AN(d, h), delete h.google_reactive_sra_index, f.push(k), Zz(466, () => m.verifyAndProcessConfig(b, h, e)))
        }
    }

    function wN(a, b) {
        const c = [];
        let d = !1;
        Ze(ro, (e, f) => {
            let g;
            a.hasOwnProperty(f) && (f = a[f], f ? .google_ad_channel && (g = String(f.google_ad_channel)));
            --e;
            c[e] && "+" !== c[e] || (c[e] = g ? g.replace(/,/g, "+") : "+", d || (d = !!g))
        });
        d && (b.google_reactive_sra_channels = c.join(","))
    }

    function xN(a, b, c) {
        if (!c.google_adtest) {
            var d = a.page_level_pubvars;
            if ("on" === a.google_adtest || "on" === d ? .google_adtest || b) c.google_adtest = "on"
        }
    };
    Ub("script");
    var CN = {
        "image-top": 0,
        "image-middle": 1,
        "image-side": 2,
        "text-only": 3,
        "in-article": 4
    };

    function DN(a, b) {
        if (!mv(b, a)) return () => {};
        a = EN(b, a);
        if (!a) return () => {};
        const c = eJ();
        b = Sc(b);
        const d = {
            xb: a,
            D: b,
            offsetWidth: a.offsetWidth
        };
        c.push(d);
        return () => db(c, d)
    }

    function EN(a, b) {
        a = b.document.getElementById(a.google_async_iframe_id);
        if (!a) return null;
        for (a = a.parentElement; a && !rv.test(a.className);) a = a.parentElement;
        return a
    }

    function FN(a, b) {
        for (let f = 0; f < a.childNodes.length; f++) {
            const g = {},
                h = a.childNodes[f];
            var c = h.style,
                d = ["width", "height"];
            for (let k = 0; k < d.length; k++) {
                const l = "google_ad_" + d[k];
                if (!g.hasOwnProperty(l)) {
                    var e = gf(c[d[k]]);
                    e = null === e ? null : Math.round(e);
                    null != e && (g[l] = e)
                }
            }
            if (g.google_ad_width == b.google_ad_width && g.google_ad_height == b.google_ad_height) return h
        }
        return null
    }

    function GN(a, b) {
        a.style.display = b ? "inline-block" : "none";
        const c = a.parentElement;
        b ? c.dataset.adStatus = a.dataset.adStatus : (a.dataset.adStatus = c.dataset.adStatus, delete c.dataset.adStatus)
    }

    function HN(a, b) {
        const c = b.innerHeight >= b.innerWidth ? 1 : 2;
        if (a.g != c) {
            a.g = c;
            a = eJ();
            for (const d of a)
                if (d.xb.offsetWidth != d.offsetWidth || d.D.google_full_width_responsive_allowed) d.offsetWidth = d.xb.offsetWidth, Zz(467, () => {
                    var e = d.xb,
                        f = d.D;
                    const g = FN(e, f);
                    f.google_full_width_responsive_allowed && (e.style.marginLeft = f.gfwroml || "", e.style.marginRight = f.gfwromr || "", e.style.height = f.gfwroh ? f.gfwroh + "px" : "", e.style.width = f.gfwrow ? f.gfwrow + "px" : "", e.style.zIndex = f.gfwroz || "", delete f.google_full_width_responsive_allowed);
                    delete f.google_ad_format;
                    delete f.google_ad_width;
                    delete f.google_ad_height;
                    delete f.google_content_recommendation_ui_type;
                    delete f.google_content_recommendation_rows_num;
                    delete f.google_content_recommendation_columns_num;
                    b.google_spfd(e, f, b);
                    const h = FN(e, f);
                    !h && g && 1 == e.childNodes.length ? (GN(g, !1), f.google_reactive_ad_format = 16, f.google_ad_section = "responsive_resize", e.dataset.adsbygoogleStatus = "reserved", e.className += " adsbygoogle-noablate", b.adsbygoogle || (b.adsbygoogle = [], Ve(b.document, sj `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`)),
                        b.adsbygoogle.push({
                            element: e,
                            params: f
                        })) : h && g && h != g && (GN(g, !1), GN(h, !0))
                })
        }
    }
    var IN = class extends T {
        constructor() {
            super(...arguments);
            this.g = null
        }
        L(a) {
            const b = VI();
            if (!Z(b, 27, !1)) {
                $I(b, 27, !0);
                this.g = a.innerHeight >= a.innerWidth ? 1 : 2;
                var c = () => {
                    HN(this, a)
                };
                Sb(a, "resize", c);
                Zo(this, () => {
                    Tb(a, "resize", c)
                })
            }
        }
    };
    var JN = class {
        constructor(a, b) {
            this.K = a;
            this.xb = b;
            this.g = null;
            this.j = 0
        }
        i() {
            10 <= ++this.j && r.clearInterval(this.g);
            var a = pv(this.K, this.xb);
            qv(this.K, this.xb, a);
            a = lv(this.xb, this.K);
            null != a && 0 === a.x || r.clearInterval(this.g)
        }
    };
    var KN = class {
        constructor(a) {
            this.i = 0;
            this.g = this.F = null;
            this.G = 0;
            this.j = [];
            this.sc = this.C = "";
            this.l = this.B = null;
            this.K = a.K;
            this.pubWin = a.pubWin;
            this.D = a.D;
            this.qa = a.qa;
            this.ra = a.ra;
            this.ub = a.ub;
            this.ha = a.ha
        }
    };

    function LN(a, b, c) {
        c = VJ(a, pE(b, {
            Fi: v(Cu) && c
        }));
        c = $i(c, 2, b.tcString);
        c = $i(c, 4, b.addtlConsent || "");
        Vh(c, 7, dh(b.internalErrorState));
        c = !rE(b);
        Vi(a, 9, c);
        null != b.gdprApplies && Vi(a, 3, b.gdprApplies)
    }

    function MN(a) {
        const b = new xE(a.pubWin, {
            timeoutMs: -1,
            Mh: !0
        });
        if (!tE(b)) return Promise.resolve(null);
        const c = VI(),
            d = Z(c, 24);
        if (d) return Promise.resolve(d);
        const e = new Promise(f => {
            f = {
                resolve: f
            };
            const g = Z(c, 25, []);
            g.push(f);
            $I(c, 25, g)
        });
        d || null === d || ($I(c, 24, null), b.addEventListener(f => {
            if (oE(f)) {
                $I(c, 24, f);
                LN(a.g, f, M(a.qa, 6));
                for (const g of Z(c, 25, [])) g.resolve(f);
                $I(c, 25, [])
            } else $I(c, 24, null)
        }));
        return e
    };

    function NN(a, b, c = 1E5) {
        a -= b;
        return a >= c ? "M" : 0 <= a ? a : "-M"
    };
    var PN = (a, b, c) => {
        const d = b.parentElement ? .classList.contains("adsbygoogle") ? b.parentElement : b;
        c.addEventListener("load", () => ON(d));
        return sN(a, "adpnt", (e, f) => {
            if (Do(f, c.contentWindow)) {
                e = Go(e).qid;
                try {
                    c.setAttribute("data-google-query-id", e), a.googletag ? ? (a.googletag = {
                        cmd: []
                    }), a.googletag.queryIds = a.googletag.queryIds ? ? [], a.googletag.queryIds.push(e), 500 < a.googletag.queryIds.length && a.googletag.queryIds.shift()
                } catch {}
                d.dataset.adStatus = "filled";
                switch (w(Du)) {
                    case 1:
                        e && (c.id += `/${e}`);
                        break;
                    case 2:
                        f =
                            document, e && (f = c.parentElement ? .querySelector("INS[data-aqiep]") ? ? We("INS", f), f.parentElement || (c.parentNode && c.parentNode.insertBefore(f, c.nextSibling), A(f, {
                                height: "0px",
                                width: "0px"
                            }), Io(f), f.setAttribute("data-aqiep", "1")), f.id = e)
                }
                e = !0
            } else e = !1;
            return e
        })
    };

    function ON(a) {
        setTimeout(() => {
            "filled" !== a.dataset.adStatus && (a.dataset.adStatus = "unfilled")
        }, 1E3)
    };
    var QN = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };
    var RN = class extends R {
        g() {
            return M(this, 6)
        }
        j() {
            return M(this, 7)
        }
    };
    var SN = class extends R {
        g() {
            return ai(this, 1, uh, 2)
        }
    };
    SN.P = [1];
    var TN = class extends R {};
    TN.P = [19];
    var UN = [13, 14];
    let VN = void 0;

    function WN() {
        ej(VN, gj);
        return VN
    }

    function XN(a) {
        ej(VN, vl);
        VN = a
    };

    function YN(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : Oc(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && "string" === typeof e && Array.isArray(d))
        } catch (b) {
            return {}
        }
    };

    function ZN(a, b, c) {
        try {
            if (!wf(c.origin) || !Do(c, a.g.contentWindow)) return
        } catch (f) {
            return
        }
        const d = b.msg_type;
        let e;
        "string" === typeof d && (e = a.va[d]) && a.T.Kc(168, () => {
            e.call(a, b, c)
        })
    }
    class $N extends T {
        constructor(a, b) {
            var c = Xz,
                d = Wz;
            super();
            this.j = a;
            this.g = b;
            this.T = c;
            this.ua = d;
            this.va = {};
            this.Cb = this.T.Oa(168, (e, f) => void ZN(this, e, f));
            this.Rc = this.T.Oa(169, (e, f) => Ho(this.j, "ras::xsf", this.ua, f));
            this.Z = [];
            this.ea(this.va);
            this.Z.push(rN(this.j, "sth", this.Cb, this.Rc))
        }
        i() {
            for (const a of this.Z) a();
            this.Z.length = 0;
            super.i()
        }
    };
    class aO extends $N {};

    function bO(a, b, c = null) {
        return new cO(a, b, c)
    }
    var cO = class extends aO {
        constructor(a, b, c) {
            super(a, b);
            this.A = c;
            this.C = u(zJ);
            this.l = () => {};
            Sb(this.g, "load", this.l)
        }
        i() {
            Tb(this.g, "load", this.l);
            super.i()
        }
        ea(a) {
            a["adsense-labs"] = b => {
                if (b = Go(b).settings)
                    if (b = dj(Nj, JSON.parse(b)), null != I(b, 1)) {
                        var c;
                        if (c = v(Zs)) c = b.W, c = 0 < qi(c, c[B], Jj, 4, 3, !1, !0).length;
                        if (c) {
                            var d = c = D(b, Jj, 4),
                                e = this.C;
                            const h = new um;
                            for (var f of d) switch (f.getVersion()) {
                                case 1:
                                    Vi(h, 1, !0);
                                    break;
                                case 2:
                                    Vi(h, 2, !0)
                            }
                            f = new vm;
                            f = ri(f, 1, wm, h);
                            yJ(e, f);
                            f = this.j;
                            e = this.A;
                            if (!Z(VI(), 37, !1)) {
                                f = new mM(f);
                                for (var g of c) switch (g.getVersion()) {
                                    case 1:
                                        jM(f, "__gads", g, e);
                                        break;
                                    case 2:
                                        jM(f, "__gpi", g, e)
                                }
                                $I(VI(), 37, !0)
                            }
                            Vh(b, 4)
                        }
                        if (v(Xs)) {
                            if (g = C(b, Jj, 5)) f = this.j, Z(VI(), 40, !1) || (f = new QN(f, {
                                Sg: !1,
                                Tg: !1
                            }), c = yi(g, 2) - Date.now() / 1E3, c = {
                                Ed: Math.max(c, 0),
                                path: O(g, 3),
                                domain: O(g, 4),
                                bh: !1
                            }, (new Wj(f.i.document)).set("__eoi", g.getValue(), c), $I(VI(), 40, !0));
                            Vh(b, 5)
                        }
                        g = this.j;
                        f = O(b, 1) || "";
                        if (null != ZJ({
                                win: g,
                                zd: WN()
                            }).g) {
                            c = ZJ({
                                win: g,
                                zd: WN()
                            });
                            c = null != c.g ? YN(c.getValue()) : {};
                            null !== b && (c[f] = b.toJSON());
                            try {
                                g.localStorage.setItem("google_adsense_settings",
                                    JSON.stringify(c))
                            } catch (h) {}
                        }
                    }
            }
        }
    };

    function dO(a) {
        a.A = a.C;
        a.F.style.transition = "height 500ms";
        a.l.style.transition = "height 500ms";
        a.g.style.transition = "height 500ms";
        eO(a)
    }

    function fO(a, b) {
        a.g.contentWindow.postMessage(JSON.stringify({
            msg_type: "expand-on-scroll-result",
            eos_success: !0,
            eos_amount: b,
            googMsgType: "sth"
        }), "*")
    }

    function eO(a) {
        const b = `rect(0px, ${a.g.width}px, ${a.A}px, 0px)`;
        a.g.style.clip = b;
        a.l.style.clip = b;
        a.g.setAttribute("height", a.A);
        a.g.style.height = a.A + "px";
        a.l.setAttribute("height", a.A);
        a.l.style.height = a.A + "px";
        a.F.style.height = a.A + "px"
    }

    function gO(a, b) {
        b = ff(b.r_nh);
        a.C = null == b ? 0 : b;
        if (0 >= a.C) return "1";
        a.I = Dk(a.F).y;
        a.H = Eo(a.j);
        if (a.I + a.A < a.H) return "2";
        if (a.I > zo(a.j) - a.j.innerHeight) return "3";
        b = a.H;
        a.g.setAttribute("height", a.C);
        a.g.style.height = a.C + "px";
        a.l.style.overflow = "hidden";
        a.F.style.position = "relative";
        a.F.style.transition = "height 100ms";
        a.l.style.transition = "height 100ms";
        a.g.style.transition = "height 100ms";
        b = Math.min(b + a.j.innerHeight - a.I, a.A);
        wk(a.l, {
            position: "relative",
            top: "auto",
            bottom: "auto"
        });
        b = `rect(0px, ${a.g.width}px, ${b}px, 0px)`;
        wk(a.g, {
            clip: b
        });
        wk(a.l, {
            clip: b
        });
        return "0"
    }
    class hO extends aO {
        constructor(a, b) {
            super(a.K, b);
            this.l = a.ha;
            this.F = this.l.parentElement && this.l.parentElement.classList.contains("adsbygoogle") ? this.l.parentElement : this.l;
            this.A = parseInt(this.l.style.height, 10);
            this.Ha = this.Qa = !1;
            this.na = this.H = this.C = 0;
            this.Qc = this.A / 5;
            this.I = Dk(this.F).y;
            this.Ua = Ob($z(651, () => {
                this.I = Dk(this.F).y;
                var c = this.H;
                this.H = Eo(this.j);
                this.A < this.C ? (c = this.H - c, 0 < c && (this.na += c, this.na >= this.Qc ? (dO(this), fO(this, this.C)) : (this.A = Math.min(this.C, this.A + c), fO(this, c), eO(this)))) :
                    Tb(this.j, "scroll", this.O)
            }), this);
            this.O = () => {
                var c = this.Ua;
                Sj.requestAnimationFrame ? Sj.requestAnimationFrame(c) : c()
            }
        }
        ea(a) {
            a["expand-on-scroll"] = (b, c) => {
                b = Go(b);
                this.Qa || (this.Qa = !0, b = gO(this, b), "0" === b && Sb(this.j, "scroll", this.O, Pb), c.source.postMessage(JSON.stringify({
                    msg_type: "expand-on-scroll-result",
                    eos_success: "0" === b,
                    googMsgType: "sth"
                }), "*"))
            };
            a["expand-on-scroll-force-expand"] = () => {
                this.Ha || (this.Ha = !0, dO(this), Tb(this.j, "scroll", this.O))
            }
        }
        i() {
            this.O && Tb(this.j, "scroll", this.O, Pb);
            super.i()
        }
    };

    function iO(a) {
        const b = a.I.getBoundingClientRect(),
            c = 0 > b.top + b.height;
        return !(b.top > a.j.innerHeight) && !c
    }
    class jO extends T {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.A = b;
            this.I = c;
            this.C = 0;
            this.l = iO(this);
            this.H = Nb(this.F, this);
            this.g = $z(433, () => {
                var d = this.H;
                Sj.requestAnimationFrame ? Sj.requestAnimationFrame(d) : d()
            });
            Sb(this.j, "scroll", this.g, Pb)
        }
        F() {
            const a = iO(this);
            if (a && !this.l) {
                var b = {
                    rr: "vis-bcr"
                };
                const c = this.A.contentWindow;
                c && (tN(c, "ig", b, "*", 2), 10 <= ++this.C && this.g && Tb(this.j, "scroll", this.g, Pb))
            }
            this.l = a
        }
    };

    function kO(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return "string" === typeof c ? c : c.property + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        wk(a, "transition", b.join(","))
    }
    var lO = Jb(function() {
        if (zc) return !0;
        var a = je(document, "DIV"),
            b = Dc ? "-webkit" : Cc ? "-moz" : zc ? "-ms" : null,
            c = {
                transition: "opacity 1s linear"
            };
        b && (c[b + "-transition"] = "opacity 1s linear");
        b = {
            style: c
        };
        Fd("div");
        b = Id("div", b);
        Pd(a, b);
        return "" != zk(a.firstChild, "transition")
    });

    function mO(a, b, c) {
        0 > a.i[b].indexOf(c) && (a.i[b] += c)
    }

    function nO(a, b) {
        0 <= a.g.indexOf(b) || (a.g = b + a.g)
    }

    function oO(a, b, c, d) {
        return "" != a.errors || b ? null : "" == a.g.replace(pO, "") ? null != c && a.i[0] || null != d && a.i[1] ? !1 : !0 : !1
    }

    function qO(a) {
        var b = oO(a, "", null, 0);
        if (null === b) return "XS";
        b = b ? "C" : "N";
        a = a.g;
        return 0 <= a.indexOf("a") ? b + "A" : 0 <= a.indexOf("f") ? b + "F" : b + "S"
    }
    var rO = class {
        constructor(a, b) {
            this.i = ["", ""];
            this.g = a || "";
            this.errors = b || ""
        }
        xa(a) {
            0 > this.errors.indexOf(a) && (this.errors = a + this.errors);
            return this
        }
        toString() {
            return [this.i[0], this.i[1], this.g, this.errors].join("|")
        }
    };

    function sO(a) {
        let b = a.T;
        a.G = () => {};
        tO(a, a.B, b);
        let c = a.B.parentElement;
        if (!c) return a.g;
        let d = !0,
            e = null;
        for (; c;) {
            try {
                e = /^head|html$/i.test(c.nodeName) ? null : Xe(c, b)
            } catch (g) {
                a.g.xa("c")
            }
            const f = uO(a, b, c, e);
            c.classList.contains("adsbygoogle") && e && (/^\-.*/.test(e["margin-left"]) || /^\-.*/.test(e["margin-right"])) && (a.O = !0);
            if (d && !f && vO(e)) {
                nO(a.g, "l");
                a.F = c;
                break
            }
            d = d && f;
            if (e && wO(a, e)) break;
            c = c.parentElement;
            if (!c) {
                if (b === a.pubWin) break;
                try {
                    if (c = b.frameElement, b = b.parent, !Re(b)) {
                        nO(a.g, "c");
                        break
                    }
                } catch (g) {
                    nO(a.g,
                        "c");
                    break
                }
            }
        }
        a.C && a.A && xO(a);
        return a.g
    }

    function yO(a) {
        function b(m) {
            for (let n = 0; n < m.length; n++) wk(k, m[n], "0px")
        }

        function c() {
            zO(d, g, h);
            !k || l || h || (b(AO), b(BO))
        }
        const d = a.B;
        d.style.overflow = a.Tc ? "visible" : "hidden";
        a.C && (a.F ? (kO(d, CO()), kO(a.F, CO())) : kO(d, "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1) .3s, height .5s cubic-bezier(.4, 0, 1, 1)"));
        null !== a.I && (d.style.opacity = String(a.I));
        const e = null != a.width && null != a.j && (a.Pd || a.j > a.width) ? a.j : null,
            f = null != a.height && null != a.i && (a.Pd || a.i > a.height) ? a.i : null;
        if (a.H) {
            const m =
                a.H.length;
            for (let n = 0; n < m; n++) zO(a.H[n], e, f)
        }
        const g = a.j,
            h = a.i,
            k = a.F,
            l = a.O;
        a.C ? r.setTimeout(c, 1E3) : c()
    }

    function DO(a) {
        if (a.A && !a.Z || null == a.j && null == a.i && null == a.I && a.A) return a.g;
        var b = a.A;
        a.A = !1;
        sO(a);
        a.A = b;
        if (!b || null != a.check && !oO(a.g, a.check, a.j, a.i)) return a.g;
        0 <= a.g.g.indexOf("n") && (a.width = null, a.height = null);
        if (null == a.width && null !== a.j || null == a.height && null !== a.i) a.C = !1;
        (0 == a.j || 0 == a.i) && 0 <= a.g.g.indexOf("l") && (a.j = 0, a.i = 0);
        b = a.g;
        b.i[0] = "";
        b.i[1] = "";
        b.g = "";
        b.errors = "";
        yO(a);
        return sO(a)
    }

    function wO(a, b) {
        let c = !1;
        "none" == b.display && (nO(a.g, "n"), a.A && (c = !0));
        "hidden" != b.visibility && "collapse" != b.visibility || nO(a.g, "v");
        "hidden" == b.overflow && nO(a.g, "o");
        "absolute" == b.position ? (nO(a.g, "a"), c = !0) : "fixed" == b.position && (nO(a.g, "f"), c = !0);
        return c
    }

    function tO(a, b, c) {
        let d = 0;
        if (!b || !b.parentElement) return !0;
        let e = !1,
            f = 0;
        const g = b.parentElement.childNodes;
        for (let k = 0; k < g.length; k++) {
            var h = g[k];
            h == b ? e = !0 : (h = EO(a, h, c), d |= h, e && (f |= h))
        }
        f & 1 && (d & 2 && mO(a.g, 0, "o"), d & 4 && mO(a.g, 1, "o"));
        return !(d & 1)
    }

    function uO(a, b, c, d) {
        let e = null;
        try {
            e = c.style
        } catch (z) {
            a.g.xa("s")
        }
        var f = c.getAttribute("width"),
            g = ff(f),
            h = c.getAttribute("height"),
            k = ff(h),
            l = d && /^block$/.test(d.display) || e && /^block$/.test(e.display);
        b = tO(a, c, b);
        var m = d && d.width;
        const n = d && d.height;
        var p = e && e.width,
            q = e && e.height,
            x = gf(m) == a.width && gf(n) == a.height;
        m = x ? m : p;
        q = x ? n : q;
        p = gf(m);
        x = gf(q);
        g = null !== a.width && (null !== p && a.width >= p || null !== g && a.width >= g);
        x = null !== a.height && (null !== x && a.height >= x || null !== k && a.height >= k);
        k = !b && vO(d);
        x = b || x || k || !(f ||
            m || d && (!FO(String(d.minWidth)) || !GO(String(d.maxWidth))));
        l = b || g || k || l || !(h || q || d && (!FO(String(d.minHeight)) || !GO(String(d.maxHeight))));
        HO(a, 0, x, c, "width", f, a.width, a.j);
        IO(a, 0, "d", x, e, d, "width", m, a.width, a.j);
        IO(a, 0, "m", x, e, d, "minWidth", e && e.minWidth, a.width, a.j);
        IO(a, 0, "M", x, e, d, "maxWidth", e && e.maxWidth, a.width, a.j);
        a.ff ? (c = /^html|body$/i.test(c.nodeName), f = gf(n), h = d ? "auto" === d.overflowY || "scroll" === d.overflowY : !1, h = null != a.i && d && f && Math.round(f) !== a.i && !h && "100%" !== d.minHeight, a.A && !c && h && (e.setProperty("height",
            "auto", "important"), d && !FO(String(d.minHeight)) && e.setProperty("min-height", "0px", "important"), d && !GO(String(d.maxHeight)) && a.i && Math.round(f) < a.i && e.setProperty("max-height", "none", "important"))) : (HO(a, 1, l, c, "height", h, a.height, a.i), IO(a, 1, "d", l, e, d, "height", q, a.height, a.i), IO(a, 1, "m", l, e, d, "minHeight", e && e.minHeight, a.height, a.i), IO(a, 1, "M", l, e, d, "maxHeight", e && e.maxHeight, a.height, a.i));
        return b
    }

    function xO(a) {
        function b() {
            if (0 < c) {
                var l = Xe(e, d) || {
                    width: 0,
                    height: 0
                };
                const m = gf(l.width);
                l = gf(l.height);
                null !== m && null !== f && h && h(0, f - m);
                null !== l && null !== g && h && h(1, g - l);
                --c
            } else r.clearInterval(k), h && (h(0, 0), h(1, 0))
        }
        let c = 31.25;
        const d = a.T,
            e = a.B,
            f = a.j,
            g = a.i,
            h = a.G;
        let k;
        r.setTimeout(() => {
            k = r.setInterval(b, 16)
        }, 990)
    }

    function EO(a, b, c) {
        if (3 == b.nodeType) return /\S/.test(b.data) ? 1 : 0;
        if (1 == b.nodeType) {
            if (/^(head|script|style)$/i.test(b.nodeName)) return 0;
            let d = null;
            try {
                d = Xe(b, c)
            } catch (e) {}
            if (d) {
                if ("none" == d.display || "fixed" == d.position) return 0;
                if ("absolute" == d.position) {
                    if (!a.l.boundingClientRect || "hidden" == d.visibility || "collapse" == d.visibility) return 0;
                    c = null;
                    try {
                        c = b.getBoundingClientRect()
                    } catch (e) {
                        return 0
                    }
                    return (c.right > a.l.boundingClientRect.left ? 2 : 0) | (c.bottom > a.l.boundingClientRect.top ? 4 : 0)
                }
            }
            return 1
        }
        return 0
    }

    function HO(a, b, c, d, e, f, g, h) {
        if (null != h) {
            if ("string" == typeof f) {
                if ("100%" == f || !f) return;
                f = ff(f);
                null == f && (a.g.xa("n"), mO(a.g, b, "d"))
            }
            if (null != f)
                if (c) {
                    if (a.A)
                        if (a.C) {
                            const k = Math.max(f + h - (g || 0), 0),
                                l = a.G;
                            a.G = (m, n) => {
                                m == b && Me(d, e, String(k - n));
                                l && l(m, n)
                            }
                        } else Me(d, e, String(h))
                } else mO(a.g, b, "d")
        }
    }

    function IO(a, b, c, d, e, f, g, h, k, l) {
        if (null != l) {
            f = f && f[g];
            "string" != typeof f || ("m" == c ? FO(f) : GO(f)) || (f = gf(f), null == f ? nO(a.g, "p") : null != k && nO(a.g, f == k ? "E" : "e"));
            if ("string" == typeof h) {
                if ("m" == c ? FO(h) : GO(h)) return;
                h = gf(h);
                null == h && (a.g.xa("p"), mO(a.g, b, c))
            }
            if (null != h)
                if (d && e) {
                    if (a.A)
                        if (a.C) {
                            const m = Math.max(h + l - (k || 0), 0),
                                n = a.G;
                            a.G = (p, q) => {
                                p == b && (e[g] = m - q + "px");
                                n && n(p, q)
                            }
                        } else e[g] = l + "px"
                } else mO(a.g, b, c)
        }
    }
    var NO = class {
        constructor(a, b, c, d, e, f, g) {
            this.pubWin = a;
            this.B = b;
            this.H = c;
            this.l = new JO(this.B);
            this.F = this.G = null;
            this.O = !1;
            this.T = (a = this.B.ownerDocument) && (a.defaultView || a.parentWindow);
            this.l = new JO(this.B);
            this.A = g;
            this.Z = KO(this.l, d.qf, d.height, d.Lc);
            this.width = this.A ? this.l.boundingClientRect ? this.l.boundingClientRect.right - this.l.boundingClientRect.left : null : e;
            this.height = this.A ? this.l.boundingClientRect ? this.l.boundingClientRect.bottom - this.l.boundingClientRect.top : null : f;
            this.j = LO(d.width);
            this.i = LO(d.height);
            this.I = this.A ? LO(d.opacity) : null;
            this.check = d.check;
            this.Lc = !!d.Lc;
            this.C = "animate" == d.qf && !MO(this.l, this.i, this.Lc) && lO();
            this.Tc = !!d.Tc;
            this.g = new rO;
            MO(this.l, this.i, this.Lc) && nO(this.g, "r");
            e = this.l;
            e.g && e.i >= e.U && nO(this.g, "b");
            this.Pd = !!d.Pd;
            this.ff = !!d.ff
        }
    };

    function MO(a, b, c) {
        var d;
        (d = a.g) && !(d = !a.visible) && (c ? (b = a.i + Math.min(b, LO(a.getHeight())), a = a.g && b >= a.U) : a = a.g && a.i >= a.U, d = a);
        return d
    }
    var JO = class {
        constructor(a) {
            this.boundingClientRect = null;
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c && Ue(c);
            this.g = !!c;
            if (a) try {
                this.boundingClientRect = a.getBoundingClientRect()
            } catch (g) {}
            var d = a;
            let e = 0,
                f = this.boundingClientRect;
            for (; d;) try {
                f && (e += f.top);
                const g = d.ownerDocument,
                    h = g && (g.defaultView || g.parentWindow);
                (d = h && h.frameElement) && (f = d.getBoundingClientRect())
            } catch (g) {
                break
            }
            this.i = e;
            c = c || r;
            this.U = ("CSS1Compat" == c.document.compatMode ? c.document.documentElement : c.document.body).clientHeight;
            b = b && KM(b);
            this.visible = !!a && !(2 == b || 3 == b) && !(this.boundingClientRect && this.boundingClientRect.top >= this.boundingClientRect.bottom && this.boundingClientRect.left >= this.boundingClientRect.right)
        }
        isVisible() {
            return this.visible
        }
        getWidth() {
            return this.boundingClientRect ? this.boundingClientRect.right - this.boundingClientRect.left : null
        }
        getHeight() {
            return this.boundingClientRect ? this.boundingClientRect.bottom - this.boundingClientRect.top : null
        }
    };

    function KO(a, b, c, d) {
        switch (b) {
            case "no_rsz":
                return !1;
            case "force":
            case "animate":
                return !0;
            default:
                return MO(a, c, d)
        }
    }

    function vO(a) {
        return !!a && /^left|right$/.test(a.cssFloat || a.styleFloat)
    }

    function OO(a, b, c, d) {
        return DO(new NO(a, b, d, c, null, null, !0))
    }
    var PO = new rO("s", ""),
        pO = RegExp("[lonvafrbpEe]", "g");

    function GO(a) {
        return !a || /^(auto|none|100%)$/.test(a)
    }

    function FO(a) {
        return !a || /^(0px|auto|none|0%)$/.test(a)
    }

    function zO(a, b, c) {
        null !== b && null !== ff(a.getAttribute("width")) && a.setAttribute("width", String(b));
        null !== c && null !== ff(a.getAttribute("height")) && a.setAttribute("height", String(c));
        null !== b && (a.style.width = b + "px");
        null !== c && (a.style.height = c + "px")
    }
    var AO = "margin-left margin-right padding-left padding-right border-left-width border-right-width".split(" "),
        BO = "margin-top margin-bottom padding-top padding-bottom border-top-width border-bottom-width".split(" ");

    function CO() {
        let a = "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1), height .3s cubic-bezier(.4, 0, 1, 1) .2s",
            b = AO;
        for (var c = 0; c < b.length; c++) a += ", " + b[c] + " .2s cubic-bezier(.4, 0, 1, 1)";
        b = BO;
        for (c = 0; c < b.length; c++) a += ", " + b[c] + " .3s cubic-bezier(.4, 0, 1, 1) .2s";
        return a
    }

    function LO(a) {
        return "string" === typeof a ? ff(a) : "number" === typeof a && isFinite(a) ? a : null
    };
    var QO = class extends aO {
        constructor(a, b, c) {
            super(a, b);
            this.l = c
        }
        ea(a) {
            a["resize-me"] = (b, c) => {
                b = Go(b);
                var d = b.r_chk;
                if (null == d || "" === d) {
                    var e = ff(b.r_nw),
                        f = ff(b.r_nh),
                        g = ff(b.r_no);
                    null != g || 0 !== e && 0 !== f || (g = 0);
                    var h = b.r_str;
                    h = h ? h : null; {
                        var k = /^true$/.test(b.r_ao),
                            l = /^true$/.test(b.r_ifr),
                            m = /^true$/.test(b.r_cab);
                        const q = window;
                        if (q)
                            if ("no_rsz" === h) b.err = "7", e = !0;
                            else {
                                var n = new JO(this.g);
                                if (n.g) {
                                    var p = n.getWidth();
                                    null != p && (b.w = p);
                                    p = n.getHeight();
                                    null != p && (b.h = p);
                                    KO(n, h, f, m) ? (n = this.l, d = OO(q, n, {
                                        width: e,
                                        height: f,
                                        opacity: g,
                                        check: d,
                                        qf: h,
                                        Tc: k,
                                        Pd: l,
                                        Lc: m
                                    }, [this.g]), b.r_cui && /^true$/.test(b.r_cui.toString()) && A(n, {
                                        height: (null === f ? 0 : f - 48) + "px",
                                        top: "24px"
                                    }), null != e && (b.nw = e), null != f && (b.nh = f), b.rsz = d.toString(), b.abl = qO(d), b.frsz = ("force" === h).toString(), b.err = "0", e = !0) : (b.err = "1", e = !1)
                                } else b.err = "3", e = !1
                            }
                        else b.err = "2", e = !1
                    }
                    c.source.postMessage(JSON.stringify({
                        msg_type: "resize-result",
                        r_str: h,
                        r_status: e,
                        googMsgType: "sth"
                    }), "*");
                    this.g.dataset.googleQueryId || this.g.setAttribute("data-google-query-id",
                        b.qid)
                }
            }
        }
    };
    const RO = {
        google: 1,
        googlegroups: 1,
        gmail: 1,
        googlemail: 1,
        googleimages: 1,
        googleprint: 1
    };
    const SO = /^blogger$/,
        TO = /^wordpress(.|\s|$)/i,
        UO = /^joomla!/i,
        VO = /^drupal/i,
        WO = /\/wp-content\//,
        XO = /\/wp-content\/plugins\/advanced-ads/,
        YO = /\/wp-content\/themes\/genesis/,
        ZO = /\/wp-content\/plugins\/genesis/;

    function $O(a) {
        var b = a.getElementsByTagName("script"),
            c = b.length;
        for (var d = 0; d < c; ++d) {
            var e = b[d];
            if (e.hasAttribute("src")) {
                e = e.getAttribute("src") || "";
                if (XO.test(e)) return 5;
                if (ZO.test(e)) return 6
            }
        }
        b = a.getElementsByTagName("link");
        c = b.length;
        for (d = 0; d < c; ++d)
            if (e = b[d], e.hasAttribute("href") && (e = e.getAttribute("href") || "", YO.test(e) || ZO.test(e))) return 6;
        a = a.getElementsByTagName("meta");
        d = a.length;
        for (e = 0; e < d; ++e) {
            var f = a[e];
            if ("generator" == f.getAttribute("name") && f.hasAttribute("content")) {
                f = f.getAttribute("content") ||
                    "";
                if (SO.test(f)) return 1;
                if (TO.test(f)) return 2;
                if (UO.test(f)) return 3;
                if (VO.test(f)) return 4
            }
        }
        for (a = 0; a < c; ++a)
            if (d = b[a], "stylesheet" == d.getAttribute("rel") && d.hasAttribute("href") && (d = d.getAttribute("href") || "", WO.test(d))) return 2;
        return 0
    };
    let aP = navigator;
    var bP = a => {
            let b = 1;
            let c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        cP = (a, b) => {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return bP(a.toLowerCase())
        };
    const dP = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        eP = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        fP = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");

    function gP(a) {
        var b = window;
        return "on" === a.google_adtest || "on" === a.google_adbreak_test || b.location.host.endsWith("h5games.usercontent.goog") ? b.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(c => Math.floor(Number(c))).filter(c => !isNaN(c) && 0 < c) || [] : []
    };

    function hP(a, b) {
        b && !a.g && (b = b.split(":"), a.g = b.find(c => 0 === c.indexOf("ID=")) || null, a.j = b.find(c => 0 === c.indexOf("T=")) ? .substring(2) || null)
    }
    var iP = class {
            constructor() {
                this.l = new Date(Date.now());
                this.j = this.g = null;
                this.i = {
                    [3]: {},
                    [4]: {},
                    [5]: {}
                };
                this.i[3] = {
                    [71]: (...a) => {
                        var b = this.g;
                        var c = this.l,
                            d = Number(a[0]);
                        a = Number(a[1]);
                        b = null !== b ? af(`${"w5uHecUBa2S"}:${d}:${b}`) % a === Math.floor(c.valueOf() / 864E5) % a : void 0;
                        return b
                    }
                };
                this.i[4] = {
                    [15]: () => {
                        var a = Number(this.j || void 0);
                        isNaN(a) ? a = void 0 : (a = new Date(1E3 * a), a = 1E4 * a.getFullYear() + 100 * (a.getMonth() + 1) + a.getDate());
                        return a
                    }
                }
            }
        },
        jP;

    function kP(a = r) {
        return a.ggeac || (a.ggeac = {})
    };

    function lP(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    };

    function mP(a = Ye()) {
        return b => af(`${b} + ${a}`) % 1E3
    };

    function nP(a, b) {
        a.g = ao(14, b, () => {})
    }
    class oP {
        constructor() {
            this.g = () => {}
        }
    }

    function pP(a) {
        u(oP).g(a)
    };

    function qP(a = kP()) {
        bo(u(co), a);
        rP(a);
        nP(u(oP), a);
        u(Wb).i()
    }

    function rP(a) {
        const b = u(Wb);
        b.j = (c, d) => ao(5, a, () => !1)(c, d, 1);
        b.l = (c, d) => ao(6, a, () => 0)(c, d, 1);
        b.A = (c, d) => ao(7, a, () => "")(c, d, 1);
        b.g = (c, d) => ao(8, a, () => [])(c, d, 1);
        b.i = () => {
            ao(15, a, () => {})(1)
        }
    };

    function sP(a, b, c) {
        var d = {
            [0]: mP(Af(b).toString())
        };
        if (c) {
            c = iM(new mM(b), "__gads", c) || "";
            jP || (jP = new iP);
            b = jP;
            hP(b, c);
            pP(b.i);
            const e = (new RegExp(/(?:^|:)(ID=[^\s:]+)/)).exec(c) ? .[1];
            d[1] = f => e ? mP(e)(f) : void 0
        }
        d = eo(a, d);
        jo.Ca(1085, vJ(u(zJ), a, d))
    }

    function tP(a, b) {
        sP(20, a, b);
        sP(17, a, b)
    }

    function uP(a) {
        const b = fo();
        a = gP(a);
        return b.concat(a).join(",")
    }

    function vP(a) {
        const b = $k();
        b && (a.debug_experiment_id = b)
    };

    function wP(a) {
        -1 === a.g && (a.g = a.data.reduce((b, c, d) => b + (c ? 2 ** d : 0), 0));
        return a.g
    }
    var xP = class {
        constructor() {
            this.data = [];
            this.g = -1
        }
        set(a, b = !0) {
            0 <= a && 52 > a && Number.isInteger(a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
        }
        get(a) {
            return !!this.data[a]
        }
    };

    function yP() {
        const a = new xP;
        "SVGElement" in r && "createElementNS" in r.document && a.set(0);
        const b = lf();
        b["allow-top-navigation-by-user-activation"] && a.set(1);
        b["allow-popups-to-escape-sandbox"] && a.set(2);
        r.crypto && r.crypto.subtle && a.set(3);
        "TextDecoder" in r && "TextEncoder" in r && a.set(4);
        return wP(a)
    };
    const zP = new Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        AP = new Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);

    function BP(a) {
        try {
            const b = a.performance ? .getEntriesByType("navigation") ? .[0];
            if (b ? .type) return zP.get(b.type) ? ? null
        } catch {}
        return AP.get(a.performance ? .navigation ? .type) ? ? null
    };
    var CP = class extends R {
        constructor() {
            super()
        }
    };

    function DP(a, b) {
        if (wc()) {
            var c = a.document.documentElement.lang;
            EP(a) ? FP(b, Af(a), !0, "", c) : (new MutationObserver((d, e) => {
                EP(a) && (FP(b, Af(a), !1, c, a.document.documentElement.lang), e.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    }

    function EP(a) {
        a = a.document ? .documentElement ? .classList;
        return !(!a ? .contains("translated-rtl") && !a ? .contains("translated-ltr"))
    }

    function FP(a, b, c, d, e) {
        Rj({
            ptt: `${a}`,
            pvsid: `${b}`,
            ibatl: String(c),
            pl: d,
            nl: e
        }, "translate-event")
    };

    function GP(a) {
        if (a = a.navigator ? .userActivation) {
            var b = 0;
            a ? .hasBeenActive && (b |= 1);
            a ? .isActive && (b |= 2);
            return b
        }
    };
    const HP = /[+, ]/;

    function IP(a, b) {
        const c = a.D;
        var d = a.pubWin,
            e = {},
            f = d.document,
            g = Df(d),
            h = !1,
            k = "",
            l = 1;
        a: {
            l = c.google_ad_width || d.google_ad_width;
            var m = c.google_ad_height || d.google_ad_height;
            if (d && d.top == d) h = !1;
            else {
                h = d.document;
                k = h.documentElement;
                if (l && m) {
                    var n = 1;
                    let q = 1;
                    d.innerHeight ? (n = d.innerWidth, q = d.innerHeight) : k && k.clientHeight ? (n = k.clientWidth, q = k.clientHeight) : h.body && (n = h.body.clientWidth, q = h.body.clientHeight);
                    if (q > 2 * m || n > 2 * l) {
                        h = !1;
                        break a
                    }
                }
                h = !0
            }
        }
        k = h;
        l = SI(g).Oe;
        m = d.top == d ? 0 : Re(d.top) ? 1 : 2;
        n = 4;
        k || 1 != m ? k ||
            2 != m ? k && 1 == m ? n = 7 : k && 2 == m && (n = 8) : n = 6 : n = 5;
        l && (n |= 16);
        k = String(n);
        l = UI(d);
        m = !!c.google_page_url;
        e.google_iframing = k;
        0 != l && (e.google_iframing_environment = l);
        if (!m && "ad.yieldmanager.com" == f.domain) {
            for (k = f.URL.substring(f.URL.lastIndexOf("http")); - 1 < k.indexOf("%");) try {
                k = decodeURIComponent(k)
            } catch (q) {
                break
            }
            c.google_page_url = k;
            m = !!k
        }
        m ? (e.google_page_url = c.google_page_url, e.google_page_location = (h ? f.referrer : f.URL) || "EMPTY") : (h && Re(d.top) && f.referrer && d.top.document.referrer === f.referrer ? e.google_page_url =
            d.top.document.URL : e.google_page_url = h ? f.referrer : f.URL, e.google_page_location = null);
        if (f.URL === e.google_page_url) try {
            var p = Math.round(Date.parse(f.lastModified) / 1E3) || null
        } catch {
            p = null
        } else p = null;
        e.google_last_modified_time = p;
        d = g == g.top ? g.document.referrer : (d = ok()) && d.referrer || "";
        e.google_referrer_url = d;
        TI(e, c);
        e = c.google_page_location || c.google_page_url;
        "EMPTY" == e && (e = c.google_page_url);
        e ? (e = e.toString(), 0 == e.indexOf("http://") ? e = e.substring(7, e.length) : 0 == e.indexOf("https://") && (e = e.substring(8,
            e.length)), d = e.indexOf("/"), -1 == d && (d = e.length), e = e.substring(0, d).split("."), d = !1, 3 <= e.length && (d = e[e.length - 3] in RO), 2 <= e.length && (d = d || e[e.length - 2] in RO), e = d) : e = !1;
        e = e ? "pagead2.googlesyndication.com" : "googleads.g.doubleclick.net";
        b = JP(a, b);
        d = a.D;
        f = d.google_ad_channel;
        g = "/pagead/ads?";
        "ca-pub-6219811747049371" === d.google_ad_client && KP.test(f) && (g = "/pagead/lopri?");
        a = Mk(b, `https://${e}${g}` + (M(a.qa, 9) && c.google_debug_params ? c.google_debug_params : ""));
        return c.google_ad_url = a
    }

    function LP(a) {
        try {
            if (a.parentNode) return a.parentNode
        } catch {
            return null
        }
        if (9 === a.nodeType) a: {
            try {
                const c = a ? ie(a) : window;
                if (c) {
                    const d = c.frameElement;
                    if (d && Re(c.parent)) {
                        var b = d;
                        break a
                    }
                }
            } catch {}
            b = null
        }
        else b = null;
        return b
    }

    function MP(a, b) {
        var c = uP(a.pubWin);
        a.D.saaei && (c += ("" === c ? "" : ",") + a.D.saaei);
        b.eid = c;
        c = a.D.google_loeid;
        "string" === typeof c && (a.i |= 4096, b.loeid = c)
    }

    function NP(a, b) {
        a = (a = Ue(a.pubWin)) && a.document ? fM(a.document, a) : new Wd(-12245933, -12245933);
        b.scr_x = Math.round(a.x);
        b.scr_y = Math.round(a.y)
    }

    function OP(a) {
        try {
            const b = r.top.location.hash;
            if (b) {
                const c = b.match(a);
                return c && c[1] || ""
            }
        } catch {}
        return ""
    }

    function PP(a, b, c) {
        const d = a.D;
        var e = a.pubWin,
            f = a.K,
            g = Df(window);
        d.fsapi && (b.fsapi = !0);
        b.ref = d.google_referrer_url;
        b.loc = d.google_page_location;
        var h;
        (h = ok(e)) && za(h.data) && "string" === typeof h.data.type ? (h = h.data.type.toLowerCase(), h = "doubleclick" == h || "adsense" == h ? null : h) : h = null;
        h && (b.apn = h.substr(0, 10));
        g = SI(g);
        b.url || b.loc || !g.url || (b.url = g.url, g.Oe || (b.usrc = 1));
        g.url != (b.loc || b.url) && (b.top = g.url);
        a.sc && (b.etu = a.sc);
        (c = jN(d, f, f ? Xj(c, f) : null)) && (b.fc = c);
        if (!Tk(d)) {
            c = a.pubWin.document;
            g = "";
            if (c.documentMode &&
                (h = re(new ee(c), "IFRAME"), h.frameBorder = "0", h.style.height = 0, h.style.width = 0, h.style.position = "absolute", c.body)) {
                c.body.appendChild(h);
                try {
                    const ba = h.contentWindow.document;
                    ba.open();
                    var k = Ed("<!DOCTYPE html>");
                    ba.write(Cd(k));
                    ba.close();
                    g += ba.documentMode
                } catch (ba) {}
                c.body.removeChild(h)
            }
            b.docm = g
        }
        let l, m, n, p, q, x, z, G, F, K;
        try {
            l = e.screenX, m = e.screenY
        } catch (ba) {}
        try {
            n = e.outerWidth, p = e.outerHeight
        } catch (ba) {}
        try {
            q = e.innerWidth, x = e.innerHeight
        } catch (ba) {}
        try {
            z = e.screenLeft, G = e.screenTop
        } catch (ba) {}
        try {
            q =
                e.innerWidth, x = e.innerHeight
        } catch (ba) {}
        try {
            F = e.screen.availWidth, K = e.screen.availTop
        } catch (ba) {}
        b.brdim = [z, G, l, m, F, K, n, p, q, x].join();
        k = 0;
        void 0 === r.postMessage && (k |= 1);
        0 < k && (b.osd = k);
        b.vis = KM(e.document);
        k = a.ha;
        e = dN(d) ? PO : DO(new NO(e, k, null, {
            width: 0,
            height: 0
        }, d.google_ad_width, d.google_ad_height, !1));
        b.rsz = e.toString();
        b.abl = qO(e);
        if (!dN(d) && (e = Uk(d), null != e)) {
            k = 0;
            a: {
                try {
                    {
                        var H = d.google_async_iframe_id;
                        const ba = window.document;
                        if (H) var N = ba.getElementById(H);
                        else {
                            var J = ba.getElementsByTagName("script"),
                                Ea = J[J.length - 1];
                            N = Ea && Ea.parentNode || null
                        }
                    }
                    if (H = N) {
                        N = [];
                        J = 0;
                        for (var Ya = Date.now(); 100 >= ++J && 50 > Date.now() - Ya && (H = LP(H));) 1 === H.nodeType && N.push(H);
                        var Eb = N;
                        b: {
                            for (Ya = 0; Ya < Eb.length; Ya++) {
                                c: {
                                    var U = Eb[Ya];
                                    try {
                                        if (U.parentNode && 0 < U.offsetWidth && 0 < U.offsetHeight && U.style && "none" !== U.style.display && "hidden" !== U.style.visibility && (!U.style.opacity || 0 !== Number(U.style.opacity))) {
                                            const ba = U.getBoundingClientRect();
                                            var tb = 0 < ba.right && 0 < ba.bottom;
                                            break c
                                        }
                                    } catch (ba) {}
                                    tb = !1
                                }
                                if (!tb) {
                                    var rc = !1;
                                    break b
                                }
                            }
                            rc = !0
                        }
                        if (rc) {
                            b: {
                                const ba =
                                    Date.now();rc = /^html|body$/i;tb = /^fixed/i;
                                for (U = 0; U < Eb.length && 50 > Date.now() - ba; U++) {
                                    const tc = Eb[U];
                                    if (!rc.test(tc.tagName) && tb.test(tc.style.position || Bk(tc, "position"))) {
                                        var sc = tc;
                                        break b
                                    }
                                }
                                sc = null
                            }
                            break a
                        }
                    }
                } catch {}
                sc = null
            }
            sc && sc.offsetWidth * sc.offsetHeight <= 4 * e.width * e.height && (k = 1);
            b.pfx = k
        }
        a: {
            if (.05 > Math.random() && f) try {
                const ba = f.document.getElementsByTagName("head")[0];
                var Sd = ba ? $O(ba) : 0;
                break a
            } catch (ba) {}
            Sd = 0
        }
        f = Sd;
        0 !== f && (b.cms = f);
        d.google_lrv !== a.ub && (b.alvm = d.google_lrv || "none")
    }

    function QP(a, b) {
        let c = 0;
        a.location && a.location.ancestorOrigins ? c = a.location.ancestorOrigins.length : Se(() => {
            c++;
            return !1
        }, a);
        c && (b.nhd = c)
    }

    function RP(a, b) {
        const c = Z(b, 8, {});
        b = Z(b, 9, {});
        const d = a.google_ad_section,
            e = a.google_ad_format;
        a = a.google_ad_slot;
        e ? c[d] = c[d] ? c[d] + `,${e}` : e : a && (b[d] = b[d] ? b[d] + `,${a}` : a)
    }

    function SP(a, b, c) {
        const d = a.D;
        var e = a.D;
        b.dt = lo;
        e.google_async_iframe_id && e.google_bpp && (b.bpp = e.google_bpp);
        a: {
            try {
                var f = r.performance;
                if (f && f.timing && f.now) {
                    var g = f.timing.navigationStart + Math.round(f.now()) - f.timing.domLoading;
                    break a
                }
            } catch (J) {}
            g = null
        }(e = (e = g) ? NN(e, r.Date.now() - lo, 1E6) : null) && (b.bdt = e);
        b.idt = NN(a.G, lo);
        e = a.D;
        b.shv = O(a.qa, 2);
        a.ub && (b.mjsv = a.ub);
        "sd" == e.google_loader_used ? b.ptt = 5 : "aa" == e.google_loader_used && (b.ptt = 9);
        /^\w{1,3}$/.test(e.google_loader_used) && (b.saldr = e.google_loader_used);
        if (e = ok(a.pubWin)) b.is_amp = 1, b.amp_v = pk(e), (e = qk(e)) && (b.act = e);
        e = a.pubWin;
        e == e.top && (b.abxe = 1);
        e = new mM(a.pubWin);
        (g = iM(e, "__gads", c)) && (b.cookie = g);
        (g = iM(e, "__gpi", c)) && !g.includes("&") && (b.gpic = g);
        "1" === iM(e, "__gpi_opt_out", c) && (b.pdopt = "1");
        v(Xs) && (e = new QN(a.pubWin, {
            Sg: !1,
            Tg: !0
        }), e = M(c, 8) || (e.g.Sg || !M(c, 5)) && e.g.Tg ? void 0 : (new Wj(e.i.document)).get("__eoi") || "", e && (b.eo_id_str = e));
        e = VI();
        f = Z(e, 8, {});
        g = d.google_ad_section;
        f[g] && (b.prev_fmts = f[g]);
        f = Z(e, 9, {});
        f[g] && (b.prev_slotnames = f[g].toLowerCase());
        RP(d, e);
        g = Z(e, 15, 0);
        0 < g && (b.nras = String(g));
        (f = ok(window)) ? (f ? (g = f.pageViewId, f = f.clientId, "string" === typeof f && (g += f.replace(/\D/g, "").substr(0, 6))) : g = null, g = +g) : (g = Df(window), f = g.google_global_correlator, f || (g.google_global_correlator = f = 1 + Math.floor(Math.random() * Math.pow(2, 43))), g = f);
        b.correlator = Z(e, 7, g);
        v(Xu) && (b.rume = 1);
        if (d.google_ad_channel) {
            g = Z(e, 10, {});
            f = "";
            var h = d.google_ad_channel.split(HP);
            for (var k = 0; k < h.length; k++) {
                var l = h[k];
                g[l] ? f += l + "+" : g[l] = !0
            }
            b.pv_ch = f
        }
        if (d.google_ad_host_channel) {
            g =
                d.google_ad_host_channel;
            f = Z(e, 11, []);
            h = g.split("|");
            e = -1;
            g = [];
            for (k = 0; k < h.length; k++) {
                l = h[k].split(HP);
                f[k] || (f[k] = {});
                var m = "";
                for (var n = 0; n < l.length; n++) {
                    var p = l[n];
                    "" !== p && (f[k][p] ? m += "+" + p : f[k][p] = !0)
                }
                m = m.slice(1);
                g[k] = m;
                "" !== m && (e = k)
            }
            f = "";
            if (-1 < e) {
                for (h = 0; h < e; h++) f += g[h] + "|";
                f += g[e]
            }
            b.pv_h_ch = f
        }
        b.frm = d.google_iframing;
        b.ife = d.google_iframing_environment;
        e = d.google_ad_client;
        try {
            var q = Df(window),
                x = q.google_prev_clients;
            x || (x = q.google_prev_clients = {});
            if (e in x) var z = 1;
            else x[e] = !0, z = 2
        } catch {
            z =
                0
        }
        b.pv = z;
        a.K && v(Kt) && (z = a.K, z = wc() && EP(z) ? z.document.documentElement.lang : void 0, z && (b.tl = z));
        x = a.pubWin.document;
        z = a.D;
        e = a.pubWin;
        q = x.domain;
        e = (M(c, 5) && Zj(e) ? e.document.cookie : null) || "";
        h = a.pubWin.screen;
        k = x.referrer;
        m = Ok();
        if (ok()) var G = window.gaGlobal || {};
        else {
            g = Math.round((new Date).getTime() / 1E3);
            f = z.google_analytics_domain_name;
            c = "undefined" == typeof f ? cP("auto", q) : cP(f, q);
            n = -1 < e.indexOf("__utma=" + c + ".");
            l = -1 < e.indexOf("__utmb=" + c);
            (q = (tk() || window).gaGlobal) || (q = {}, (tk() || window).gaGlobal = q);
            x = !1;
            if (n) {
                var F = e.split("__utma=" + c + ".")[1].split(";")[0].split(".");
                l ? q.sid = F[3] : q.sid || (q.sid = g + "");
                q.vid = F[0] + "." + F[1];
                q.from_cookie = !0
            } else {
                q.sid || (q.sid = g + "");
                if (!q.vid) {
                    x = !0;
                    l = Math.round(2147483647 * Math.random());
                    n = aP.appName;
                    p = aP.version;
                    var K = aP.language ? aP.language : aP.browserLanguage,
                        H = aP.platform,
                        N = aP.userAgent;
                    try {
                        F = aP.javaEnabled()
                    } catch (J) {
                        F = !1
                    }
                    F = [n, p, K, H, N, F ? 1 : 0].join("");
                    h ? F += h.width + "x" + h.height + h.colorDepth : r.java && r.java.awt && (h = r.java.awt.Toolkit.getDefaultToolkit().getScreenSize(),
                        F += h.screen.width + "x" + h.screen.height);
                    F = F + e + (k || "");
                    for (h = F.length; 0 < m;) F += m-- ^ h++;
                    q.vid = (l ^ bP(F) & 2147483647) + "." + g
                }
                q.from_cookie || (q.from_cookie = !1)
            }
            if (!q.cid) {
                b: for (g = f, F = 999, g && (g = 0 == g.indexOf(".") ? g.substr(1) : g, F = g.split(".").length), g = 999, e = e.split(";"), f = 0; f < e.length; f++)
                    if (h = dP.exec(e[f]) || eP.exec(e[f]) || fP.exec(e[f])) {
                        k = h[1] || 0;
                        if (k == F) {
                            G = h[2];
                            break b
                        }
                        k < g && (g = k, G = h[2])
                    }x && G && -1 != G.search(/^\d+\.\d+$/) ? (q.vid = G, q.from_cookie = !0) : G != q.vid && (q.cid = G)
            }
            q.dh = c;
            q.hid || (q.hid = Math.round(2147483647 *
                Math.random()));
            G = q
        }
        b.ga_vid = G.vid;
        b.ga_sid = G.sid;
        b.ga_hid = G.hid;
        b.ga_fc = G.from_cookie;
        b.ga_cid = G.cid;
        b.ga_wpids = z.google_analytics_uacct;
        QP(a.pubWin, b);
        (a = d.google_ad_layout) && 0 <= CN[a] && (b.rplot = CN[a])
    }

    function TP(a, b) {
        var c = a.g;
        a = a.qa;
        if (c ? .g() || dJ()) b.npa = 1;
        v(Cu) && M(a, 6) && !c ? .j() && (b.ltd_cs = 1);
        c && (c.j() && (b.gdpr = M(c, 3) ? "1" : "0"), (a = I(c, 1)) && (b.us_privacy = a), (a = I(c, 2)) && (b.gdpr_consent = a), (a = I(c, 4)) && (b.addtl_consent = a), (a = L(c, 7)) && (b.tcfe = a), v(Ws) && ((a = O(c, 11)) && (b.gpp = a), (c = ai(c, 10, ph, 2, void 0, void 0, 0)) && 0 < c.length && (b.gpp_sid = c.join(","))))
    }

    function UP(a, b) {
        const c = a.D;
        TP(a, b);
        Ze(hJ, (d, e) => {
            b[d] = c[e]
        });
        dN(c) && (a = pN(c), b.fa = a);
        b.pi || null == c.google_ad_slot || (a = bB(c), null != a.g && (a = uq(a.getValue()), b.pi = a))
    }

    function jR(a, b) {
        var c = sk() || dM(a.pubWin.top);
        c && (b.biw = c.width, b.bih = c.height);
        c = a.pubWin;
        c !== c.top && (a = dM(a.pubWin)) && (b.isw = a.width, b.ish = a.height)
    }

    function kR(a, b) {
        var c = a.pubWin;
        null !== c && c != c.top ? (a = [c.document.URL], c.name && a.push(c.name), c = dM(c, !1), a.push(c.width.toString()), a.push(c.height.toString()), a = af(a.join(""))) : a = 0;
        0 !== a && (b.ifk = a)
    }

    function lR(a, b) {
        (a = bJ()[a.D.google_ad_client]) && (b.psts = a.join())
    }

    function mR(a, b) {
        (a = a.pubWin.tmod) && (b.tmod = a)
    }

    function nR(a, b) {
        (a = a.pubWin.google_user_agent_client_hint) && (b.uach = Lf(a))
    }

    function oR(a, b) {
        try {
            const e = a.pubWin && a.pubWin.external && a.pubWin.external.getHostEnvironmentValue && a.pubWin.external.getHostEnvironmentValue.bind(a.pubWin.external);
            if (e) {
                var c = JSON.parse(e("os-mode")),
                    d = parseInt(c["os-mode"], 10);
                0 <= d && (b.wsm = d + 1)
            }
        } catch {}
    }

    function pR(a, b) {
        0 <= a.D.google_ad_public_floor && (b.pubf = a.D.google_ad_public_floor);
        0 <= a.D.google_ad_private_floor && (b.pvtf = a.D.google_ad_private_floor)
    }

    function qR(a, b) {
        const c = Number(a.D.google_traffic_source);
        c && Object.values(Na).includes(c) && (b.trt = a.D.google_traffic_source)
    }

    function rR(a, b) {
        var c;
        (c = v(cv)) || (c = a.A ? .label, c = v(Hu) && c ? !!c.match(Xb(Fu)) : !1);
        c || "runAdAuction" in a.pubWin.navigator && "joinAdInterestGroup" in a.pubWin.navigator && (b.td = 1)
    }

    function sR(a, b) {
        if (null != a.A && wc()) {
            var c = new CP,
                d = aj(c, 3, a.A.label);
            Q(d, 4, a.A.status);
            b.psd = Lf(bj(c))
        }
    }

    function tR(a, b) {
        v(Uu) || lP("attribution-reporting", a.pubWin.document) && (b.nt = 1)
    }

    function uR(a, b) {
        if ("string" === typeof a.D.google_privacy_treatments) {
            var c = new Map([
                ["disablePersonalization", 1]
            ]);
            a = a.D.google_privacy_treatments.split(",");
            var d = [];
            for (const [e, f] of c.entries()) c = f, a.includes(e) && d.push(c);
            d.length && (b.ppt = d.join("~"))
        }
    }

    function vR(a, b) {
        v(xu) && (b.bz = Ef(a.pubWin))
    }

    function JP(a, b) {
        const c = {};
        UP(a, c);
        nR(a, c);
        SP(a, c, b);
        c.u_tz = -(new Date).getTimezoneOffset();
        c.u_his = Ok();
        c.u_h = Sj.screen ? .height;
        c.u_w = Sj.screen ? .width;
        c.u_ah = Sj.screen ? .availHeight;
        c.u_aw = Sj.screen ? .availWidth;
        c.u_cd = Sj.screen ? .colorDepth;
        c.u_sd = eM(a.pubWin);
        c.dmc = a.pubWin.navigator ? .deviceMemory;
        Zz(889, () => {
            if (null == a.K) c.adx = -12245933, c.ady = -12245933;
            else {
                var e = hM(a.K, a.ha);
                c.adx && -12245933 != c.adx && c.ady && -12245933 != c.ady || (c.adx = Math.round(e.x), c.ady = Math.round(e.y));
                gM(a.ha) || (c.adx = -12245933,
                    c.ady = -12245933, a.i |= 32768)
            }
        });
        jR(a, c);
        kR(a, c);
        NP(a, c);
        MP(a, c);
        c.oid = 2;
        lR(a, c);
        c.pvsid = Af(a.pubWin, Xz);
        mR(a, c);
        oR(a, c);
        c.uas = GP(a.pubWin);
        const d = BP(a.pubWin);
        d && (c.nvt = d);
        a.C && (c.scar = a.C);
        a.l instanceof Uint8Array ? c.topics = Jf(a.l) : a.l && (c.topics = a.l, c.tps = a.l);
        PP(a, c, b);
        c.fu = a.i;
        c.bc = yP();
        M(a.qa, 9) && (vP(c), c.creatives = OP(/\b(?:creatives)=([\d,]+)/), c.adgroups = OP(/\b(?:adgroups)=([\d,]+)/), c.adgroups && (c.adtest = "on", c.disable_budget_throttling = !0, c.use_budget_filtering = !1, c.retrieve_only = !0, c.disable_fcap = !0));
        ek() && (c.atl = !0);
        vR(a, c);
        pR(a, c);
        qR(a, c);
        rR(a, c);
        sR(a, c);
        tR(a, c);
        uR(a, c);
        v(Iu) && "true" === String(a.D.google_xz) && (c.scd = 1);
        null == Xb(Ju) || !1 !== a.D.google_video_play_muted && !0 !== v(Ku) || 10 !== a.D.google_reactive_ad_format && 11 !== a.D.google_reactive_ad_format || (c.sdkv = Xb(Ju));
        return c
    }
    const KP = /YtLoPri/;
    var wR = class extends R {};
    wR.P = [5];
    var pi = class extends R {
            Ge() {
                return O(this, 18)
            }
            ud() {
                return O(this, 19)
            }
            He() {
                return O(this, 20)
            }
        },
        xR = hj(pi);
    pi.P = [15];
    var yR = class extends R {},
        zR = hj(yR);
    yR.P = [3];
    var AR = class {
        constructor(a) {
            this.Vb = a.Vb ? ? [];
            this.Uc = a.Uc ? ? 0;
            this.Pc = a.Pc ? ? !1;
            this.jf = !!a.jf;
            this.Rg = !!a.Rg;
            this.Ye = a.Ye ? ? .1;
            this.df = a.df ? ? !1;
            this.cf = !!a.cf;
            this.rb = a.rb ? ? !1;
            this.yg = a.yg ? ? 0;
            this.Hf = a.Hf ? ? 0;
            this.ze = a.ze ? ? !1;
            this.Ae = a.Ae ? ? !1;
            this.nf = !!a.nf;
            this.De = !!a.De;
            this.ee = a.ee ? ? 3E4;
            this.de = a.de ? ? "";
            this.ib = a.ib ? ? "";
            this.Oc = !!a.Oc;
            this.pe = !!a.pe;
            this.V = !!a.V;
            this.Ec = a.Ec ? ? .3;
            this.jd = !!a.jd
        }
    };

    function BR(a, b, c, d, e) {
        const f = C(b, RN, 2);
        try {
            const k = a ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/);
            if (k) {
                var g = decodeURIComponent(k[1]);
                var h = xR(g)
            } else h = null
        } catch (k) {
            h = null
        }
        h = h || oi(b);
        a = f ? .g() && (488 > wo(a) || !f ? .j()) ? 0 : 1;
        b = D(b, or, 3);
        b = {
            Ej: w(St),
            gf: 2,
            ge: 5,
            Ub: 300,
            Yf: b
        };
        return {
            aa: h,
            gd: c,
            Be: a,
            Ci: d,
            Ya: b,
            ce: {
                rf: w(su)
            },
            J: new AR({
                Vb: fo(),
                Uc: w(Pt),
                Ye: w(ju),
                Pc: v(tu),
                jf: v(ou),
                df: v(mu),
                cf: v(lu),
                rb: v($t),
                yg: w(gu),
                Hf: w(Ot),
                ze: v(Vt),
                Ae: v(Wt),
                nf: v(qu),
                De: v(au),
                ee: w(Rt),
                de: Xb(bu),
                ib: Xb(cu),
                Oc: v(Xt),
                pe: v(Ut),
                V: v(ru),
                Ec: w(iu),
                jd: v(Zt)
            }),
            be: e
        }
    }

    function CR(a, b) {
        a = iB(xA(b, a), a);
        if (0 !== a.length) return a.reduce((c, d) => c.ja.g > d.ja.g ? c : d)
    };

    function DR(a, b) {
        a.entries.push(Rh(b));
        return a.entries.length - 1
    }

    function ER(a, b, c, d, e, f, g, h) {
        var k = new xn,
            l = new Dm;
        c = aj(l, 1, c);
        d = aj(c, 2, d);
        b = Wi(d, 3, b);
        k = E(k, 1, b);
        b = new Em;
        b = aj(b, 2, a.i);
        e = aj(b, 3, e);
        e = E(k, 2, e);
        g = P(e, 3, Math.round(g));
        b = D(f, wR, 15);
        e = d = k = 0;
        for (m of b) k += (M(m, 3) ? 1 : 0) + (M(m, 4) ? 1 : 0) + ai(m, 5, uh, 2).length, c = M(m, 3) ? 1 : 0, l = M(m, 4) || ai(m, 5, uh, 2).length ? 1 : 0, d += c + l, e += M(m, 3) ? 1 : 0;
        var m = new wn;
        m = Xi(m, 1, b.length);
        m = Xi(m, 2, k);
        m = Vh(m, 3, null == d ? d : hh(d));
        m = Vh(m, 4, null == e ? e : hh(e));
        m = E(g, 6, m);
        h.length ? (a = new on, a = si(a, 1, h), ri(m, 5, yn, a)) : (h = new vn, h = si(h, 2, a.entries), f = D(f,
            wR, 15).length, f = P(h, 3, f), a = E(f, 4, a.g), ri(m, 4, yn, a));
        return m
    }
    var FR = class {
        constructor() {
            this.entries = [];
            this.g = this.i = null
        }
    };
    async function GR(a, b) {
        await new Promise(c => {
            0 < a.j && a.win.requestIdleCallback ? a.win.requestIdleCallback(() => void c(), {
                timeout: a.j
            }) : a.win.setTimeout(c, 0)
        });
        a.i = a.g.za(b) + a.l
    }
    var HR = class {
        constructor(a, b) {
            var c = w(Tt),
                d = w(eu);
            this.win = a;
            this.g = b;
            this.l = c;
            this.j = d;
            this.i = b.za(2) + c
        }
    };
    var IR = class {
            constructor(a) {
                this.performance = a
            }
            za() {
                return this.performance.now()
            }
        },
        JR = class {
            za() {
                return Date.now()
            }
        };
    const KR = [255, 255, 255];

    function LR(a) {
        function b(d) {
            return [Number(d[1]), Number(d[2]), Number(d[3]), 4 < d.length ? Number(d[4]) : 1]
        }
        var c = a.match(/rgb\(([0-9]+),\s*([0-9]+),\s*([0-9]+)\)/);
        if (c || (c = a.match(/rgba\(([0-9]+),\s*([0-9]+),\s*([0-9]+),\s*([0-9\\.]+)\)/))) return b(c);
        if ("transparent" === a || "" === a) return [0, 0, 0, 0];
        throw Error(`Invalid color: ${a}`);
    }

    function MR(a) {
        var b = getComputedStyle(a);
        if ("none" !== b.backgroundImage) return null;
        b = LR(b.backgroundColor);
        var c = NR(b);
        if (c) return c;
        a = (a = a.parentElement) ? MR(a) : KR;
        if (!a) return null;
        c = b[3];
        return [Math.round(c * b[0] + (1 - c) * a[0]), Math.round(c * b[1] + (1 - c) * a[1]), Math.round(c * b[2] + (1 - c) * a[2])]
    }

    function NR(a) {
        return 1 === a[3] ? [a[0], a[1], a[2]] : null
    };
    var PR = class {
        constructor(a, b, c, d) {
            this.gf = b;
            this.ge = c;
            this.Ub = d;
            this.i = 0;
            this.g = new OR(a)
        }
    };

    function QR(a, b) {
        b -= a.l;
        for (const c of a.g.keys()) {
            const d = a.g.get(c);
            let e = 0;
            for (; e < d.length && d[e] < b;) e++;
            a.i -= e;
            0 < e && a.g.set(c, d.slice(e))
        }
    }
    class OR {
        constructor(a) {
            this.l = a;
            this.g = new Map;
            this.i = 0
        }
        get j() {
            return this.i
        }
    };

    function RR(a) {
        A(a, {
            border: "0",
            "box-shadow": "none",
            display: "inline",
            "float": "none",
            margin: "0",
            outline: "0",
            padding: "0"
        })
    };

    function SR(a, b) {
        return TR(a, "100 -1000 840 840", `calc(${b} - 2px)`, b, "m784-120-252-252q-30 24-69 38t-83 14q-109 0-184.5-75.5t-75.5-184.5q0-109 75.5-184.5t184.5-75.5q109 0 184.5 75.5t75.5 184.5q0 44-14 83t-38 69l252 252-56 56zm-404-280q75 0 127.5-52.5t52.5-127.5q0-75-52.5-127.5t-127.5-52.5q-75 0-127.5 52.5t-52.5 127.5q0 75 52.5 127.5t127.5 52.5z")
    }

    function UR(a, b, c) {
        switch (c) {
            case 1:
                return b = TR(a, "0 -960 960 960", "20px", "20px", "m274-274-128-70 42-42 100 14 156-156-312-170 56-56 382 98 157-155q17-17 42.5-17t42.5 17q17 17 17 42.5T812-726L656-570l98 382-56 56-170-312-156 156 14 100-42 42-70-128Z"), A(b, {
                    fill: "#FFFFFF"
                }), b;
            case 2:
                return a = TR(a, "0 -960 960 960", "20px", "20px", "M784-120 532-372q-30 24-69 38t-83 14q-109 0-184.5-75.5T120-580q0-109 75.5-184.5T380-840q109 0 184.5 75.5T640-580q0 44-14 83t-38 69l252 252-56 56ZM380-400q75 0 127.5-52.5T560-580q0-75-52.5-127.5T380-760q-75 0-127.5 52.5T200-580q0 75 52.5 127.5T380-400Z"),
                    b && A(a, {
                        fill: b
                    }), a;
            default:
                return a = TR(a, "0 -960 960 960", "20px", "20px", "M503-104q-24 24-57 24t-57-24L103-390q-23-23-23-56.5t23-56.5l352-353q11-11 26-17.5t32-6.5h286q33 0 56.5 23.5T879-800v286q0 17-6.5 32T855-456L503-104Zm196-536q25 0 42.5-17.5T759-700q0-25-17.5-42.5T699-760q-25 0-42.5 17.5T639-700q0 25 17.5 42.5T699-640ZM446-160l353-354v-286H513L160-446l286 286Zm353-640Z"), b && A(a, {
                    fill: b
                }), a
        }
    }

    function VR(a, b, c, d) {
        a = TR(a, "0 -960 960 960", "20px", "20px", "m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z");
        A(a, {
            left: "13px",
            right: "",
            "pointer-events": "initial",
            position: "absolute",
            top: b.V ? "11px" : "15px",
            transform: "none"
        });
        d && A(a, {
            fill: "#1A73E8"
        });
        a.role = "button";
        a.ariaLabel = c;
        a.tabIndex = 0;
        return a
    }

    function TR(a, b, c, d, e) {
        const f = a.createElementNS("http://www.w3.org/2000/svg", "path");
        f.setAttribute("d", e);
        a = a.createElementNS("http://www.w3.org/2000/svg", "svg");
        a.setAttribute("viewBox", b);
        a.setAttribute("width", c);
        a.setAttribute("height", d);
        RR(a);
        a.appendChild(f);
        return a
    };
    const WR = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500"];

    function YR(a, b, c, d, e) {
        a = new ZR(a, b, c, d, e);
        if (a.l) {
            Vp(a.win, WR);
            var f = a.win;
            b = a.message;
            c = Rv(f);
            e = c.shadowRoot;
            d = e.appendChild;
            f = new ee(f.document);
            var g = fs('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500" rel="stylesheet"><style>.ipr-container {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; color: #000; border-top: 2px solid rgb(236, 237, 237); border-bottom: 2px solid rgb(236, 237, 237); background-color: #fff; padding: 5px; margin: 5px 0; text-align: center;}.ipr-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ipr-display-none {display: none;}</style><div class="ipr-container"><button class="ipr-button"></button><div class="ipr-info"></div></div>');
            d.call(e,
                se(f, as(g)));
            d = lx("ipr-container", e);
            e = lx("ipr-button", d);
            b.actionButton ? (e.appendChild(b.actionButton.buttonText), e.addEventListener("click", b.actionButton.onClick)) : e.classList.add("ipr-display-none");
            d = lx("ipr-info", d);
            b.informationText ? d.appendChild(b.informationText) : d.classList.add("ipr-display-none");
            a.g = c.Ta;
            gB(a.l, a.g);
            a.j && a.j(xm(1));
            $R(a)
        } else aS(a)
    }

    function $R(a) {
        const b = new Yp(a.win);
        b.L(2E3);
        Yo(a, b);
        Wp(b, () => {
            bS(a);
            aS(a);
            b.la()
        })
    }

    function aS(a) {
        tz(a.win, a.Kb).addRegulatoryMessage({
            messageSpec: {
                regulatoryMessage: a.message,
                orderingIndex: 0
            }
        });
        a.j && a.j(xm(2))
    }

    function bS(a) {
        a.g && (a.g.parentNode ? .removeChild(a.g), a.g = null)
    }
    var ZR = class extends T {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.l = b;
            this.message = c;
            this.Kb = d;
            this.j = e;
            this.g = null
        }
        i() {
            bS(this);
            super.i()
        }
    };

    function cS(a, b, c, d, e, f) {
        if (!a.g) {
            var g = b.document.createElement("span");
            g.appendChild(SR(b.document, "12px"));
            g.appendChild(b.document.createTextNode(d));
            YR(b, c || null, {
                informationText: g
            }, e, f ? h => {
                var k = f.handle,
                    l = dS(f, 16);
                h = ri(l, 11, Jn, h);
                k.call(f, h)
            } : f);
            a.g = !0
        }
    }
    var eS = class {
        constructor() {
            this.g = !1
        }
    };
    const fS = [{
        Rd: "1907259590",
        Hd: 480,
        Eb: 220
    }, {
        Rd: "2837189651",
        Hd: 400,
        Eb: 180
    }, {
        Rd: "9211025045",
        Hd: 360,
        Eb: 160
    }, {
        Rd: "6584860439",
        Hd: -Infinity,
        Eb: 150
    }];

    function gS(a) {
        return fS.find(b => b.Hd <= a)
    };

    function hS(a, b) {
        return b ? a.replace("ca", "partner") : "pub-adfiliates-query-origin"
    };

    function iS(a) {
        jS.g.push(a)
    }
    const jS = new class {
        constructor() {
            this.g = []
        }
    };
    let kS = !1;

    function lS(a) {
        mS(a.config, 1065, a.win, () => {
            if (!a.g) {
                var b = new Gn;
                b = P(b, 1, a.i);
                var c = new Fn;
                b = ri(b, 2, Hn, c);
                nS(a.config.ba, b)
            }
        }, 1E4)
    }
    class oS {
        constructor(a, b, c) {
            this.win = a;
            this.config = b;
            this.i = c;
            this.g = !1
        }
        cancel(a) {
            this.win.clearTimeout(a)
        }
    }

    function pS(a, b, c, d, e, f) {
        const g = gS(a.document.body.clientWidth);
        d = b.sa ? qS(a, b, d, g, e, f) : rS(a, b, d, g, e, f);
        jp(d.isVisible(), !1, () => {
            kS = !1;
            var k = jS;
            for (const l of k.g) l();
            k.g.length = 0
        });
        d.show({
            bg: !0
        });
        kS = !0;
        const h = new oS(a, b, c);
        lS(h);
        iS(() => {
            var k = b.ba;
            var l = new Gn;
            l = P(l, 1, c);
            var m = new En;
            l = ri(l, 3, Hn, m);
            nS(k, l);
            h.g = !0
        })
    }

    function qS(a, b, c, d, e, f) {
        d = b.J.Pc ? sS(a, b, c, f) : tS(a, b, c, {
            re: d,
            cg: a.innerWidth,
            ag: "100%",
            Dg: "15px",
            Zf: "13px",
            Eg: "center",
            jh: 0
        }, e, f);
        return ny(a, d, {
            Ze: .95,
            Fe: .95,
            zIndex: 100001,
            qb: !0,
            xe: "adpub-drawer-root",
            we: !1,
            Ja: !0,
            Ce: new V(O(b.aa, 10).replace("TERM", c))
        })
    }

    function rS(a, b, c, d, e, f) {
        a: {
            var g = a.document.body.clientWidth;
            var h = .9 * g;
            for (g = 768 >= g ? 3 : 4; 1 <= g; g--) {
                const k = d.Eb * g + 42;
                if (k <= h) {
                    h = k;
                    break a
                }
            }
        }
        d = b.J.Pc ? sS(a, b, c, f) : tS(a, b, c, {
            re: d,
            cg: h,
            ag: "600px",
            Dg: "24px",
            Zf: "24px",
            Eg: "start",
            jh: 0
        }, e, f);
        return xx(a, d, {
            vc: `${h}px`,
            uc: b.ka(),
            kc: O(b.aa, 14),
            zIndex: 100001,
            qb: !0,
            kd: !0,
            xe: "adpub-drawer-root",
            we: !1,
            Ja: !0,
            Ce: new V(O(b.aa, 10).replace("TERM", c))
        })
    }

    function sS(a, b, c, d) {
        const e = a.document.createElement("iframe");
        var f = b.aa;
        f = new Ls(e, O(f, 16), "anno-cse", hS(b.g, M(f, 22)), "ShoppingVariant", a.location, O(f, 7), O(f, 10).replace("TERM", c), b.J.Vb, !1, !0, void 0, !0, b.J.jf ? b.g : void 0);
        f.L();
        uS(a, b, e, c, f, d);
        return e
    }

    function tS(a, b, c, d, e, f) {
        var g = b.aa,
            h = O(g, 10),
            k = h.indexOf("TERM"),
            l = d.cg,
            m = d.re;
        l = Math.max(Math.floor((l - Math.floor(l / m.Eb) * m.Eb) / 2), 5);
        m = d.ag;
        const n = O(g, 3),
            p = d.Dg,
            q = d.Zf,
            x = d.Eg,
            z = O(g, 6),
            G = h.substring(0, k);
        h = h.substring(k + 4);
        k = !!M(g, 13);
        e = fs('<link href="https://fonts.googleapis.com/css2?family=Google+Material+Icons:wght@400;500;700" rel="stylesheet"><link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400;500;700&display=swap" rel="stylesheet"><div style="font-family: Roboto, sans-serif;"><div style="border: 0 solid #eee; border-bottom-width: 1px; color: #3c4043; font-size: 13px; line-height: 20px; padding: 0 ' + js(X(p)) +
            " " + js(X(q)) + "; text-align: " + js(X(x)) + ';">' + (e ? '<div style="max-width: ' + js(X(m)) + '">' + es(n) + '\u00a0<a href="https://support.google.com/adsense/answer/11188578" target="_blank" style="color: #1967d2; text-decoration: none; white-space: nowrap">' + es(z) + "</a></div>" : "") + "</div><div style=\"border-bottom: 1px solid #eee; color: #202124; font-family: 'Google Sans'; font-size: 15px; line-height: 24px; padding: 15px " + js(X(p)) + "; text-align: " + js(X(x)) + '"><div style="display: -webkit-box; overflow: hidden; -webkit-line-clamp: 2; -webkit-box-orient: vertical;"><span style="bottom: -2px; color: #1967d2; font-family: \'Google Material Icons\'; padding-right: 5px; position: relative">search</span><span style="color:#80868b"> ' +
            es(G) + "</span>" + es(c) + '<span style="color:#80868b">' + es(h) + '</span></div></div><div id="anno-csa" style="margin:5px ' + js(X(l)) + "px\"></div><script>(function(g,o){g[o]=g[o]||function(){(g[o]['q']=g[o]['q']||[]).push(arguments)},g[o]['t']=1*new Date})(window,'_googCsa');parent.postMessage({query:" + ns(os(c)) + "},parent.location.origin);\x3c/script>" + (k ? "<script>const el = document.getElementById('anno-csa'); el.dir = 'ltr'; el.style.height = '800px'; el.style.width = '75vw'; el.style.overflow = 'hidden'; el.style.overflowWrap = 'break-word'; el.textContent = JSON.stringify(window._googCsa.q);\x3c/script>" :
                '<script async="async" src="https://www.google.com/adsense/search/ads.js">\x3c/script>') + "</div>");
        g = {
            dir: b.ka() ? "rtl" : "ltr",
            lang: O(g, 7),
            style: rd({
                margin: "0",
                height: "100%",
                "padding-top": `${d.jh}px`,
                overflow: "hidden"
            })
        };
        e = as(e);
        Fd("body");
        g = Id("body", g, e);
        e = a.document.createElement("IFRAME");
        A(e, {
            border: "0",
            width: "100%"
        });
        vS(a, b, e, c, d.re, f);
        e.srcdoc = Cd(g);
        return e
    }

    function vS(a, b, c, d, e, f) {
        const g = wS(b, a, function(h) {
            h.data.query === d && xS(a, b, c, d, e, f)
        });
        iS(() => {
            a.removeEventListener("message", g)
        })
    }

    function uS(a, b, c, d, e, f) {
        const g = wS(b, a.top, function(h) {
            "init" === h.data.action && "ShoppingVariant" === h.data.adChannel && yS(a, b, c, e, d, f)
        });
        iS(() => {
            a.top.removeEventListener("message", g)
        })
    }

    function xS(a, b, c, d, e, f) {
        const g = c.contentDocument ? .documentElement;
        g && ((new ResizeObserver(() => {
            c.height = `${g.offsetHeight}px`
        })).observe(g), zS(b, a, () => {
            const h = g.offsetHeight;
            h && (c.height = `${h}px`)
        }), AS(b, c, d, e, f))
    }

    function yS(a, b, c, d, e, f) {
        M(b.aa, 13) || Js(d, e, f);
        const g = c.contentDocument.documentElement,
            h = new ResizeObserver(() => {
                c.height = `${Math.ceil(g.offsetHeight+22)}px`
            });
        h.observe(g);
        const k = zS(b, a, () => {
            const l = g.offsetHeight;
            l && (c.height = `${l+22}px`)
        });
        iS(() => {
            h.disconnect();
            a.clearInterval(k)
        })
    }

    function AS(a, b, c, d, e) {
        const f = a.aa,
            g = b.contentWindow;
        b = b ? .contentDocument || b.contentWindow ? .document;
        if (g) {
            if (void 0 === g._googCsa) throw Error("No _googCsa");
            if (!b) throw Error("No contentDocument");
        } else throw Error("No googCsa window");
        a = {
            pubId: hS(a.g, M(f, 22)),
            styleId: d.Rd,
            disableCarousel: !0,
            query: c,
            hl: O(f, 7),
            personalizedAds: "false",
            fexp: a.J.Vb.join(","),
            adfiliateWp: a.g,
            adtest: a.be ? "on" : ""
        };
        e && (a.afdToken = e);
        g._googCsa("ads", a, {
            container: "anno-csa",
            linkTarget: "_blank",
            number: 8,
            width: b.body.offsetWidth -
                30
        });
        M(f, 13) && (e = b.getElementById("anno-csa"), e.dir = "ltr", e.style.height = "800px", e.style.width = "75vw", e.style.overflow = "hidden", e.style.g = "break-word", e.textContent = JSON.stringify(g._googCsa.q))
    };

    function BS(a) {
        a = LR(a);
        var b = new qn;
        b = Yi(b, 1, a[0]);
        b = Yi(b, 2, a[1]);
        b = Yi(b, 3, a[2]);
        return ki(b, 4, $g(a[3]), 0)
    };

    function CS(a, b, c) {
        return c.Oc ? DS(a, b, c) ? ? ES(a, b, c) : ES(a, b, c) ? ? DS(a, b, c)
    }

    function ES(a, b, c) {
        const d = c.sa === c.ka;
        var e = FS(a, b, c, d);
        if (!e) return null;
        e = e.position.qd();
        const f = b.V ? 7 : 16;
        a = GS(a, b, e, c, function(g) {
            g = g.getBoundingClientRect();
            return d ? c.R - g.right : g.left
        });
        if (!a || 200 > a - f) return null;
        b = c.R;
        return {
            ta: d ? b - a : f,
            Fa: d ? f : b - a,
            ca: e
        }
    }

    function HS(a, b, c) {
        const d = wo(a),
            e = S(a);
        return 0 < Xv(new Zv(a), new hk(e - c.ca - (b.V ? 40 : 50), d - c.Fa, e - c.ca, c.ta)).size
    }

    function FS(a, b, c, d) {
        c = Math.floor(c.U * (c.Ec ? ? .3));
        const e = b.V ? 40 : 66;
        return c < e ? null : uy(a, {
            cc: d ? Ay({
                ca: b.V ? 0 : 16,
                Fa: b.V ? 7 : 16
            }) : yy({
                ca: b.V ? 0 : 16,
                ta: b.V ? 7 : 16
            }),
            Qe: c - e,
            Bb: 50,
            Te: b.V ? 40 : 50,
            Fd: c,
            mb: b.V ? 7 : 16
        }, [a.document.body]).ie
    }

    function GS(a, b, c, d, e) {
        a = d.sa ? IS(a, b, c, d) : JS(a, b, c, d);
        c = d.R;
        let f = d.sa ? c : .35 * c;
        a.forEach(g => {
            f = Math.min(f, e(g))
        });
        b = b.V ? 7 : 16;
        return f < b ? null : f - b
    }

    function IS(a, b, c, d) {
        const e = d.U,
            f = b.V ? 7 : 16;
        return Xv(new Zv(a), new hk(e - c - (b.V ? 40 : 50), d.R - f, e - c, f))
    }

    function JS(a, b, c, d) {
        const e = d.U,
            f = d.R;
        d = d.ka;
        const g = b.V ? 7 : 16;
        return Xv(new Zv(a), new hk(e - c - (b.V ? 40 : 50), (d ? .35 * f : f) - g, e - c, (d ? g : .65 * f) + g))
    }

    function DS(a, b, c) {
        const d = c.R;
        var e = KS(a, b, c);
        let f = a = b.V ? 7 : 16;
        for (const g of e) {
            e = g.start;
            const h = g.end;
            if (e > f) {
                if (200 <= e - f - a) return LS(c, b, e, f);
                f = h + a
            } else h >= f && (f = h + a)
        }
        return 200 <= d - f - a ? LS(c, b, d, f) : null
    }

    function LS(a, b, c, d) {
        const e = a.ka;
        return {
            ta: e ? MS(a, b, c, d) : d,
            Fa: e ? d : MS(a, b, c, d),
            ca: b.V ? 0 : 16
        }
    }

    function MS(a, b, c, d) {
        const e = a.R;
        b = b.V ? 7 : 16;
        return a.sa ? e - c + b : Math.max(e - d - .35 * e, e - c + b)
    }

    function KS(a, b, c) {
        const d = c.ka,
            e = c.R;
        a = c.sa ? IS(a, b, b.V ? 0 : 16, c) : JS(a, b, b.V ? 0 : 16, c);
        return Array.from(a).map(f => new ty(d ? e - f.getBoundingClientRect().right : f.getBoundingClientRect().left, d ? e - f.getBoundingClientRect().left : f.getBoundingClientRect().right)).sort((f, g) => f.start - g.start)
    };

    function NS(a, b, c, d, e, f, g, h, k) {
        A(c, {
            width: "50px",
            bottom: g ? g.ca + "px" : "16px",
            left: b.ka() === b.sa ? "" : g ? g.ta + "px" : "16px",
            right: b.ka() === b.sa ? g ? g.Fa + "px" : "16px" : ""
        });
        c.role = "button";
        c.ariaLabel = b.He();
        A(e, {
            display: "none"
        });
        A(d, {
            display: "none"
        });
        const l = UR(a.document, b.J.ib, b.Ke.get(k) || 0);
        b.J.jd ? (a = a.document.createElement("SPAN"), A(a, {
            display: "inline-block",
            position: "absolute",
            top: b.J.V ? "12px" : "14px",
            left: "15px"
        }), c.appendChild(a), a.appendChild(l)) : (A(l, {
                position: "absolute",
                top: b.J.V ? "12px" : "14px",
                left: "15px"
            }),
            c.appendChild(l));
        OS(b, 1064, c, m => {
            h ? .();
            l.remove();
            A(c, {
                bottom: g ? g.ca + "px" : "16px",
                left: g ? g.ta + "px" : b.sa ? "16px" : b.ka() ? "16px" : "65%",
                right: g ? g.Fa + "px" : PS(b),
                width: ""
            });
            c.role = "";
            c.ariaLabel = "";
            A(e, {
                display: ""
            });
            A(d, {
                display: "flex"
            });
            f.focus();
            m.preventDefault();
            return !1
        });
        c.focus()
    }

    function PS(a) {
        return a.ka() ? a.sa ? "16px" : "65%" : "16px"
    }

    function QS(a, b) {
        return {
            "margin-left": b ? "6px" : "4px",
            "margin-right": b ? "4px" : "6px",
            "margin-top": a.V ? "8px" : "12px"
        }
    };

    function RS(a, b, c, d, e, f, g, h, k) {
        const l = document.createElement("SPAN");
        l.id = "gda";
        l.appendChild(VR(a.document, b.J, b.Ge(), b.J.ib));
        OS(b, 1064, l, m => {
            g ? .();
            NS(a, b, c, d, l, e, f, h, k);
            m.preventDefault();
            m.stopImmediatePropagation();
            return !1
        });
        return l
    }

    function SS(a, b) {
        (new MutationObserver(c => {
            c.forEach(d => {
                "attributes" === d.type && "0px" === a.document.body.style.paddingBottom && A(a.document.body, {
                    "padding-bottom": (b.V ? 40 : 66) + "px"
                })
            })
        })).observe(a.document.body, {
            attributes: !0
        })
    }

    function TS(a, b, c, d, e, f, g) {
        var h = b.J,
            k = a.getComputedStyle(a.document.body).paddingBottom.match(/\d+/);
        A(a.document.body, {
            "padding-bottom": (k && k.length ? Number(k[0]) : 0) + (h.V ? 40 : 66) + "px"
        });
        SS(a, b.J);
        h = document.createElement("div");
        h.id = "google-anno-sa";
        h.dir = b.ka() ? "rtl" : "ltr";
        h.tabIndex = 0;
        k = {
            background: b.J.de || "#1A73E8",
            "border-style": "solid",
            bottom: e ? e.ca + "px" : "16px",
            "border-radius": b.J.V ? e ? .ca ? "12px" : "12px 12px 0 0" : "16px",
            height: (b.J.V ? 40 : 50) + "px",
            position: "fixed",
            "text-align": "center",
            border: "0px",
            left: e ? e.ta + "px" : b.sa ? "16px" : b.ka() ? "16px" : "65%",
            right: e ? e.Fa + "px" : PS(b),
            "box-shadow": "0px 1px 2px rgba(0, 0, 0, 0.3), 0px 1px 3px 1px rgba(0, 0, 0, 0.15)",
            "z-index": "1000"
        };
        A(h, k);
        A(h, {
            fill: "white"
        });
        k = document.createElement("SPAN");
        const l = document.createElement("SPAN");
        RR(l);
        var m = {
            position: "absolute",
            top: "2.5px",
            bottom: "2.5px",
            left: (b.ka(), "50px"),
            right: b.ka() ? "24px" : "12px",
            display: "flex",
            "flex-direction": "row",
            color: b.J.ib || "#FFFFFF",
            cursor: "pointer",
            transition: "width 5s"
        };
        A(l, m);
        b.sa || A(l, {
            "justify-content": ""
        });
        m = UR(a.document, b.J.ib, b.Ke.get(d) || 0);
        if (b.J.jd) {
            const n = document.createElement("SPAN");
            A(n, {
                display: "inline-block"
            });
            A(n, QS(b.J, b.ka()));
            l.appendChild(n);
            n.appendChild(m)
        } else A(m, QS(b.J, b.ka())), l.appendChild(m);
        k.classList ? .add("google-anno-sa-qtx", "google-anno-skip");
        m = b.ud();
        k.tabIndex = 0;
        k.role = "link";
        k.ariaLive = "polite";
        k.ariaLabel = m.replace("TERM", d);
        A(k, {
            height: b.J.V ? "" : "40px",
            "align-items": "center",
            "line-height": b.J.V ? "35px" : "44px",
            "font-size": "16px",
            "font-weight": "400",
            "font-style": "normal",
            "font-family": "Roboto",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
            overflow: "hidden",
            "-webkit-tap-highlight-color": "transparent",
            color: b.J.ib
        });
        OS(b, 999, l, c);
        l.appendChild(k);
        c = RS(a, b, h, l, k, e, f, g, d);
        b.J.pe && !b.ka() ? (h.appendChild(l), h.appendChild(c), NS(a, b, h, l, c, k, e, g, d)) : (h.appendChild(l), h.appendChild(c));
        return h
    }

    function US(a, b, c) {
        b = b.getElementsByClassName("google-anno-sa-qtx")[0];
        b instanceof HTMLElement && (b.innerText = a.g);
        b.ariaLabel = c.aa.ud().replace("TERM", a.g);
        c = c.ba;
        b = new Cm;
        b = Zi(b, 1, a.i);
        b = aj(b, 4, a.g);
        a = c.handle;
        var d = dS(c, 13);
        b = ri(d, 6, Jn, b);
        return a.call(c, b)
    }

    function VS(a, b, c, d) {
        if (c.J.rb && HS(b, c.J, d) || !c.J.rb && mD(b)) return null;
        const e = c.za(20);
        d = TS(b, c, g => {
            if (!c.J.Uc || e + c.J.Uc <= c.za(21)) {
                var h = c.ba;
                var k = new zn;
                k = aj(k, 4, a.g);
                k = Zi(k, 1, a.i);
                k = Zi(k, 3, a.j);
                h = WS(h, k);
                pS(b, c, h, a.g, !1, c.l.get(a.g) || "")
            }
            g.preventDefault();
            return !1
        }, a.g, d, () => {
            var g = c.ba;
            var h = new zm;
            h = P(h, 1, a.i);
            var k = aj(h, 2, a.g);
            h = g.handle;
            var l = dS(g, 18);
            k = ri(l, 12, Jn, k);
            return h.call(g, k)
        }, () => {
            var g = c.ba,
                h = new Am,
                k = g.handle,
                l = dS(g, 19);
            h = ri(l, 13, Jn, h);
            return k.call(g, h)
        });
        const f = US(a, d, c);
        b.document.body.appendChild(d);
        return f
    }

    function XS(a, b, c, d, e, f) {
        if (a.g !== d || null !== a.i || a.l !== e) {
            if (null !== a.j) {
                var g = a.j,
                    h = c.ba;
                var k = new Bm;
                k = P(k, 1, g);
                g = h.handle;
                var l = dS(h, 14);
                k = ri(l, 7, Jn, k);
                g.call(h, k)
            }
            a.g = d;
            a.i = null;
            a.l = e;
            M(c.aa, 17) || (d = b.document.getElementById("google-anno-sa"), a.j = d ? US(a, d, c) : VS(a, b, c, f))
        }
    }
    var YS = class {
        constructor() {
            this.g = "";
            this.i = null;
            this.l = "";
            this.j = null
        }
    };

    function ZS(a, b) {
        a.g >= a.i.length && (a.g = 0);
        if (kS) iS(() => void ZS(a, b));
        else {
            var c = a.i[a.g++];
            a.j = !1;
            XS(a.A, a.win, a.config, c.g, c.i, a.l);
            mS(a.config, 898, a.win, () => void ZS(a, b), a.rf)
        }
    }
    var $S = class {
        constructor(a, b, c) {
            var d = new YS;
            this.win = a;
            this.config = b;
            this.A = d;
            this.l = c;
            this.i = [];
            this.j = !0;
            this.g = 0;
            this.rf = b.ce.rf
        }
    };
    class aT {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function bT(a, b, c, d) {
        b.forEach(e => {
            var f = sn(1);
            f = aj(f, 4, e);
            DR(c, f);
            d.i.push(new aT(e, e));
            d.j && ZS(d, a)
        })
    };
    const cT = /[\s!'",:;\\(\\)\\?\\.\u00bf\u00a1\u30a0\uff1d\u037e\u061f\u3002\uff1f\uff1b\uff1a\u2014\u2014\uff5e\u300a\u300b\u3008\u3009\uff08\uff09\u300c\u300d\u3001\u00b7\u2026\u2025\uff01\uff0c\u00b7\u2019\u060c\u061b\u060d\u06d4\u0648]/;

    function dT(a, b) {
        switch (b) {
            case 1:
                return !0;
            default:
                return "" === a || cT.test(a)
        }
    };
    var eT = class {
        constructor(a) {
            this.g = a
        }
        isEmpty() {
            return this.g.isEmpty()
        }
        match(a) {
            return this.g.match(a)
        }
    };
    class fT {
        constructor(a) {
            this.B = a;
            this.size = 1;
            this.g = [new gT];
            this.j = [];
            this.i = new Map;
            this.A = new Map;
            this.l = 0
        }
        isEmpty() {
            return 0 === this.l
        }
        match(a) {
            let b = 0;
            const c = [];
            for (let g = 0; g < a.length; g++) {
                for (;;) {
                    var d = a.charCodeAt(g),
                        e = this.g[b];
                    if (e.contains(d)) {
                        b = e.j.get(d);
                        break
                    }
                    if (0 === b) break;
                    b = e.g
                }
                let h = b;
                for (;;) {
                    h = this.g[h].i;
                    if (0 === h) break;
                    const k = g + 1 - this.j[this.g[h].G],
                        l = g;
                    d = a;
                    e = l;
                    var f = this.B;
                    dT(d.charAt(k - 1), f) && dT(d.charAt(e + 1), f) && c.push(new hT(k, l, this.A.get(this.g[h].B)));
                    h = this.g[h].g
                }
            }
            return c
        }
    }
    class gT {
        constructor() {
            this.j = new Map;
            this.I = !1;
            this.ea = this.H = this.F = this.Z = this.O = this.T = -1
        }
        contains(a) {
            return this.j.has(a)
        }
        set A(a) {
            this.T = a
        }
        get A() {
            return this.T
        }
        set C(a) {
            this.O = a
        }
        get C() {
            return this.O
        }
        set l(a) {
            this.I = a
        }
        get l() {
            return this.I
        }
        set B(a) {
            this.H = a
        }
        get B() {
            return this.H
        }
        set g(a) {
            this.Z = a
        }
        get g() {
            return this.Z
        }
        set i(a) {
            this.F = a
        }
        get i() {
            return this.F
        }
        set G(a) {
            this.ea = a
        }
        get G() {
            return this.ea
        }
        get na() {
            return this.j.values()
        }
    }
    var hT = class {
        constructor(a, b, c) {
            this.j = a;
            this.i = b;
            this.B = c
        }
        get l() {
            return this.j
        }
        get A() {
            return this.i
        }
        get g() {
            return this.B
        }
        get length() {
            return this.i - this.j
        }
    };
    const iT = ["block", "inline", "inline-block", "list-item", "table-cell"];
    async function jT(a, b, c, d, e) {
        d.g.za(5) >= d.i && await GR(d, 6);
        if (!c.J.ze) {
            const f = D(c.aa, wR, 15);
            f.length && kT(a, b, c, e, f)
        }
        c.J.Ae || await lT(a, c, d, e)
    }

    function kT(a, b, c, d, e) {
        c.J.De && !CS(a, c.J, mT(a, c)) ? mS(c, 898, a, () => {
            nT(a, b, c, d, e)
        }, c.J.ee) : nT(a, b, c, d, e)
    }

    function oT(a, b, c, d) {
        var e = !0;
        const f = b.ua;
        let g = hD({
            K: a,
            Re: 3E3,
            Ue: 400,
            ua: f,
            Uh: !b.J.rb
        });
        b.J.rb && !c && (g |= 16777216);
        if (c = g) e = d.g = d.g ? ? new un, P(e, 2, c), e = !1;
        0 !== b.Be || 0 !== pT(a, 1, f) || b.sa && 0 === pT(a, 2, f) || (Wi(d.g = d.g ? ? new un, 3, !0), e = !1);
        return e
    }

    function pT(a, b, c) {
        return hD({
            K: a,
            Re: 3E3,
            Ue: a.innerWidth > to ? 650 : 0,
            ua: c,
            Qf: b
        })
    }
    async function lT(a, b, c, d) {
        var e = D(b.aa, wR, 15);
        var f = new fT(b.i);
        for (var g of e)
            if (M(g, 3)) {
                e = O(g, 1);
                var h = f.i.has(e) ? f.i.get(e) : f.l++;
                f.i.set(e, h);
                f.A.set(h, e);
                var k = 0;
                for (var l = 0; l < e.length; l++) {
                    const n = e.charCodeAt(l);
                    f.g[k].contains(n) || (f.g.push(new gT), f.g[f.size].A = k, f.g[f.size].C = n, f.g[k].j.set(n, f.size), f.size++);
                    k = f.g[k].j.get(n)
                }
                f.g[k].l = !0;
                f.g[k].B = h;
                f.g[k].G = f.j.length;
                f.j.push(e.length)
            }
        g = [];
        for (g.push(0); 0 < g.length;) {
            h = g.shift();
            e = f;
            k = e.g[h];
            if (0 === h) k.g = 0, k.i = 0;
            else if (0 === k.A) k.g =
                0, k.i = k.l ? h : e.g[e.g[h].g].i;
            else {
                k = e.g[e.g[h].A].g;
                for (l = e.g[h].C;;) {
                    if (e.g[k].contains(l)) {
                        e.g[h].g = e.g[k].j.get(l);
                        break
                    }
                    if (0 === k) {
                        e.g[h].g = 0;
                        break
                    }
                    k = e.g[k].g
                }
                e.g[h].i = e.g[h].l ? h : e.g[e.g[h].g].i
            }
            for (var m of f.g[h].na) g.push(m)
        }
        f = new eT(f);
        f.isEmpty() || (m = b.J.cf ? qT(D(b.aa, wR, 15)) : null, await b.Ca(898, rT(a, b, c, d, f, m, new PR(b.Ya.Ej, b.Ya.gf, b.Ya.ge, b.Ya.Ub))))
    }

    function qT(a) {
        return RegExp(a.filter(b => M(b, 3)).map(b => O(b, 1).replace(/[/\\^$*+?.()|[\]{}]/g, "\\$&")).join("|"), "u")
    }
    async function rT(a, b, c, d, e, f, g) {
        var h = new eS;
        let k = a.document.body;
        if (M(b.aa, 17) || C(b.aa, gr, 21))
            for (; k;) {
                c.g.za(7) >= c.i && await GR(c, 8);
                if (k.nodeType === Node.TEXT_NODE && "" !== k.textContent && k.parentElement) {
                    const Kb = k.parentElement;
                    a: {
                        var l = a,
                            m = b,
                            n = Kb,
                            p = k.textContent,
                            q = d,
                            x = e,
                            z = g;
                        const wb = [];b: {
                            var G = p;
                            switch (m.i) {
                                case 1:
                                    var F = G;
                                    const xb = Array(F.length);
                                    let Ga = 0;
                                    for (let Lb = 0; Lb < F.length; Lb++) cT.test(F[Lb]) || Ga++, xb[Lb] = Ga;
                                    var K = xb;
                                    break b;
                                default:
                                    var H = G;
                                    const cb = Array(H.length);
                                    let nb = 0,
                                        Qa = 0;
                                    for (; Qa <
                                        H.length;) {
                                        for (;
                                            /\s/.test(H[Qa]);) cb[Qa] = nb, Qa++;
                                        let Lb = !1;
                                        for (; Qa < H.length && !/\s/.test(H[Qa]);) Lb = !0, cb[Qa] = nb, Qa++;
                                        Lb && (nb++, cb[Qa - 1] = nb)
                                    }
                                    K = cb
                            }
                        }
                        const mb = K;
                        if (p.includes("\u00bb")) var N = [];
                        else {
                            const xb = x.match(p),
                                Ga = new Map;
                            for (const cb of xb) {
                                const nb = cb.l;
                                if (Ga.has(nb)) {
                                    const Qa = Ga.get(nb);
                                    cb.length > Qa.length && Ga.set(nb, cb)
                                } else Ga.set(nb, cb)
                            }
                            N = Array.from(Ga.values())
                        }
                        const Ki = N;
                        let Ie = -1;
                        for (const xb of Ki) {
                            const Ga = xb.l,
                                cb = xb.A;
                            var J = z,
                                Ea = xb.g;
                            QR(J.g, J.i + mb[Ga]);
                            var Ya = J,
                                Eb = Ya.g,
                                U = Ea;
                            if (!((Eb.g.has(U) ?
                                    Eb.g.get(U).length : 0) < Ya.gf && J.g.j < J.ge)) continue;
                            const nb = l.getComputedStyle(n),
                                Qa = nb.fontSize.match(/\d+/);
                            if (!(Qa && 12 <= Number(Qa[0]) && 22 >= Number(Qa[0]) && bb(iT, nb.display))) {
                                z.i += mb[mb.length - 1];
                                var tb = [];
                                break a
                            }
                            const Lb = Ie + 1;
                            Lb < Ga && wb.push(l.document.createTextNode(p.substring(Lb, Ga)));
                            const Mi = p.substring(Ga, cb + 1);
                            var rc = p,
                                sc = Ga,
                                Sd = cb + 1,
                                ba = l,
                                tc = n,
                                Mm = Mi,
                                Nm = rc.substring(Math.max(sc - 30, 0), sc) + "~~" + rc.substring(Sd, Math.min(Sd + 30, rc.length)),
                                Om = xb.g,
                                Pm = mb[Ga];
                            const Ni = tc.getBoundingClientRect();
                            var Qm =
                                sn(2);
                            var Rm = aj(Qm, 2, Mm);
                            var Sm = aj(Rm, 3, Nm);
                            var Tm = aj(Sm, 4, Om);
                            var Um = Yi(Tm, 5, Pm);
                            var Vm = Yi(Um, 6, Math.round(Ni.x));
                            var Wm = Yi(Vm, 7, Math.round(Ni.y));
                            const Nc = ba.getComputedStyle(tc);
                            var Xm = new rn;
                            var Ym = aj(Xm, 1, Nc.fontFamily);
                            var Zm = BS(Nc.color);
                            var $m = E(Ym, 7, Zm);
                            var an = BS(Nc.backgroundColor);
                            var bn = E($m, 8, an);
                            const Oi = Nc.fontSize.match(/^(\d+(\.\d+)?)px$/);
                            var ag = Yi(bn, 4, Oi ? Math.round(Number(Oi[1])) : 0);
                            const jg = Math.round(Number(Nc.fontWeight));
                            isNaN(jg) || 400 === jg || Yi(ag, 5, jg);
                            "none" !== Nc.textDecorationLine &&
                                aj(ag, 6, Nc.textDecorationLine);
                            var Ci = E(Wm, 8, ag);
                            const kg = [];
                            let Td = tc;
                            for (; Td && 20 > kg.length;) {
                                var Di = kg,
                                    Ei = Di.push,
                                    Fe = Td,
                                    Fi = new pn;
                                const Pi = aj(Fi, 1, Fe.tagName);
                                "" !== Fe.className && ji(Pi, 2, Fe.className.split(" "), sh);
                                Ei.call(Di, Pi);
                                if ("BODY" === Td.tagName) break;
                                Td = Td.parentElement
                            }
                            var Gi = kg.reverse();
                            var cn = si(Ci, 9, Gi);
                            const fn = DR(q, cn);
                            wb.push(sT(l, m, fn, xb.g, Mi, n));
                            var Ge = z.g,
                                He = xb.g,
                                Hi = z.i + mb[Ga];
                            let lg = [];
                            Ge.g.has(He) && (lg = Ge.g.get(He));
                            lg.push(Hi);
                            Ge.i++;
                            Ge.g.set(He, lg);
                            Ie = cb;
                            if (0 < z.Ub && z.g.j >=
                                z.Ub) break
                        }
                        const Je = Ie + 1;0 !== Je && Je < p.length && wb.push(l.document.createTextNode(p.substring(Je)));z.i += mb[mb.length - 1];tb = wb
                    }
                    const uc = tb;
                    if (0 < uc.length && !M(b.aa, 17)) {
                        cS(h, a, b.Ya.Yf ? CR(a, b.Ya.Yf) : void 0, O(b.aa, 3), C(b.aa, gr, 21).i(), b.ba);
                        for (const wb of uc) Kb.insertBefore(wb, k), tT(wb);
                        Kb.removeChild(k);
                        for (k = uc[uc.length - 1]; k.lastChild;) k = k.lastChild;
                        if (0 < g.Ub && g.g.j >= g.Ub) break
                    }
                }
                a: {
                    var Wa = k,
                        dg = f,
                        Ii = g,
                        Ji = b.i;
                    if (Wa.firstChild && (Wa.nodeType !== Node.ELEMENT_NODE ? 0 : !Wa.classList ? .contains("google-anno-skip") &&
                            Wa.offsetHeight)) {
                        b: {
                            switch (Wa.tagName ? .toUpperCase ? .()) {
                                case "IFRAME":
                                case "A":
                                case "AUDIO":
                                case "BUTTON":
                                case "CANVAS":
                                case "CITE":
                                case "CODE":
                                case "EMBED":
                                case "FOOTER":
                                case "FORM":
                                case "KBD":
                                case "LABEL":
                                case "OBJECT":
                                case "PRE":
                                case "SAMP":
                                case "SCRIPT":
                                case "SELECT":
                                case "STYLE":
                                case "SUB":
                                case "SUPER":
                                case "SVG":
                                case "TEXTAREA":
                                case "TIME":
                                case "VAR":
                                case "VIDEO":
                                case null:
                                    var eg = !1;
                                    break b
                            }
                            eg = !(Wa.className.toUpperCase ? .() ? .includes("CRUMB") || Wa.id.toUpperCase ? .() ? .includes("CRUMB")) && (!dg ||
                                2 > (Wa.parentNode ? .childElementCount ? ? 0) || !!Wa.textContent ? .match(dg))
                        }
                        if (eg) {
                            k = Wa.firstChild;
                            break a
                        }
                        if (Wa.textContent ? .length) {
                            var fg = Ii;
                            b: {
                                var gg = Wa.textContent;
                                switch (Ji) {
                                    case 1:
                                        var hg = gg;
                                        let uc = 0;
                                        for (let mb = hg.length - 1; 0 <= mb; mb--) cT.test(hg[mb]) || uc++;
                                        var ig = uc;
                                        break b;
                                    default:
                                        const wb = gg.trim();
                                        ig = "" === wb ? 0 : wb.split(/\s+/).length
                                }
                            }
                            QR(fg.g, fg.i + ig)
                        }
                    }
                    let Kb = Wa;
                    for (;;) {
                        if (Kb.nextSibling) {
                            k = Kb.nextSibling;
                            break a
                        }
                        if (!Kb.parentNode) {
                            k = null;
                            break a
                        }
                        Kb = Kb.parentNode
                    }
                }
            }
    }

    function mT(a, b) {
        return {
            ka: b.ka(),
            sa: b.sa,
            R: wo(a),
            U: S(a),
            Oc: b.J.Oc,
            Ec: b.J.Ec
        }
    }

    function nT(a, b, c, d, e) {
        e = e.filter(g => M(g, 4) || 0 < ai(g, 5, uh, 3, void 0, !0).length).map(g => O(g, 1));
        if (0 !== e.length) {
            var f = c.J.rb ? CS(a, c.J, mT(a, c)) : null;
            oT(a, c, f, d) && (c.J.df && qb(e), bT(b, e, d, new $S(a, c, f)))
        }
    }

    function tT(a) {
        if (a.nodeType === Node.ELEMENT_NODE) {
            if ("A" === a.tagName) {
                var b = NR(LR(getComputedStyle(a.parentElement).color)),
                    c = NR(LR(getComputedStyle(a).color));
                var d = MR(a);
                if (d = b && c && d ? RL(c, d) < Math.min(RL(b, d), 2.5) ? b : null : b) {
                    b = d[0];
                    c = d[1];
                    d = d[2];
                    b = Number(b);
                    c = Number(c);
                    d = Number(d);
                    if (b != (b & 255) || c != (c & 255) || d != (d & 255)) throw Error('"(' + b + "," + c + "," + d + '") is not a valid RGB color');
                    c = b << 16 | c << 8 | d;
                    b = 16 > b ? "#" + (16777216 | c).toString(16).slice(1) : "#" + c.toString(16);
                    A(a, {
                        color: b
                    })
                }
            }
            for (b = 0; b < a.childElementCount; b++) tT(a.children[b])
        }
    }
    class uT {
        constructor() {
            this.g = null
        }
        get i() {
            return this.g
        }
    }

    function sT(a, b, c, d, e, f) {
        const g = a.document.createElement("SPAN");
        RR(g);
        A(g, {
            "text-decoration": "underline"
        });
        A(g, {
            "text-decoration-style": "dotted"
        });
        A(g, {
            "-webkit-text-decoration-line": "underline",
            "-webkit-text-decoration-style": "dotted"
        });
        g.appendChild(a.document.createTextNode(e));
        e = a.document.createElement("A");
        RR(e);
        A(e, {
            "text-decoration": "none",
            fill: "currentColor"
        });
        Ee(e);
        e.className = "google-anno";
        e.appendChild(SR(a.document, a.getComputedStyle(f).fontSize));
        e.appendChild(a.document.createTextNode("\u00a0"));
        e.appendChild(g);
        const h = vT(b, c, e);
        OS(b, 999, e, k => {
            try {
                var l = b.ba,
                    m = new zn;
                var n = aj(m, 4, d);
                var p = Zi(n, 1, c);
                var q = Zi(p, 2, h.i);
                const x = WS(l, q);
                pS(a, b, x, d, !0, b.A.get(d) || "");
                return !1
            } finally {
                k.preventDefault(), k.stopImmediatePropagation()
            }
        });
        return e
    }

    function vT(a, b, c) {
        const d = new uT;
        wT(a, e => {
            for (const k of e)
                if (k.isIntersecting) {
                    var f = b;
                    e = a.ba;
                    var g = new Dn;
                    g = f = P(g, 1, f);
                    f = e.handle;
                    var h = dS(e, 11);
                    g = ri(h, 4, Jn, g);
                    e = f.call(e, g);
                    d.g = e
                } else d.g && (e = a.ba, f = new Cn, g = f = P(f, 1, d.g), f = e.handle, h = dS(e, 12), g = ri(h, 5, Jn, g), f.call(e, g), d.g = null)
        }).observe(c);
        return d
    };

    function nS(a, b) {
        var c = a.handle,
            d = dS(a, 15);
        b = ri(d, 9, Jn, b);
        c.call(a, b)
    }

    function WS(a, b) {
        var c = a.handle,
            d = dS(a, 10);
        b = ri(d, 8, Jn, b);
        return c.call(a, b)
    }

    function dS(a, b) {
        var c = new In;
        var d = a.A++;
        c = P(c, 1, d);
        b = P(c, 2, Math.round(a.g.za(b) - a.i));
        return E(b, 10, a.j)
    }
    var xT = class {
        constructor(a, b, c, d) {
            this.g = a;
            this.i = b;
            this.j = c;
            this.A = 1;
            this.l = [...d]
        }
        handle(a) {
            for (const b of this.l) b(a);
            return yi(a, 1)
        }
    };

    function mS(a, b, c, d, e) {
        c.setTimeout(yT(a, b, d), e)
    }

    function wS(a, b, c) {
        a = yT(a, 999, c);
        b.addEventListener("message", a);
        return a
    }

    function zS(a, b, c) {
        return b.setInterval(yT(a, 1066, c), 1E3)
    }

    function OS(a, b, c, d) {
        c.addEventListener("click", yT(a, b, d))
    }

    function wT(a, b) {
        return new IntersectionObserver(yT(a, 1065, b), {
            threshold: .98
        })
    }

    function yT(a, b, c) {
        return a.j.Oa(b, c, void 0, d => void zT(a, d))
    }

    function zT(a, b) {
        b.es = a.J.Vb.join(",");
        b.c = `${a.C}`
    }
    var BT = class {
        constructor(a, b, c, d, e, f, g, h, k, l, m, n, p = !1) {
            this.g = a;
            this.sa = b;
            this.Be = c;
            this.aa = d;
            this.C = e;
            this.j = f;
            this.ba = g;
            this.ua = h;
            this.B = k;
            this.Ya = l;
            this.ce = m;
            this.be = p;
            this.J = new AR(n);
            this.i = bb(AT, O(d, 7)) ? 1 : 0;
            this.A = new Map;
            this.l = new Map;
            this.Ke = new Map;
            for (const q of D(this.aa, wR, 15)) null != I(q, 6) && this.A.set(O(q, 1), O(q, 6)), null != I(q, 7) && this.l.set(O(q, 1), O(q, 7)), null != L(q, 10) && this.Ke.set(O(q, 1), zi(q, 10))
        }
        Ca(a, b) {
            this.j.Ca(a, b, c => void zT(this, c));
            return b
        }
        za(a) {
            return this.B.za(a)
        }
        ka() {
            return 2 ===
                zi(this.aa, 12)
        }
        Ge() {
            return this.aa.Ge()
        }
        He() {
            return this.aa.He()
        }
        ud() {
            return this.aa.ud()
        }
    };
    const AT = ["ja", "zh_CN", "zh_TW"];

    function CT(a, b) {
        return null == b ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function DT(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function ET() {
        const a = new Set,
            b = GB();
        try {
            if (!b) return a;
            const c = b.pubads();
            for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function FT(a) {
        a = a.id;
        return null != a && (ET().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function GT(a, b, c) {
        if (!a.sources) return !1;
        switch (HT(a)) {
            case 2:
                const d = IT(a);
                if (d) return c.some(f => JT(d, f));
                break;
            case 1:
                const e = KT(a);
                if (e) return b.some(f => JT(e, f))
        }
        return !1
    }

    function HT(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function KT(a) {
        return LT(a, b => b.currentRect)
    }

    function IT(a) {
        return LT(a, b => b.previousRect)
    }

    function LT(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function JT(a, b) {
        const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
    }

    function MT() {
        const a = Array.from(document.getElementsByTagName("iframe")).filter(FT),
            b = [...ET()].map(c => document.getElementById(c)).filter(c => null !== c);
        NT = window.scrollX;
        OT = window.scrollY;
        return PT = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function QT(a, b) {
        const c = NT !== window.scrollX || OT !== window.scrollY ? [] : PT,
            d = MT();
        for (const e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                RT(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Cb = Math.floor(b.renderTime || b.loadTime);
                a.Ua = b.size;
                break;
            case "first-input":
                b = e;
                a.va = Number((b.processingStart - b.startTime).toFixed(3));
                a.Ha = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || ST(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.C +=
                    b;
                a.H = Math.max(a.H, b);
                a.Z += 1;
                break;
            case "event":
                ST(a, e);
                break;
            default:
                Oe(b, void 0)
        }
    }

    function TT(a) {
        a.A || (a.A = new PerformanceObserver(Dv(640, b => {
            QT(a, b)
        })));
        return a.A
    }

    function UT(a) {
        const b = Dv(641, () => {
                2 === KM(document) && VT(a)
            }),
            c = Dv(641, () => void VT(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.na = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            TT(a).disconnect()
        }
    }

    function VT(a) {
        if (!a.xf) {
            a.xf = !0;
            TT(a).takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += DT("cls", a.G), b += DT("mls", a.I), b += CT("nls", a.T), window.LayoutShiftAttribution && (b += DT("cas", a.B), b += CT("nas", a.Rc), b += DT("was", a.Of)), b += DT("wls", a.ea), b += DT("tls", a.Mf));
            window.LargestContentfulPaint && (b += CT("lcp", a.Cb), b += CT("lcps", a.Ua));
            window.PerformanceEventTiming && a.Ha && (b += CT("fid", a.va));
            window.PerformanceLongTaskTiming && (b += CT("cbt", a.C),
                b += CT("mbt", a.H), b += CT("nlt", a.Z));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) FT(c) && d++;
            b += CT("nif", d);
            b += CT("ifi", Qk(window));
            c = fo();
            b += `&${"eid"}=${encodeURIComponent(c.join())}`;
            b += `&${"top"}=${r===r.top?1:0}`;
            b += a.zf ? `&${"qqid"}=${encodeURIComponent(a.zf)}` : CT("pvsid", Af(r));
            window.googletag && (b += "&gpt=1");
            c = Math.min(a.g.length - 1, Math.floor((a.A ? a.Qa : performance.interactionCount || 0) / 50));
            0 <= c && (c = a.g[c].latency, 0 <= c && (b += CT("inp", c)));
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            a.na()
        }
    }

    function RT(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.G += Number(b.value);
            Number(b.value) > a.I && (a.I = Number(b.value));
            a.T += 1;
            if (c = GT(b, c, d)) a.B += b.value, a.Rc++;
            if (5E3 < b.startTime - a.Qc || 1E3 < b.startTime - a.yf) a.Qc = b.startTime, a.i = 0, a.j = 0;
            a.yf = b.startTime;
            a.i += b.value;
            c && (a.j += b.value);
            a.i > a.ea && (a.ea = a.i, a.Of = a.j, a.Mf = b.startTime + b.duration)
        }
    }

    function ST(a, b) {
        WT(a, b);
        const c = a.g[a.g.length - 1],
            d = a.F[b.interactionId];
        if (d || 10 > a.g.length || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.F[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.F[e.id]
        })
    }

    function WT(a, b) {
        b.interactionId && (a.O = Math.min(a.O, b.interactionId), a.l = Math.max(a.l, b.interactionId), a.Qa = a.l ? (a.l - a.O) / 7 + 1 : 0)
    }
    var XT = class {
            constructor() {
                this.j = this.i = this.T = this.I = this.G = 0;
                this.yf = this.Qc = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.F = {};
                this.Qa = 0;
                this.O = Infinity;
                this.va = this.Ua = this.Cb = this.Rc = this.Of = this.B = this.Mf = this.ea = this.l = 0;
                this.Ha = !1;
                this.Z = this.H = this.C = 0;
                this.A = null;
                this.xf = !1;
                this.na = () => {};
                const a = document.querySelector("[data-google-query-id]");
                this.zf = a ? a.getAttribute("data-google-query-id") : null;
                this.di = {
                    Zh: !1
                }
            }
            observe() {
                var a = window;
                if (!a.google_plmetrics && window.PerformanceObserver) {
                    a.google_plmetrics = !0;
                    a = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                    this.di.Zh && a.push("event");
                    for (const b of a) a = {
                        type: b,
                        buffered: !0
                    }, "event" === b && (a.durationThreshold = 40), TT(this).observe(a);
                    UT(this)
                }
            }
        },
        NT, OT, PT = [];
    async function YT(a, b, c, d, e, f, g, h) {
        var k = Xz,
            l = Wz;
        const m = ((h = iM(new mM(a), "__gads", h)) ? af(h + "t2Z7mVic") % 20 : null) ? ? Math.floor(20 * Ye());
        c.J.Rg || ZT(c.J.Ye, k);
        var n = f.za(0);
        h = 488 > wo(a);
        const p = c.aa;
        var q = c.J,
            x = An(m);
        q = ji(x, 3, q.Vb, jh);
        e = new xT(f, n, q, e);
        k = new BT(d, h, c.Be, p, m, k, e, l, f, c.Ya, c.ce, c.J, c.be);
        d = new FR;
        b = await $T(a, a.document, b, k, g, d);
        f = f.za(9) - n;
        k = c.J;
        if (!k.nf && !M(p, 17) && d.entries.length && !M(p, 13)) {
            g = a.document;
            n = g.createElement("LINK");
            a: {
                k = k.Pc ? sj `https://cse.google.com/cse.js?cx=${O(p,16)}&language=${O(p, 
7)}` : sj `https://www.google.com/adsense/search/ads.js`;
                if (k instanceof Yc) n.href = ad(k).toString();
                else {
                    if (-1 === Pe.indexOf("prefetch")) throw Error('TrustedResourceUrl href attribute required with rel="prefetch"');
                    k = k instanceof hd ? id(k) : De(k);
                    if (void 0 === k) break a;
                    n.href = k
                }
                n.rel = "prefetch"
            }
            n.as = "script";
            n.fetchPriority = "low";
            g.head.appendChild(n)
        }
        c = ER(d, h, c.gd, a.location.hostname, c.Ci, p, f, b);
        a = e.handle;
        h = dS(e, 9);
        c = ri(h, 3, Jn, c);
        a.call(e, c)
    }
    async function $T(a, b, c, d, e, f) {
        b = b.body;
        if (!b || !aU(b)) return [Gm()];
        e.g.za(3) >= e.i && await GR(e, 4);
        b = (b = O(d.aa, 7)) ? (b = b.match(/^[a-z]{2,3}/i)) ? b[0].toLowerCase() : "" : "";
        f.i = b;
        b = [];
        if (a.document.querySelector('script[src*="www.google.com/adsense/search/ads.js"]')) {
            var g = b.push;
            var h = new Hm;
            var k = new Fm;
            h = ri(h, 3, Im, k);
            g.call(b, h)
        }
        b.length || await jT(a, c, d, e, f);
        return b
    }

    function aU(a) {
        try {
            Ub(new ResizeObserver(() => {})), Ub(new MutationObserver(() => {}))
        } catch {
            return !1
        }
        return a.classList && void 0 !== a.classList.contains && void 0 !== a.attachShadow
    }

    function ZT(a, b) {
        if (Math.random() < a) try {
            (new XT).observe()
        } catch (c) {
            b.Ba(1161, c instanceof Error ? c : Error("Unknown error."))
        }
    };
    async function bU(a, b, c, d, e, f, g) {
        if (v(wu) && (ZT(w(ju), Xz), d.push(async () => {
                delete window.google_plmetrics
            }), v(pu))) return;
        a = a ? await cU(a, b, c, d, e, f, g) : await dU(b, c, d, e, f, g);
        a.Da.length && eU(b, c, g, a)
    }
    async function dU(a, b, c, d, e, f) {
        if ("string" !== typeof d) return {
            Ga: null,
            Da: [mn()]
        };
        d = zR(d);
        const g = oi(d);
        if (!a) return {
            Ga: g,
            Da: [Jm()]
        };
        const h = a.performance ? .now ? new IR(a.performance) : new JR,
            k = new HR(a, h),
            l = b.google_ad_client;
        if ("string" !== typeof l) return {
            Ga: g,
            Da: [ln()]
        };
        if (qc()) return {
            Ga: g,
            Da: [Gm()]
        };
        if (cf()) return {
            Ga: g,
            Da: [nn()]
        };
        await fU(a, c, u(zJ), BR(a, d, gU(b), f, "on" === b.google_adtest), l, h, k, e);
        return {
            Ga: g,
            Da: []
        }
    }
    async function cU(a, b, c, d, e, f, g) {
        const h = a.performance ? .now ? new IR(a.performance) : new JR;
        a = new HR(a, h);
        if ("string" !== typeof e) return {
            Ga: null,
            Da: [mn()]
        };
        e = zR(e);
        const k = oi(e);
        if (!b) return {
            Ga: k,
            Da: [Jm()]
        };
        const l = c.google_ad_client;
        if ("string" !== typeof l) return {
            Ga: k,
            Da: [ln()]
        };
        if (qc()) return {
            Ga: k,
            Da: [Gm()]
        };
        if (cf()) return {
            Ga: k,
            Da: [nn()]
        };
        await fU(b, d, u(zJ), BR(b, e, gU(c), g, "on" === c.google_adtest), l, h, a, f);
        return {
            Ga: k,
            Da: []
        }
    }

    function eU(a, b, c, d) {
        a = ER(new FR, !!a && 488 > wo(a), gU(b), a ? .location ? .hostname ? ? "", c, d.Ga ? ? new pi, 0, d.Da);
        c = Math.floor(20 * Ye());
        b = new In;
        b = P(b, 1, 1);
        b = P(b, 2, 0);
        c = An(c);
        d = fo();
        c = ji(c, 3, d, jh);
        b = E(b, 10, c);
        a = ri(b, 3, Jn, a);
        b = u(zJ);
        Xz.Ca(1214, xJ(b, a, Date.now()), hU)
    }
    async function fU(a, b, c, d, e, f, g, h) {
        const k = $v(a);
        k.wasReactiveAdConfigReceived[42] || (k.wasReactiveAdConfigReceived[42] = !0, await YT(a, b, d, e, [l => {
            Xz.Ca(1214, xJ(c, l, f.za(17)), hU)
        }], f, g, h))
    }

    function hU(a) {
        a.es = fo().join(",")
    }

    function gU(a) {
        a = a.google_page_url;
        return "string" === typeof a ? a : ""
    };

    function iU({
        Sf: a,
        eh: b
    }) {
        return a || ("dev" === b ? "dev" : "")
    };

    function jU(a) {
        Xz.kf(b => {
            b.shv = String(a);
            b.mjsv = iU({
                Sf: "m202401220101",
                eh: a
            });
            b.eid = uP(r)
        })
    };
    var kU = "undefined" === typeof sttc ? void 0 : sttc;

    function lU(a) {
        var b = Xz;
        try {
            return ej(a, ul), new TN(JSON.parse(a))
        } catch (c) {
            b.Ba(838, c instanceof Error ? c : Error(String(c)), void 0, d => {
                d.jspb = String(a)
            })
        }
        return new TN
    };
    const mU = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.callback({
                    nb: c ? ? void 0,
                    ld: d ? void 0 : 2
                })
            })
        },
        nU = {
            Dc: a => a.callback,
            Rb: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            wb: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    nb: b.returnValue ? ? void 0,
                    ld: b.success ? void 0 : 2
                })
            }
        };

    function oU(a) {
        let b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            bf: b.__uspapiReturn.callId
        }
    }

    function pU(a, b) {
        let c = {};
        if (cE(a.caller)) {
            var d = Mb(() => {
                b(c)
            });
            eE(a.caller, "getDataWithCallback", {
                callback: e => {
                    e.ld || (c = e.nb);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    }
    var qU = class extends T {
        constructor(a) {
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new fE(a, "__uspapiLocator", b => "function" === typeof b.__uspapi, oU);
            this.caller.A.set("getDataWithCallback", mU);
            this.caller.j.set("getDataWithCallback", nU)
        }
        i() {
            this.caller.la();
            super.i()
        }
    };

    function rU(a, b) {
        b = b && b[0];
        if (!b) return null;
        b = b.target;
        const c = b.getBoundingClientRect(),
            d = ge(a.g.da() || window);
        if (0 >= c.bottom || c.bottom > d.height || 0 >= c.right || c.left >= d.width) return null;
        var e = sU(a, b, c, a.g.g.elementsFromPoint(Rd(c.left + c.width / 2, c.left, c.right - 1), Rd(c.bottom - 1 - 2, c.top, c.bottom - 1)), 1, []),
            f = sU(a, b, c, a.g.g.elementsFromPoint(Rd(c.left + c.width / 2, c.left, c.right - 1), Rd(c.top + 2, c.top, c.bottom - 1)), 2, e.pb),
            g = sU(a, b, c, a.g.g.elementsFromPoint(Rd(c.left + 2, c.left, c.right - 1), Rd(c.top + c.height / 2,
                c.top, c.bottom - 1)), 3, [...e.pb, ...f.pb]);
        const h = sU(a, b, c, a.g.g.elementsFromPoint(Rd(c.right - 1 - 2, c.left, c.right - 1), Rd(c.top + c.height / 2, c.top, c.bottom - 1)), 4, [...e.pb, ...f.pb, ...g.pb]);
        var k = tU(a, b, c),
            l = n => bb(a.j, n.overlapType) && bb(a.l, n.overlapDepth) && bb(a.i, n.overlapDetectionPoint);
        e = Xa([...e.entries, ...f.entries, ...g.entries, ...h.entries], l);
        l = Xa(k, l);
        k = [...e, ...l];
        f = -2 > c.left || c.right > d.width + 2;
        f = 0 < k.length || f;
        g = he(a.g.g);
        const m = new kk(c.left, c.top, c.width, c.height);
        e = [...Za(e, n => new kk(n.elementRect.left,
            n.elementRect.top, n.elementRect.width, n.elementRect.height)), ...pb(Za(l, n => mk(m, n.elementRect))), ...Xa(mk(m, new kk(0, 0, d.width, d.height)), n => 0 <= n.top && n.top + n.height <= d.height)];
        return {
            entries: k,
            isOverlappingOrOutsideViewport: f,
            scrollPosition: {
                scrollX: g.x,
                scrollY: g.y
            },
            target: b,
            targetRect: c,
            viewportSize: {
                width: d.width,
                height: d.height
            },
            overlappedArea: 20 > e.length ? uU(m, e) : vU(c, e)
        }
    }

    function wU(a, b) {
        const c = a.g.da(),
            d = a.g.g;
        return new Promise((e, f) => {
            const g = c.IntersectionObserver;
            if (g)
                if (d.elementsFromPoint)
                    if (d.createNodeIterator)
                        if (d.createRange)
                            if (c.Range.prototype.getBoundingClientRect) {
                                var h = new g(k => {
                                    const l = new jl,
                                        m = il(l, () => rU(a, k));
                                    m && (l.i.length && (m.executionTime = Math.round(Number(l.i[0].duration))), h.disconnect(), e(m))
                                }, xU);
                                h.observe(b)
                            } else f(Error("5"));
            else f(Error("4"));
            else f(Error("3"));
            else f(Error("2"));
            else f(Error("1"))
        })
    }

    function sU(a, b, c, d, e, f) {
        if (0 === c.width || 0 === c.height) return {
            entries: [],
            pb: []
        };
        const g = [],
            h = [];
        for (let m = 0; m < d.length; m++) {
            const n = d[m];
            if (n === b) continue;
            if (bb(f, n)) continue;
            h.push(n);
            const p = n.getBoundingClientRect();
            if (a.g.contains(n, b)) {
                g.push(yU(a, c, n, p, 1, e));
                continue
            }
            if (a.g.contains(b, n)) {
                g.push(yU(a, c, n, p, 2, e));
                continue
            }
            a: {
                var k = a;
                var l = b;
                const z = k.g.wi(l, n);
                if (!z) {
                    k = null;
                    break a
                }
                const {
                    suspectAncestor: G,
                    Hb: F
                } = zU(k, l, z, n) || {},
                {
                    suspectAncestor: K,
                    Hb: H
                } = zU(k, n, z, l) || {};k = G && F && K && H ? F <= H ? {
                    suspectAncestor: G,
                    overlapType: AU[F]
                } : {
                    suspectAncestor: K,
                    overlapType: BU[H]
                } : G && F ? {
                    suspectAncestor: G,
                    overlapType: AU[F]
                } : K && H ? {
                    suspectAncestor: K,
                    overlapType: BU[H]
                } : null
            }
            const {
                suspectAncestor: q,
                overlapType: x
            } = k || {};
            q && x ? g.push(yU(a, c, n, p, x, e, q)) : g.push(yU(a, c, n, p, 9, e))
        }
        return {
            entries: g,
            pb: h
        }
    }

    function tU(a, b, c) {
        const d = [];
        for (b = b.parentElement; b; b = b.parentElement) {
            const f = b.getBoundingClientRect();
            if (f) {
                var e = Xe(b, a.g.da());
                e && "visible" !== e.overflow && ("auto" !== e.overflowY && "scroll" !== e.overflowY && c.bottom > f.bottom + 2 ? d.push(yU(a, c, b, f, 5, 1)) : (e = "auto" === e.overflowX || "scroll" === e.overflowX, !e && c.left < f.left - 2 ? d.push(yU(a, c, b, f, 5, 3)) : !e && c.right > f.right + 2 && d.push(yU(a, c, b, f, 5, 4))))
            }
        }
        return d
    }

    function uU(a, b) {
        if (0 === a.width || 0 === a.height || 0 === b.length) return 0;
        let c = 0;
        for (let d = 1; d < 1 << b.length; d++) {
            let e = a,
                f = 0;
            for (let g = 0; g < b.length && (!(d & 1 << g) || (f++, e = lk(e, b[g]), e)); g++);
            e && (c = 1 === f % 2 ? c + (e.width + 1) * (e.height + 1) : c - (e.width + 1) * (e.height + 1))
        }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function vU(a, b) {
        if (0 === a.width || 0 === a.height || 0 === b.length) return 0;
        let c = 0;
        for (let d = a.left; d <= a.right; d++)
            for (let e = a.top; e <= a.bottom; e++)
                for (let f = 0; f < b.length; f++)
                    if (d >= b[f].left && d <= b[f].left + b[f].width && e >= b[f].top && e <= b[f].top + b[f].height) {
                        c++;
                        break
                    }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function yU(a, b, c, d, e, f, g) {
        const h = {
            element: c,
            elementRect: d,
            overlapType: e,
            overlapDetectionPoint: f
        };
        if (bb(a.j, e) && bb(a.i, f)) {
            b = new hk(b.top, b.right - 1, b.bottom - 1, b.left);
            if ((a = CU(a, c)) && jk(b, a)) c = 4;
            else {
                a = DU(c, d);
                if (zc) {
                    e = Hk(c, "paddingLeft");
                    f = Hk(c, "paddingRight");
                    var k = Hk(c, "paddingTop"),
                        l = Hk(c, "paddingBottom");
                    e = new hk(k, f, l, e)
                } else e = Ak(c, "paddingLeft"), f = Ak(c, "paddingRight"), k = Ak(c, "paddingTop"), l = Ak(c, "paddingBottom"), e = new hk(parseFloat(k), parseFloat(f), parseFloat(l), parseFloat(e));
                jk(b, new hk(a.top +
                    e.top, a.right - e.right, a.bottom - e.bottom, a.left + e.left)) ? c = 3 : (c = DU(c, d), c = jk(b, c) ? 2 : 1)
            }
            h.overlapDepth = c
        }
        g && (h.suspectAncestor = g);
        return h
    }

    function zU(a, b, c, d) {
        const e = [];
        for (var f = b; f && f !== c; f = f.parentElement) e.unshift(f);
        c = a.g.da();
        for (f = 0; f < e.length; f++) {
            const h = e[f];
            var g = Xe(h, c);
            if (g) {
                if ("fixed" === g.position) return {
                    suspectAncestor: h,
                    Hb: 1
                };
                if ("sticky" === g.position && a.g.contains(h.parentElement, d)) return {
                    suspectAncestor: h,
                    Hb: 2
                };
                if ("absolute" === g.position) return {
                    suspectAncestor: h,
                    Hb: 3
                };
                if ("none" !== g.cssFloat) {
                    g = h === e[0];
                    const k = EU(a, e.slice(0, f), h);
                    if (g || k) return {
                        suspectAncestor: h,
                        Hb: 4
                    }
                }
            }
        }
        return (a = EU(a, e, b)) ? {
                suspectAncestor: a,
                Hb: 5
            } :
            null
    }

    function EU(a, b, c) {
        const d = c.getBoundingClientRect();
        if (!d) return null;
        for (let e = 0; e < b.length; e++) {
            const f = b[e];
            if (!a.g.contains(f, c)) continue;
            const g = f.getBoundingClientRect();
            if (!g) continue;
            const h = Xe(f, a.g.da());
            if (h && d.bottom > g.bottom + 2 && "visible" === h.overflowY) return f
        }
        return null
    }

    function CU(a, b) {
        var c = a.g.g;
        a = c.createRange();
        if (!a) return null;
        c = c.createNodeIterator(b, NodeFilter.SHOW_TEXT, {
            acceptNode: d => /^[\s\xa0]*$/.test(d.nodeValue) ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT
        });
        for (b = c.nextNode(); c.nextNode(););
        c = c.previousNode();
        if (!b || !c) return null;
        a.setStartBefore(b);
        a.setEndAfter(c);
        a = a.getBoundingClientRect();
        return 0 === a.width || 0 === a.height ? null : new hk(a.top, a.right, a.bottom, a.left)
    }

    function DU(a, b) {
        if (!zc || 9 <= Number(Mc)) {
            var c = Ak(a, "borderLeftWidth");
            d = Ak(a, "borderRightWidth");
            e = Ak(a, "borderTopWidth");
            a = Ak(a, "borderBottomWidth");
            c = new hk(parseFloat(e), parseFloat(d), parseFloat(a), parseFloat(c))
        } else {
            c = Jk(a, "borderLeft");
            var d = Jk(a, "borderRight"),
                e = Jk(a, "borderTop");
            a = Jk(a, "borderBottom");
            c = new hk(e, d, a, c)
        }
        return new hk(b.top + c.top, b.right - 1 - c.right, b.bottom - 1 - c.bottom, b.left + c.left)
    }
    class FU {
        constructor(a) {
            var b = GU;
            this.g = de(a);
            this.j = [5, 8, 9];
            this.l = [3, 4];
            this.i = b
        }
    }
    const AU = {
            [1]: 3,
            [4]: 10,
            [3]: 12,
            [2]: 4,
            [5]: 5
        },
        BU = {
            [1]: 6,
            [4]: 11,
            [3]: 13,
            [2]: 7,
            [5]: 8
        };
    Xa($e({
        Bl: 1,
        Cl: 2,
        rn: 3,
        sn: 4,
        vn: 5,
        xl: 6,
        yl: 7,
        Al: 8,
        Dm: 9,
        un: 10,
        zl: 11,
        qn: 12,
        wl: 13
    }), a => !bb([1, 2], a));
    $e({
        Jk: 1,
        Gm: 2,
        Uk: 3,
        wn: 4
    });
    const GU = $e({
            Kk: 1,
            zn: 2,
            qm: 3,
            dn: 4
        }),
        xU = {
            threshold: [0, .25, .5, .75, .95, .96, .97, .98, .99, 1]
        };

    function HU(a, b, c, d) {
        const e = new bK;
        let f = "";
        const g = k => {
            try {
                const l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                f === l.paw_id && (Tb(a, "message", g), l.error ? e.g(Error(l.error)) : e.resolve(d(l)))
            } catch (l) {}
        };
        var h = "function" === typeof a.gmaSdk ? .getQueryInfo ? a.gmaSdk : void 0;
        if (h) return Sb(a, "message", g), f = c(h), e.promise;
        c = "function" === typeof a.webkit ? .messageHandlers ? .getGmaQueryInfo ? .postMessage || "function" === typeof a.webkit ? .messageHandlers ? .getGmaSig ? .postMessage ? a.webkit.messageHandlers : void 0;
        return c ? (f = String(Math.floor(2147483647 * Ye())), Sb(a, "message", g), b(c, f), e.promise) : null
    }

    function IU(a) {
        return HU(a, (b, c) => void(b.getGmaQueryInfo ? ? b.getGmaSig) ? .postMessage(c), b => b.getQueryInfo(), b => b.signal)
    };
    const JU = (a, b) => {
        try {
            const k = void 0 === M(b, 6) ? !0 : M(b, 6);
            var c = Fj(zi(b, 2)),
                d = O(b, 3);
            a: switch (zi(b, 4)) {
                case 1:
                    var e = "pt";
                    break a;
                case 2:
                    e = "cr";
                    break a;
                default:
                    e = ""
            }
            var f = new Hj(c, d, e),
                g = C(b, Aj, 5) ? .g() ? ? "";
            f.Ac = g;
            f.g = k;
            f.win = a;
            var h = f.build();
            yj(h)
        } catch {}
    };

    function KU(a, b) {
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? JU(a, b) : Sb(a, "load", () => void JU(a, b)))
    };

    function LU(a) {
        const b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    }

    function MU(a) {
        if (a === a.top || Re(a.top)) return Promise.resolve({
            status: 4
        });
        a: {
            try {
                var b = (a.top ? .frames ? ? {}).google_ads_top_frame;
                break a
            } catch (d) {}
            b = null
        }
        if (!b) return Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && LU(a.document.referrer)) return Promise.resolve({
            status: 3
        });
        const c = new bK;
        a = new MessageChannel;
        a.port1.onmessage = d => {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                sc: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    var xl = {
        Hn: 0,
        Dn: 1,
        En: 9,
        An: 2,
        Bn: 3,
        Gn: 5,
        Fn: 7,
        Cn: 10
    };
    var NU = class extends R {},
        OU = hj(NU),
        PU = [1, 3];
    const QU = sj `https://securepubads.g.doubleclick.net/static/topics/topics_frame.html`;

    function RU(a) {
        const b = a.google_tag_topics_state ? ? (a.google_tag_topics_state = {});
        return b.messageChannelSendRequestFn ? Promise.resolve(b.messageChannelSendRequestFn) : new Promise(c => {
            function d(h) {
                return g.g(h).then(({
                    data: k
                }) => k)
            }
            const e = We("IFRAME");
            e.style.display = "none";
            e.name = "goog_topics_frame";
            e.src = ad(QU).toString();
            const f = (new URL(QU.toString())).origin,
                g = $L({
                    destination: a,
                    Na: e,
                    origin: f,
                    ke: "goog:gRpYw:doubleclick"
                });
            g.g("goog:topics:frame:handshake:ack").then(({
                data: h
            }) => {
                "goog:topics:frame:handshake:ack" ===
                h && c(d)
            });
            b.messageChannelSendRequestFn = d;
            a.document.documentElement.appendChild(e)
        })
    }

    function SU(a, b, c) {
        var d = Xz,
            e = {
                skipTopicsObservation: v(Pu)
            };
        const {
            bd: f,
            Zc: g
        } = TU(c);
        b = b.google_tag_topics_state ? ? (b.google_tag_topics_state = {});
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e.skipTopicsObservation,
            includeBuyerTopics: e.includeBuyerTopics
        }).then(h => {
            let k = g;
            if (h instanceof Uint8Array) k || (k = !(f instanceof Uint8Array && lb(h, f)));
            else if (wl()(h)) k || (k = h !== f);
            else return d.Ba(989, Error(JSON.stringify(h))), 7;
            if (k && c) try {
                var l = new NU;
                var m = Zi(l, 2, al());
                h instanceof Uint8Array ? li(m, 1, PU, Lg(h, !1, !1)) : li(m, 3, PU, dh(h));
                c.setItem("goog:cached:topics", bj(m))
            } catch {}
            return h
        }), b.getTopicsPromise = a);
        return f && !g ? Promise.resolve(f) : b.getTopicsPromise
    }

    function TU(a) {
        if (!a) return {
            bd: null,
            Zc: !0
        };
        try {
            const m = a.getItem("goog:cached:topics");
            if (!m) return {
                bd: null,
                Zc: !0
            };
            const n = OU(m);
            let p;
            const q = n.W;
            var b = mi(q, q[B], PU);
            switch (b) {
                case 0:
                    p = null;
                    break;
                case 1:
                    var c;
                    a = n;
                    var d = ni(n, PU, 1);
                    const z = a.W;
                    let G = z[B];
                    const F = Uh(z, G, d),
                        K = Lg(F, !0, !!(G & 34));
                    null != K && K !== F && Wh(z, G, d, K);
                    var e = K;
                    var f = null == e ? Xf() : e;
                    Wf(Uf);
                    var g = f.M;
                    if (null == g || Sf(g)) var h = g;
                    else {
                        if ("string" === typeof g) {
                            d = g;
                            Pf.test(d) && (d = d.replace(Pf, Rf));
                            let H;
                            H = atob(d);
                            const N = new Uint8Array(H.length);
                            for (d = 0; d < H.length; d++) N[d] = H.charCodeAt(d);
                            var k = N
                        } else k = null;
                        h = k
                    }
                    var l = h;
                    p = (c = null == l ? l : f.M = l) ? new Uint8Array(c) : Tf || (Tf = new Uint8Array(0));
                    break;
                case 3:
                    p = zi(n, ni(n, PU, 3));
                    break;
                default:
                    Oe(b, void 0)
            }
            const x = yi(n, 2) + 6048E5 < al();
            return {
                bd: p,
                Zc: x
            }
        } catch {
            return {
                bd: null,
                Zc: !0
            }
        }
    };

    function gJ() {
        return navigator.cookieDeprecationLabel ? Promise.race([navigator.cookieDeprecationLabel.getValue().then(a => ({
            status: 1,
            label: a
        })).catch(() => ({
            status: 2
        })), Cf(w(Gu), {
            status: 5
        })]) : Promise.resolve({
            status: 3
        })
    }

    function UU(a) {
        return v(Hu) && a ? !!a.match(Xb(Fu)) : !1
    }

    function VU(a) {
        a = a.innerInsElement;
        if (!a) throw Error("no_wrapper_element_in_loader_provided_slot");
        return a
    }
    async function WU({
        qa: a,
        ra: b,
        ub: c,
        slot: d
    }) {
        const e = d.vars,
            f = Ue(d.pubWin),
            g = VU(d),
            h = new KN({
                K: f,
                pubWin: d.pubWin,
                D: e,
                qa: a,
                ra: b,
                ub: c,
                ha: g
            });
        h.G = Date.now();
        gk(1, [h.D]);
        Zz(1032, () => {
            if (f && v(av)) {
                var k = h.D;
                Z(VI(), 32, !1) || ($I(VI(), 32, !0), DP(f, "sd" === k.google_loader_used ? 5 : 9))
            }
        });
        try {
            await XU(h)
        } catch (k) {
            if (!bA(159, k)) throw k;
        }
        Zz(639, () => {
            var k;
            var l = h.D;
            (k = h.K) && 1 === l.google_responsive_auto_format && !0 === l.google_full_width_responsive_allowed ? (l = (l = k.document.getElementById(l.google_async_iframe_id)) ? pe(l,
                "INS", "adsbygoogle") : null) ? (k = new JN(k, l), k.g = r.setInterval(Ia(k.i, k), 500), k.i(), k = !0) : k = !1 : k = !1;
            return k
        });
        f ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/) ? cA(1008, YU(d.pubWin, f, e, h.j, bj(ZU()), h.g, O(a, 8)), hU) : sN(h.pubWin, "affa", k => {
            k = YU(d.pubWin, f, e, h.j, k.config, h.g, O(a, 8));
            Xz.Ca(1008, k, hU);
            return !0
        });
        return h
    }
    async function YU(a, b, c, d, e, f, g) {
        await bU(v(ku) ? a : null, b, c, d, e, f, g)
    }

    function ZU() {
        const a = new yR;
        if (!v(nu)) {
            var b = new RN;
            b = Wi(b, 5, !0);
            E(a, 2, b)
        }
        if (!v(fu)) {
            b = new or;
            b = Vh(b, 2, dh(4));
            b = Vh(b, 8, dh(1));
            var c = new qq;
            c = $i(c, 7, "#dpId");
            b = E(b, 1, c);
            ti(a, 3, or, b)
        }
        return a
    }

    function XU(a) {
        if (/_sdo/.test(a.D.google_ad_format)) return Promise.resolve();
        var b = a.pubWin;
        sP(13, b);
        sP(11, b);
        b = VI();
        var c = Z(b, 23, !1);
        c || $I(b, 23, !0);
        if (!c) {
            b = a.D.google_ad_client;
            c = a.qa;
            b = void 0 !== Yh(c, RN, ni(c, UN, 13)) ? C(Si(c, RN, 13, UN), $J, 2) : lb(Si(c, SN, 14, UN) ? .g() ? ? [], [b]) ? C(C(Si(c, SN, 14, UN), RN, 2), $J, 2) : new $J;
            b = new aK(a.pubWin, a.D.google_ad_client, b, M(a.qa, 6), M(a.qa, 20));
            b.i = !0;
            c = C(b.B, pr, 1);
            if (b.i) {
                var d = b.g;
                if (b.j && !SD(c)) {
                    var e = new SJ;
                    e = Vh(e, 1, dh(1))
                } else e = null;
                if (e) {
                    e = bj(e);
                    try {
                        d.localStorage.setItem("google_auto_fc_cmp_setting",
                            e)
                    } catch (f) {}
                }
            }
            d = SD(c) && (b.j || b.A);
            c && d && TD(new UD(b.g, new AE(b.g, b.l), c, new hw(b.g)))
        }
        b = !ok() && !pc();
        return !b || b && !$U(a) ? aV(a) : Promise.resolve()
    }

    function bV(a, b, c = !1) {
        b = hM(a.K, b);
        const d = sk() || dM(a.pubWin.top);
        if (!b || -12245933 === b.y || -12245933 === d.width || -12245933 === d.height || !d.height) return 0;
        let e = 0;
        try {
            const f = a.pubWin.top;
            e = fM(f.document, f).y
        } catch (f) {
            return 0
        }
        a = e + d.height;
        return b.y < e ? c ? 0 : (e - b.y) / d.height : b.y > a ? (b.y - a) / d.height : 0
    }

    function $U(a) {
        return cV(a) || dV(a)
    }

    function cV(a) {
        const b = a.D;
        if (!b.google_pause_ad_requests) return !1;
        const c = r.setTimeout(() => {
                aA("abg:cmppar", {
                    client: a.D.google_ad_client,
                    url: a.D.google_page_url
                })
            }, 1E4),
            d = $z(450, () => {
                b.google_pause_ad_requests = !1;
                r.clearTimeout(c);
                a.pubWin.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
                if (!$U(a)) {
                    const e = aV(a);
                    Xz.Ca(1222, e)
                }
            });
        a.pubWin.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
        return !0
    }

    function dV(a) {
        const b = a.pubWin.document,
            c = a.ha;
        if (3 === KM(b)) return NM($z(332, () => {
            if (!eV(a, fV().visible, c)) {
                const g = aV(a);
                Xz.Ca(1222, g)
            }
        }), b), !0;
        const d = fV();
        if (0 > d.hidden && 0 > d.visible) return !1;
        const e = LM(b);
        if (!e) return !1;
        if (!MM(b)) return eV(a, d.visible, c);
        if (bV(a, c) <= d.hidden) return !1;
        let f = $z(332, () => {
            if (!MM(b) && f) {
                Tb(b, e, f);
                if (!eV(a, d.visible, c)) {
                    const g = aV(a);
                    Xz.Ca(1222, g)
                }
                f = null
            }
        });
        return Sb(b, e, f)
    }

    function fV() {
        const a = {
            hidden: 0,
            visible: 3
        };
        r.IntersectionObserver || (a.visible = -1);
        te() && (a.visible *= 2);
        return a
    }

    function eV(a, b, c) {
        if (!c || 0 > b) return !1;
        var d = a.D;
        if (!Co(d.google_reactive_ad_format) && (dN(d) || d.google_reactive_ads_config) || !gM(c) || bV(a, c) <= b) return !1;
        var e = VI(),
            f = Z(e, 8, {});
        e = Z(e, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        const g = !!a.pubWin.google_apltlad;
        if (!f[d] && !e[d] && !g) return !1;
        f = new Promise(h => {
            const k = new r.IntersectionObserver((l, m) => {
                Ua(l, n => {
                    0 >= n.intersectionRatio || (m.unobserve(n.target), h(void 0))
                })
            }, {
                rootMargin: `${100*b}%`
            });
            a.F = k;
            k.observe(c)
        });
        e = new Promise(h => {
            c.addEventListener("adsbygoogle-close-to-visible-event",
                () => {
                    h(void 0)
                })
        });
        ka(Promise, "any").call(Promise, [f, e]).then(() => {
            Zz(294, () => {
                const h = aV(a);
                Xz.Ca(1222, h)
            })
        });
        return !0
    }

    function aV(a) {
        Zz(326, () => {
            if (1 === Qk(a.D)) {
                var c = v(bv),
                    d = c || v($u),
                    e = a.pubWin;
                if (d && e === a.K) {
                    var f = new Uj;
                    d = new Vj;
                    var g = f.setCorrelator(Af(a.pubWin));
                    var h = uP(a.pubWin);
                    g = aj(g, 5, h);
                    Q(g, 2, 1);
                    f = E(d, 1, f);
                    g = new Tj;
                    g = Wi(g, 10, !0);
                    h = v(Vu);
                    g = Wi(g, 8, h);
                    h = v(Wu);
                    g = Wi(g, 12, h);
                    h = v(Zu);
                    g = Wi(g, 7, h);
                    h = v(Yu);
                    g = Wi(g, 13, h);
                    E(f, 2, g);
                    e.google_rum_config = d.toJSON();
                    Ve(e.document, M(a.qa, 9) && c ? a.ra.mj : a.ra.nj)
                } else hl(Yz)
            }
        });
        a.D.google_ad_channel = gV(a, a.D.google_ad_channel);
        a.D.google_tag_partner = hV(a, a.D.google_tag_partner);
        iV(a);
        const b = a.D.google_start_time;
        "number" === typeof b && (lo = b, a.D.google_start_time = null);
        cM(a);
        a.K && hN(a.K, Zc(a.ra.fi, fK()));
        cJ() && qK({
            win: a.pubWin,
            webPropertyCode: a.D.google_ad_client,
            jb: Zc(a.ra.jb, fK())
        });
        dN(a.D) && (oK() && (a.D.google_adtest = a.D.google_adtest || "on"), a.D.google_pgb_reactive = a.D.google_pgb_reactive || 3);
        return jV(a)
    }

    function gV(a, b) {
        return (b ? [b] : []).concat(QI(a.pubWin).ad_channels || []).join("+")
    }

    function hV(a, b) {
        return (b ? [b] : []).concat(QI(a.pubWin).tag_partners || []).join("+")
    }

    function kV(a) {
        const b = We("IFRAME");
        Ze(a, (c, d) => {
            null != c && b.setAttribute(d, c)
        });
        return b
    }

    function lV(a, b, c) {
        return 9 === a.D.google_reactive_ad_format && pe(a.ha, null, "fsi_container") ? (a.ha.appendChild(b), Promise.resolve(b)) : oN(a.ra.Vg, 525, d => {
            a.ha.appendChild(b);
            d.createAdSlot(a.K, a.D, b, a.ha.parentElement, Xj(c, a.pubWin));
            return b
        })
    }

    function mV(a, b, c, d) {
        u(zJ).gd = a.D.google_page_url;
        KU(a.pubWin, Dj(Cj(Q(Q(Bj(new Ej, zj(new Aj, String(Af(a.pubWin)))), 4, 1), 2, 1), O(a.qa, 2)), M(d, 5)));
        const e = a.K;
        a.D.google_acr && a.D.google_acr(b);
        Sb(b, "load", () => {
            b && b.setAttribute("data-load-complete", !0);
            const f = e ? QI(e).enable_overlap_observer || !1 : !1;
            (a.D.ovlp || f) && e && e === a.pubWin && nV(e, a, a.ha, b)
        });
        d = f => {
            f && a.j.push(() => {
                f.la()
            })
        };
        oV(a, b);
        pV(a, b);
        !e || dN(a.D) && !qN(a.D) || (d(new QO(e, b, a.ha)), d(new hO(a, b)), d(e.IntersectionObserver ? null : new jO(e, b, a.ha)));
        e && (d(bO(e, b, a.g)), a.j.push(DN(e, a.D)), u(IN).L(e), a.j.push(PN(e, a.ha, b)));
        b && b.setAttribute("data-google-container-id", c);
        c = a.D.iaaso;
        if (null != c) {
            d = a.ha;
            const f = d.parentElement;
            (f && rv.test(f.className) ? f : d).setAttribute("data-auto-ad-size", c)
        }
        c = a.ha;
        c.setAttribute("tabindex", "0");
        c.setAttribute("title", "Advertisement");
        c.setAttribute("aria-label", "Advertisement");
        qV(a)
    }

    function oV(a, b) {
        const c = a.pubWin,
            d = a.D.google_ad_client,
            e = bJ();
        let f = null;
        const g = rN(c, "pvt", (h, k) => {
            "string" === typeof h.token && k.source === b.contentWindow && (f = h.token, g(), e[d] = e[d] || [], e[d].push(f), 100 < e[d].length && e[d].shift())
        });
        a.j.push(g)
    }

    function rV(a, b) {
        var c = iM(a, "__gpi_opt_out", b.g);
        c && (c = Mj(Lj(Kj(Ij(c), 2147483647), "/"), b.pubWin.location.hostname), jM(a, "__gpi_opt_out", c, b.g))
    }

    function pV(a, b) {
        const c = rN(a.pubWin, "gpi-uoo", (d, e) => {
            if (e.source === b.contentWindow) {
                e = Mj(Lj(Kj(Ij(d.userOptOut ? "1" : "0"), 2147483647), "/"), a.pubWin.location.hostname);
                var f = new mM(a.pubWin);
                jM(f, "__gpi_opt_out", e, a.g);
                if (d.userOptOut || d.clearAdsData) kM(f, "__gads", a.g), kM(f, "__gpi", a.g)
            }
        });
        a.j.push(c)
    }

    function qV(a) {
        const b = ok(a.pubWin);
        if (b)
            if ("AMP-STICKY-AD" === b.container) {
                const c = d => {
                    "fill_sticky" === d.data && b.renderStart && b.renderStart()
                };
                Sb(a.pubWin, "message", Xz.Oa(616, c));
                a.j.push(() => {
                    Tb(a.pubWin, "message", c)
                })
            } else b.renderStart && b.renderStart()
    }

    function nV(a, b, c, d) {
        wU(new FU(a), c).then(e => {
            gk(8, [e]);
            return e
        }).then(e => {
            const f = c.parentElement;
            (f && rv.test(f.className) ? f : c).setAttribute("data-overlap-observer-io", e.isOverlappingOrOutsideViewport);
            return e
        }).then(e => {
            const f = b.D.armr || "",
                g = e.executionTime || "",
                h = null == b.D.iaaso ? "" : Number(b.D.iaaso),
                k = Number(e.isOverlappingOrOutsideViewport),
                l = Za(e.entries, G => `${G.overlapType}:${G.overlapDepth}:${G.overlapDetectionPoint}`),
                m = Number(e.overlappedArea.toFixed(2)),
                n = d.dataset.googleQueryId || "",
                p =
                m * e.targetRect.width * e.targetRect.height,
                q = `${e.scrollPosition.scrollX},${e.scrollPosition.scrollY}`,
                x = Rk(e.target),
                z = [e.targetRect.left, e.targetRect.top, e.targetRect.right, e.targetRect.bottom].join();
            e = `${e.viewportSize.width}x${e.viewportSize.height}`;
            aA("ovlp", {
                adf: b.D.google_ad_dom_fingerprint,
                armr: f,
                client: b.D.google_ad_client,
                eid: uP(b.D),
                et: g,
                fwrattr: b.D.google_full_width_responsive,
                iaaso: h,
                io: k,
                saldr: b.D.google_loader_used,
                oa: m,
                oe: l.join(","),
                qid: n,
                rafmt: b.D.google_responsive_auto_format,
                roa: p,
                slot: b.D.google_ad_slot,
                sp: q,
                tgt: x,
                tr: z,
                url: b.D.google_page_url,
                vp: e,
                pvc: Af(a)
            }, 1)
        }).catch(e => {
            gk(8, ["Error:", e.message, c]);
            aA("ovlp-err", {
                err: e.message
            }, 1)
        })
    }

    function sV(a, b) {
        b.allow = b.allow && 0 < b.allow.length ? b.allow + ("; " + a) : a
    }

    function tV(a, b, c) {
        var d = a.D,
            e = d.google_async_iframe_id;
        const f = d.google_ad_width,
            g = d.google_ad_height,
            h = uN(d);
        e = {
            id: e,
            name: e
        };
        lP("browsing-topics", a.pubWin.document) && uV(a) && !v(Lu) && !UU(a.A ? .label) && (e.browsingTopics = "true");
        e.style = h ? [`width:${f}px !IMPORTANT`, `height:${g}px !IMPORTANT`].join(";") : "left:0;position:absolute;top:0;border:0;" + `width:${f}px;` + `height:${g}px;`;
        var k = lf();
        k["allow-top-navigation-by-user-activation"] && k["allow-popups-to-escape-sandbox"] && (v(Ft) && h || (k = "=" + encodeURIComponent("1"),
            b = we(b, "fsb" + k)), e.sandbox = kf().join(" "));
        !1 === d.google_video_play_muted && sV("autoplay", e);
        k = b;
        61440 < k.length && (k = k.substring(0, 61432), k = k.replace(/%\w?$/, ""), k = k.replace(/&[^=]*=?$/, ""), k += "&trunc=1");
        if (k !== b) {
            let l = b.lastIndexOf("&", 61432); - 1 === l && (l = b.lastIndexOf("?", 61432));
            aA("trn", {
                ol: b.length,
                tr: -1 === l ? "" : b.substring(l + 1),
                url: b
            }, .01)
        }
        b = k;
        null != f && (e.width = String(f));
        null != g && (e.height = String(g));
        e.frameborder = "0";
        e.marginwidth = "0";
        e.marginheight = "0";
        e.vspace = "0";
        e.hspace = "0";
        e.allowtransparency =
            "true";
        e.scrolling = "no";
        d.dash && (e.srcdoc = d.dash);
        a.pubWin.document.featurePolicy ? .features().includes("attribution-reporting") && sV("attribution-reporting", e);
        v(Su) && (d = a.pubWin, void 0 !== d.credentialless && (v(Tu) || d.crossOriginIsolated) && (e.credentialless = "true"));
        if (h) e.src = b, e = kV(e), a = lV(a, e, c);
        else {
            c = {};
            c.dtd = NN((new Date).getTime(), lo);
            c = Mk(c, b);
            e.src = c;
            c = a.pubWin;
            c = c == c.top;
            e = kV(e);
            c && a.j.push(uk(a.pubWin, e));
            a.ha.style.visibility = "visible";
            for (a = a.ha; c = a.firstChild;) a.removeChild(c);
            a.appendChild(e);
            a = Promise.resolve(e)
        }
        return a
    }
    async function vV(a) {
        var b = a.D,
            c = a.pubWin;
        const d = a.g;
        M(d, 5) && rV(new mM(a.pubWin), a);
        var e = Xj(d, a.pubWin);
        if (!M(d, 5)) return aA("afc_noc_req", {}, w(bt)), Promise.resolve();
        v(Eu) && (a.A = await fJ());
        if (!v(Nu)) {
            var f = lP("shared-storage", a.pubWin.document),
                g = lP("browsing-topics", a.pubWin.document);
            if (f || g) try {
                a.B = RU(a.pubWin)
            } catch (h) {
                bA(984, h)
            }
        }
        v(Us) || qM(d, a.pubWin, a.D.google_ad_client);
        tP(a.pubWin, d);
        if (f = a.D.google_reactive_ads_config) nN(a.K, f), vN(f, a, Xj(d)), f = f.page_level_pubvars, za(f) && Uc(a.D, f);
        f = lP("shared-storage",
            a.pubWin.document);
        a.B && M(d, 5) && f && !v(Au) && !Z(VI(), 34, !1) && ($I(VI(), 34, !0), f = a.B.then(h => {
            h({
                message: "goog:spam:client_age",
                pvsid: Af(a.pubWin),
                useObfuscatedKey: v(Bu)
            })
        }), Xz.Ca(1069, f));
        if (lP("browsing-topics", a.pubWin.document) && a.B && !v(Mu) && !UU(a.A ? .label))
            if (uV(a)) {
                a.l = 1;
                const h = Xj(a.g, a.pubWin);
                f = a.B.then(async k => {
                    await SU(k, a.pubWin, h).then(l => {
                        a.l = l
                    })
                });
                v(Ou) && (g = w(Qu), 0 < g ? await Promise.race([f, Cf(g)]) : await f)
            } else a.l = 5;
        f = "";
        uN(b) ? (e = a.ra.Ij, f = Xb(Nt), "inhead" === f ? e = a.ra.Gj : "nohtml" === f && (e =
            a.ra.Hj), v(Et) && (e = Zc(e, {
            hello: "world"
        })), f = e.toString() + "#" + (encodeURIComponent("RS-" + b.google_reactive_sra_index + "-") + "&" + Lk({
            adk: b.google_ad_unit_key,
            client: b.google_ad_client,
            fa: b.google_reactive_ad_format
        })), RP(b, VI()), wV(b)) : (5 === b.google_pgb_reactive && b.google_reactive_ads_config || !eN(b) || cN(c, b, e)) && wV(b) && (f = IP(a, d));
        gk(2, [b, f]);
        if (!f) return Promise.resolve();
        b.google_async_iframe_id || Pk(c);
        e = Qk(b);
        b = a.pubWin === a.K ? "a!" + e.toString(36) : `${e.toString(36)}.${Math.floor(2147483648*Math.random()).toString(36)+ 
Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)}`;
        c = 0 < bV(a, a.ha, !0);
        e = {
            ifi: e,
            uci: b
        };
        c && (c = VI(), e.btvi = Z(c, 21, 1), aJ(c, 21));
        f = Mk(e, f);
        c = tV(a, f, d);
        a.D.rpe && OO(a.pubWin, a.ha, {
            height: a.D.google_ad_height,
            qf: "force",
            Tc: !0,
            ff: !0,
            Yd: a.D.google_ad_client
        });
        c = await c;
        try {
            mV(a, c, b, d)
        } catch (h) {
            bA(223, h)
        }
    }

    function xV(a) {
        const b = new qU(a);
        return new Promise(c => {
            pU(b, d => {
                d && "string" === typeof d.uspString ? c(d.uspString) : c(null)
            })
        })
    }

    function yV(a) {
        var b = mf(r.top, "googlefcPresent");
        r.googlefc && !b && aA("adsense_fc_has_namespace_but_no_iframes", {
            publisherId: a
        }, 1)
    }

    function zV(a, b, c) {
        var d = c.Bj,
            e = c.uspString;
        c = c.Di;
        d ? LN(a, d, b) : v(Cu) || VJ(a, !0);
        e && (b = $i(a, 1, e), e = e.toUpperCase(), 4 == e.length && (-1 == e.indexOf("-") || "---" === e.substring(1)) && "1" <= e[0] && "9" >= e[0] && tK.hasOwnProperty(e[1]) && tK.hasOwnProperty(e[2]) && tK.hasOwnProperty(e[3]) ? (d = new sK, d = Yi(d, 1, parseInt(e[0], 10)), d = Q(d, 2, tK[e[1]]), d = Q(d, 3, tK[e[2]]), e = Q(d, 4, tK[e[3]])) : e = null, e = 2 === e ? .Ai(), Vi(b, 13, e));
        c && EM(a, c)
    }

    function AV(a) {
        const b = w($s);
        if (0 >= b) return null;
        const c = al(),
            d = IU(a.pubWin);
        if (!d) return null;
        a.C = "0";
        return Promise.race([d, Cf(b, "0")]).then(e => {
            aA("adsense_paw", {
                time: al() - c
            });
            1E4 < e ? .length ? bA(809, Error(`ML:${e.length}`)) : a.C = e
        }).catch(e => {
            bA(809, e)
        })
    }

    function BV(a) {
        const b = al();
        return Promise.race([Zz(832, () => MU(a)), Cf(200)]).then(c => {
            aA("afc_etu", {
                etus: c ? .status ? ? 100,
                sig: al() - b,
                tms: 200
            });
            return c ? .sc
        })
    }
    async function CV(a) {
        const b = AV(a),
            c = Zz(868, () => BV(a.pubWin));
        GL(a.pubWin);
        yV(a.D.google_ad_client);
        var d = new mE(a.pubWin);
        await (jE(d, ".google.cn" === O(a.qa, 8)) ? kE(d) : Promise.resolve(null));
        let e;
        a.g = new WJ;
        v(Cu) && (e = M(a.qa, 6), VJ(a.g, !e));
        d = [MN(a), xV(a.pubWin), v(Ws) ? FM(a) : null];
        d = await Promise.all(d);
        zV(a.g, e, {
            Bj: d[0],
            uspString: d[1],
            Di: d[2]
        });
        await b;
        a.sc = await c || "";
        await vV(a)
    }

    function uV(a) {
        const b = a.g;
        a = a.D;
        return !a.google_restrict_data_processing && 1 !== a.google_tag_for_under_age_of_consent && 1 !== a.google_tag_for_child_directed_treatment && !!M(b, 5) && !b.g() && !dJ() && !M(b, 9) && !M(b, 13) && (!v(Ws) || !M(b, 12)) && ("string" !== typeof a.google_privacy_treatments || !a.google_privacy_treatments.split(",").includes("disablePersonalization"))
    }

    function jV(a) {
        Df(a.pubWin) !== a.pubWin && (a.i |= 4);
        3 === KM(a.pubWin.document) && (a.i |= 32);
        var b;
        if (b = a.K) {
            b = a.K;
            const c = wo(b);
            b = !(Ao(b).scrollWidth <= c)
        }
        b && (a.i |= 1024);
        a.pubWin.Prototype ? .Version && (a.i |= 16384);
        a.D.google_loader_features_used && (a.i |= a.D.google_loader_features_used);
        return CV(a)
    }

    function wV(a) {
        const b = VI(),
            c = a.google_ad_section;
        dN(a) && aJ(b, 15);
        if (Tk(a)) {
            if (100 < aJ(b, 5)) return !1
        } else if (100 < aJ(b, 6) - Z(b, 15, 0) && "" === c) return !1;
        return !0
    }

    function iV(a) {
        const b = a.K;
        if (b && !QI(b).ads_density_stats_processed && !ok(b) && (QI(b).ads_density_stats_processed = !0, v(Jt) || .01 > Ye())) {
            const c = () => {
                if (b) {
                    var d = FH(AH(b), a.D.google_ad_client, b.location.hostname, uP(a.D).split(","));
                    aA("ama_stats", d, 1)
                }
            };
            Bf(b, () => {
                r.setTimeout(c, 1E3)
            })
        }
    };
    (function(a, b, c) {
        Zz(843, () => {
            if (!r.google_sa_impl) {
                var d = new $n(b);
                try {
                    Vg(k => {
                        var l = new Pn;
                        var m = new On;
                        try {
                            var n = Af(window);
                            P(m, 1, n)
                        } catch (z) {}
                        try {
                            var p = fo();
                            ji(m, 2, p, fh)
                        } catch (z) {}
                        try {
                            aj(m, 3, window.document.URL)
                        } catch (z) {}
                        l = E(l, 2, m);
                        m = new Nn;
                        m = Q(m, 1, 1192);
                        try {
                            var q = ul(k ? .name) ? k.name : "Unknown error";
                            aj(m, 2, q)
                        } catch (z) {}
                        try {
                            var x = ul(k ? .message) ? k.message : `Caught ${k}`;
                            aj(m, 3, x)
                        } catch (z) {}
                        try {
                            const z = ul(k ? .stack) ? k.stack : Error().stack;
                            z && ji(m, 4, z.split(/\n\s*/), sh)
                        } catch (z) {}
                        k = E(l, 1, m);
                        q = new Mn;
                        try {
                            aj(q,
                                1, "m202401220101")
                        } catch {}
                        ri(k, 6, Qn, q);
                        P(k, 5, 1);
                        Sn(d, k)
                    })
                } catch (k) {}
                var e = lU(a);
                jU(O(e, 2));
                XN(M(e, 6));
                gk(16, [3, e.toJSON()]);
                var f = iU({
                        Sf: b,
                        eh: O(e, 2)
                    }),
                    g = c(f, e);
                r.google_sa_impl = k => WU({
                    qa: e,
                    ra: g,
                    ub: f,
                    slot: k
                });
                qP(kP(r));
                r.google_process_slots ? .();
                var h = (r.Prototype || {}).Version;
                null != h && aA("prtpjs", {
                    version: h
                })
            }
        })
    })(kU, "m202401220101", function(a, b) {
        const c = 2012 < xi(b, 1) ? `_fy${xi(b,1)}` : "",
            d = O(b, 3);
        b = O(b, 2);
        return {
            nj: sj `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/rum${c}.js`,
            mj: sj `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/rum_debug${c}.js`,
            Vg: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}reactive_library${c}.js`,
            fi: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}debug_card_library${c}.js`,
            Ij: sj `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup${c}.html`,
            Gj: sj `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup_inhead${c}.html`,
            Hj: sj `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup_nohtml${c}.html`,
            eo: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}slotcar_library${c}.js`,
            Tn: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/gallerify${c}.js`,
            jb: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}autogames${c}.js`
        }
    });
}).call(this, "[2021,\"r20240118\",\"r20110914\",null,null,null,null,\".google.bi\",null,null,null,null,null,null,null,null,null,-1,[95320239,44759876,44759927,44759837]]");